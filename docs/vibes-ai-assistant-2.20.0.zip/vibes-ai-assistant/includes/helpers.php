<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ───────── settings ───────── */

function vai_settings() {
	$s = get_option( 'vai_settings', array() );
	return is_array( $s ) ? $s : array();
}

function vai_opt( $key, $default = '' ) {
	$s = vai_settings();
	if ( array_key_exists( $key, $s ) && $s[ $key ] !== '' && $s[ $key ] !== null ) {
		return $s[ $key ];
	}
	return $default;
}

function vai_update_settings( array $patch ) {
	$s = vai_settings();
	foreach ( $patch as $k => $v ) {
		$s[ $k ] = $v;
	}
	update_option( 'vai_settings', $s, false );
}

function vai_mode() {
	return vai_opt( 'mode', 'site' ) === 'hub' ? 'hub' : 'site';
}

function vai_is_hub() {
	return vai_mode() === 'hub';
}

/** Default hub-level settings (editable from the hub settings page). */
function vai_defaults() {
	return array(
		'bot_name'          => 'المستشار',
		'bot_subtitle'      => 'نادي المستثمرين — شركة المجتمع الافتراضي للاستثمار',
		'avatar_url'        => 'https://vcmem.com/wp-content/uploads/2025/11/لوجو-نادي-المستثمرين-جوولد-شفاف.png',
		'primary_color'     => '#B8962E',
		'welcome'           => "حياك الله 🌹 معك مساعد Vibes Ventures ونادي المستثمرين.\nاسألني عن أي شيء في المنظومة، وأقدر أفتح لك الصفحات وأعبّي لك النماذج وأرتّب لك الخطوة التالية. وش أقدر أخدمك فيه؟",
		'menu'              => "الانضمام إلى النادي\nعضوية النادي ومزاياها\nعندي مشروع وأبي أعرضه\nشركات المنظومة\nخدمة اصنع ملتقاك\nإعداد Pitch Deck\nبنك المشاريع\nالتواصل مع الإدارة",
		'gate_free'         => 1,
		'gate_identified'   => 6,
		'member_daily'      => 2500,
		'rate_per_hour'     => 20,
		'site_daily_cap'    => 1500,
		'human_pause_min'   => 20,
		'reply_timeout'     => 180,
		'launcher_style'    => 'whatsapp',
		'extra_instructions' => '',
		'auto_open'         => 0,
		'voice_enabled'     => 1,
		'openai_key'        => '',
		'nav_mode'          => 'button',
		'account_pill'      => 1,
		'account_bar2'      => 0,
		'mobile_mode'       => 'compact',
		'pill_position'     => 'opposite',
		'notify_registration' => 1,
		'allowed_email_domains' => '*',
		'instant_lead_types' => 'partner, payment, cooperation',
		'digest_enabled'    => 1,
		'digest_hours'      => 12,
		'trial_days'        => 30,
		'member_days'       => 360,
		'member_expired_text' => "انتهت عضويتك السنوية 🙏 كان شرفًا لنا مرافقتك — جدّدها الآن لتستمر مزاياك: أولوية العرض، الخصومات، رصيد بنك المشاريع، والملتقيات.",
		'nudge_every'       => 8,
		'account_gate_text' => "أنشئ حسابك في ثوانٍ لتكمل الاشتراك في عضوية النادي السنوية — بنفس الحساب تدخل على كل مواقع المنظومة:",
		'trial_expired_text' => "انتهت عضويتك التجريبية 🙏 استمتعت معك، وللأسف ما نقدر نكمل بدون اشتراك — اشترك في عضوية النادي السنوية وتفتح لك كل المزايا: تقييم مشروعك خلال 10 أيام عمل، خصم 50% على الخدمات، رصيد بنك المشاريع، وأكثر.",
		'welcome_email_subject' => 'أهلًا بك في نادي المستثمرين يا {name} — خطوة واحدة لتفعيل عضويتك',
		'welcome_email'     => "مرحبًا {name}،\n\nتم إنشاء حسابك في Vibes Ventures ونادي المستثمرين. بيانات الدخول: البريد {email} أو الجوال {phone} مع كلمة المرور التي اخترتها — وتعمل على كل مواقع المنظومة (vcmem.com، vibesholding.com، pvspaces.com، wdeny.com وغيرها) من أيقونة المساعد.\n\nلتفعيل عضويتك السنوية ادفع عبر هذا الرابط: {pay_url}\nوبعد الدفع يفعّل الفريق عضويتك فورًا، ويتحول المساعد إلى مستشارك الخاص على مدار الساعة بذاكرة كاملة، مع خصم 50% على كل خدمات المنظومة (البودكاست، اصنع ملتقاك، Pitch Deck، المواقع والتطبيقات، المسرح وغرفة الاجتماعات) ورصيد 5 مشاريع في بنك المشاريع.\n\nللتواصل مع الإدارة: {mgmt}\n\nنادي المستثمرين — Vibes Ventures",
		'edu_topics'        => '',
		'price_sheet'       => "أسعار استوديو بودكاست الملتقى (غير شاملة الضريبة) — بعضوية النادي خصم 50% على كل باقة طوال السنة بلا حدود استخدام:\nBASIC STUDIO (إيجار الاستوديو ومعدات وكروما — تصوّر بنفسك مع طاقمك، بدون مصوّر ومخرج): ستوديو فقط 800/الساعة | كروما + معدات 1,200/الساعة | كروما + معدات + مونتاج (الأكثر طلبًا) 2,500/الساعة.\nFULL PODCAST PRODUCTION (طاقم كامل: 3 كاميرات سينمائية، مصوّر محترف، مخرج، إضاءة وصوت احترافي، استشارة قبل التصوير): تصوير بالمعدات فقط بدون مونتاج 1,600/الساعة | كروما بدون مونتاج 2,400/الساعة | تصوير + مونتاج احترافي بدون كروما 3,000/الساعة | تصوير + كروما + مونتاج (الأكثر طلبًا) 4,000/الساعة.\nFULL PACKAGE (تصوير + مونتاج + حزمة ريلز، حلقات وريلز جاهزة للنشر — عرض سبتمبر حتى 30 سبتمبر): بكج الساعتين 5,120 بدل 8,000 (12 ريلز + 2 برومو + 2 بوستر) | بكج 5 ساعات (الأكثر طلبًا) 10,600 بدل 20,000 (30 ريلز + 5 برومو + 5 بوستر) | بكج 10 ساعات (الأشمل) 18,400 بدل 40,000 (60 ريلز + 10 برومو + 10 بوستر).\nTHEATER EXPERIENCE (مسرح فاخر حتى 80 شخصًا، صوت وشاشات وإضاءة احترافية، منطقة استقبال): المسرح فقط 2,000/الساعة | المسرح + ضيافة 2,500/الساعة | المسرح + ضيافة + تصوير ومخرج 3,500/الساعة | الباقة الشاملة مع مونتاج كامل (الأكثر طلبًا) 5,000/الساعة.\nOUTDOOR SERVICES (أفلام وثائقية، برامج، تغطيات، تصوير فوتوغرافي، ريلز، مونتاج وجرافيكس خارج الاستوديو): تبدأ من 15,000 للساعتين شامل التصوير والمونتاج ونقل معدات الإضاءة، والتكلفة النهائية حسب الخدمة والمكان.\nADD-ONS (تُحتسب فوق الباقة): حزمة الريلز (6 ريلز + 2 برومو + بوستر) +1,000 | إضافة مذيع +3,000 | النشر على 10 منصات +5,000 | الظهور كضيف لدى الملتقى (إخراج + مونتاج + تصوير + نشر + إعلانات) +8,000 | ترجمة احترافية على الشاشة تبدأ من +1,500/الساعة.\nالحجز والتفاصيل: https://almoltaqapodcast.com/studio/ — واتساب الاستوديو: +966538461110.",
		'links'             => "تصفح جميع مشاريع Vibes Ventures | https://vibesholding.com/ | لما يبغى يشوف مشاريع وشركات Vibes Ventures أو يرجع لموقع فايبز | Vibes Ventures, فايبز القابضة, مشاريع فايبز, شركات فايبز, vibesholding\nالرئيسية — نادي المستثمرين vcmem | https://vcmem.com/ | لما يقول رجّعني/نرجع للنادي أو لموقع vcmem | موقع النادي, vcmem\nبنك المشاريع | https://vibesholding.com/pb | لما يبغى يتصفح مشاريع رواد الأعمال المعروضة | بنك المشاريع, مشاريع رواد\nالمشاريع الذهبية | https://vibesholding.com/gp/ | لما يسأل عن شركات Vibes Ventures الذهبية | المشاريع الذهبية, مشروع ذهبي, الشركات الذهبية\nخدمة اصنع ملتقاك | https://vibesholding.com/urmeet/ | لما يبغى ملتقى خاص باسم مشروعه أو مستعجل يعرض مشروعه | اصنع ملتقاك, ملتقاك, ملتقى خاص\nبودكاست الملتقى — الاستوديو والباقات | https://almoltaqapodcast.com/studio/ | لما يسأل عن البودكاست أو التصوير أو باقاته وأسعاره | بودكاست, البودكاست, الاستوديو, حلقة\nبرنامج شركاء النجاح | https://pvspaces.com/sp/ | لصاحب مشروع يبغى يعرضه أو يسجله | شركاء النجاح, تسجيل المشروع, أسجل مشروعي\nمومنتوم للتسويق بالذكاء الاصطناعي | https://momentummix.com/ | لما يسأل عن التسويق أو المواقع أو التطبيقات أو الذكاء الاصطناعي (وإن سُئل من صنع مواقع المنظومة أو هذا المساعد: مومنتوم) | مومنتوم, التسويق الرقمي, تسويق, momentum\nعضوية النادي — صفحة الاشتراك والدفع | https://vcmem.com/payment/ | لما يبغى يشترك أو يسأل عن العضوية ومزاياها والسعر | العضوية, عضوية النادي, الاشتراك, اشترك, 1,900\nالاشتراك المباشر في العضوية | https://vcmem.com/?vai-pay=membership | لما يقرر يدفع العضوية الآن | رابط الدفع, ادفع العضوية, أدفع\nالتوثيق الرسمي عبر أبشر (للأعضاء) | https://vcmem.com/investors-club/#subscribe | بعد الاشتراك لتوثيق حسابه رسميًا | أبشر, التوثيق, التسجيل الرسمي\nمزايا العضوية بالتفصيل | https://vcmem.com/member-benefits/ | لما يسأل وش أستفيد من العضوية | مزايا العضوية, فوائد العضوية\nعرض الشراكة — نادي المستثمرين (شركة المجتمع الافتراضي) | https://vcmem.com/offer/ | مستثمر مهتم بالدخول شريكًا في شركة النادي | شركة المجتمع الافتراضي, شريك في النادي\nعرض الشراكة — وديني | https://wdeny.com/offer/ | مستثمر مهتم بالتوصيل والتطبيقات | وديني, wdeny\nعرض الشراكة — سكة تك | https://sekaride.com/offer/ | مستثمر مهتم بالتقنية والنقل المدرسي | سكة تك, سكة, سكه, sekaride, النقل المدرسي\nعرض الشراكة — بودكاست الملتقى | https://almoltaqapodcast.com/offer/ | مستثمر مهتم بالإعلام والمحتوى | شراكة البودكاست, شريك في البودكاست\nعرض الشراكة — القضمة السريعة QB | https://qbarabia.com/offer/ | مستثمر مهتم بالمطاعم والامتياز | القضمة السريعة, القضمة, qbarabia, مطاعم\nعرض الشراكة — مومنتوم | https://momentummix.com/offer/ | مستثمر مهتم بالتسويق الرقمي | شراكة مومنتوم, شريك في مومنتوم\nعرض الشراكة — QDT الصفقات السريعة للتجارة | https://qdtco.com/offer/ | مستثمر مهتم بالتجارة الإلكترونية | الصفقات السريعة للتجارة, qdt, منفذ\nعرض الشراكة — PV ذبذبات إيجابية | https://pvspaces.com/offer/ | مستثمر مهتم بحاضنات الأعمال | ذبذبات إيجابية, PV, حاضنة\nعرض الشراكة — تمكين الامتياز | https://franchment.com/offer/ | مستثمر مهتم بالامتياز التجاري | تمكين الامتياز, الامتياز التجاري, franchment\nعرض الشراكة — الصفقات السريعة للاستثمار QD | https://qdealsi.com/offer/ | مستثمر مهتم بمنصات الشراكة | الصفقات السريعة للاستثمار, qdealsi\nعرض الشراكة — كمفورت بوكس | https://comfortboxsa.com/offer/ | مستثمر مهتم بالضيافة والسياحة | كمفورت بوكس, comfortbox, وحدات ضيافة\nعرض الشراكة — Vibes Ventures | https://vibesholding.com/offer/ | مستثمر يبغى يفهم المنظومة كلها | شراكة فايبز, شريك في فايبز\nحجز زيارة المقر | https://vcmem.com/location/#reservation | لما يبغى يزور النادي في الرياض | المقر, زيارة المقر, حجز زيارة\nالتسجيل في الملتقيات | https://vibesholding.com/mup | لما يبغى يحضر ملتقى | الملتقيات, حضور ملتقى, ملتقى 5 دقائق\nمبادرة شخصية ومسيرة | https://vcmem.com/famous | عضو يبغى يعرّف بنفسه ومسيرته | شخصية ومسيرة\nكتاب مليونير تحت الإنشاء (بدون رسوم) | https://vcmem.com/book | لما يسأل عن المؤسس أو يبغى الكتاب | الكتاب, مليونير تحت الإنشاء, المؤسس",
		'welcome_links'     => "تصفح جميع مشاريع Vibes Ventures | https://vibesholding.com/\nبنك المشاريع | https://vibesholding.com/pb\nخدمة اصنع ملتقاك | https://vibesholding.com/urmeet/\nبودكاست الملتقى | https://almoltaqapodcast.com/studio/\nبرنامج شركاء النجاح | https://pvspaces.com/sp/\nمومنتوم للتسويق بالذكاء الاصطناعي | https://momentummix.com/",
		'paymob_hmac'       => '',
		// 2.8.0 (M45): the plugin starts payments itself (intention API) so every payer is known — the
		// static payment links and their callbacks stay untouched. Keys live in options only, never in code.
		'paymob_secret'     => '',
		'paymob_direct'     => '',
		'paymob_public'     => '',
		'paymob_methods'    => '',
		'paymob_amounts'    => "190000 | membership | العضوية السنوية\n29000 | workshop | تسجيل الورشة (290 ريال)\n250000 | pitchdeck | Pitch Deck احترافي (سعر الأعضاء)\n1500000 | urmeet | اصنع ملتقاك (سعر الأعضاء)",
		'member_services'   => "🎙️ احجز حلقتك في بودكاست الملتقى بخصم 50% | أقرب موعد لتسجيل حلقتك الخاصة — ويمكن لأي شخص من طرفك التسجيل بنفس الخصم | wa:966538461110 | احجز الآن\n📊 Pitch Deck احترافي بخصم 50% | ملف عرض احترافي يرفع فرص قبول مشروعك — للأعضاء المفعّلين فقط | https://vcmem.com/?vai-pay=pitchdeck | ادفع بسعر الأعضاء\n🎤 اصنع ملتقاك بخصم 50% | ملتقاك الخاص باسم مشروعك أمام نخبة الأعضاء | https://vcmem.com/?vai-pay=urmeet | ادفع بسعر الأعضاء\n🏦 بنك المشاريع | تصفّح المشاريع وتواصل مع مؤسسيها — رصيدك 5 مشاريع في السنة | https://vibesholding.com/pb | افتح البنك\n☎️ باقي الخدمات عبر الإدارة | المسرح وقاعة الاجتماعات، المواقع والتطبيقات، الملتقيات — خصم 50% للأعضاء | wa:966551623111 | تواصل مع الإدارة",
		'member_email_subject' => 'تم تفعيل عضويتك في نادي المستثمرين يا {name} ⭐',
		'member_email'      => "مبروك يا {name} 🌹\n\nتم تفعيل عضويتك السنوية في نادي المستثمرين و Vibes Ventures حتى {end_date}. من الآن مساعد المنظومة هو مستشارك الخاص على مدار الساعة، وهذه مزاياك:\n\n• رصيد 2,500 ريال في بنك المشاريع = التواصل المباشر مع أصحاب 5 مشاريع تختارها بنفسك: {pb_url}\n• تقييم مشروعك خلال 10 أيام عمل وعرضه على المستثمرين بأولوية، وإعادة إبرازه مرة كل شهر، والتقديم على شركاء النجاح بأولوية\n• خصم 50% على كل باقات استوديو بودكاست الملتقى — احجز أقرب موعد لتسجيل حلقتك (ويمكن لأي شخص من طرفك الاستفادة بنفس الخصم): واتساب الاستوديو {podcast_wa}\n• خصم 50% على Pitch Deck الاحترافي: {pitchdeck_url}\n• خصم 50% على خدمة اصنع ملتقاك: {urmeet_url}\n• خصم 50% على مسرح النادي وقاعة الاجتماعات، والمواقع والتطبيقات من مومنتوم، وحقائب الامتياز\n• دخول مقر النادي بالرياض وأولوية الحضور في الملتقيات وملتقى 5 دقائق — سنتواصل معك عند كل ملتقى\n• استشارة أونلاين مع مستشار ذكي بدون رسوم، وظهورك في «شخصية ومسيرة»\n• برومو كود «شركاؤنا» الخاص بك في تطبيق النادي (شاشة «شركاؤنا» وكارت العضوية): كود شخصي يفتح لك خصومات كل شركاء النادي فورًا\n• كود خصم حتى 20% على منتجات «منفذ» — وكل خصم جديد يدخل المنظومة يسري عليك تلقائيًا\n\nحسابك واحد على كل مواقع المنظومة: {email} — وللإدارة رقم واحد: {mgmt}\n\nنادي المستثمرين — Vibes Ventures",
		'weekly_enabled'    => 1,
		'broadcast_enabled' => 1,
		'broadcast_member_texts' => "يا {name}، رصيدك في بنك المشاريع ينتظرك 🏦\nأهلًا {name} 🌹\n\nتذكير سريع بأهم ميزة في عضويتك: رصيد {pb_left} في بنك المشاريع — تواصل مباشر مع أصحاب المشاريع التي تختارها بنفسك: {pb_url}\n\nمستشارك الخاص جاهز على أي موقع في المنظومة، وللإدارة: {mgmt}\nعضويتك سارية حتى {end_date}.\n---\nحلقتك في بودكاست الملتقى بخصم 50% 🎙️\nأهلًا {name} 🌹\n\nبصفتك عضوًا، لك خصم 50% على كل باقات استوديو بودكاست الملتقى — احجز أقرب موعد لتسجيل حلقتك، ويمكن لأي شخص من طرفك الاستفادة بنفس الخصم.\n\nللحجز مباشرة: واتساب الاستوديو {podcast_wa}\nوللإدارة: {mgmt}\n---\nخصم 50% على Pitch Deck واصنع ملتقاك 🧩\nأهلًا {name} 🌹\n\nمشروعك يستحق عرضًا محترفًا: لك خصم 50% على Pitch Deck الاحترافي ({pitchdeck_url}) وعلى خدمة اصنع ملتقاك ({urmeet_url}) وعلى مسرح النادي وقاعة الاجتماعات.\n\nاسأل مستشارك الخاص عن التفاصيل على أي موقع في المنظومة — وللإدارة: {mgmt}\n---\nمقر النادي وملتقياته بانتظارك 🤝\nأهلًا {name} 🌹\n\nعضويتك تفتح لك مقر النادي بالرياض وأولوية الحضور في الملتقيات وملتقى 5 دقائق، مع استشارة أونلاين مع مستشار ذكي بدون رسوم.\n\nسنتواصل معك بأولوية عند كل ملتقى — وللإدارة: {mgmt}\nعضويتك سارية حتى {end_date}.",
		'broadcast_nonmember_texts' => "حسابك جاهز — بقيت خطوة العضوية ⭐\nأهلًا {name} 🌹\n\nحسابك في نادي المستثمرين جاهز، وبقيت خطوة واحدة تفتح لك كل المزايا: رصيد 2,500 ريال في بنك المشاريع، وخصم 50% على البودكاست وPitch Deck واصنع ملتقاك والمسرح، وأولوية الملتقيات، واستشارة أونلاين مع مستشار ذكي بدون رسوم.\n\nفعّل عضويتك السنوية الآن — تُفعّل تلقائيًا فور الدفع: {pay_url}\n---\nأصحاب المشاريع بانتظارك في بنك المشاريع 🏦\nأهلًا {name} 🌹\n\nفي بنك المشاريع مشاريع حقيقية معروضة بأرقامها، وأعضاء النادي يتواصلون مباشرة مع أصحابها برصيد 2,500 ريال يتجدد سنويًا.\n\nعضويتك تبدأ من هنا وتُفعّل تلقائيًا فور الدفع: {pay_url}\n---\nخصم 50% على كل خدمات المنظومة 🎯\nأهلًا {name} 🌹\n\nعضوية واحدة تخفّض لك أسعار الخدمات 50%: البودكاست وPitch Deck واصنع ملتقاك والمسرح وقاعة الاجتماعات والمواقع والتطبيقات — وتفتح لك مقر النادي وملتقياته.\n\nفعّلها الآن وتبدأ فورًا: {pay_url}",
		'pb_bridge_url'     => 'https://vibesholding.com/wp-json/pb/v1/bridge',
		'pb_bridge_key'     => '',
		'weekly_subject'    => 'يا {name}، رصيدك في بنك المشاريع ينتظرك 🏦',
		'weekly_email'      => "أهلًا {name} 🌹\n\nتذكير ودّي من نادي المستثمرين:\n\n• لا يزال لديك رصيد التواصل مع أصحاب {pb_left} في بنك المشاريع — تصفّح المشاريع الجديدة واختر ما يناسب توجهك: {pb_url}\n• تقدر تحجز حلقتك في بودكاست الملتقى بخصم 50% في أقرب موعد: واتساب الاستوديو {podcast_wa}\n• خصم 50% على Pitch Deck ({pitchdeck_url}) واصنع ملتقاك ({urmeet_url}) والمسرح وقاعة الاجتماعات والمواقع والتطبيقات\n• وإذا فيه ملتقى قريب سنتواصل معك بأولوية\n\nمستشارك الخاص جاهز على أي موقع في المنظومة — اسأله عن أي شيء. وللإدارة: {mgmt}\n\nعضويتك سارية حتى {end_date}.\nنادي المستثمرين — Vibes Ventures",
		'event_title'       => 'ورشة «مشروعك من الفكرة إلى التنفيذ»',
		'event_date'        => 'الثلاثاء 30 سبتمبر 2026 — 6:30 مساءً',
		'event_place'       => 'مقر نادي المستثمرين — الرياض',
		'event_amount'      => 29000,
		'event_note'        => 'أحضر التذكرة على جوالك (أو محفوظة كصورة) وسنمسح رمز QR عند الدخول. الرقم المرجعي هو رقم حجزك.',
		'notify_user_events' => 1,
		'wa_members_only'   => 1,
		'auto_open_words'   => 'افتح,افتحي,فتح,ودّيني,وديني,ودني,خذني,خدني,روح,روحني,انتقل,انقلني,حولني,حوّلني,اذهب,وين صفحة,وين رابط,أبي أشوف,ابي اشوف,أبغى أشوف,ابغى اشوف,عايز اشوف,وريني,ورني,اعرض لي,أعرض لي',
		'mgmt_whatsapp'     => '+966551623111',
		'club_whatsapp'     => '+966551623111',
		'saudi_only'        => 0,
		'contact_gate_text' => 'حياك الله 🌹 عشان أكمل معك وأخدمك صح، لازم أتعرّف عليك أكثر — سجّل بياناتك في ثوانٍ وبعدها نكمل:',
		'gcc_only'          => 1,
		'member_gate_text'  => "أنا آسف 🙏 ما أقدر أكمل معك أكثر بدون عضوية سنوية. لازم تسجّل عضوية عشان نكمل: بعدها أكون مستشارك الخاص على مدار الساعة بذاكرة كاملة، وتاخذ خصم 50% على كل الخدمات ورصيد بنك المشاريع — الدفع المباشر من الرابط:",
		'first_reply_note'  => "هذه المحادثة غير مسجّلة وقد لا أتذكر تفاصيلها بعد إغلاقها — بعضوية النادي السنوية أكون مستشارك الخاص بذاكرة كاملة على مدار الساعة.",
		'unpaid_note'       => "⚠️ عضويتك غير مفعّلة — برجاء تفعيل عضويتك السنوية لتستفيد بالخصومات والمجموعات والمستشار الخاص.",
		'unsaved_note'      => "💡 هذه المحادثة غير مسجّلة — بعد إغلاقها قد لا أتذكر تفاصيلها. بعضوية النادي السنوية أكون مستشارك الخاص بذاكرة كاملة على مدار الساعة.",
		'allowed_hosts'     => "vibesholding.com\nvibesholdingsa.com\nvcmem.com\npvspaces.com\nmomentummix.com\nalmoltaqapodcast.com\nsekaride.com\nwdeny.com\nwdenysky.com\nqbarabia.com\nqdtco.com\nqdealsi.com\nfranchment.com\ncomfortboxsa.com\npaymob.link\nyoutube.com\nyoutu.be\nwa.me\nmaps.app.goo.gl\nchat.whatsapp.com",
		'videos'            => "1|ما هو النادي وقوته ودوره في ريادة الأعمال بالمملكة|https://www.youtube.com/watch?v=3hvxhZL-gsM|نخبة من رجال الأعمال ورواد المشاريع في بيئة احترافية تصنع الفرص\n2|فئات النادي الثلاث ولمن هو|https://www.youtube.com/watch?v=TzeJOrO4nMI|مكان كل شخص داخل النادي: باحث عن شراكة، رائد أعمال، أو مهتم يستكشف\n3|رد المؤسس على أكثر الاستفسارات|https://www.youtube.com/watch?v=KUzcLImZc-c|المهندس سالم المسرحي بنفسه يشرح النادي و Vibes Ventures\n4|مقر النادي بالرياض|https://www.youtube.com/watch?v=XERenNWNziA|جولة توضح بيئة الأعمال والملتقيات في المقر\n5|ملتقى 5 دقائق (تعريفي)|https://www.youtube.com/watch?v=ReJljicbEJc|فكرة أو تجربة أو رؤية في خمس دقائق فقط\n6|لقطات حقيقية من ملتقى 5 دقائق|https://www.youtube.com/watch?v=Cyelv-klNyw|مشاركون حقيقيون يعرضون أفكارهم أمام نخبة من الأعضاء\n7|ملتقى اليوم المفتوح|https://www.youtube.com/watch?v=qvtBPNvmKvk|خذ المايك وشارك تجربتك أو اعرض مشروعك\n8|بنك المشاريع|https://www.youtube.com/watch?v=xsoLckayQZA|كيف تتحول الأفكار الواعدة إلى مشاريع قابلة للنمو\n9|دور شركة PV في دراسة المشاريع|https://www.youtube.com/watch?v=Ce4ZMGxSxcA|رحلة المشروع من التحليل والتقييم حتى طرحه على الأعضاء\n10|برنامج شركاء النجاح|https://www.youtube.com/watch?v=RfzNuS_q1UE|السند لمن اجتهد وبلغ مراحل متقدمة وبقيت خطوة\n11|فعاليات أعضاء النادي في الرياض|https://www.youtube.com/watch?v=_Ht_9Yv1Y7c|أجواء اللقاءات والفعاليات بين الأعضاء\n12|قصة تأسيس النادي|https://www.youtube.com/watch?v=CnWMWS_nDpM|كيف بدأت الفكرة وكيف أصبحت منظومة\n13|أعمال بودكاست الملتقى|https://www.youtube.com/watch?v=6TNxF2cxL4Q|جودة الاستوديوهات والإنتاج بالصورة\n14|برنامج صناع القيمة|https://www.youtube.com/watch?v=Emj4CYVUJq4|مساحة إعلامية لأصحاب الأفكار والتجارب الصادقة\n15|تطبيق سكة|https://www.youtube.com/watch?v=vLI-G989nIk|نقل مدرسي تشاركي أكثر أمانًا وتنظيمًا\n16|تطبيق وديني|https://www.youtube.com/shorts/65FtXIjFpK8|خدمات التوصيل في مكان واحد بأفضل الأسعار\n17|جميع أعمال المهندس سالم المسرحي وبودكاسته|https://www.youtube.com/watch?v=m9438gClv-Y&list=PL5MbrT9ENcuGpCRo3yv3Iqtr_CiPvEyuX|التعرّف على المؤسس وفكره من المصدر مباشرة\n18|شرح خدمة اصنع ملتقاك|https://www.youtube.com/watch?v=xpxKMnj_Nzk|كيف يصنع صاحب المشروع ملتقاه الخاص أمام نخبة الأعضاء",
	);
}

function vai_cfg( $key ) {
	$d = vai_defaults();
	$v = vai_opt( $key, isset( $d[ $key ] ) ? $d[ $key ] : '' );
	if ( $key === 'reply_timeout' ) {
		$v = max( 60, min( 600, (int) $v ) );
	}
	return $v;
}

/* ───────── normalisation ───────── */

function vai_home_host() {
	$h = wp_parse_url( home_url(), PHP_URL_HOST );
	return vai_norm_host( $h );
}

function vai_norm_host( $h ) {
	$h = strtolower( trim( (string) $h ) );
	if ( strpos( $h, '://' ) !== false ) {
		$p = wp_parse_url( $h, PHP_URL_HOST );
		$h = $p ? $p : $h;
	}
	$h = preg_replace( '#[/?\#].*$#', '', $h );
	$h = preg_replace( '/^www\./', '', $h );
	return trim( $h, " \t\n\r./" );
}

function vai_url_host( $url ) {
	$h = wp_parse_url( trim( (string) $url ), PHP_URL_HOST );
	return $h ? vai_norm_host( $h ) : '';
}

function vai_norm_phone( $p ) {
	$p = preg_replace( '/\D+/', '', (string) $p );
	if ( $p === '' ) {
		return '';
	}
	if ( strpos( $p, '00' ) === 0 ) {
		$p = substr( $p, 2 );
	}
	if ( strlen( $p ) === 10 && $p[0] === '0' ) {
		$p = '966' . substr( $p, 1 );
	} elseif ( strlen( $p ) === 9 && $p[0] === '5' ) {
		$p = '966' . $p;
	}
	return $p;
}

function vai_norm_email( $e ) {
	$e = strtolower( trim( (string) $e ) );
	return is_email( $e ) ? $e : '';
}

/** 2.10.0 (M45 TODO «2.8.3»): a placeholder e-mail the site's old anonymous Paymob links send (na@na.com and friends) —
 * valid in FORM only, so is_email() lets it through; no account mail may ever go there. */
function vai_junk_email( $email_norm ) {
	$email_norm = (string) $email_norm;
	if ( $email_norm === '' || strpos( $email_norm, '@' ) === false ) {
		return true;
	}
	list( $local, $domain ) = explode( '@', $email_norm, 2 );
	$words   = array( 'na', 'nan', 'none', 'null', 'nil', 'no', 'test', 'x', 'xx', 'xxx', 'noemail', 'nomail', 'noname', 'unknown', 'anonymous', 'undefined', 'empty' );
	$strip   = function ( $s ) {
		return strtolower( preg_replace( '/[^a-z]/i', '', (string) $s ) );
	};
	$dombase = preg_replace( '/\..*$/', '', $domain );
	return in_array( $strip( $local ), $words, true )
		|| in_array( $strip( $dombase ), $words, true )
		|| in_array( $domain, array( 'example.com', 'example.org', 'email.com', 'mail.com' ), true );
}

/** 2.10.0: both contact channels are garbage (or missing) — nobody real can be reached, so nothing
 * automatic may be built on this identity: no auto-account, no password link. Name alone never decides. */
function vai_junk_identity( $phone, $email_norm ) {
	$digits     = preg_replace( '/\D+/', '', (string) $phone );
	$phone_junk = strlen( $digits ) < 8
		|| preg_match( '/^(\d)\1+$/', $digits )
		|| in_array( substr( $digits, -9 ), array( '123456789', '987654321', '111111111', '000000000' ), true );
	return $phone_junk && vai_junk_email( $email_norm );
}

function vai_norm_text( $s ) {
	$s = (string) $s;
	$s = preg_replace( '/[\x{064B}-\x{0652}\x{0640}]/u', '', $s );
	$s = str_replace( array( 'أ', 'إ', 'آ' ), 'ا', $s );
	$s = str_replace( 'ى', 'ي', $s );
	$s = str_replace( 'ة', 'ه', $s );
	$s = function_exists( 'mb_strtolower' ) ? mb_strtolower( $s, 'UTF-8' ) : strtolower( $s );
	$s = preg_replace( '/\s+/u', ' ', $s );
	return trim( (string) $s );
}

function vai_stopwords() {
	return array( 'the', 'and', 'for', 'with', 'this', 'that', 'you', 'are', 'من', 'في', 'على', 'الى', 'عن', 'هل', 'ما', 'ماذا', 'كيف', 'ايش', 'وش', 'هو', 'هي', 'انا', 'انت', 'عندكم', 'عندك', 'ابي', 'ابغى', 'ابغي', 'اريد', 'ممكن', 'لو', 'سمحت', 'كم', 'متى', 'اين', 'فين', 'لي', 'لك', 'لكم', 'مع', 'او', 'ثم', 'قد', 'كل', 'هذا', 'هذه', 'ذلك', 'ده', 'دي', 'ايه', 'ليه', 'لما', 'عشان', 'بس', 'يا', 'ان', 'انه', 'ابيه', 'عندي', 'حاب', 'ودي', 'يعني', 'الي', 'اللي', 'ذا', 'شي', 'شيء' );
}

function vai_tokens( $s ) {
	$n     = vai_norm_text( $s );
	$parts = preg_split( '/[^\p{L}\p{N}]+/u', $n );
	$stop  = vai_stopwords();
	$out   = array();
	foreach ( (array) $parts as $p ) {
		$p = trim( (string) $p );
		if ( $p === '' || in_array( $p, $stop, true ) ) {
			continue;
		}
		$len = function_exists( 'mb_strlen' ) ? mb_strlen( $p, 'UTF-8' ) : strlen( $p );
		if ( $len < 2 ) {
			continue;
		}
		if ( $len < 3 && ! preg_match( '/\p{N}/u', $p ) ) {
			continue;
		}
		$out[ $p ] = true;
	}
	return array_keys( $out );
}

function vai_clip( $s, $n ) {
	$s = trim( (string) preg_replace( '/\s+/u', ' ', (string) $s ) );
	if ( function_exists( 'mb_strlen' ) ) {
		return mb_strlen( $s, 'UTF-8' ) > $n ? mb_substr( $s, 0, max( 1, $n - 1 ), 'UTF-8' ) . '…' : $s;
	}
	return strlen( $s ) > $n ? substr( $s, 0, $n - 1 ) . '…' : $s;
}

function vai_now() {
	return gmdate( 'Y-m-d H:i:s' );
}

function vai_iso( $mysql_utc ) {
	if ( ! $mysql_utc ) {
		return '';
	}
	$t = strtotime( $mysql_utc . ' UTC' );
	return $t ? gmdate( 'Y-m-d\TH:i:s\Z', $t ) : '';
}

function vai_riyadh( $mysql_utc, $fmt = 'Y-m-d H:i' ) {
	if ( ! $mysql_utc ) {
		return '';
	}
	try {
		$d = new DateTime( $mysql_utc, new DateTimeZone( 'UTC' ) );
		$d->setTimezone( new DateTimeZone( 'Asia/Riyadh' ) );
		return $d->format( $fmt );
	} catch ( Exception $e ) {
		return (string) $mysql_utc;
	}
}

/** UTC datetime string of today's midnight in Riyadh. */
function vai_riyadh_day_start_utc() {
	try {
		$d = new DateTime( 'now', new DateTimeZone( 'Asia/Riyadh' ) );
		$d->setTime( 0, 0, 0 );
		$d->setTimezone( new DateTimeZone( 'UTC' ) );
		return $d->format( 'Y-m-d H:i:s' );
	} catch ( Exception $e ) {
		return gmdate( 'Y-m-d 00:00:00' );
	}
}

/** Riyadh calendar day (Y-m-d) → UTC datetime string of that day's midnight. Riyadh is UTC+3 all year. */
function vai_riyadh_day_utc( $day ) {
	$t = strtotime( (string) $day . ' 00:00:00 UTC' );
	return $t ? gmdate( 'Y-m-d H:i:s', $t - 3 * 3600 ) : vai_riyadh_day_start_utc();
}

/** Integer input clamped to a range (default when missing or not numeric). */
function vai_int_in( $arr, $key, $min, $max, $default ) {
	$v = isset( $arr[ $key ] ) && is_numeric( $arr[ $key ] ) ? (int) $arr[ $key ] : (int) $default;
	return max( (int) $min, min( (int) $max, $v ) );
}

function vai_key( $len = 40 ) {
	return wp_generate_password( $len, false, false );
}

function vai_hash( $s ) {
	return hash( 'sha256', (string) $s );
}

function vai_ip() {
	$ip = '';
	if ( ! empty( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) {
		$ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
	} elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
		$parts = explode( ',', $_SERVER['HTTP_X_FORWARDED_FOR'] );
		$ip    = trim( $parts[0] );
	} elseif ( ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
		$ip = $_SERVER['REMOTE_ADDR'];
	}
	return sanitize_text_field( (string) $ip );
}

function vai_allowed_hosts() {
	$raw   = (string) vai_cfg( 'allowed_hosts' );
	$lines = preg_split( '/[\r\n,\s]+/', $raw );
	$out   = array();
	foreach ( (array) $lines as $l ) {
		$l = vai_norm_host( $l );
		if ( $l !== '' ) {
			$out[ $l ] = true;
		}
	}
	if ( vai_is_hub() ) {
		foreach ( vai_links() as $lk ) {
			$lh = vai_url_host( $lk['url'] );
			if ( $lh !== '' ) {
				$out[ $lh ] = true;
			}
		}
	}
	// Registered sites are always allowed on the hub.
	if ( vai_is_hub() && class_exists( 'VAI_Hub' ) ) {
		foreach ( VAI_Hub::site_hosts() as $h ) {
			$out[ $h ] = true;
		}
	}
	return array_keys( $out );
}

function vai_url_allowed( $url ) {
	$h = vai_url_host( $url );
	if ( $h === '' ) {
		return false;
	}
	foreach ( vai_allowed_hosts() as $a ) {
		if ( $h === $a || substr( $h, - strlen( '.' . $a ) ) === '.' . $a ) {
			return true;
		}
	}
	return false;
}

/** Remove any URL whose host is not allowed. */
function vai_strip_bad_urls( $text ) {
	return preg_replace_callback(
		'~https?://[^\s<>"\'«»()\]]+~u',
		function ( $m ) {
			$u = rtrim( $m[0], '.,،;:!?؟' );
			return vai_url_allowed( $u ) ? $m[0] : '';
		},
		(string) $text
	);
}

function vai_youtube_id( $url ) {
	$url = (string) $url;
	if ( preg_match( '~(?:youtu\.be/|youtube\.com/(?:watch\?v=|shorts/|embed/))([A-Za-z0-9_\-]{6,})~', $url, $m ) ) {
		return $m[1];
	}
	return '';
}

function vai_videos() {
	$raw = (string) vai_cfg( 'videos' );
	// merge default videos the admin's saved list doesn't have (by URL) so new library entries appear without re-saving
	$defs = vai_defaults();
	if ( $raw !== $defs['videos'] ) {
		$have = array();
		foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $l ) {
			$p = array_map( 'trim', explode( '|', $l ) );
			if ( isset( $p[2] ) ) {
				$have[] = vai_youtube_id( $p[2] );
			}
		}
		$max = 0;
		foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $l ) {
			$max = max( $max, (int) trim( explode( '|', $l )[0] ) );
		}
		foreach ( preg_split( '/\r\n|\r|\n/', $defs['videos'] ) as $l ) {
			$p = array_map( 'trim', explode( '|', $l ) );
			if ( count( $p ) >= 3 && ! in_array( vai_youtube_id( $p[2] ), $have, true ) ) {
				$max++;
				$raw .= "\n" . $max . '|' . $p[1] . '|' . $p[2] . '|' . ( isset( $p[3] ) ? $p[3] : '' );
			}
		}
	}
	$lines = preg_split( '/\r\n|\r|\n/', $raw );
	$out   = array();
	foreach ( (array) $lines as $l ) {
		$l = trim( $l );
		if ( $l === '' ) {
			continue;
		}
		$p = array_map( 'trim', explode( '|', $l ) );
		if ( count( $p ) < 3 ) {
			continue;
		}
		$out[] = array(
			'id'     => (int) $p[0],
			'title'  => $p[1],
			'url'    => $p[2],
			'teaser' => isset( $p[3] ) ? $p[3] : '',
			'yt'     => vai_youtube_id( $p[2] ),
		);
	}
	return $out;
}

/* ───────── phone formats (world — GCC keep strict rules, the rest use the generic length check) ───────── */
function vai_gcc_countries() {
	static $all = null;
	if ( $all !== null ) {
		return $all;
	}
	$all = array(
		'sa' => array( 'name' => 'السعودية', 'en' => 'Saudi Arabia', 'code' => '966', 'flag' => '🇸🇦', 'local' => '/^0?5\d{8}$/', 'example' => '0512345678' ),
		'ae' => array( 'name' => 'الإمارات', 'en' => 'United Arab Emirates', 'code' => '971', 'flag' => '🇦🇪', 'local' => '/^0?5\d{8}$/', 'example' => '0501234567' ),
		'kw' => array( 'name' => 'الكويت', 'en' => 'Kuwait', 'code' => '965', 'flag' => '🇰🇼', 'local' => '/^[569]\d{7}$/', 'example' => '51234567' ),
		'qa' => array( 'name' => 'قطر', 'en' => 'Qatar', 'code' => '974', 'flag' => '🇶🇦', 'local' => '/^[3567]\d{7}$/', 'example' => '55123456' ),
		'bh' => array( 'name' => 'البحرين', 'en' => 'Bahrain', 'code' => '973', 'flag' => '🇧🇭', 'local' => '/^[3679]\d{7}$/', 'example' => '36123456' ),
		'om' => array( 'name' => 'عُمان', 'en' => 'Oman', 'code' => '968', 'flag' => '🇴🇲', 'local' => '/^[79]\d{7}$/', 'example' => '91234567' ),
	);
	// iso2 => [arabic name, dial code, flag, english name] — generic validation (no strict local rule).
	$world = array(
		'eg' => array( 'مصر', '20', '🇪🇬', 'Egypt' ), 'jo' => array( 'الأردن', '962', '🇯🇴', 'Jordan' ), 'lb' => array( 'لبنان', '961', '🇱🇧', 'Lebanon' ),
		'sy' => array( 'سوريا', '963', '🇸🇾', 'Syria' ), 'iq' => array( 'العراق', '964', '🇮🇶', 'Iraq' ), 'ps' => array( 'فلسطين', '970', '🇵🇸', 'Palestine' ),
		'ye' => array( 'اليمن', '967', '🇾🇪', 'Yemen' ), 'ly' => array( 'ليبيا', '218', '🇱🇾', 'Libya' ), 'tn' => array( 'تونس', '216', '🇹🇳', 'Tunisia' ),
		'dz' => array( 'الجزائر', '213', '🇩🇿', 'Algeria' ), 'ma' => array( 'المغرب', '212', '🇲🇦', 'Morocco' ), 'sd' => array( 'السودان', '249', '🇸🇩', 'Sudan' ),
		'so' => array( 'الصومال', '252', '🇸🇴', 'Somalia' ), 'mr' => array( 'موريتانيا', '222', '🇲🇷', 'Mauritania' ), 'dj' => array( 'جيبوتي', '253', '🇩🇯', 'Djibouti' ),
		'km' => array( 'جزر القمر', '269', '🇰🇲', 'Comoros' ), 'is' => array( 'آيسلندا', '354', '🇮🇸', 'Iceland' ), 'et' => array( 'إثيوبيا', '251', '🇪🇹', 'Ethiopia' ),
		'az' => array( 'أذربيجان', '994', '🇦🇿', 'Azerbaijan' ), 'am' => array( 'أرمينيا', '374', '🇦🇲', 'Armenia' ), 'er' => array( 'إريتريا', '291', '🇪🇷', 'Eritrea' ),
		'es' => array( 'إسبانيا', '34', '🇪🇸', 'Spain' ), 'au' => array( 'أستراليا', '61', '🇦🇺', 'Australia' ), 'ee' => array( 'إستونيا', '372', '🇪🇪', 'Estonia' ),
		'sz' => array( 'إسواتيني', '268', '🇸🇿', 'Eswatini' ), 'cf' => array( 'أفريقيا الوسطى', '236', '🇨🇫', 'Central African Republic' ), 'af' => array( 'أفغانستان', '93', '🇦🇫', 'Afghanistan' ),
		'ar' => array( 'الأرجنتين', '54', '🇦🇷', 'Argentina' ), 'ec' => array( 'الإكوادور', '593', '🇪🇨', 'Ecuador' ), 'al' => array( 'ألبانيا', '355', '🇦🇱', 'Albania' ),
		'bs' => array( 'الباهاما', '1242', '🇧🇸', 'Bahamas' ), 'br' => array( 'البرازيل', '55', '🇧🇷', 'Brazil' ), 'pt' => array( 'البرتغال', '351', '🇵🇹', 'Portugal' ),
		'ba' => array( 'البوسنة والهرسك', '387', '🇧🇦', 'Bosnia and Herzegovina' ), 'cz' => array( 'التشيك', '420', '🇨🇿', 'Czechia' ), 'me' => array( 'الجبل الأسود', '382', '🇲🇪', 'Montenegro' ),
		'dk' => array( 'الدنمارك', '45', '🇩🇰', 'Denmark' ), 'do' => array( 'الدومينيكان', '1809', '🇩🇴', 'Dominican Republic' ), 'cv' => array( 'الرأس الأخضر', '238', '🇨🇻', 'Cape Verde' ),
		'sv' => array( 'السلفادور', '503', '🇸🇻', 'El Salvador' ), 'sn' => array( 'السنغال', '221', '🇸🇳', 'Senegal' ), 'se' => array( 'السويد', '46', '🇸🇪', 'Sweden' ),
		'cn' => array( 'الصين', '86', '🇨🇳', 'China' ), 'ga' => array( 'الغابون', '241', '🇬🇦', 'Gabon' ), 'va' => array( 'الفاتيكان', '379', '🇻🇦', 'Vatican City' ),
		'ph' => array( 'الفلبين', '63', '🇵🇭', 'Philippines' ), 'cm' => array( 'الكاميرون', '237', '🇨🇲', 'Cameroon' ), 'cg' => array( 'الكونغو', '242', '🇨🇬', 'Congo' ),
		'cd' => array( 'الكونغو الديمقراطية', '243', '🇨🇩', 'DR Congo' ), 'mv' => array( 'المالديف', '960', '🇲🇻', 'Maldives' ), 'de' => array( 'ألمانيا', '49', '🇩🇪', 'Germany' ),
		'hu' => array( 'المجر', '36', '🇭🇺', 'Hungary' ), 'mx' => array( 'المكسيك', '52', '🇲🇽', 'Mexico' ), 'no' => array( 'النرويج', '47', '🇳🇴', 'Norway' ),
		'at' => array( 'النمسا', '43', '🇦🇹', 'Austria' ), 'ne' => array( 'النيجر', '227', '🇳🇪', 'Niger' ), 'in' => array( 'الهند', '91', '🇮🇳', 'India' ),
		'us' => array( 'الولايات المتحدة', '1', '🇺🇸', 'United States' ), 'jp' => array( 'اليابان', '81', '🇯🇵', 'Japan' ), 'gr' => array( 'اليونان', '30', '🇬🇷', 'Greece' ),
		'ag' => array( 'أنتيغوا وباربودا', '1268', '🇦🇬', 'Antigua and Barbuda' ), 'ad' => array( 'أندورا', '376', '🇦🇩', 'Andorra' ), 'id' => array( 'إندونيسيا', '62', '🇮🇩', 'Indonesia' ),
		'ao' => array( 'أنغولا', '244', '🇦🇴', 'Angola' ), 'uy' => array( 'أوروغواي', '598', '🇺🇾', 'Uruguay' ), 'uz' => array( 'أوزبكستان', '998', '🇺🇿', 'Uzbekistan' ),
		'ug' => array( 'أوغندا', '256', '🇺🇬', 'Uganda' ), 'ua' => array( 'أوكرانيا', '380', '🇺🇦', 'Ukraine' ), 'ir' => array( 'إيران', '98', '🇮🇷', 'Iran' ),
		'ie' => array( 'أيرلندا', '353', '🇮🇪', 'Ireland' ), 'it' => array( 'إيطاليا', '39', '🇮🇹', 'Italy' ), 'pg' => array( 'بابوا غينيا الجديدة', '675', '🇵🇬', 'Papua New Guinea' ),
		'py' => array( 'باراغواي', '595', '🇵🇾', 'Paraguay' ), 'bb' => array( 'باربادوس', '1246', '🇧🇧', 'Barbados' ), 'pk' => array( 'باكستان', '92', '🇵🇰', 'Pakistan' ),
		'pw' => array( 'بالاو', '680', '🇵🇼', 'Palau' ), 'bn' => array( 'بروناي', '673', '🇧🇳', 'Brunei' ), 'gb' => array( 'بريطانيا', '44', '🇬🇧', 'United Kingdom' ),
		'be' => array( 'بلجيكا', '32', '🇧🇪', 'Belgium' ), 'bg' => array( 'بلغاريا', '359', '🇧🇬', 'Bulgaria' ), 'bz' => array( 'بليز', '501', '🇧🇿', 'Belize' ),
		'bd' => array( 'بنغلاديش', '880', '🇧🇩', 'Bangladesh' ), 'pa' => array( 'بنما', '507', '🇵🇦', 'Panama' ), 'bj' => array( 'بنين', '229', '🇧🇯', 'Benin' ),
		'bt' => array( 'بوتان', '975', '🇧🇹', 'Bhutan' ), 'bw' => array( 'بوتسوانا', '267', '🇧🇼', 'Botswana' ), 'bf' => array( 'بوركينا فاسو', '226', '🇧🇫', 'Burkina Faso' ),
		'bi' => array( 'بوروندي', '257', '🇧🇮', 'Burundi' ), 'pl' => array( 'بولندا', '48', '🇵🇱', 'Poland' ), 'bo' => array( 'بوليفيا', '591', '🇧🇴', 'Bolivia' ),
		'pe' => array( 'بيرو', '51', '🇵🇪', 'Peru' ), 'by' => array( 'بيلاروسيا', '375', '🇧🇾', 'Belarus' ), 'th' => array( 'تايلاند', '66', '🇹🇭', 'Thailand' ),
		'tw' => array( 'تايوان', '886', '🇹🇼', 'Taiwan' ), 'tm' => array( 'تركمانستان', '993', '🇹🇲', 'Turkmenistan' ), 'tr' => array( 'تركيا', '90', '🇹🇷', 'Turkey' ),
		'tt' => array( 'ترينيداد وتوباغو', '1868', '🇹🇹', 'Trinidad and Tobago' ), 'td' => array( 'تشاد', '235', '🇹🇩', 'Chad' ), 'cl' => array( 'تشيلي', '56', '🇨🇱', 'Chile' ),
		'tz' => array( 'تنزانيا', '255', '🇹🇿', 'Tanzania' ), 'tg' => array( 'توغو', '228', '🇹🇬', 'Togo' ), 'tv' => array( 'توفالو', '688', '🇹🇻', 'Tuvalu' ),
		'to' => array( 'تونغا', '676', '🇹🇴', 'Tonga' ), 'tl' => array( 'تيمور الشرقية', '670', '🇹🇱', 'Timor-Leste' ), 'jm' => array( 'جامايكا', '1876', '🇯🇲', 'Jamaica' ),
		'sb' => array( 'جزر سليمان', '677', '🇸🇧', 'Solomon Islands' ), 'mh' => array( 'جزر مارشال', '692', '🇲🇭', 'Marshall Islands' ), 'za' => array( 'جنوب أفريقيا', '27', '🇿🇦', 'South Africa' ),
		'ss' => array( 'جنوب السودان', '211', '🇸🇸', 'South Sudan' ), 'ge' => array( 'جورجيا', '995', '🇬🇪', 'Georgia' ), 'dm' => array( 'دومينيكا', '1767', '🇩🇲', 'Dominica' ),
		'rw' => array( 'رواندا', '250', '🇷🇼', 'Rwanda' ), 'ru' => array( 'روسيا', '7', '🇷🇺', 'Russia' ), 'ro' => array( 'رومانيا', '40', '🇷🇴', 'Romania' ),
		'zm' => array( 'زامبيا', '260', '🇿🇲', 'Zambia' ), 'zw' => array( 'زيمبابوي', '263', '🇿🇼', 'Zimbabwe' ), 'ci' => array( 'ساحل العاج', '225', '🇨🇮', 'Ivory Coast' ),
		'ws' => array( 'ساموا', '685', '🇼🇸', 'Samoa' ), 'sm' => array( 'سان مارينو', '378', '🇸🇲', 'San Marino' ), 'vc' => array( 'سانت فنسنت والغرينادين', '1784', '🇻🇨', 'Saint Vincent and the Grenadines' ),
		'kn' => array( 'سانت كيتس ونيفيس', '1869', '🇰🇳', 'Saint Kitts and Nevis' ), 'lc' => array( 'سانت لوسيا', '1758', '🇱🇨', 'Saint Lucia' ), 'st' => array( 'ساو تومي وبرينسيبي', '239', '🇸🇹', 'Sao Tome and Principe' ),
		'lk' => array( 'سريلانكا', '94', '🇱🇰', 'Sri Lanka' ), 'sk' => array( 'سلوفاكيا', '421', '🇸🇰', 'Slovakia' ), 'si' => array( 'سلوفينيا', '386', '🇸🇮', 'Slovenia' ),
		'sg' => array( 'سنغافورة', '65', '🇸🇬', 'Singapore' ), 'sr' => array( 'سورينام', '597', '🇸🇷', 'Suriname' ), 'ch' => array( 'سويسرا', '41', '🇨🇭', 'Switzerland' ),
		'sl' => array( 'سيراليون', '232', '🇸🇱', 'Sierra Leone' ), 'sc' => array( 'سيشل', '248', '🇸🇨', 'Seychelles' ), 'rs' => array( 'صربيا', '381', '🇷🇸', 'Serbia' ),
		'tj' => array( 'طاجيكستان', '992', '🇹🇯', 'Tajikistan' ), 'gm' => array( 'غامبيا', '220', '🇬🇲', 'Gambia' ), 'gh' => array( 'غانا', '233', '🇬🇭', 'Ghana' ),
		'gd' => array( 'غرينادا', '1473', '🇬🇩', 'Grenada' ), 'gt' => array( 'غواتيمالا', '502', '🇬🇹', 'Guatemala' ), 'gy' => array( 'غيانا', '592', '🇬🇾', 'Guyana' ),
		'gn' => array( 'غينيا', '224', '🇬🇳', 'Guinea' ), 'gq' => array( 'غينيا الاستوائية', '240', '🇬🇶', 'Equatorial Guinea' ), 'gw' => array( 'غينيا بيساو', '245', '🇬🇼', 'Guinea-Bissau' ),
		'vu' => array( 'فانواتو', '678', '🇻🇺', 'Vanuatu' ), 'fr' => array( 'فرنسا', '33', '🇫🇷', 'France' ), 've' => array( 'فنزويلا', '58', '🇻🇪', 'Venezuela' ),
		'fi' => array( 'فنلندا', '358', '🇫🇮', 'Finland' ), 'vn' => array( 'فيتنام', '84', '🇻🇳', 'Vietnam' ), 'fj' => array( 'فيجي', '679', '🇫🇯', 'Fiji' ),
		'cy' => array( 'قبرص', '357', '🇨🇾', 'Cyprus' ), 'kg' => array( 'قيرغيزستان', '996', '🇰🇬', 'Kyrgyzstan' ), 'kz' => array( 'كازاخستان', '7', '🇰🇿', 'Kazakhstan' ),
		'hr' => array( 'كرواتيا', '385', '🇭🇷', 'Croatia' ), 'kh' => array( 'كمبوديا', '855', '🇰🇭', 'Cambodia' ), 'ca' => array( 'كندا', '1', '🇨🇦', 'Canada' ),
		'cu' => array( 'كوبا', '53', '🇨🇺', 'Cuba' ), 'kr' => array( 'كوريا الجنوبية', '82', '🇰🇷', 'South Korea' ), 'kp' => array( 'كوريا الشمالية', '850', '🇰🇵', 'North Korea' ),
		'cr' => array( 'كوستاريكا', '506', '🇨🇷', 'Costa Rica' ), 'xk' => array( 'كوسوفو', '383', '🇽🇰', 'Kosovo' ), 'co' => array( 'كولومبيا', '57', '🇨🇴', 'Colombia' ),
		'ki' => array( 'كيريباتي', '686', '🇰🇮', 'Kiribati' ), 'ke' => array( 'كينيا', '254', '🇰🇪', 'Kenya' ), 'lv' => array( 'لاتفيا', '371', '🇱🇻', 'Latvia' ),
		'la' => array( 'لاوس', '856', '🇱🇦', 'Laos' ), 'lu' => array( 'لوكسمبورغ', '352', '🇱🇺', 'Luxembourg' ), 'lr' => array( 'ليبيريا', '231', '🇱🇷', 'Liberia' ),
		'lt' => array( 'ليتوانيا', '370', '🇱🇹', 'Lithuania' ), 'li' => array( 'ليختنشتاين', '423', '🇱🇮', 'Liechtenstein' ), 'ls' => array( 'ليسوتو', '266', '🇱🇸', 'Lesotho' ),
		'mo' => array( 'ماكاو', '853', '🇲🇴', 'Macau' ), 'mw' => array( 'مالاوي', '265', '🇲🇼', 'Malawi' ), 'mt' => array( 'مالطا', '356', '🇲🇹', 'Malta' ),
		'ml' => array( 'مالي', '223', '🇲🇱', 'Mali' ), 'my' => array( 'ماليزيا', '60', '🇲🇾', 'Malaysia' ), 'mg' => array( 'مدغشقر', '261', '🇲🇬', 'Madagascar' ),
		'mk' => array( 'مقدونيا الشمالية', '389', '🇲🇰', 'North Macedonia' ), 'mn' => array( 'منغوليا', '976', '🇲🇳', 'Mongolia' ), 'mu' => array( 'موريشيوس', '230', '🇲🇺', 'Mauritius' ),
		'mz' => array( 'موزمبيق', '258', '🇲🇿', 'Mozambique' ), 'md' => array( 'مولدوفا', '373', '🇲🇩', 'Moldova' ), 'mc' => array( 'موناكو', '377', '🇲🇨', 'Monaco' ),
		'mm' => array( 'ميانمار', '95', '🇲🇲', 'Myanmar' ), 'fm' => array( 'ميكرونيزيا', '691', '🇫🇲', 'Micronesia' ), 'na' => array( 'ناميبيا', '264', '🇳🇦', 'Namibia' ),
		'nr' => array( 'ناورو', '674', '🇳🇷', 'Nauru' ), 'np' => array( 'نيبال', '977', '🇳🇵', 'Nepal' ), 'ng' => array( 'نيجيريا', '234', '🇳🇬', 'Nigeria' ),
		'ni' => array( 'نيكاراغوا', '505', '🇳🇮', 'Nicaragua' ), 'nz' => array( 'نيوزيلندا', '64', '🇳🇿', 'New Zealand' ), 'ht' => array( 'هايتي', '509', '🇭🇹', 'Haiti' ),
		'hn' => array( 'هندوراس', '504', '🇭🇳', 'Honduras' ), 'nl' => array( 'هولندا', '31', '🇳🇱', 'Netherlands' ), 'hk' => array( 'هونغ كونغ', '852', '🇭🇰', 'Hong Kong' ),
	);
	foreach ( $world as $k => $w ) {
		$all[ $k ] = array( 'name' => $w[0], 'en' => $w[3], 'code' => $w[1], 'flag' => $w[2], 'local' => '', 'example' => '' );
	}
	return $all;
}

/** Validate a local mobile number for a country; returns international digits (e.g. 9665…) or ''. */
function vai_phone_intl( $country, $local ) {
	$cc = vai_gcc_countries();
	$country = strtolower( trim( (string) $country ) ) ?: 'sa';
	if ( ! isset( $cc[ $country ] ) ) {
		return '';
	}
	$d = preg_replace( '/\D+/', '', (string) $local );
	// accept numbers typed with the country code already
	$code = $cc[ $country ]['code'];
	if ( strpos( $d, '00' . $code ) === 0 ) {
		$d = substr( $d, 2 + strlen( $code ) );
	} elseif ( strpos( $d, $code ) === 0 && strlen( $d ) > strlen( $code ) + 7 ) {
		$d = substr( $d, strlen( $code ) );
	}
	if ( $cc[ $country ]['local'] !== '' ) {
		if ( ! preg_match( $cc[ $country ]['local'], $d ) ) {
			return '';
		}
		return $code . ltrim( $d, '0' );
	}
	// generic world rule: 5–12 digits after the dial code, E.164 total of 15 max
	$d = ltrim( $d, '0' );
	if ( ! preg_match( '/^\d{5,12}$/', $d ) || strlen( $code . $d ) > 15 ) {
		return '';
	}
	return $code . $d;
}

/** Display form: Saudi numbers as 05XXXXXXXX (no spaces, no country code); other countries as plain digits. */
function vai_phone_local( $phone ) {
	$d = preg_replace( '/\D+/', '', (string) $phone );
	if ( strpos( $d, '00966' ) === 0 ) {
		$d = substr( $d, 2 );
	}
	if ( strpos( $d, '966' ) === 0 && strlen( $d ) === 12 ) {
		return '0' . substr( $d, 3 );
	}
	if ( strlen( $d ) === 10 && strpos( $d, '05' ) === 0 ) {
		return $d;
	}
	if ( strlen( $d ) === 9 && $d[0] === '5' ) {
		return '0' . $d;
	}
	return $d;
}

function vai_phone_policy_text() {
	return 'التسجيل متاح من أي دولة في العالم. اختر دولتك من القائمة واكتب رقم الجوال بدون مسافات وبدون رمز الدولة — في السعودية مثلًا بهذا الشكل: 0512345678.';
}

/** Registration e-mail policy: any valid address by default ('*'), or a configured domain list. */
function vai_email_allowed( $email ) {
	$email = vai_norm_email( $email );
	if ( $email === '' ) {
		return false;
	}
	$dom  = substr( $email, strrpos( $email, '@' ) + 1 );
	$list = preg_split( '/[\s,]+/', strtolower( (string) vai_cfg( 'allowed_email_domains' ) ) );
	foreach ( (array) $list as $rule ) {
		$rule = trim( $rule );
		if ( $rule === '' ) {
			continue;
		}
		if ( $rule === '*' ) {
			return true;
		}
		if ( strpos( $rule, '*.' ) === 0 ) {
			$suffix = substr( $rule, 1 ); // ".sa"
			if ( substr( $dom, - strlen( $suffix ) ) === $suffix ) {
				return true;
			}
		} elseif ( $dom === $rule ) {
			return true;
		}
	}
	return false;
}

function vai_email_policy_text() {
	return 'سيصلك كود التفعيل على هذا البريد — تأكد من كتابته صحيحًا (بريد شخصي أو بريد شركتك، أي دومين مقبول)';
}

/** Member services (paid members panel): title | desc | url-or-wa:number | button. */
function vai_member_services() {
	$out = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) vai_cfg( 'member_services' ) ) as $l ) {
		$p = array_map( 'trim', explode( '|', $l ) );
		if ( count( $p ) < 3 ) {
			continue;
		}
		$out[] = array( 'title' => $p[0], 'desc' => $p[1], 'url' => $p[2], 'btn' => isset( $p[3] ) ? $p[3] : 'افتح' );
	}
	return $out;
}

/** Paymob amount map: cents | key | label. */
function vai_paymob_amounts() {
	$out = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) vai_cfg( 'paymob_amounts' ) ) as $l ) {
		$p = array_map( 'trim', explode( '|', $l ) );
		if ( count( $p ) < 2 || ! is_numeric( $p[0] ) ) {
			continue;
		}
		$out[ (int) $p[0] ] = array( 'key' => preg_replace( '/[^a-z0-9_]/', '', strtolower( $p[1] ) ), 'label' => isset( $p[2] ) ? $p[2] : $p[1] );
	}
	return $out;
}

/** Welcome links (shown as buttons after account activation): label | url per line. */
function vai_welcome_links() {
	$out = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) vai_cfg( 'welcome_links' ) ) as $l ) {
		$p = array_map( 'trim', explode( '|', $l ) );
		if ( count( $p ) >= 2 && preg_match( '~^https?://~', $p[1] ) ) {
			$out[] = array( 'label' => $p[0], 'url' => $p[1] );
		}
	}
	return $out;
}

/** Links library: label | url | when (one per line). */
function vai_parse_links( $raw ) {
	$lines = preg_split( '/\r\n|\r|\n/', (string) $raw );
	$out   = array();
	foreach ( (array) $lines as $l ) {
		$p = array_map( 'trim', explode( '|', $l ) );
		if ( count( $p ) < 2 || ! preg_match( '~^https?://~', $p[1] ) ) {
			continue;
		}
		$kw    = isset( $p[3] ) ? array_values( array_filter( array_map( 'trim', explode( ',', $p[3] ) ) ) ) : array();
		$out[] = array( 'label' => $p[0], 'url' => $p[1], 'when' => isset( $p[2] ) ? $p[2] : '', 'keywords' => $kw );
	}
	return $out;
}

/** Links library — keywords are backfilled from the defaults (by URL) and from label/URL words so matching never depends on the admin typing them. */
function vai_links() {
	$saved    = vai_parse_links( vai_cfg( 'links' ) );
	$defaults = vai_defaults();
	$def      = array();
	foreach ( vai_parse_links( $defaults['links'] ) as $d ) {
		$def[ rtrim( $d['url'], '/' ) ] = $d['keywords'];
	}
	$generic = array( 'عرض', 'الشراكه', 'شراكه', 'صفحه', 'خدمه', 'برنامج', 'الرئيسيه', 'تصفح', 'جميع', 'رابط', 'الاشتراك', 'والدفع', 'المباشر', 'في', 'من', 'الى', 'على', 'او', 'و', 'the', 'and', 'for', 'www', 'com', 'sa', 'net', 'offer', 'https', 'http', 'index' );
	foreach ( $saved as &$l ) {
		$kw = $l['keywords'];
		$k  = rtrim( $l['url'], '/' );
		if ( isset( $def[ $k ] ) ) {
			$kw = array_merge( $kw, $def[ $k ] );
		}
		// label words (≥3 chars, non-generic)
		foreach ( preg_split( '/[^\p{L}\p{N}]+/u', $l['label'] ) as $w ) {
			$wn = vai_norm_text( $w );
			if ( mb_strlen( $wn, 'UTF-8' ) >= 3 && ! in_array( $wn, $generic, true ) ) {
				$kw[] = $w;
			}
		}
		// url words (host name without tld, path segments)
		$host = vai_url_host( $l['url'] );
		$hw   = explode( '.', $host );
		if ( $hw && strlen( $hw[0] ) >= 4 ) {
			$kw[] = $hw[0];
		}
		$path = trim( (string) wp_parse_url( $l['url'], PHP_URL_PATH ), '/' );
		foreach ( explode( '/', $path ) as $seg ) {
			if ( strlen( $seg ) >= 3 && ! in_array( strtolower( $seg ), $generic, true ) ) {
				$kw[] = $seg;
			}
		}
		$l['keywords'] = array_values( array_unique( array_filter( array_map( 'trim', $kw ) ) ) );
	}
	unset( $l );
	return $saved;
}

/* ───────── public PHP API for other plugins (e.g. Projects Bank) ─────────
 * The widget stores the visitor id in a first-party cookie (vai_uuid); any plugin on the same site can ask the hub
 * who this visitor is and whether the unified ecosystem membership is active.
 */
function vai_current_uuid() {
	$u = isset( $_COOKIE['vai_uuid'] ) ? preg_replace( '/[^a-zA-Z0-9\-]/', '', (string) $_COOKIE['vai_uuid'] ) : '';
	return strlen( $u ) >= 8 ? $u : '';
}

/** Returns the visitor's account/contact array (id, name, email, phone, has_account, verified, is_member, member_left, trial_left, daily_left, avatar, company, ...) or null. Cached 60s. */
function vai_current_contact( $fresh = false ) {
	static $memo = null;
	if ( $memo !== null && ! $fresh ) {
		return $memo;
	}
	$uuid = vai_current_uuid();
	if ( $uuid === '' ) {
		return null;
	}
	$key = 'vai_cc_' . md5( $uuid );
	if ( ! $fresh ) {
		$cached = get_transient( $key );
		if ( is_array( $cached ) ) {
			$memo = $cached['c'];
			return $memo;
		}
	}
	$res  = VAI_Site::client( 'account', array( 'uuid' => $uuid ), 10 );
	$memo = ( ! is_wp_error( $res ) && ! empty( $res['contact'] ) ) ? $res['contact'] : null;
	set_transient( $key, array( 'c' => $memo ), MINUTE_IN_SECONDS );
	return $memo;
}

/** true when the visitor holds an ACTIVE paid ecosystem membership. */
function vai_is_paid_member() {
	$c = vai_current_contact();
	return is_array( $c ) && ! empty( $c['is_member'] );
}

/** true when the visitor has a verified account (trial or paid). */
function vai_has_account() {
	$c = vai_current_contact();
	return is_array( $c ) && ! empty( $c['has_account'] ) && ! empty( $c['verified'] );
}

/** Membership status by phone/email (server-side, for plugins that store their own user identity). */
function vai_member_status_by_login( $phone = '', $email = '' ) {
	$res = VAI_Site::client( 'member_status', array( 'phone' => (string) $phone, 'email' => (string) $email ), 10 );
	return is_wp_error( $res ) ? null : $res;
}

/* ───────── http ───────── */

function vai_http_json( $method, $url, $body = null, $headers = array(), $timeout = 25 ) {
	$args = array(
		'method'    => $method,
		'timeout'   => $timeout,
		'headers'   => array_merge(
			array(
				'Content-Type' => 'application/json; charset=utf-8',
				'Accept'       => 'application/json',
				'User-Agent'   => 'VibesAI/' . VAI_VERSION . ' (+' . home_url() . ')',
			),
			$headers
		),
		'sslverify' => true,
	);
	if ( $body !== null ) {
		$args['body'] = wp_json_encode( $body );
	}
	$res = wp_remote_request( $url, $args );
	if ( is_wp_error( $res ) ) {
		return array( 0, null, $res->get_error_message() );
	}
	$code = (int) wp_remote_retrieve_response_code( $res );
	$raw  = (string) wp_remote_retrieve_body( $res );
	$data = json_decode( $raw, true );
	return array( $code, $data, $data === null ? vai_clip( $raw, 300 ) : '' );
}

function vai_error( $code, $msg, $status = 400 ) {
	return new WP_Error( $code, $msg, array( 'status' => $status ) );
}

function vai_body( WP_REST_Request $req ) {
	$b = $req->get_json_params();
	if ( ! is_array( $b ) ) {
		$b = $req->get_params();
	}
	return is_array( $b ) ? $b : array();
}

function vai_str( $arr, $key, $max = 500 ) {
	$v = isset( $arr[ $key ] ) ? $arr[ $key ] : '';
	if ( is_array( $v ) ) {
		return '';
	}
	$v = trim( (string) $v );
	return vai_clip( $v, $max );
}

function vai_text_ok( $arr, $key, $max = 4000 ) {
	$v = isset( $arr[ $key ] ) ? $arr[ $key ] : '';
	if ( is_array( $v ) ) {
		return '';
	}
	$v = trim( (string) $v );
	if ( function_exists( 'mb_substr' ) && mb_strlen( $v, 'UTF-8' ) > $max ) {
		$v = mb_substr( $v, 0, $max, 'UTF-8' );
	}
	return $v;
}

/** 2.20.0 (owner): the app's unified registration interests (M107 list) — Arabic label + English label.
 * The forms SEND the Arabic labels (joined by «، ») so the admin mail and dashboard stay Arabic. */
function vai_interest_options() {
	return array(
		array( 'ريادة الأعمال والشركات الناشئة', 'Entrepreneurship & Startups' ),
		array( 'التقنية والذكاء الاصطناعي', 'Technology & AI' ),
		array( 'الاستثمار والتمويل والأسواق المالية', 'Investment, Finance & Markets' ),
		array( 'العقار والإنشاءات', 'Real Estate & Construction' ),
		array( 'التجارة والتجزئة والتجارة الإلكترونية', 'Trade, Retail & E-commerce' ),
		array( 'الصناعة واللوجستيات', 'Industry & Logistics' ),
		array( 'السياحة والترفيه والرياضة', 'Tourism, Entertainment & Sports' ),
		array( 'الصحة والتعليم', 'Health & Education' ),
		array( 'الطاقة والتعدين', 'Energy & Mining' ),
		array( 'أخرى', 'Other' ),
	);
}
