<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Hub-only:
 *  - Paymob "transaction processed" callback: verify HMAC → match payer (phone/e-mail) → activate membership / record service purchase.
 *  - Mail queue with throttling (one e-mail every 5 minutes = 12/hour) used for member e-mails, weekly reminders and campaigns.
 */
class VAI_Payments {

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_filter( 'cron_schedules', array( __CLASS__, 'schedules' ) );
		add_action( 'vai_mail_tick', array( __CLASS__, 'mail_tick' ) );
		add_action( 'vai_weekly_members', array( __CLASS__, 'weekly_members' ) ); // manual button only (2.15.1)
		add_action( 'vai_rematch_payments', array( __CLASS__, 'rematch_payments' ) );
		if ( ! wp_next_scheduled( 'vai_rematch_payments' ) ) {
			wp_schedule_event( time() + 900, 'hourly', 'vai_rematch_payments' );
		}
		if ( ! wp_next_scheduled( 'vai_mail_tick' ) ) {
			wp_schedule_event( time() + 120, 'vai_5min', 'vai_mail_tick' );
		}
		// 2.15.1 (owner: «ناس كتير اشتكت من كتر الإيميلات»): NOTHING mails itself — every send is a button.
		// Both automatic schedules are cleared here so a live site stops the moment it upgrades.
		if ( wp_next_scheduled( 'vai_weekly_members' ) ) {
			wp_clear_scheduled_hook( 'vai_weekly_members' );
		}
		if ( wp_next_scheduled( 'vai_broadcast' ) ) {
			wp_clear_scheduled_hook( 'vai_broadcast' );
		}
	}

	public static function schedules( $s ) {
		$s['vai_5min'] = array( 'interval' => 300, 'display' => 'Vibes AI mail tick (5 min)' );
		$s['vai_2days'] = array( 'interval' => 172800, 'display' => 'Vibes AI broadcast (2 days)' );
		return $s;
	}

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'vai_mail_queue';
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$t = self::table();
		$c = $wpdb->get_charset_collate();
		dbDelta(
			"CREATE TABLE $t (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				contact_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				to_email VARCHAR(190) NOT NULL DEFAULT '',
				subject VARCHAR(255) NOT NULL DEFAULT '',
				body LONGTEXT NULL,
				kind VARCHAR(30) NOT NULL DEFAULT 'campaign',
				batch VARCHAR(40) NOT NULL DEFAULT '',
				status VARCHAR(12) NOT NULL DEFAULT 'pending',
				attempts TINYINT NOT NULL DEFAULT 0,
				created_at DATETIME NULL,
				sent_at DATETIME NULL,
				PRIMARY KEY  (id),
				KEY status (status),
				KEY batch (batch)
			) $c;"
		);
		$tt = $wpdb->prefix . 'vai_tickets';
		dbDelta(
			"CREATE TABLE $tt (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				ref VARCHAR(20) NOT NULL DEFAULT '',
				contact_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				name VARCHAR(190) NOT NULL DEFAULT '',
				phone VARCHAR(40) NOT NULL DEFAULT '',
				email VARCHAR(190) NOT NULL DEFAULT '',
				event_title VARCHAR(255) NOT NULL DEFAULT '',
				event_date VARCHAR(120) NOT NULL DEFAULT '',
				event_place VARCHAR(190) NOT NULL DEFAULT '',
				source VARCHAR(30) NOT NULL DEFAULT '',
				checked_in TINYINT NOT NULL DEFAULT 0,
				created_at DATETIME NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY ref (ref)
			) $c;"
		);
		$pt = $wpdb->prefix . 'vai_payments';
		dbDelta(
			"CREATE TABLE $pt (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				txn_id VARCHAR(40) NOT NULL DEFAULT '',
				order_id VARCHAR(40) NOT NULL DEFAULT '',
				amount_cents BIGINT NOT NULL DEFAULT 0,
				currency VARCHAR(8) NOT NULL DEFAULT '',
				success TINYINT NOT NULL DEFAULT 0,
				action VARCHAR(30) NOT NULL DEFAULT '',
				name VARCHAR(190) NOT NULL DEFAULT '',
				phone VARCHAR(40) NOT NULL DEFAULT '',
				email VARCHAR(190) NOT NULL DEFAULT '',
				contact_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				note VARCHAR(255) NOT NULL DEFAULT '',
				created_at DATETIME NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY txn (txn_id)
			) $c;"
		);
	}

	/* ───────────── Paymob ───────────── */

	public static function routes() {
		register_rest_route(
			'vibes-ai/v1',
			'/paymob/callback',
			array(
				'methods'             => array( 'POST', 'GET' ),
				'permission_callback' => '__return_true',
				'callback'            => array( __CLASS__, 'paymob_callback' ),
			)
		);
		// 2.8.0 (M45): the pay page posts here; the plugin creates the Paymob intention itself so the
		// payer's name/phone/e-mail travel with the payment and the EXISTING callback matches him.
		register_rest_route(
			'vibes-ai/v1',
			'/paymob/start',
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'callback'            => array( __CLASS__, 'paymob_start' ),
			)
		);
		// 2.15.2: step 2 of the pay-page registration — the e-mail code proves the payer owns the typed address.
		register_rest_route(
			'vibes-ai/v1',
			'/paymob/confirm',
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'callback'            => array( __CLASS__, 'paymob_confirm' ),
			)
		);
	}

	/** Paymob transaction HMAC: SHA512 over a fixed field order. */
	public static function paymob_hmac( $obj ) {
		$pick = function ( $arr, $path, $default = '' ) {
			$cur = $arr;
			foreach ( explode( '.', $path ) as $k ) {
				if ( ! is_array( $cur ) || ! array_key_exists( $k, $cur ) ) {
					return $default;
				}
				$cur = $cur[ $k ];
			}
			if ( is_bool( $cur ) ) {
				return $cur ? 'true' : 'false';
			}
			return $cur === null ? $default : (string) $cur;
		};
		$fields = array( 'amount_cents', 'created_at', 'currency', 'error_occured', 'has_parent_transaction', 'id', 'integration_id', 'is_3d_secure', 'is_auth', 'is_capture', 'is_refunded', 'is_standalone_payment', 'is_voided', 'order.id', 'owner', 'pending', 'source_data.pan', 'source_data.sub_type', 'source_data.type', 'success' );
		$str    = '';
		foreach ( $fields as $f ) {
			$str .= $pick( $obj, $f );
		}
		return hash_hmac( 'sha512', $str, trim( (string) vai_opt( 'paymob_hmac', '' ) ) );
	}

	public static function paymob_callback( WP_REST_Request $req ) {
		nocache_headers();
		$raw  = (string) $req->get_body();
		$data = json_decode( $raw, true );
		$obj  = is_array( $data ) && isset( $data['obj'] ) ? $data['obj'] : ( is_array( $data ) ? $data : array() );
		$hmac = strtolower( (string) $req->get_param( 'hmac' ) );
		$key  = trim( (string) vai_opt( 'paymob_hmac', '' ) );
		if ( $key === '' ) {
			update_option( 'vai_last_paymob', array( 'at' => vai_now(), 'ok' => 0, 'msg' => 'وصل إشعار Paymob لكن مفتاح HMAC غير محفوظ في الإعدادات' ), false );
			return new WP_REST_Response( array( 'ok' => false, 'error' => 'hmac_not_configured' ), 400 );
		}
		if ( ! $obj || ! isset( $obj['id'] ) ) {
			return new WP_REST_Response( array( 'ok' => false, 'error' => 'bad_payload' ), 400 );
		}
		$calc = self::paymob_hmac( $obj );
		if ( $hmac === '' || ! hash_equals( $calc, $hmac ) ) {
			update_option( 'vai_last_paymob', array( 'at' => vai_now(), 'ok' => 0, 'msg' => 'إشعار Paymob مرفوض: توقيع HMAC غير مطابق (تأكد من نسخ مفتاح HMAC كاملًا)' ), false );
			return new WP_REST_Response( array( 'ok' => false, 'error' => 'bad_hmac' ), 403 );
		}
		$res = self::handle_transaction( $obj );
		update_option( 'vai_last_paymob', array( 'at' => vai_now(), 'ok' => 1, 'msg' => $res['msg'] ), false );
		return array( 'ok' => true, 'result' => $res['msg'] );
	}

	/* ───────────── the site's own pay page (2.8.0, M45) ─────────────
	 * The plugin starts the payment itself (Paymob Intention API) with the payer's name, phone and
	 * e-mail, so the EXISTING callback above — its URL and the old static links untouched — receives a
	 * payment it can always match and activate. notification_url is set per payment to this site's
	 * callback, so it never depends on what the chosen integration id has configured elsewhere. */

	const PAYMOB_BASE = 'https://ksa.paymob.com';

	/** Integration ids from the settings: "28390" or comma separated. */
	public static function pay_methods() {
		$out = array();
		foreach ( explode( ',', (string) vai_opt( 'paymob_methods', '' ) ) as $p ) {
			$p = trim( $p );
			if ( $p !== '' && ctype_digit( $p ) ) {
				$out[] = (int) $p;
			}
		}
		return $out;
	}

	/** 2.10.1/2.10.2 interim (owner, 2026-09-23 night: «خلي الزرار يحول مباشرة على الدفع» + «في اكتر من رابط —
	 * دي خدمات كتير»): while Paymob keeps the Intention API off for this account, the pay button hands the visitor
	 * to the service's own DIRECT payment link. The setting is one line per service — `key | https://…` (keys from
	 * the amounts table) — and a line holding only a URL is the default for the rest. Any line = direct mode wins
	 * over the intention keys and services WITHOUT a link leave the page (never a wrong-amount link); emptied
	 * after Paymob's fix = the page is back fully automatic. */
	private static function pay_direct_map() {
		$map = array( 'default' => '', 'keys' => array() );
		foreach ( preg_split( '/\r\n|\r|\n/', (string) vai_opt( 'paymob_direct', '' ) ) as $line ) {
			$line = trim( $line );
			if ( $line === '' ) {
				continue;
			}
			// 2.10.3: pairs are read wherever they stand in the line — sanitize_text_field once glued the saved
			// lines into one (the 2.10.2 admin bug), and a glued value must still read as ALL its pairs.
			if ( preg_match_all( '#([a-z0-9_]+)\s*\|\s*(https://[^\s|]+)#i', $line, $pairs, PREG_SET_ORDER ) ) {
				foreach ( $pairs as $p ) {
					$map['keys'][ strtolower( $p[1] ) ] = $p[2];
				}
			} elseif ( strpos( $line, '|' ) === false && preg_match( '#^https://\S+$#', $line ) ) {
				$map['default'] = $line;
			}
		}
		return $map;
	}

	/** The direct link for one service key ('' = only the default), or '' when that service has none. */
	public static function pay_direct_url( $key = '' ) {
		$map = self::pay_direct_map();
		$key = strtolower( (string) $key );
		if ( $key !== '' && isset( $map['keys'][ $key ] ) ) {
			return $map['keys'][ $key ];
		}
		return $map['default'];
	}

	/** True while ANY direct line is saved — the interim mode that replaces the broken Intention start. */
	public static function pay_direct_mode() {
		$map = self::pay_direct_map();
		return $map['default'] !== '' || $map['keys'] !== array();
	}

	/** True once the owner saved the live keys + integration id (or an interim direct link) — else the page says payment is closed. */
	public static function pay_ready() {
		if ( self::pay_direct_mode() ) {
			return true;
		}
		return trim( (string) vai_opt( 'paymob_secret', '' ) ) !== '' && trim( (string) vai_opt( 'paymob_public', '' ) ) !== '' && self::pay_methods() !== array();
	}

	/** The amounts table as purchasable items — the same source the callback matches against.
	 * 2.10.2: in direct-interim mode only services that HAVE a direct link (their own or the default) are offered —
	 * a fixed-amount link for another service must never be reachable from the wrong item. */
	public static function pay_items() {
		$direct = self::pay_direct_mode();
		$out    = array();
		foreach ( vai_paymob_amounts() as $cents => $row ) {
			if ( (int) $cents > 0 && $row['key'] !== '' && ( ! $direct || self::pay_direct_url( $row['key'] ) !== '' ) ) {
				$out[] = array( 'key' => $row['key'], 'label' => $row['label'], 'cents' => (int) $cents );
			}
		}
		return $out;
	}

	public static function pay_item( $key ) {
		foreach ( self::pay_items() as $item ) {
			if ( $item['key'] === $key ) {
				return $item;
			}
		}
		return null;
	}

	/** The signed-in visitor behind a `vai_uuid` (the widget's cookie): his contact row, or null. */
	public static function contact_by_uuid( $uuid ) {
		global $wpdb;
		$uuid = preg_replace( '/[^a-zA-Z0-9\-]/', '', (string) $uuid );
		if ( strlen( $uuid ) < 8 ) {
			return null;
		}
		$cid = $wpdb->get_var( $wpdb->prepare( 'SELECT contact_id FROM ' . VAI_Hub::t( 'visitors' ) . ' WHERE uuid=%s ORDER BY last_at DESC LIMIT 1', $uuid ) );
		$c   = $cid ? VAI_Hub::contact( (int) $cid ) : null;
		// «عنده حساب» = a verified contact with a password; anyone else goes through the register-and-pay form.
		return ( $c && (int) $c->verified && ! empty( $c->pass_hash ) ) ? $c : null;
	}

	/** 2.12.0: a real human name — at least two words, letters only, no digits and no keyboard mash. */
	private static function real_name( $name ) {
		$name = trim( preg_replace( '/\\s+/u', ' ', (string) $name ) );
		if ( mb_strlen( $name, 'UTF-8' ) < 5 || preg_match( '/[0-9\x{0660}-\x{0669}]/u', $name ) ) {
			return false;
		}
		$words = preg_split( '/\\s/u', $name );
		if ( count( $words ) < 2 ) {
			return false;
		}
		foreach ( $words as $w ) {
			if ( ! preg_match( '/^[\\p{Arabic}A-Za-z][\\p{Arabic}A-Za-z\x{2019}.-]*$/u', $w ) || preg_match( '/(.)\\1{3,}/u', $w ) ) {
				return false;
			}
			if ( preg_match( '/[bcdfghjklmnpqrstvwxz]{5,}/i', $w ) ) {
				return false; // latin keyboard mash: five consonants in a row never happen in a real name
			}
		}
		return true;
	}

	/** 2.12.0 (owner: «يتسجل دخول أوتوماتيك»): the payer's browser uuid becomes his signed-in widget
	 * session the moment the SIGNED callback confirms the payment — he returns from checkout already in. */
	private static function bind_uuid_to_contact( $uuid, $contact_id ) {
		global $wpdb;
		$uuid = preg_replace( '/[^a-zA-Z0-9\-]/', '', (string) $uuid );
		if ( strlen( $uuid ) < 8 || ! $contact_id ) {
			return;
		}
		$vt  = VAI_Hub::t( 'visitors' );
		$now = vai_now();
		$hit = $wpdb->query( $wpdb->prepare( "UPDATE $vt SET contact_id=%d, last_at=%s WHERE uuid=%s", (int) $contact_id, $now, $uuid ) );
		if ( ! $hit ) {
			$hub = $wpdb->get_row( 'SELECT id FROM ' . VAI_Hub::t( 'sites' ) . ' WHERE is_self=1 ORDER BY id ASC LIMIT 1' );
			$wpdb->insert( $vt, array( 'uuid' => $uuid, 'site_id' => $hub ? (int) $hub->id : 0, 'contact_id' => (int) $contact_id, 'first_at' => $now, 'last_at' => $now ) );
		}
	}

	/** 2.12.0: the فئة/الوظيفة/النبذة typed on the pay page land on the account the callback created. */
	private static function apply_profile_extras( $contact_id, $held ) {
		global $wpdb;
		if ( ! $contact_id || ! is_array( $held ) ) {
			return;
		}
		$upd = array();
		if ( ! empty( $held['persona'] ) && in_array( $held['persona'], array( 'neutral', 'entrepreneur', 'investor' ), true ) ) {
			$upd['persona'] = $held['persona'];
		}
		if ( ! empty( $held['job'] ) ) {
			$upd['job_title'] = mb_substr( (string) $held['job'], 0, 150, 'UTF-8' );
		}
		if ( ! empty( $held['bio'] ) ) {
			$upd['bio'] = mb_substr( (string) $held['bio'], 0, 600, 'UTF-8' );
		}
		// 2.18.2 (M69): «فرد / شركة» typed on the pay page lands on the account like the widget's.
		if ( ! empty( $held['member_type'] ) && in_array( $held['member_type'], array( 'individual', 'company' ), true ) ) {
			$upd['member_type'] = $held['member_type'];
		}
		if ( ! empty( $held['company'] ) ) {
			$upd['company'] = mb_substr( (string) $held['company'], 0, 190, 'UTF-8' );
		}
		// 2.20.0: the pay-page registration interests land on the account like the widget's and the app's.
		if ( ! empty( $held['interests'] ) ) {
			$upd['interests'] = mb_substr( (string) $held['interests'], 0, 300, 'UTF-8' );
		}
		if ( $upd ) {
			$wpdb->update( VAI_Hub::t( 'contacts' ), $upd, array( 'id' => (int) $contact_id ) );
		}
	}

	/**
	 * POST → {ok, url}: the hosted checkout for THIS payer.
	 * Account mode {item, uuid}: the payer is the signed-in account — identity comes from the server, nothing retyped.
	 * Register mode {item, name, phone, email, password}: the page IS the registration — since 2.15.2 the account
	 * is created AT ONCE (welcome mail + owner notification), and the verified callback only activates the membership.
	 */
	public static function paymob_start( WP_REST_Request $req ) {
		nocache_headers();
		if ( ! self::pay_ready() ) {
			return new WP_REST_Response( array( 'ok' => false, 'error' => 'off', 'text' => 'الدفع غير متاح حاليًا — تواصل مع الإدارة' ), 503 );
		}
		// Honeypot: a filled "website" field is a bot.
		if ( trim( (string) $req->get_param( 'website' ) ) !== '' ) {
			return new WP_REST_Response( array( 'ok' => false, 'error' => 'invalid', 'text' => 'تعذّر بدء الدفع' ), 400 );
		}
		$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '';
		$tk  = 'vai_paystart_' . md5( $ip );
		$hit = (int) get_transient( $tk );
		if ( $hit >= 12 ) {
			return new WP_REST_Response( array( 'ok' => false, 'error' => 'rate', 'text' => 'محاولات كثيرة — حاول بعد قليل' ), 429 );
		}
		set_transient( $tk, $hit + 1, HOUR_IN_SECONDS );
		$item = self::pay_item( preg_replace( '/[^a-z0-9_]/', '', strtolower( (string) $req->get_param( 'item' ) ) ) );
		if ( ! $item ) {
			return new WP_REST_Response( array( 'ok' => false, 'error' => 'invalid', 'text' => 'اختر الخدمة المطلوبة' ), 400 );
		}
		$ref    = 'vaipay-' . time() . '-' . strtolower( vai_key( 6 ) );
		$direct = self::pay_direct_url( $item['key'] );

		$acc = self::contact_by_uuid( (string) $req->get_param( 'uuid' ) );
		if ( $acc ) {
			// 2.12.0: a Google-born (or legacy) account without جوال/فئة completes them here, strictly, before paying.
			global $wpdb;
			$enA  = (string) $req->get_param( 'lang' ) === 'en';
			$badA = function ( $ar, $enTxt ) use ( $enA ) {
				return new WP_REST_Response( array( 'ok' => false, 'error' => 'invalid', 'text' => $enA ? $enTxt : $ar ), 400 );
			};
			$updA          = array();
			$acc_needs_all = trim( (string) $acc->phone_norm ) === '';
			if ( $acc_needs_all ) {
				$countryA = strtolower( preg_replace( '/[^a-z]/', '', (string) $req->get_param( 'country' ) ) ) ?: 'sa';
				$pnA      = vai_phone_intl( $countryA, (string) $req->get_param( 'phone' ) );
				if ( $pnA === '' ) {
					$ccA = vai_gcc_countries();
					$exA = isset( $ccA[ $countryA ] ) && $ccA[ $countryA ]['example'] !== '' ? $ccA[ $countryA ]['example'] : '';
					return $badA( 'أكمل حسابك أولًا: رقم الجوال غير صحيح' . ( $exA !== '' ? ' — مثال: ' . $exA : '' ), 'Complete your account first: invalid mobile' . ( $exA !== '' ? ' — example: ' . $exA : '' ) );
				}
				$dupA = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . VAI_Hub::t( 'contacts' ) . " WHERE phone_norm=%s AND pass_hash<>'' AND id<>%d LIMIT 1", $pnA, $acc->id ) );
				if ( $dupA ) {
					return $badA( 'هذا الجوال مسجّل لحساب آخر — ادخل بذلك الحساب أو تواصل مع الإدارة', 'This mobile belongs to another account — sign in with it or contact management' );
				}
				$updA['phone']      = vai_phone_local( $pnA );
				$updA['phone_norm'] = $pnA;
			}
			if ( $acc_needs_all && ! in_array( (string) $acc->persona, array( 'neutral', 'entrepreneur', 'investor' ), true ) ) {
				$perA = preg_replace( '/[^a-z]/', '', strtolower( (string) $req->get_param( 'persona' ) ) );
				if ( ! in_array( $perA, array( 'neutral', 'entrepreneur', 'investor' ), true ) ) {
					return $badA( 'أكمل حسابك أولًا: اختر فئتك في النادي', 'Complete your account first: choose your club category' );
				}
				$updA['persona'] = $perA;
				$bioA = sanitize_textarea_field( mb_substr( (string) $req->get_param( 'bio' ), 0, 600, 'UTF-8' ) );
				if ( mb_strlen( trim( $bioA ), 'UTF-8' ) >= 10 ) {
					$updA['bio'] = $bioA;
				}
			}
			if ( $updA ) {
				$wpdb->update( VAI_Hub::t( 'contacts' ), $updA, array( 'id' => (int) $acc->id ) );
				$acc = VAI_Hub::contact( (int) $acc->id );
			}
			if ( $direct !== '' ) {
				// Interim: his account already matches the callback by phone/e-mail — just hand him the direct link.
				return array( 'ok' => true, 'url' => $direct, 'mode' => 'account', 'direct' => 1 );
			}
			// Account mode: billing data from HIS account — nothing retyped, the callback matches him for sure.
			$url = self::create_intention( $item, (string) $acc->name, (string) ( $acc->phone_norm ?: $acc->phone ), (string) $acc->email, $ref );
			if ( ! $url ) {
				return new WP_REST_Response( array( 'ok' => false, 'error' => 'gateway', 'text' => 'تعذّر الاتصال ببوابة الدفع الآن — حاول بعد قليل أو تواصل مع الإدارة' ), 502 );
			}
			return array( 'ok' => true, 'url' => $url, 'mode' => 'account' );
		}

		// Register mode 2.12.0 (owner: «ميعديش حد من غير بيانات حقيقية»): FULL data with the widget's own
		// strictness — GCC phone patterns, the e-mail domain policy, a real two-word name, فئة and نبذة —
		// all held aside until the SIGNED callback proves the payment (rule 5).
		$en      = (string) $req->get_param( 'lang' ) === 'en';
		$name    = sanitize_text_field( (string) $req->get_param( 'name' ) );
		$country = strtolower( preg_replace( '/[^a-z]/', '', (string) $req->get_param( 'country' ) ) ) ?: 'sa';
		$email   = vai_norm_email( sanitize_text_field( (string) $req->get_param( 'email' ) ) );
		$pass    = (string) $req->get_param( 'password' );
		$persona = preg_replace( '/[^a-z]/', '', strtolower( (string) $req->get_param( 'persona' ) ) );
		$job     = sanitize_text_field( mb_substr( (string) $req->get_param( 'job' ), 0, 150, 'UTF-8' ) );
		$bio     = sanitize_textarea_field( mb_substr( (string) $req->get_param( 'bio' ), 0, 600, 'UTF-8' ) );
		// 2.18.2 (M69): «فرد / شركة» — a missing or unknown value means فرد, so older pages keep working.
		$mtype   = preg_replace( '/[^a-z]/', '', strtolower( (string) $req->get_param( 'member_type' ) ) );
		$mtype   = in_array( $mtype, array( 'individual', 'company' ), true ) ? $mtype : 'individual';
		$cname   = sanitize_text_field( mb_substr( (string) $req->get_param( 'company_name' ), 0, 190, 'UTF-8' ) );
		// 2.20.0 (owner): the app's registration interests are mandatory on the site too — Arabic labels, ready for the admin mail.
		$ints    = sanitize_text_field( mb_substr( (string) $req->get_param( 'interests' ), 0, 300, 'UTF-8' ) );
		$bad     = function ( $ar, $enTxt ) use ( $en ) {
			return new WP_REST_Response( array( 'ok' => false, 'error' => 'invalid', 'text' => $en ? $enTxt : $ar ), 400 );
		};
		if ( ! self::real_name( $name ) ) {
			return $bad( 'اكتب اسمك الحقيقي الثنائي (الاسم واسم العائلة) بالحروف فقط', 'Write your real full name (first and family name), letters only' );
		}
		if ( 'company' === $mtype && mb_strlen( trim( $cname ), 'UTF-8' ) < 2 ) {
			return $bad( 'اكتب اسم الشركة لإكمال التسجيل', 'Enter the company name to continue' );
		}
		if ( 'individual' === $mtype ) {
			$cname = '';
		}
		$phone = vai_phone_intl( $country, (string) $req->get_param( 'phone' ) );
		if ( $phone === '' ) {
			$cc = vai_gcc_countries();
			$ex = isset( $cc[ $country ] ) && $cc[ $country ]['example'] !== '' ? $cc[ $country ]['example'] : '';
			return $bad( 'رقم الجوال غير صحيح لدولتك — اكتبه بدون رمز الدولة' . ( $ex !== '' ? ' بهذا الشكل: ' . $ex : '' ), 'Invalid mobile number for your country — write it without the country code' . ( $ex !== '' ? ', like: ' . $ex : '' ) );
		}
		if ( $email === '' || ! is_email( $email ) || ! vai_email_allowed( $email ) ) {
			return $bad( 'البريد الإلكتروني غير صحيح — اكتب بريدك الحقيقي (أي بريد شخصي أو بريد شركة مقبول)', 'Invalid e-mail — use your real address (any personal or company mail is accepted)' );
		}
		if ( ! in_array( $persona, array( 'neutral', 'entrepreneur', 'investor' ), true ) ) {
			return $bad( 'اختر فئتك في النادي: محايد، رائد أعمال، أو مستثمر', 'Choose your club category: Neutral, Entrepreneur, or Investor' );
		}
		if ( mb_strlen( trim( $bio ), 'UTF-8' ) < 10 ) {
			return $bad( 'اكتب نبذة مختصرة حقيقية عنك (سطر على الأقل)', 'Write a short real bio about yourself (at least one line)' );
		}
		if ( trim( $ints ) === '' ) {
			return $bad( 'اختر اهتمامًا واحدًا على الأقل (حتى 3)', 'Pick at least one interest (up to 3)' );
		}
		if ( strlen( $pass ) < 6 || strlen( $pass ) > 100 ) {
			return $bad( 'كلمة المرور 6 أحرف على الأقل — بها تدخل حسابك بعد الدفع', 'Password: at least 6 characters — you will sign in with it after paying' );
		}
		// 2.15.2 (owner: «اللي يسجّل يوصلني فورًا إشعار بالتسجيل، ويكون فورًا معانا، ويقدر يفعّل من نفس الصفحة»
		// + «نتأكد إن هو صاحب الحساب اللي بيحجز»): the account is HELD the moment the form is sent and a 4-digit
		// code goes to the typed e-mail; /paymob/confirm proves ownership, completes the account (welcome mail +
		// instant owner notice) and only THEN opens the checkout. The signed callback stays the only membership
		// activator (rule 5), and an abandoned payment no longer loses the registration.
		global $wpdb;
		$dup = $wpdb->get_row( $wpdb->prepare( 'SELECT email_norm, phone_norm FROM ' . VAI_Hub::t( 'contacts' ) . " WHERE (phone_norm=%s OR email_norm=%s) AND pass_hash<>'' LIMIT 1", $phone, $email ) );
		if ( $dup ) {
			$ch = (string) $dup->email_norm === $email ? 'البريد' : 'الجوال';
			return $bad( 'هذا ' . $ch . ' مسجّل بالفعل بحساب له كلمة مرور — افتح المساعد من أيقونته أسفل الموقع وسجّل الدخول ثم ارجع لهذه الصفحة، أو استخدم «نسيت كلمة المرور»', 'This ' . ( $ch === 'البريد' ? 'e-mail' : 'mobile' ) . ' already belongs to an account with a password — open the assistant (bottom icon), sign in and come back, or use "Forgot password".' );
		}
		$held = VAI_Hub::pay_hold_contact( $name, $phone, $email, $en ? 'en' : '' );
		if ( is_wp_error( $held ) ) {
			return $bad( $held->get_error_message(), 'This mobile is registered under another e-mail — use that same e-mail or contact management.' );
		}
		if ( ! $held ) {
			return new WP_REST_Response( array( 'ok' => false, 'error' => 'invalid', 'text' => 'تعذّر بدء التسجيل — تواصل مع الإدارة' ), 500 );
		}
		$sent  = VAI_Hub::pay_issue_code( (int) $held->id );
		$token = strtolower( vai_key( 24 ) );
		set_transient(
			'vai_payconf_' . $token,
			array(
				'contact_id' => (int) $held->id,
				'item'       => $item['key'],
				'name'       => $name,
				'pass_hash'  => wp_hash_password( $pass ),
				'persona'    => $persona,
				'job'        => $job,
				'bio'        => $bio,
				'member_type' => $mtype,
				'company'     => $cname,
				'interests'   => $ints,
				'lang'        => $en ? 'en' : '',
				'uuid'       => preg_replace( '/[^a-zA-Z0-9\-]/', '', (string) $req->get_param( 'uuid' ) ),
			),
			HOUR_IN_SECONDS
		);
		return array(
			'ok'      => true,
			'pending' => true,
			'token'   => $token,
			'email'   => (string) $email,
			'text'    => $sent ? ( $en ? 'We sent a 4-digit code to ' . $email . ' — type it below to confirm it is really you, then continue to payment.' : 'أرسلنا رمزًا من 4 أرقام إلى ' . $email . ' — اكتبه بالأسفل لنتأكد أنك صاحب البريد، ثم تكمل الدفع مباشرة.' ) : ( $en ? 'Could not send the code — try again or contact management.' : 'تعذّر إرسال الرمز — حاول من جديد أو تواصل مع الإدارة' ),
		);
	}

	/** 2.15.2: step 2 of the pay-page registration — the e-mail code proves ownership, the account completes, the checkout opens. */
	public static function paymob_confirm( WP_REST_Request $req ) {
		nocache_headers();
		$en    = (string) $req->get_param( 'lang' ) === 'en';
		$err   = function ( $code, $ar, $enTxt, $status = 400 ) use ( $en ) {
			return new WP_REST_Response( array( 'ok' => false, 'error' => $code, 'text' => $en ? $enTxt : $ar ), $status );
		};
		$token = preg_replace( '/[^a-z0-9]/', '', strtolower( (string) $req->get_param( 'token' ) ) );
		$held  = $token !== '' ? get_transient( 'vai_payconf_' . $token ) : false;
		if ( ! is_array( $held ) || empty( $held['contact_id'] ) ) {
			return $err( 'expired', 'انتهت صلاحية هذه الخطوة — ارجع واملأ البيانات من جديد', 'This step expired — go back and fill the form again' );
		}
		$cid = (int) $held['contact_id'];
		if ( $req->get_param( 'resend' ) ) {
			if ( get_transient( 'vai_payconf_rs_' . $cid ) ) {
				return $err( 'rate', 'أعدنا الإرسال قبل قليل — انتظر دقيقة', 'Just resent — wait a minute', 429 );
			}
			set_transient( 'vai_payconf_rs_' . $cid, 1, MINUTE_IN_SECONDS );
			$sent = VAI_Hub::pay_issue_code( $cid );
			return array( 'ok' => true, 'resent' => $sent ? 1 : 0, 'text' => $sent ? ( $en ? 'A new code is on its way to your inbox.' : 'رمز جديد في طريقه إلى بريدك الآن.' ) : ( $en ? 'Could not send the code — contact management.' : 'تعذّر إرسال الرمز — تواصل مع الإدارة' ) );
		}
		$tries = (int) get_transient( 'vai_payconf_try_' . $cid );
		if ( $tries >= 8 ) {
			return $err( 'rate', 'محاولات كثيرة — أعد إرسال رمز جديد بعد قليل', 'Too many attempts — resend a new code shortly', 429 );
		}
		set_transient( 'vai_payconf_try_' . $cid, $tries + 1, 15 * MINUTE_IN_SECONDS );
		if ( ! VAI_Hub::pay_check_code( $cid, (string) $req->get_param( 'code' ) ) ) {
			return $err( 'bad_code', 'الرمز غير صحيح أو انتهت صلاحيته', 'Wrong or expired code' );
		}
		delete_transient( 'vai_payconf_' . $token );
		delete_transient( 'vai_payconf_try_' . $cid );
		$c = VAI_Hub::contact( $cid );
		// Ownership proven: NOW the password lands, the welcome mail goes out, and the owner hears about the registration.
		$nc = VAI_Hub::create_account_for( (string) ( $c->name ?: $held['name'] ), (string) $c->phone_norm, (string) $c->email_norm, false, 'paypage', (string) $held['pass_hash'], isset( $held['lang'] ) ? (string) $held['lang'] : '' );
		if ( ! $nc ) {
			return $err( 'invalid', 'تعذّر إكمال الحساب — تواصل مع الإدارة', 'Could not complete the account — contact management', 500 );
		}
		self::apply_profile_extras( (int) $nc->id, array( 'persona' => (string) $held['persona'], 'job' => (string) $held['job'], 'bio' => (string) $held['bio'], 'member_type' => isset( $held['member_type'] ) ? (string) $held['member_type'] : '', 'company' => isset( $held['company'] ) ? (string) $held['company'] : '', 'interests' => isset( $held['interests'] ) ? (string) $held['interests'] : '' ) );
		self::bind_uuid_to_contact( (string) $held['uuid'], (int) $nc->id );
		$item = self::pay_item( (string) $held['item'] );
		self::notify_admin_registration( VAI_Hub::contact( (int) $nc->id ), $item ? $item['label'] : (string) $held['item'] );
		if ( ! $item ) {
			return $err( 'invalid', 'تم تأكيد حسابك ✅ لكن الخدمة لم تعد متاحة — اختر من صفحة الدفع', 'Account confirmed ✅ but the service is no longer available — pick one on the pay page' );
		}
		$direct = self::pay_direct_url( $item['key'] );
		if ( $direct !== '' ) {
			return array( 'ok' => true, 'url' => $direct, 'mode' => 'register', 'direct' => 1 );
		}
		$url = self::create_intention( $item, (string) $nc->name, (string) $nc->phone_norm, (string) $nc->email, 'vaipay-' . time() . '-' . strtolower( vai_key( 6 ) ) );
		if ( ! $url ) {
			return $err( 'gateway', 'تم تأكيد حسابك ✅ لكن تعذّر الاتصال ببوابة الدفع الآن — ادخل بحسابك وأكمل الدفع بعد قليل', 'Account confirmed ✅ but the gateway is unreachable — sign in and pay again shortly', 502 );
		}
		return array( 'ok' => true, 'url' => $url, 'mode' => 'register' );
	}

	/** 2.15.2: the owner hears about every pay-page registration AT ONCE — not only about payments. */
	private static function notify_admin_registration( $c, $service_label ) {
		if ( ! $c ) {
			return;
		}
		$personas = array( 'neutral' => 'محايد', 'entrepreneur' => 'رائد أعمال', 'investor' => 'مستثمر' );
		$emails   = array_filter( array_map( 'trim', explode( ',', (string) vai_opt( 'notify_email', get_option( 'admin_email' ) ) ) ) );
		$body     = "📝 تسجيل جديد من صفحة الدفع\n\nالاسم: " . ( $c->name ?: '—' ) . "\nالجوال: " . ( $c->phone_norm ? vai_phone_local( $c->phone_norm ) : '—' ) . "\nالبريد: " . ( $c->email ?: '—' ) . "\nالفئة: " . ( isset( $personas[ (string) $c->persona ] ) ? $personas[ (string) $c->persona ] : '—' ) . "\nالنوع: " . ( 'company' === (string) $c->member_type ? 'شركة' . ( $c->company ? ' — ' . $c->company : '' ) : 'فرد' ) . "\nالاهتمامات: " . ( isset( $c->interests ) && $c->interests !== '' ? $c->interests : '—' ) . ( isset( $c->lang ) && 'en' === (string) $c->lang ? "\nلغة التسجيل: إنجليزي" : '' ) . "\nالخدمة المختارة: " . $service_label . "\nالحالة: أنشأ حسابه وكلمة مروره وذهب لصفحة الدفع — إن لم تصلك رسالة «دفعة ناجحة» بعد قليل فلم يكمل الدفع، وحسابه محفوظ ويمكنه الدفع في أي وقت.\nالتاريخ: " . vai_riyadh( vai_now() ) . "\n\nالحسابات: " . admin_url( 'admin.php?page=vibes-ai-accounts' );
		foreach ( $emails as $e ) {
			if ( is_email( $e ) ) {
				VAI_Hub::mail( $e, '[Vibes AI] 📝 تسجيل جديد: ' . vai_clip( (string) $c->name, 40 ) . ' — ' . vai_clip( $service_label, 30 ), $body );
			}
		}
	}

	/** Creates the Paymob intention; returns the unified-checkout URL or null. Secrets never leave the options. */
	private static function create_intention( $item, $name, $phone, $email, $ref = '' ) {
		// The option exists for the local test rig only (outbound HTTP is blocked there); live sites never set it.
		$base   = trim( (string) vai_opt( 'paymob_base', '' ) ) ?: self::PAYMOB_BASE;
		$secret = trim( (string) vai_opt( 'paymob_secret', '' ) );
		$public = trim( (string) vai_opt( 'paymob_public', '' ) );
		$ref    = $ref !== '' ? $ref : 'vaipay-' . time() . '-' . strtolower( vai_key( 6 ) );
		$parts  = preg_split( '/\s+/u', trim( $name ), 2 );
		$first  = $parts[0];
		$last   = isset( $parts[1] ) && trim( $parts[1] ) !== '' ? $parts[1] : 'عميل';
		$person = array( 'first_name' => $first, 'last_name' => $last, 'email' => $email, 'phone_number' => '+' . $phone );
		$body   = array(
			'amount'            => (int) $item['cents'],
			'currency'          => 'SAR',
			'payment_methods'   => self::pay_methods(),
			'items'             => array( array( 'name' => $item['label'], 'amount' => (int) $item['cents'], 'description' => $item['key'], 'quantity' => 1 ) ),
			'billing_data'      => array_merge( $person, array( 'apartment' => 'NA', 'street' => 'NA', 'building' => 'NA', 'city' => 'Riyadh', 'country' => 'SA', 'floor' => 'NA', 'state' => 'NA' ) ),
			'customer'          => array( 'first_name' => $first, 'last_name' => $last, 'email' => $email ),
			'special_reference' => $ref,
			'expiration'        => 3600,
			'notification_url'  => rest_url( 'vibes-ai/v1/paymob/callback' ),
			'redirection_url'   => home_url( '/?vai-pay-done=1' ),
		);
		$res = wp_remote_post(
			$base . '/v1/intention/',
			array(
				'timeout' => 20,
				'headers' => array( 'Authorization' => 'Token ' . $secret, 'Content-Type' => 'application/json', 'Accept' => 'application/json' ),
				'body'    => wp_json_encode( $body ),
			)
		);
		if ( is_wp_error( $res ) ) {
			update_option( 'vai_last_paystart', array( 'at' => vai_now(), 'ok' => 0, 'msg' => 'تعذّر الاتصال ببوابة الدفع: ' . $res->get_error_message() ), false );
			return null;
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$data = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		if ( $code >= 400 || ! is_array( $data ) || empty( $data['client_secret'] ) ) {
			// 2.8.2: keep Paymob's own words (no secrets in responses) so the settings page can say WHY.
			$snippet = mb_substr( trim( wp_strip_all_tags( (string) wp_remote_retrieve_body( $res ) ) ), 0, 180, 'UTF-8' );
			update_option( 'vai_last_paystart', array( 'at' => vai_now(), 'ok' => 0, 'msg' => 'بوابة الدفع رفضت الطلب (HTTP ' . $code . ') — راجع المفاتيح ورقم الدمج في الإعدادات. رد البوابة: ' . ( $snippet !== '' ? $snippet : '—' ) ), false );
			return null;
		}
		update_option( 'vai_last_paystart', array( 'at' => vai_now(), 'ok' => 1, 'msg' => $item['label'] . ' — ' . $name ), false );
		return $base . '/unifiedcheckout/?publicKey=' . rawurlencode( $public ) . '&clientSecret=' . rawurlencode( (string) $data['client_secret'] );
	}

	/** Process a verified Paymob transaction object. */
	public static function handle_transaction( $obj ) {
		global $wpdb;
		$pt      = $wpdb->prefix . 'vai_payments';
		$txn     = (string) $obj['id'];
		$success = ! empty( $obj['success'] ) && ( $obj['success'] === true || $obj['success'] === 'true' );
		$amount  = (int) ( $obj['amount_cents'] ?? 0 );
		$cur     = (string) ( $obj['currency'] ?? '' );
		$bd      = isset( $obj['payment_key_claims']['billing_data'] ) && is_array( $obj['payment_key_claims']['billing_data'] ) ? $obj['payment_key_claims']['billing_data'] : ( isset( $obj['order']['shipping_data'] ) && is_array( $obj['order']['shipping_data'] ) ? $obj['order']['shipping_data'] : array() );
		$name    = trim( ( $bd['first_name'] ?? '' ) . ' ' . ( $bd['last_name'] ?? '' ) );
		$phone   = (string) ( $bd['phone_number'] ?? '' );
		$email   = (string) ( $bd['email'] ?? '' );
		$order   = (string) ( $obj['order']['id'] ?? '' );
		// 2.8.1 (M45): a register-and-pay profile (the password chosen on the pay page) parked under our reference —
		// applied ONLY here, after the HMAC check proved the payment (rule 5: the callback is the only truth).
		$mo      = (string) ( $obj['order']['merchant_order_id'] ?? '' );
		$payreg  = '';
		$profile = null;
		if ( strpos( $mo, 'vaipay-' ) === 0 ) {
			$held = get_transient( 'vai_payreg_' . md5( $mo ) );
			if ( $success && is_array( $held ) && ! empty( $held['pass_hash'] ) ) {
				$payreg  = (string) $held['pass_hash'];
				$profile = $held; // 2.12.0: فئة/وظيفة/نبذة typed on the page ride along
				delete_transient( 'vai_payreg_' . md5( $mo ) );
			}
		}
		if ( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $pt WHERE txn_id=%s", $txn ) ) ) {
			return array( 'msg' => 'المعاملة ' . $txn . ' مسجّلة مسبقًا' );
		}
		$map    = vai_paymob_amounts();
		$action = isset( $map[ $amount ] ) ? $map[ $amount ]['key'] : '';
		$label  = isset( $map[ $amount ] ) ? $map[ $amount ]['label'] : ( number_format( $amount / 100 ) . ' ' . $cur );
		$pn     = vai_norm_phone( $phone );
		$em     = vai_norm_email( $email );
		// 2.10.0: a placeholder e-mail (na@na.com…) never MATCHES a contact, is never STORED on one and never
		// receives account mail — otherwise the next NA-NA payment would activate whoever holds the junk address.
		// The payment ROW below keeps the raw value for the admin's review.
		$emc = vai_junk_email( $em ) ? '' : $em;
		$c   = null;
		$ct  = VAI_Hub::t( 'contacts' );
		if ( $pn !== '' || $emc !== '' ) {
			$where = array();
			$args  = array();
			if ( $pn !== '' ) {
				$where[] = 'phone_norm=%s';
				$args[]  = $pn;
			}
			if ( $emc !== '' ) {
				$where[] = 'email_norm=%s';
				$args[]  = $emc;
			}
			$c = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $ct WHERE (" . implode( ' OR ', $where ) . ") ORDER BY (pass_hash<>'') DESC, verified DESC, id ASC LIMIT 1", $args ) );
		}
		$wpdb->insert(
			$pt,
			array(
				'txn_id'       => $txn,
				'order_id'     => $order,
				'amount_cents' => $amount,
				'currency'     => $cur,
				'success'      => $success ? 1 : 0,
				'action'       => $action,
				'name'         => $name,
				'phone'        => vai_phone_local( $pn ?: $phone ),
				'email'        => $em,
				'contact_id'   => $c ? (int) $c->id : 0,
				'note'         => $label,
				'created_at'   => vai_now(),
			)
		);
		// 2.7.0: tell the app server a payment was recorded (ids only, no personal data). Queued, sent after the response.
		VAI_Hub::webhook( 'payment.recorded', array( 'id' => (int) $wpdb->insert_id, 'action' => (string) $action, 'success' => $success ? 1 : 0 ) );
		if ( ! $success ) {
			return array( 'msg' => 'معاملة غير ناجحة (' . $label . ') — لم يُتخذ إجراء' );
		}
		// 2.10.1 interim: a payment through the DIRECT link that STARTED on our pay page — the typed profile rides
		// on the payer's identity. Applied only now, after the HMAC check proved the payment; the chosen password
		// lands ONLY on an account this very callback creates, and only when BOTH channels match what he typed
		// (an existing account is matched and activated as usual, its password never touched).
		$fromPage = false;
		if ( ! $payreg ) {
			foreach ( array( $pn !== '' ? 'vai_paydirect_p_' . md5( $pn ) : '', $emc !== '' ? 'vai_paydirect_e_' . md5( $emc ) : '' ) as $dk ) {
				$held = $dk !== '' ? get_transient( $dk ) : false;
				if ( is_array( $held ) && ! empty( $held['pass_hash'] ) ) {
					$fromPage = true;
					if ( ! $c && $pn === (string) $held['phone'] && $emc === (string) $held['email'] ) {
						$payreg  = (string) $held['pass_hash'];
						$profile = $held;
					}
					delete_transient( 'vai_paydirect_p_' . md5( (string) $held['phone'] ) );
					delete_transient( 'vai_paydirect_e_' . md5( (string) $held['email'] ) );
					break;
				}
			}
		}
		$msg = '';
		if ( $payreg && $action !== 'membership' ) {
			// A register-and-pay for a service: the payment is real, so the account exists from now on (no membership).
			$c = self::apply_payreg( $c, $payreg, $name, $pn, $emc, $txn );
			if ( $c ) {
				self::apply_profile_extras( (int) $c->id, $profile );
				VAI_Hub::maybe_deferred_notify( (int) $c->id );
				self::bind_uuid_to_contact( is_array( $profile ) ? ( $profile['uuid'] ?? '' ) : '', (int) $c->id );
			}
		}
		if ( $action === 'membership' ) {
			if ( $c ) {
				self::bind_uuid_to_contact( is_array( $profile ) ? ( $profile['uuid'] ?? '' ) : '', (int) $c->id );
				VAI_Hub::member_context( 'paymob', $txn ); // history row: source paymob, reference = transaction id
				$on = VAI_Hub::set_member( $c->id, true ); // sends the benefits e-mail itself
				$c = VAI_Hub::contact( $c->id );
				if ( $payreg && empty( $c->pass_hash ) ) {
					$c = self::apply_payreg( $c, $payreg, $name, $pn, $emc, $txn );
				}
				$msg = 'تم تفعيل العضوية تلقائيًا لـ ' . ( $c->name ?: $name ) . ' (' . vai_phone_local( $c->phone_norm ) . ')';
				if ( ! $on ) {
					// 2.7.0: the database refused the change (nothing was written) — say so instead of reporting an activation.
					$msg = 'دفع العضوية من ' . ( $c->name ?: $name ) . ' (' . vai_phone_local( $c->phone_norm ) . ') — تعذّر تفعيل العضوية تلقائيًا؛ فعّلها يدويًا من صفحة الحسابات';
				}
			} elseif ( ! $payreg && vai_junk_identity( $pn, $em ) ) {
				// 2.10.0 (M45 TODO «2.8.3»): the old anonymous links send placeholder billing (NA NA / na@na.com) —
				// the money is recorded above, but no account and no password mail may grow from a ghost identity.
				$msg = 'دفعة عضوية ببيانات دفع مجهولة (' . ( $name ?: '—' ) . ' · ' . ( $em ?: '—' ) . ' · ' . ( $pn ? vai_phone_local( $pn ) : '—' ) . ') — لا يُنشأ حساب تلقائيًا؛ اعرف صاحبها وفعّل يدويًا من صفحة الحسابات';
			} else {
				// no account yet → create it now (verified) + activate membership + e-mail a set-password link; also keep the pre-approval list
				$mt = VAI_Hub::t( 'members' );
				$wpdb->insert( $mt, array( 'name' => $name, 'phone_norm' => $pn, 'email_norm' => $emc, 'source' => 'paymob', 'created_at' => vai_now() ) );
				VAI_Hub::member_context( 'paymob', $txn );
				$nc = VAI_Hub::create_account_for( $name, $pn, $emc, true, 'paymob', $payreg );
				if ( $nc ) {
					self::apply_profile_extras( (int) $nc->id, $profile );
					self::bind_uuid_to_contact( is_array( $profile ) ? ( $profile['uuid'] ?? '' ) : '', (int) $nc->id );
					$wpdb->update( $pt, array( 'contact_id' => (int) $nc->id ), array( 'txn_id' => $txn ) );
					$msg = 'دفع العضوية من ' . ( $name ?: $em ?: $pn ) . ' — أُنشئ له حساب تلقائيًا وفُعّلت عضويته، ' . ( $payreg ? 'ويدخل بكلمة المرور التي اختارها في صفحة الدفع' : 'ووصله رابط اختيار كلمة المرور' );
					if ( ! (int) $nc->is_member ) {
						$msg = 'دفع العضوية من ' . ( $name ?: $em ?: $pn ) . ' — أُنشئ له حساب تلقائيًا، لكن تعذّر تفعيل العضوية؛ فعّلها يدويًا من صفحة الحسابات';
					}
				} else {
					$msg = 'دفع العضوية من ' . ( $name ?: $em ?: $pn ) . ' — بلا بريد أو جوال في بيانات الدفع؛ يحتاج تفعيلًا يدويًا';
				}
			}
		} elseif ( $action === 'workshop' ) {
			$t   = self::issue_ticket( $name ?: ( $c ? $c->name : '' ), $pn ?: ( $c ? $c->phone_norm : '' ), $em ?: ( $c ? $c->email : '' ), $c ? (int) $c->id : 0, 'paymob' );
			$msg = 'تسجيل في ' . vai_cfg( 'event_title' ) . ' — أُصدرت تذكرة ' . $t['ref'] . ' لـ ' . ( $name ?: $em ?: $pn ) . ' وأُرسلت على بريده';
			if ( $c ) {
				VAI_Hub::insert_message( $c->id, (int) $c->last_site_id, 'system', '🎟️ تذكرة ورشة ' . $t['ref'] . ' (Paymob ' . $txn . ')' );
			}
		} elseif ( $action !== '' ) {
			$msg = 'دفع خدمة: ' . $label . ' من ' . ( $c ? $c->name : ( $name ?: $em ?: $pn ) );
			if ( $c ) {
				VAI_Hub::insert_message( $c->id, (int) $c->last_site_id, 'system', '💳 دفع عبر Paymob: ' . $label . ' (معاملة ' . $txn . ')' );
			}
			self::send_receipt_email( $name ?: ( $c ? $c->name : '' ), $em ?: ( $c ? $c->email : '' ), $label, $txn, $c );
		} else {
			$msg = 'دفعة ناجحة بمبلغ غير معروف في جدول المبالغ (' . $label . ') من ' . ( $name ?: $em ?: $pn ) . ' — راجعها';
			self::send_receipt_email( $name ?: ( $c ? $c->name : '' ), $em ?: ( $c ? $c->email : '' ), $label, $txn, $c );
		}
		if ( $fromPage ) {
			$msg .= ' — بدأ الطلب من صفحة الدفع بالموقع';
		}
		self::notify_admin_payment( $msg, $name, $pn, $em, $label, $txn );
		return array( 'msg' => $msg );
	}

	/** 2.8.1: apply the pay-page registration to the matched/created payer once the payment is REAL.
	 * Creates the account (verified, no membership) when none matched, or fills an EMPTY password —
	 * an existing password is never overwritten (payment proves the money, not the account). */
	private static function apply_payreg( $c, $pass_hash, $name, $pn, $em, $txn ) {
		global $wpdb;
		if ( ! $pass_hash ) {
			return $c;
		}
		if ( ! $c ) {
			$nc = VAI_Hub::create_account_for( $name, $pn, $em, false, 'paymob', $pass_hash );
			if ( $nc ) {
				$wpdb->update( $wpdb->prefix . 'vai_payments', array( 'contact_id' => (int) $nc->id ), array( 'txn_id' => $txn ) );
			}
			return $nc;
		}
		if ( empty( $c->pass_hash ) ) {
			$wpdb->update( VAI_Hub::t( 'contacts' ), array( 'pass_hash' => (string) $pass_hash, 'verified' => 1 ), array( 'id' => $c->id ) );
			VAI_Hub::note_verified( $c->id, 'paymob', 'pay page password' );
			$c = VAI_Hub::contact( $c->id );
			if ( $c && $c->email ) {
				if ( VAI_Hub::lang_of( $c ) === 'en' ) {
					VAI_Hub::mail( $c->email, 'Your Investors Club account is ready ✅', 'Hello ' . $c->name . ",\n\nYour payment is confirmed and your account is complete — sign in now with your e-mail " . $c->email . ( $c->phone ? ' or mobile ' . vai_phone_local( $c->phone_norm ) : '' ) . " and the password you chose on the pay page, on any ecosystem site from the assistant icon.\n\nInvestors Club — Vibes Ventures" );
				} else {
					VAI_Hub::mail( $c->email, 'حسابك في نادي المستثمرين جاهز ✅', 'مرحبًا ' . $c->name . "،\n\nتم تأكيد دفعتك واكتمل حسابك — تدخل الآن ببريدك " . $c->email . ( $c->phone ? ' أو جوالك ' . vai_phone_local( $c->phone_norm ) : '' ) . " مع كلمة المرور التي اخترتها في صفحة الدفع، على أي موقع من مواقع المنظومة من أيقونة المساعد.\n\nنادي المستثمرين — Vibes Ventures" );
				}
			}
		}
		return $c;
	}

	private static function notify_admin_payment( $msg, $name, $pn, $em, $label, $txn ) {
		$emails = array_filter( array_map( 'trim', explode( ',', (string) vai_opt( 'notify_email', get_option( 'admin_email' ) ) ) ) );
		$body   = "💳 دفعة ناجحة عبر Paymob\n\n" . $msg . "\n\nالاسم: " . ( $name ?: '—' ) . "\nالجوال: " . ( $pn ? vai_phone_local( $pn ) : '—' ) . "\nالبريد: " . ( $em ?: '—' ) . "\nالمبلغ/الخدمة: " . $label . "\nرقم المعاملة: " . $txn . "\nالتاريخ: " . vai_riyadh( vai_now() ) . "\n\nالمدفوعات: " . admin_url( 'admin.php?page=vibes-ai-mail' );
		foreach ( $emails as $e ) {
			if ( is_email( $e ) ) {
				VAI_Hub::mail( $e, '[Vibes AI] 💳 ' . vai_clip( $msg, 70 ), $body );
			}
		}
	}

	/* ───────────── event tickets ───────────── */

	public static function tickets_table() {
		global $wpdb;
		return $wpdb->prefix . 'vai_tickets';
	}

	public static function ticket_url( $ref ) {
		return home_url( '/?vai-ticket=' . rawurlencode( $ref ) );
	}

	/** Issue a ticket (reference VC-YYMM-XXXX), store it, e-mail the confirmation. */
	public static function issue_ticket( $name, $phone, $email, $contact_id = 0, $source = 'manual' ) {
		global $wpdb;
		$tt  = self::tickets_table();
		$ref = 'VC-' . gmdate( 'ym' ) . '-' . strtoupper( substr( str_replace( array( '0', 'O', 'I', '1' ), array( '7', 'K', 'M', '4' ), vai_key( 6 ) ), 0, 5 ) );
		while ( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $tt WHERE ref=%s", $ref ) ) ) {
			$ref = 'VC-' . gmdate( 'ym' ) . '-' . strtoupper( substr( vai_key( 6 ), 0, 5 ) );
		}
		$row = array(
			'ref'         => $ref,
			'contact_id'  => (int) $contact_id,
			'name'        => (string) $name,
			'phone'       => vai_phone_local( $phone ),
			'email'       => vai_norm_email( $email ),
			'event_title' => (string) vai_cfg( 'event_title' ),
			'event_date'  => (string) vai_cfg( 'event_date' ),
			'event_place' => (string) vai_cfg( 'event_place' ),
			'source'      => $source,
			'created_at'  => vai_now(),
		);
		$wpdb->insert( $tt, $row );
		$row['id'] = (int) $wpdb->insert_id;
		self::send_ticket_email( (object) $row );
		return $row;
	}

	public static function ticket( $ref ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::tickets_table() . ' WHERE ref=%s', preg_replace( '/[^A-Z0-9\-]/', '', strtoupper( (string) $ref ) ) ) );
	}

	public static function qr_url( $data, $size = 220 ) {
		return 'https://api.qrserver.com/v1/create-qr-code/?size=' . (int) $size . 'x' . (int) $size . '&margin=8&data=' . rawurlencode( $data );
	}

	public static function send_ticket_email( $t ) {
		if ( ! is_email( $t->email ) || vai_junk_email( vai_norm_email( $t->email ) ) ) {
			return false;
		}
		$url  = self::ticket_url( $t->ref );
		$qr   = self::qr_url( $url );
		$logo = esc_url( vai_cfg( 'avatar_url' ) );
		$html = '<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"></head><body style="margin:0;background:#f4f3ef;font-family:Tahoma,Arial,sans-serif;direction:rtl">'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="padding:24px 10px"><tr><td align="center">'
			. '<table role="presentation" width="520" cellpadding="0" cellspacing="0" style="max-width:520px;width:100%;background:#fff;border-radius:22px;overflow:hidden;box-shadow:0 14px 40px rgba(0,0,0,.12)">'
			. '<tr><td style="background:#000;padding:26px 24px;text-align:center;border-bottom:3px solid #B8962E"><img src="' . $logo . '" alt="" width="64" style="width:64px;height:64px;border-radius:50%;border:2px solid #B8962E;display:inline-block"><div style="color:#F3E4B5;font-size:13px;letter-spacing:2px;margin-top:10px">نادي المستثمرين — تذكرة حضور</div><div style="color:#fff;font-size:20px;font-weight:700;margin-top:6px">' . esc_html( $t->event_title ) . '</div></td></tr>'
			. '<tr><td style="padding:22px 26px 6px;color:#111;font-size:15px;line-height:1.9">'
			. '<p style="margin:0 0 10px">أهلًا <b>' . esc_html( $t->name ) . '</b> 🌹<br>تم تسجيلك بنجاح، وهذه تذكرتك:</p>'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border:1px dashed #B8962E;border-radius:14px;background:#FBF7EC"><tr><td style="padding:14px 16px;font-size:14px;line-height:1.9">'
			. '<div>🔖 الرقم المرجعي: <b style="font-size:18px;letter-spacing:1px;color:#7A6320">' . esc_html( $t->ref ) . '</b></div>'
			. '<div>📅 موعد الحضور: <b>' . esc_html( $t->event_date ) . '</b></div>'
			. '<div>📍 المكان: <b>' . esc_html( $t->event_place ) . '</b></div>'
			. '<div>📱 الجوال: <b dir="ltr">' . esc_html( $t->phone ) . '</b></div>'
			. '</td></tr></table>'
			. '<div style="text-align:center;margin:18px 0 6px"><img src="' . esc_url( $qr ) . '" alt="QR" width="180" height="180" style="width:180px;height:180px;border:6px solid #fff;border-radius:12px;box-shadow:0 6px 18px rgba(0,0,0,.12)"><div style="font-size:12px;color:#6b6861;margin-top:6px">امسح الرمز عند الدخول</div></div>'
			. '<p style="margin:14px 0 6px;font-size:13.5px;color:#333">' . esc_html( vai_cfg( 'event_note' ) ) . '</p>'
			. '<div style="text-align:center;margin:18px 0 8px"><a href="' . esc_url( $url ) . '" style="display:inline-block;background:#B8962E;color:#fff;text-decoration:none;font-weight:700;padding:13px 28px;border-radius:999px;font-size:15px">افتح تذكرتك واحفظها كصورة JPEG</a></div>'
			. '</td></tr>'
			. '<tr><td style="background:#111;color:#cfcac0;padding:14px 20px;text-align:center;font-size:12px">نادي المستثمرين — Vibes Ventures · للإدارة: <span dir="ltr">' . esc_html( vai_phone_local( vai_cfg( 'mgmt_whatsapp' ) ) ) . '</span></td></tr>'
			. '</table></td></tr></table></body></html>';
		add_filter( 'wp_mail_content_type', array( __CLASS__, 'html_type' ) );
		$ok = VAI_Hub::mail( $t->email, '🎟️ تذكرتك — ' . $t->event_title . ' — ' . $t->ref, $html );
		remove_filter( 'wp_mail_content_type', array( __CLASS__, 'html_type' ) );
		return $ok;
	}

	public static function html_type() {
		return 'text/html';
	}

	/** Public ticket page: /?vai-ticket=REF — QR + "save as JPEG". */
	public static function render_ticket_page( $ref ) {
		$t = self::ticket( $ref );
		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		header( 'X-Robots-Tag: noindex' );
		$logo = esc_url( vai_cfg( 'avatar_url' ) );
		if ( ! $t ) {
			echo '<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>التذكرة غير موجودة</title></head><body style="font-family:Tahoma,sans-serif;text-align:center;padding:60px 20px;background:#f4f3ef"><h2>التذكرة غير موجودة</h2><p>تأكد من الرابط الذي وصلك على بريدك، أو تواصل مع الإدارة.</p></body></html>';
			exit;
		}
		$url = self::ticket_url( $t->ref );
		echo '<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>تذكرة ' . esc_html( $t->ref ) . '</title>'
			. '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;600;700&display=swap">'
			. '<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script><script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>'
			. '<style>body{margin:0;background:#0d0d0d;font-family:"IBM Plex Sans Arabic",Tahoma,sans-serif;color:#111;min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:24px 12px;box-sizing:border-box}.tk{width:100%;max-width:420px;background:#fff;border-radius:26px;overflow:hidden;box-shadow:0 24px 60px rgba(0,0,0,.5)}.tk-h{background:#000;color:#fff;text-align:center;padding:26px 20px 22px;border-bottom:3px solid #B8962E}.tk-h img{width:66px;height:66px;border-radius:50%;border:2px solid #B8962E}.tk-k{color:#F3E4B5;font-size:12px;letter-spacing:3px;margin-top:10px}.tk-t{font-size:20px;font-weight:700;margin-top:6px;line-height:1.5}.tk-b{padding:20px 22px 16px}.tk-n{font-size:20px;font-weight:700;margin:0 0 12px}.tk-row{display:flex;justify-content:space-between;gap:10px;border-bottom:1px dashed #E6E4DE;padding:9px 0;font-size:14.5px}.tk-row b{color:#7A6320}.tk-ref{font-size:22px;letter-spacing:2px;color:#7A6320;font-weight:700}.tk-q{text-align:center;padding:16px 0 6px}.tk-q>div{display:inline-block;padding:10px;background:#fff;border-radius:14px;box-shadow:0 6px 18px rgba(0,0,0,.12)}.tk-note{font-size:12.5px;color:#6b6861;text-align:center;line-height:1.7;margin:8px 0 0}.tk-f{background:#111;color:#cfcac0;text-align:center;font-size:12px;padding:12px}.btn{margin-top:16px;background:#B8962E;color:#fff;border:0;border-radius:999px;padding:14px 30px;font:inherit;font-size:16px;font-weight:700;cursor:pointer;box-shadow:0 10px 26px rgba(184,150,46,.4)}.btn2{margin-top:10px;background:transparent;color:#F3E4B5;border:1px solid #B8962E;border-radius:999px;padding:10px 22px;font:inherit;font-size:14px;cursor:pointer}</style></head><body>'
			. '<div class="tk" id="tk"><div class="tk-h"><img src="' . $logo . '" alt=""><div class="tk-k">نادي المستثمرين · تذكرة حضور</div><div class="tk-t">' . esc_html( $t->event_title ) . '</div></div>'
			. '<div class="tk-b"><div class="tk-n">' . esc_html( $t->name ) . '</div>'
			. '<div class="tk-row"><span>الرقم المرجعي</span><span class="tk-ref">' . esc_html( $t->ref ) . '</span></div>'
			. '<div class="tk-row"><span>موعد الحضور</span><b>' . esc_html( $t->event_date ) . '</b></div>'
			. '<div class="tk-row"><span>المكان</span><b>' . esc_html( $t->event_place ) . '</b></div>'
			. '<div class="tk-row"><span>الجوال</span><b dir="ltr">' . esc_html( $t->phone ) . '</b></div>'
			. '<div class="tk-row"><span>تاريخ الحجز</span><b>' . esc_html( vai_riyadh( $t->created_at, 'Y-m-d' ) ) . '</b></div>'
			. '<div class="tk-q"><div id="qr"></div></div><div class="tk-note">' . esc_html( vai_cfg( 'event_note' ) ) . '</div></div>'
			. '<div class="tk-f">نادي المستثمرين — Vibes Ventures · ' . esc_html( vai_phone_local( vai_cfg( 'mgmt_whatsapp' ) ) ) . '</div></div>'
			. '<button class="btn" id="save">💾 حفظ التذكرة كصورة JPEG</button><button class="btn2" onclick="window.print()">🖨️ طباعة</button>'
			. '<script>new QRCode(document.getElementById("qr"),{text:' . wp_json_encode( $url ) . ',width:170,height:170,correctLevel:QRCode.CorrectLevel.M});'
			. 'document.getElementById("save").onclick=function(){var b=this;b.textContent="جارٍ الحفظ…";b.disabled=true;html2canvas(document.getElementById("tk"),{scale:2,useCORS:true,backgroundColor:"#ffffff"}).then(function(cv){var a=document.createElement("a");a.download=' . wp_json_encode( 'ticket-' . $t->ref . '.jpg' ) . ';a.href=cv.toDataURL("image/jpeg",0.94);document.body.appendChild(a);a.click();a.remove();b.textContent="✅ تم الحفظ";setTimeout(function(){b.textContent="💾 حفظ التذكرة كصورة JPEG";b.disabled=false;},2500);}).catch(function(){b.textContent="تعذّر الحفظ — خذ لقطة شاشة";b.disabled=false;});};</script>'
			. '</body></html>';
		exit;
	}

	/** Public pay page: /?vai-pay[=key] — pick the service, enter name/phone/e-mail, pay by card. */
	public static function render_pay_page( $preselect = '' ) {
		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		header( 'X-Robots-Tag: noindex' );
		$logo  = esc_url( vai_cfg( 'avatar_url' ) );
		$ready = self::pay_ready();
		$items = self::pay_items();
		$pre   = preg_replace( '/[^a-z0-9_]/', '', strtolower( (string) $preselect ) );
		// 2.10.0 (M47): the widget opens this same page inside a full-screen iframe on the site's own pages —
		// vai-embed turns the dark page into a translucent overlay with a close (✕) that tells the parent to shut the modal.
		$embed = isset( $_GET['vai-embed'] );
		// 2.12.0 (owner: «مهم أوي موضوع اللغة»): full English mode via ?lang=en + an in-page toggle.
		// 2.20.0: with no explicit ?lang, a visitor coming from an English page (/en/ URLs) gets English automatically.
		$en = isset( $_GET['lang'] )
			? $_GET['lang'] === 'en'
			: (bool) preg_match( '#/en(/|$)#', (string) wp_parse_url( isset( $_SERVER['HTTP_REFERER'] ) ? (string) $_SERVER['HTTP_REFERER'] : '', PHP_URL_PATH ) );
		$tr = function ( $ar, $enTxt ) use ( $en ) {
			return $en ? $enTxt : $ar;
		};
		$enLabels = array(
			'membership' => 'Annual Club Membership',
			'workshop'   => 'Intensive Workshop (member price)',
			'pitchdeck'  => 'Professional Pitch Deck (member price)',
			'urmeet'     => 'UrMeet — Your Own Forum (member price)',
		);
		$toggle_qs = '/?vai-pay=' . rawurlencode( $pre ) . ( $embed ? '&vai-embed=1' : '' ) . ( isset( $_GET['vai-pay-new'] ) ? '&vai-pay-new=1' : '' );
		$head  = '<!doctype html><html dir="' . ( $en ? 'ltr' : 'rtl' ) . '" lang="' . ( $en ? 'en' : 'ar' ) . '"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>' . ( $en ? 'Checkout — Investors Club' : 'الدفع — نادي المستثمرين' ) . '</title>'
			. '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;600;700&display=swap">'
			. '<style>body{margin:0;background:#0d0d0d;font-family:"IBM Plex Sans Arabic",Tahoma,sans-serif;color:#111;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px 12px;box-sizing:border-box}.pg{width:100%;max-width:440px;background:#fff;border-radius:26px;overflow:hidden;box-shadow:0 24px 60px rgba(0,0,0,.5)}.pg-h{background:#000;color:#fff;text-align:center;padding:24px 20px 20px;border-bottom:3px solid #B8962E}.pg-h img{width:62px;height:62px;border-radius:50%;border:2px solid #B8962E}.pg-k{color:#F3E4B5;font-size:12px;letter-spacing:3px;margin-top:10px}.pg-t{font-size:20px;font-weight:700;margin-top:6px}.pg-b{padding:20px 22px 24px}.it{display:flex;align-items:center;gap:10px;border:1.5px solid #E6E4DE;border-radius:14px;padding:12px 14px;margin-bottom:10px;cursor:pointer;transition:border-color .15s}.it.on{border-color:#B8962E;background:#FBF7EC}.it input{accent-color:#B8962E;width:18px;height:18px}.it .l{flex:1;font-size:15px;font-weight:600}.it .p{font-size:14px;color:#7A6320;font-weight:700;white-space:nowrap}label.f{display:block;font-size:13.5px;color:#555;margin:12px 2px 6px}input.v,select.v,textarea.v{width:100%;box-sizing:border-box;border:1.5px solid #E6E4DE;border-radius:12px;padding:12px 14px;font:inherit;font-size:16px;background:#fff;color:#111;resize:vertical;appearance:none;-webkit-appearance:none}select.v{background:#fff url("data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%2712%27 height=%278%27%3E%3Cpath d=%27M1 1l5 5 5-5%27 stroke=%27%23947A25%27 stroke-width=%272%27 fill=%27none%27 stroke-linecap=%27round%27/%3E%3C/svg%3E") no-repeat left 14px center;padding-left:34px}html[dir=ltr] select.v{background-position:right 14px center;padding-left:14px;padding-right:34px}textarea.v{min-height:64px;line-height:1.7}input.v:focus,select.v:focus,textarea.v:focus{outline:none;border-color:#B8962E;box-shadow:0 0 0 3px rgba(184,150,46,.14)}.btn:active{transform:scale(.985)}.err{display:none;background:#FDECEC;color:#B3261E;border-radius:12px;padding:10px 14px;font-size:13.5px;margin-top:12px}.btn{width:100%;margin-top:16px;background:#B8962E;color:#fff;border:0;border-radius:999px;padding:15px 20px;font:inherit;font-size:16px;font-weight:700;cursor:pointer;box-shadow:0 10px 26px rgba(184,150,46,.4)}.btn[disabled]{opacity:.6;cursor:default}.note{font-size:12.5px;color:#6b6861;text-align:center;line-height:1.7;margin-top:12px}.pg-f{background:#111;color:#cfcac0;text-align:center;font-size:12px;padding:12px}.off{padding:26px 22px;text-align:center;font-size:15px;line-height:1.9}.hp{position:absolute;left:-9999px;top:-9999px}.who{background:#FBF7EC;border:1.5px solid #E8DDBB;border-radius:14px;padding:12px 14px;margin-bottom:12px;font-size:15px;line-height:1.8}.who span{font-size:12.5px;color:#6b6861}.who.alt{background:#F4F6FB;border-color:#D8DFEE}.sw{color:#7A6320;text-decoration:underline}.cc{position:relative;display:block}.cc-face{position:absolute;top:2px;bottom:2px;right:2px;left:34px;background:#fff;border-radius:10px;display:flex;align-items:center;gap:8px;padding:0 12px;pointer-events:none;font-weight:600;font-size:14.5px;direction:ltr;justify-content:flex-start;overflow:hidden;white-space:nowrap}html[dir=ltr] .cc-face{left:2px;right:34px}.cc-face .fg{width:22px;height:15px;border-radius:2.5px;flex:0 0 auto}.cc-face .fg-em{display:inline-flex;align-items:center;justify-content:center;font-size:13px;line-height:1;background:#F3F1EC;color:#555;overflow:hidden}.phh{font-size:12.5px;color:#8a8577;margin:6px 2px 0;text-align:start}.phh b{direction:ltr;unicode-bidi:isolate;color:#7A6320}input.v::placeholder{color:#B9B4A8;letter-spacing:.04em}input.v.otp{font-size:26px;font-weight:700;letter-spacing:.5em;text-align:center;border:2px dashed #B8962E;background:#FBF7EC;border-radius:14px;min-height:60px}input.v.otp:focus{border-style:solid}input.v.otp::placeholder{letter-spacing:.2em}</style></head><body>';
		echo $head;
		if ( $embed ) {
			echo '<style>html,body{background:transparent!important}body{background:rgba(12,11,8,.66)!important;animation:vaiE .18s ease-out}@keyframes vaiE{from{opacity:0}to{opacity:1}}.pg{position:relative;animation:vaiP .22s ease-out}@keyframes vaiP{from{opacity:0;transform:translateY(14px) scale(.985)}to{opacity:1;transform:none}}.pgx{position:absolute;top:12px;left:12px;z-index:2;width:34px;height:34px;border:0;border-radius:50%;background:rgba(255,255,255,.14);color:#fff;font-size:17px;line-height:34px;text-align:center;cursor:pointer;padding:0}.pgx:hover{background:rgba(255,255,255,.26)}</style>';
		}
		echo '<div class="pg">' . ( $embed ? '<button type="button" class="pgx" id="pgx" aria-label="' . ( $en ? 'Close' : 'إغلاق' ) . '">✕</button>' : '' ) . '<div class="pg-h"><img src="' . $logo . '" alt=""><div class="pg-k">' . $tr( 'نادي المستثمرين · الدفع الآمن', 'INVESTORS CLUB · SECURE CHECKOUT' ) . '</div><div class="pg-t">' . $tr( 'ادفع باسمك مباشرة', 'Pay directly under your name' ) . '</div><div style="margin-top:8px"><a class="sw" style="color:#F3E4B5;font-size:12.5px" href="' . esc_url( home_url( $toggle_qs . ( $en ? '' : '&lang=en' ) ) ) . '">' . ( $en ? 'العربية' : 'English' ) . '</a></div></div>';
		// 2.8.1: a signed-in member (the widget's vai_uuid cookie) pays with his account — nothing retyped;
		// anyone else registers RIGHT HERE (the account is only created once the signed callback proves the payment).
		$acc = isset( $_GET['vai-pay-new'] ) ? null : self::contact_by_uuid( isset( $_COOKIE['vai_uuid'] ) ? sanitize_text_field( wp_unslash( $_COOKIE['vai_uuid'] ) ) : '' );
		if ( ! $ready || ! $items ) {
			echo '<div class="off">' . $tr( 'الدفع من الموقع غير متاح حاليًا 🙏<br>تواصل مع الإدارة:', 'Online payment is unavailable right now 🙏<br>Contact management:' ) . ' <b dir="ltr">' . esc_html( vai_phone_local( vai_cfg( 'mgmt_whatsapp' ) ) ) . '</b></div>';
		} else {
			echo '<div class="pg-b"><form id="f" autocomplete="on">';
			$acc_incomplete = $acc && trim( (string) $acc->phone_norm ) === ''; // google-born accounts (no phone) complete here
			if ( $acc ) {
				echo '<div class="who">' . $tr( 'أهلًا', 'Welcome' ) . ' <b>' . esc_html( $acc->name ) . '</b> 🌹<br><span>' . $tr( 'الدفع سيتم باسمك وبياناتك المسجّلة', 'Payment will be under your registered account' ) . ( (int) $acc->is_member === 1 ? '' : $tr( ' — ودفع العضوية يفعّلها فورًا', ' — paying the membership activates it instantly' ) ) . '</span></div>';
				if ( (int) $acc->is_member === 1 ) {
					// 2.12.0 (owner): members attend ALL workshops with no fees — a paid workshop fee is refunded at once.
					echo '<div class="who" style="background:#EFF7EF;border-color:#CBE5CB">' . $tr( 'تنبيه للعضو: حضور ورش العمل طوال السنة <b>بدون رسوم</b> — لو دفعت رسم ورشة تُرَدّ لك قيمته فورًا.', 'Member note: workshops are <b>free of charge</b> for you all year — a paid workshop fee is refunded immediately.' ) . '</div>';
				}
				echo '<input type="hidden" name="uuid" value="' . esc_attr( sanitize_text_field( wp_unslash( $_COOKIE['vai_uuid'] ) ) ) . '">';
				if ( $acc_incomplete ) {
					// 2.12.0 (M51 spirit): a Google-born account completes جواله وفئته ونبذته before it can pay.
					$cc2 = vai_gcc_countries();
					echo '<div class="who alt">' . $tr( 'أكمل بيانات حسابك أولًا — مرة واحدة فقط:', 'Complete your account first — one time only:' ) . '</div>';
					if ( true ) {
						echo '<label class="f">' . $tr( 'الدولة', 'Country' ) . '</label><span class="cc"><span class="cc-face" id="pgcf" aria-hidden="true"></span><select class="v" name="country" id="pgc">';
						foreach ( $cc2 as $code => $row ) {
							echo '<option value="' . esc_attr( $code ) . '" data-ex="' . esc_attr( $row['example'] ) . '" data-fg="' . esc_attr( $row['flag'] ) . '"' . ( $code === 'sa' ? ' selected' : '' ) . '>' . esc_html( $en && ! empty( $row['en'] ) ? $row['en'] : $row['name'] ) . '</option>';
						}
						echo '</select></span>';
						// 2.15.2 (owner): the placeholder is a MASK (05XXXXXXXX) so nobody mistakes it for a prefilled number; the real example sits below.
						echo '<label class="f">' . $tr( 'رقم الجوال (بدون رمز الدولة)', 'Mobile number (without country code)' ) . '</label><input class="v" name="phone" id="pgp" required dir="ltr" inputmode="tel" placeholder="05XXXXXXXX" autocomplete="tel"><div class="phh" id="pgph"></div>';
					}
					if ( ! in_array( (string) $acc->persona, array( 'neutral', 'entrepreneur', 'investor' ), true ) ) { // google-born: ask فئة/نبذة in the same single step
						echo '<label class="f">' . $tr( 'فئتك في النادي', 'Your club category' ) . '</label><div>';
						foreach ( array( array( 'neutral', 'محايد — أستكشف توجهي', 'Neutral — exploring my direction' ), array( 'entrepreneur', 'رائد أعمال — لدي مشروع', 'Entrepreneur — I have a project' ), array( 'investor', 'مستثمر — أبحث عن فرص', 'Investor — seeking opportunities' ) ) as $pp ) {
							echo '<label class="it" style="margin-bottom:8px"><input type="radio" name="persona" value="' . $pp[0] . '" required><span class="l">' . esc_html( $tr( $pp[1], $pp[2] ) ) . '</span></label>';
						}
						echo '</div>';
						echo '<label class="f">' . $tr( 'نبذة مختصرة عنك', 'A short bio about you' ) . '</label><textarea class="v" name="bio" required minlength="10" maxlength="600" rows="2"></textarea>';
					}
				}
			} else {
				echo '<div class="who alt">' . $tr( 'سجّل حسابك وادفع — <b>خطوة واحدة</b><br><span>لو عندك حساب بالفعل: افتح المساعد (الأيقونة أسفل الموقع) وسجّل الدخول ثم ارجع لهذه الصفحة، أو اكتب نفس جوالك وبريدك المسجّلين.</span>', 'Register and pay — <b>one step</b><br><span>Already have an account? Open the assistant (bottom icon), sign in and come back — or type the same mobile and e-mail you registered with.</span>' ) . '</div>';
			}
			// 2.15.0 (owner): a keyed link (?vai-pay=membership / workshop …) locks the page to THAT service only.
			if ( $pre !== '' ) {
				$only = array_values( array_filter( $items, function ( $it ) use ( $pre ) { return $it['key'] === $pre; } ) );
				if ( $only ) { $items = $only; }
			}
			$checked = false;
			foreach ( $items as $item ) {
				$on = $pre !== '' ? $item['key'] === $pre : ! $checked;
				$ilabel = $en && isset( $enLabels[ $item['key'] ] ) ? $enLabels[ $item['key'] ] : $item['label'];
				echo '<label class="it' . ( $on ? ' on' : '' ) . '"><input type="radio" name="item" value="' . esc_attr( $item['key'] ) . '"' . ( $on ? ' checked' : '' ) . '><span class="l">' . esc_html( $ilabel ) . '</span><span class="p">' . esc_html( number_format( $item['cents'] / 100 ) ) . ' ' . $tr( 'ريال', 'SAR' ) . '</span></label>';
				$checked = true;
			}
			// 2.15.5 (owner): «اكتب في كل محل ان السعر شامل VAT»
			echo '<div class="note" style="margin-top:2px;margin-bottom:8px;text-align:center;font-weight:700">' . $tr( 'جميع الأسعار شاملة ضريبة القيمة المضافة (VAT).', 'All prices include VAT.' ) . '</div>';
			if ( ! $acc ) {
				$gcid = trim( (string) vai_opt( 'google_client_id', '' ) );
				if ( $gcid !== '' ) {
					// 2.12.0 (owner): «أي حد يدخل بحساب جوجل مباشر ويدفع» — the same hub-verified Google op as the widget.
					echo '<div style="text-align:center;margin:2px 0 10px"><div id="pgg" style="display:inline-block;min-height:44px"></div><div class="note" style="margin-top:6px">' . $tr( 'أو أكمل البيانات يدويًا 👇', 'Or fill the form manually 👇' ) . '</div></div>';
				}
				$cc = vai_gcc_countries();
				echo '<label class="f">' . $tr( 'الاسم الكامل (الاسم واسم العائلة)', 'Full name (first + family name)' ) . '</label><input class="v" name="name" required minlength="5" maxlength="120" autocomplete="name">';
				// 2.18.2 (M69): «فرد / شركة» directly under the name, same as the widget and the app.
				echo '<label class="f">' . $tr( 'نوع الحساب', 'Account type' ) . '</label><div>';
				foreach ( array( array( 'individual', 'فرد', 'Individual' ), array( 'company', 'شركة', 'Company' ) ) as $mt ) {
					echo '<label class="it" style="margin-bottom:8px"><input type="radio" name="member_type" value="' . $mt[0] . '"' . ( 'individual' === $mt[0] ? ' checked' : '' ) . '><span class="l">' . esc_html( $tr( $mt[1], $mt[2] ) ) . '</span></label>';
				}
				echo '</div>';
				echo '<div id="pgco" style="display:none"><label class="f">' . $tr( 'اسم الشركة', 'Company name' ) . '</label><input class="v" name="company_name" maxlength="190" autocomplete="organization"></div>';
				echo '<label class="f">' . $tr( 'الدولة', 'Country' ) . '</label><span class="cc"><span class="cc-face" id="pgcf" aria-hidden="true"></span><select class="v" name="country" id="pgc">';
				foreach ( $cc as $code => $row ) {
					echo '<option value="' . esc_attr( $code ) . '" data-ex="' . esc_attr( $row['example'] ) . '" data-fg="' . esc_attr( $row['flag'] ) . '"' . ( $code === 'sa' ? ' selected' : '' ) . '>' . esc_html( $en && ! empty( $row['en'] ) ? $row['en'] : $row['name'] ) . '</option>';
				}
				echo '</select></span>';
				echo '<label class="f">' . $tr( 'رقم الجوال (بدون رمز الدولة)', 'Mobile number (without country code)' ) . '</label><input class="v" name="phone" id="pgp" required dir="ltr" inputmode="tel" placeholder="05XXXXXXXX" autocomplete="tel"><div class="phh" id="pgph"></div>';
				echo '<label class="f">' . $tr( 'البريد الإلكتروني', 'E-mail' ) . '</label><input class="v" name="email" type="email" required dir="ltr" placeholder="name@gmail.com" autocomplete="email">';
				echo '<label class="f">' . $tr( 'فئتك في النادي', 'Your club category' ) . '</label><div>';
				foreach ( array( array( 'neutral', 'محايد — أستكشف توجهي', 'Neutral — exploring my direction' ), array( 'entrepreneur', 'رائد أعمال — لدي مشروع', 'Entrepreneur — I have a project' ), array( 'investor', 'مستثمر — أبحث عن فرص', 'Investor — seeking opportunities' ) ) as $pp ) {
					echo '<label class="it" style="margin-bottom:8px"><input type="radio" name="persona" value="' . $pp[0] . '" required><span class="l">' . esc_html( $tr( $pp[1], $pp[2] ) ) . '</span></label>';
				}
				echo '</div>';
				// 2.20.0 (owner): the app's registration interests — mandatory on the site too (1 to 3).
				echo '<label class="f">' . $tr( 'اهتماماتك (اختر من 1 إلى 3)', 'Your interests (pick 1 to 3)' ) . '</label><div id="pgints">';
				foreach ( vai_interest_options() as $io ) {
					echo '<label class="it" style="margin-bottom:8px"><input type="checkbox" name="interest" value="' . esc_attr( $io[0] ) . '"><span class="l">' . esc_html( $tr( $io[0], $io[1] ) ) . '</span></label>';
				}
				echo '</div>';
				echo '<label class="f">' . $tr( 'الوظيفة أو المنصب (اختياري)', 'Job title (optional)' ) . '</label><input class="v" name="job" maxlength="150">';
				echo '<label class="f">' . $tr( 'نبذة مختصرة عنك', 'A short bio about you' ) . '</label><textarea class="v" name="bio" required minlength="10" maxlength="600" rows="2" placeholder="' . esc_attr( $tr( 'مثال: صاحب مشروع مطاعم في الرياض وأبحث عن شركاء…', 'Example: restaurant founder in Riyadh looking for partners…' ) ) . '"></textarea>';
				echo '<label class="f">' . $tr( 'كلمة مرور لحسابك (6 أحرف على الأقل)', 'A password for your account (min 6 characters)' ) . '</label><input class="v" name="password" type="password" required minlength="6" maxlength="100" dir="ltr" autocomplete="new-password">';
				echo '<input type="hidden" name="uuid" value="' . esc_attr( isset( $_COOKIE['vai_uuid'] ) ? sanitize_text_field( wp_unslash( $_COOKIE['vai_uuid'] ) ) : '' ) . '">';
			}
			echo '<input class="hp" type="text" name="website" tabindex="-1" autocomplete="off">';
			echo '<div class="err" id="err"></div><button class="btn" id="go" type="submit">' . $tr( 'الانتقال لصفحة الدفع الآمنة 💳', 'Continue to secure payment 💳' ) . '</button>';
			// 2.10.1 interim: on the direct link the payer types his data on Paymob's page too — SAME identity = automatic activation.
			if ( self::pay_direct_mode() ) {
				echo '<div class="note">' . ( $acc ? $tr( 'ستنتقل لصفحة الدفع الآمنة — اكتب فيها <b>نفس جوالك أو بريدك المسجّلين</b> لتُفعَّل تلقائيًا فور تأكيد الدفع.', 'You will move to the secure payment page — enter <b>the same registered mobile or e-mail</b> there so it activates automatically once the payment is confirmed.' ) : $tr( 'بعد الضغط على الزر يصلك <b>رمز تأكيد قصير على بريدك</b> تكتبه هنا (لنتأكد أنك صاحب البريد)، فيكتمل حسابك فورًا وتصلك رسالة ترحيب، ثم تنتقل لصفحة الدفع الآمنة — اكتب فيها <b>نفس الجوال والبريد</b>، وتتفعّل عضويتك تلقائيًا فور تأكيد الدفع.', 'After pressing the button a <b>short confirmation code reaches your inbox</b> — type it here (to prove the address is yours); your account completes at once with a welcome mail, then you move to the secure payment page — enter <b>the same mobile and e-mail</b> there, and your membership activates automatically once the payment is confirmed.' ) ) . ' ' . $tr( 'الدفع يتم بالكامل على صفحة Paymob الآمنة — لا نحفظ بيانات بطاقتك.', 'Card entry happens entirely on Paymob\'s secure page — we never store card data.' ) . '</div>';
			} else {
				echo '<div class="note">' . ( $acc ? $tr( 'دفع العضوية يفعّلها فورًا وتصلك رسالة تأكيد على بريدك.', 'Paying the membership activates it instantly and a confirmation reaches your inbox.' ) : $tr( 'بعد الضغط على الزر يصلك <b>رمز تأكيد قصير على بريدك</b> تكتبه هنا (لنتأكد أنك صاحب البريد)، فيكتمل حسابك فورًا وتصلك رسالة ترحيب — حتى لو لم تُكمل الدفع يبقى حسابك محفوظًا وتدخل به وتدفع في أي وقت. ودفع العضوية يفعّلها تلقائيًا فور تأكيد الدفع.', 'After pressing the button a <b>confirmation code reaches your inbox</b> — type it here to prove the address is yours; your account then completes at once with a welcome mail. Even if you do not finish paying, the account is kept and you can sign in and pay any time. Paying the membership activates it automatically.' ) ) . ' ' . $tr( 'الدفع يتم بالكامل على صفحة Paymob الآمنة — لا نحفظ بيانات بطاقتك.', 'Card entry happens entirely on Paymob\'s secure page — we never store card data.' ) . '</div>';
			}
			if ( $acc ) {
				echo '<div class="note"><a class="sw" href="' . esc_url( home_url( '/?vai-pay=' . rawurlencode( $pre ) . '&vai-pay-new=1' . ( $embed ? '&vai-embed=1' : '' ) ) ) . '">' . ( $en ? 'Not ' . esc_html( $acc->name ) . '? Pay with different details' : 'لست ' . esc_html( $acc->name ) . '؟ ادفع ببيانات أخرى' ) . '</a></div>';
			}
			echo '</form></div>';
		}
		echo '<div class="pg-f">' . $tr( 'نادي المستثمرين — Vibes Ventures · ', 'Investors Club — Vibes Ventures · ' ) . '<span dir="ltr">' . esc_html( vai_phone_local( vai_cfg( 'mgmt_whatsapp' ) ) ) . '</span></div></div>';
		if ( $ready && $items ) {
			echo '<script>var F=document.getElementById("f"),E=document.getElementById("err"),B=document.getElementById("go");'
				. 'var CONFIRM=' . wp_json_encode( esc_url_raw( rest_url( 'vibes-ai/v1/paymob/confirm' ) ) ) . ',LANG=' . ( $en ? '"en"' : '""' ) . ';'
				. 'function goUrl(u){try{window.top.location.href=u;}catch(e){window.location.href=u;}}'
				. 'function digits(s){return String(s||"").replace(/[٠-٩]/g,function(d){return "٠١٢٣٤٥٦٧٨٩".indexOf(d);}).replace(/\D/g,"");}'
				// 2.15.2 (owner: «نتأكد إن هو صاحب الحساب اللي بيحجز»): the e-mail code step, on the same page.
				. 'function codeStep(j){F.innerHTML=\'<div class="who" style="text-align:center">✉️ \'+(j.text||"")+\'</div>\''
				. '+\'<label class="f" style="font-weight:700">' . $tr( 'اكتب الرمز هنا (4 أرقام)', 'Type the code here (4 digits)' ) . '</label>\''
				. '+\'<input class="v otp" id="pgcode" dir="ltr" inputmode="numeric" autocomplete="one-time-code" maxlength="4" placeholder="· · · ·">\''
				. '+\'<div class="phh">' . $tr( 'وصلك على', 'Sent to' ) . ' <b>\'+(j.email||"")+\'</b> — ' . $tr( 'تفقّد «غير المرغوبة» إن لم تجده.', 'check spam if missing.' ) . '</div>\''
				. '+\'<div class="err" id="err2"></div><button class="btn" id="go2" type="button">' . $tr( 'تأكيد الرمز وإكمال الدفع 💳', 'Confirm the code & continue to payment 💳' ) . '</button>\''
				. '+\'<div class="note"><a class="sw" href="#" id="pgrs">' . $tr( 'لم يصلك؟ إعادة إرسال الرمز', 'Nothing arrived? Resend the code' ) . '</a> · <a class="sw" href="">' . $tr( 'تعديل بياناتي', 'Edit my details' ) . '</a></div>\';'
				. 'var I=document.getElementById("pgcode"),E2=document.getElementById("err2"),B2=document.getElementById("go2"),RS=document.getElementById("pgrs");'
				. 'try{I.focus();}catch(e){}'
				. 'function send(){if(B2.disabled){return;}var v=digits(I.value);if(v.length<4){E2.textContent="' . $tr( 'اكتب الرمز المكوّن من 4 أرقام الذي وصلك على بريدك', 'Type the 4-digit code from your inbox' ) . '";E2.style.display="block";return;}B2.disabled=true;B2.textContent="' . $tr( 'لحظات…', 'One moment…' ) . '";'
				. 'fetch(CONFIRM,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({token:j.token,code:v,lang:LANG})}).then(function(r){return r.json()}).then(function(x){'
				. 'if(x&&x.ok&&x.url){goUrl(x.url);return;}E2.textContent=(x&&x.text)||"' . $tr( 'الرمز غير صحيح', 'Wrong code' ) . '";E2.style.display="block";B2.disabled=false;B2.textContent="' . $tr( 'تأكيد الرمز وإكمال الدفع 💳', 'Confirm the code & continue to payment 💳' ) . '";'
				. '}).catch(function(){E2.textContent="' . $tr( 'تعذّر الاتصال — حاول من جديد', 'Connection failed — try again' ) . '";E2.style.display="block";B2.disabled=false;B2.textContent="' . $tr( 'تأكيد الرمز وإكمال الدفع 💳', 'Confirm the code & continue to payment 💳' ) . '";});}'
				. 'I.addEventListener("input",function(){var n=digits(I.value).slice(0,4);if(n!==I.value){I.value=n;}if(n.length===4){send();}});'
				. 'B2.addEventListener("click",send);'
				. 'RS.addEventListener("click",function(e){e.preventDefault();fetch(CONFIRM,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({token:j.token,resend:1,lang:LANG})}).then(function(r){return r.json()}).then(function(x){E2.textContent=(x&&x.text)||"";E2.style.display=x&&x.text?"block":"none";}).catch(function(){});});}'
				. 'F.addEventListener("change",function(e){if(e.target.name==="item"){document.querySelectorAll(".it").forEach(function(x){x.classList.remove("on")});e.target.closest(".it").classList.add("on");}'
				// 2.18.2 (M69): «شركة» reveals the required company-name field.
				. 'if(e.target.name==="member_type"){var co=document.getElementById("pgco"),ci=co?co.querySelector("input"):null;var on=e.target.value==="company";if(co){co.style.display=on?"block":"none";}if(ci){ci.required=on;if(!on){ci.value="";}}}'
					// 2.20.0: at most 3 interests — the fourth tick bounces back.
					. 'if(e.target.name==="interest"&&e.target.checked&&F.querySelectorAll("input[name=interest]:checked").length>3){e.target.checked=false;}'
					. 'if(e.target.name==="interest"){e.target.closest(".it").classList.toggle("on",e.target.checked);}});'
				. 'F.addEventListener("submit",function(ev){ev.preventDefault();E.style.display="none";'
					. 'var ints=[].slice.call(F.querySelectorAll("input[name=interest]:checked")).map(function(x){return x.value;});'
					. 'if(document.getElementById("pgints")&&!ints.length){E.textContent="' . $tr( 'اختر اهتمامًا واحدًا على الأقل (حتى 3)', 'Pick at least one interest (up to 3)' ) . '";E.style.display="block";return;}'
					. 'B.disabled=true;B.textContent="' . $tr( 'لحظات…', 'One moment…' ) . '";'
				. 'var d=new FormData(F),p={item:d.get("item"),name:d.get("name"),member_type:d.get("member_type"),company_name:d.get("company_name"),country:d.get("country"),phone:d.get("phone"),email:d.get("email"),persona:d.get("persona"),job:d.get("job"),bio:d.get("bio"),interests:ints.join("، "),password:d.get("password"),uuid:d.get("uuid"),website:d.get("website"),lang:' . ( $en ? '"en"' : '""' ) . '};'
				. 'fetch(' . wp_json_encode( esc_url_raw( rest_url( 'vibes-ai/v1/paymob/start' ) ) ) . ',{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(p)}).then(function(r){return r.json()}).then(function(j){'
				. 'if(j&&j.ok&&j.url){goUrl(j.url);return;}if(j&&j.ok&&j.pending&&j.token){codeStep(j);return;}E.textContent=(j&&j.text)?j.text:"' . $tr( 'تعذّر بدء الدفع — حاول من جديد', 'Could not start the payment — try again' ) . '";E.style.display="block";B.disabled=false;B.textContent="' . $tr( 'الانتقال لصفحة الدفع الآمنة 💳', 'Continue to secure payment 💳' ) . '";'
				. '}).catch(function(){E.textContent="' . $tr( 'تعذّر الاتصال — تأكد من الإنترنت وحاول', 'Connection failed — check your internet and retry' ) . '";E.style.display="block";B.disabled=false;B.textContent="' . $tr( 'الانتقال لصفحة الدفع الآمنة 💳', 'Continue to secure payment 💳' ) . '";});});</script>';
		}
		if ( $ready && $items ) { // 2.15.2: the flag/mask script also serves the «أكمل حسابك» phone field of a google-born account
			$fg = array(
				'sa' => '<svg class="fg" viewBox="0 0 24 16" aria-hidden="true"><defs><clipPath id="gfsa"><rect width="24" height="16" rx="2.5"/></clipPath></defs><g clip-path="url(#gfsa)"><rect width="24" height="16" fill="#006C35"/><text x="12" y="7.1" text-anchor="middle" fill="#fff" font-size="3.1" font-family="IBM Plex Sans Arabic,Tahoma,sans-serif">لا إله إلا الله محمد رسول الله</text><path d="M18.2 10.7H6.4L4.9 11.3l1.5.6h11.8z" fill="#fff"/><rect x="18.5" y="10.35" width=".6" height="1.9" rx=".3" fill="#fff"/><rect x="19.4" y="10.75" width="1.6" height="1.1" rx=".55" fill="#fff"/></g></svg>',
				'ae' => '<svg class="fg" viewBox="0 0 24 16" aria-hidden="true"><defs><clipPath id="gfae"><rect width="24" height="16" rx="2.5"/></clipPath></defs><g clip-path="url(#gfae)"><rect width="24" height="16" fill="#fff"/><rect width="24" height="5.4" fill="#00732F"/><rect y="10.6" width="24" height="5.4" fill="#000"/><rect width="6.4" height="16" fill="#FF0000"/></g></svg>',
				'kw' => '<svg class="fg" viewBox="0 0 24 16" aria-hidden="true"><defs><clipPath id="gfkw"><rect width="24" height="16" rx="2.5"/></clipPath></defs><g clip-path="url(#gfkw)"><rect width="24" height="16" fill="#fff"/><rect width="24" height="5.4" fill="#007A3D"/><rect y="10.6" width="24" height="5.4" fill="#CE1126"/><path d="M0 0l7.5 5.33v5.34L0 16z" fill="#000"/></g></svg>',
				'qa' => '<svg class="fg" viewBox="0 0 24 16" aria-hidden="true"><defs><clipPath id="gfqa"><rect width="24" height="16" rx="2.5"/></clipPath></defs><g clip-path="url(#gfqa)"><rect width="24" height="16" fill="#fff"/><path d="M24 0H9L6.5.9 9 1.8 6.5 2.7 9 3.6 6.5 4.4 9 5.3 6.5 6.2 9 7.1 6.5 8 9 8.9 6.5 9.8 9 10.7 6.5 11.6 9 12.4 6.5 13.3 9 14.2 6.5 15.1 9 16h15z" fill="#8A1538"/></g></svg>',
				'bh' => '<svg class="fg" viewBox="0 0 24 16" aria-hidden="true"><defs><clipPath id="gfbh"><rect width="24" height="16" rx="2.5"/></clipPath></defs><g clip-path="url(#gfbh)"><rect width="24" height="16" fill="#fff"/><path d="M24 0H9L6.5 1.6 9 3.2 6.5 4.8 9 6.4 6.5 8 9 9.6 6.5 11.2 9 12.8 6.5 14.4 9 16h15z" fill="#CE1126"/></g></svg>',
				'om' => '<svg class="fg" viewBox="0 0 24 16" aria-hidden="true"><defs><clipPath id="gfom"><rect width="24" height="16" rx="2.5"/></clipPath></defs><g clip-path="url(#gfom)"><rect width="24" height="16" fill="#fff"/><rect x="6.4" y="10.6" width="17.6" height="5.4" fill="#009A44"/><rect x="6.4" y="5.4" width="17.6" height="5.2" fill="#C8102E"/><rect width="6.4" height="16" fill="#C8102E"/><path d="M2.1 1.5l2.2 2.6M4.3 1.5L2.1 4.1" stroke="#fff" stroke-width=".7" stroke-linecap="round"/></g></svg>',
			);
			echo '<script>(function(){var FG=' . wp_json_encode( $fg ) . ';var c=document.getElementById("pgc"),ph=document.getElementById("pgp"),f=document.getElementById("pgcf"),hh=document.getElementById("pgph");'
				// 2.15.2: the placeholder shows a MASK (05XXXXXXXX) — the real example moves to the help line below, bold.
				. 'function u(){if(!c){return;}var o=c.options[c.selectedIndex],ex=(o&&o.getAttribute("data-ex"))||"";if(ph){ph.placeholder=(c.value==="sa"||c.value==="ae")?"05XXXXXXXX":ex.replace(/[0-9]/g,"X");}if(hh){hh.innerHTML=ex?' . wp_json_encode( $tr( 'مثال: ', 'Example: ' ) ) . '+"<b>"+ex+"</b>":"";}if(f&&o){f.innerHTML=(FG[c.value]||("<span class=\"fg fg-em\">"+(o.getAttribute("data-fg")||"")+"</span>"))+"<span>"+o.text+"</span>";}}if(c){c.addEventListener("change",u);u();}})();</script>';
			$gcid2 = trim( (string) vai_opt( 'google_client_id', '' ) );
			if ( $gcid2 !== '' && ! $acc ) {
				// 2.12.0: Google on the gate — the SAME hub-verified op as the widget; on success the visitor
				// uuid is signed in server-side and the page reloads into account mode (no retyping, no password).
				echo '<script>(function(){var U=(document.cookie.match(/(?:^|; )vai_uuid=([^;]+)/)||[])[1];'
					. 'if(!U){U="pg-"+Date.now().toString(36)+Math.random().toString(36).slice(2,10);document.cookie="vai_uuid="+U+"; path=/; max-age=31536000; SameSite=Lax";}'
					. 'function ok(r){if(r&&r.ok!==false){location.reload();}else{var E=document.getElementById("err");if(E){E.textContent=(r&&r.text)||"' . $tr( 'تعذّر الدخول بحساب Google', 'Google sign-in failed' ) . '";E.style.display="block";}}}'
					. 'function cred(resp){fetch(' . wp_json_encode( esc_url_raw( rest_url( 'vibes-ai/v1/client/google' ) ) ) . ',{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({credential:resp&&resp.credential,uuid:U,lang:' . ( $en ? '"en"' : '""' ) . '})}).then(function(r){return r.json()}).then(ok).catch(function(){ok(null)});}'
					. 'var sc=document.createElement("script");sc.src="https://accounts.google.com/gsi/client";sc.async=true;sc.defer=true;'
					. 'sc.onload=function(){var g=window.google&&window.google.accounts&&window.google.accounts.id;var slot=document.getElementById("pgg");if(!g||!slot){return;}'
					. 'g.initialize({client_id:' . wp_json_encode( $gcid2 ) . ',callback:cred,ux_mode:"popup"});'
					. 'g.renderButton(slot,{type:"standard",theme:"outline",size:"large",text:"continue_with",shape:"pill",locale:' . wp_json_encode( $en ? 'en' : 'ar' ) . ',width:280});};'
					. 'document.head.appendChild(sc);})();</script>';
			}
		}
		if ( $embed ) {
			echo '<script>(function(){var P=function(){try{parent.postMessage("vai-pay-close",window.location.origin);}catch(e){}};'
				. 'var x=document.getElementById("pgx");if(x){x.addEventListener("click",P);}'
				. 'document.body.addEventListener("click",function(e){if(e.target===document.body){P();}});'
				. 'document.addEventListener("keydown",function(e){if(e.key==="Escape"){P();}});})();</script>';
		}
		echo '</body></html>';
		exit;
	}

	/** Return page after checkout: display only — the truth arrives through the signed callback. */
	public static function render_pay_done_page() {
		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		header( 'X-Robots-Tag: noindex' );
		$ok   = isset( $_GET['success'] ) && in_array( strtolower( (string) $_GET['success'] ), array( 'true', '1' ), true );
		$logo = esc_url( vai_cfg( 'avatar_url' ) );
		// 2.20.0: ?lang=en, or the widget's own saved English state, flips the whole page to English (the
		// Paymob redirection URL stays untouched — rule 6 — so the client-side fallback covers that path).
		$den = isset( $_GET['lang'] ) && 'en' === $_GET['lang'];
		echo '<!doctype html><html dir="' . ( $den ? 'ltr' : 'rtl' ) . '" lang="' . ( $den ? 'en' : 'ar' ) . '" id="vaidone"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>' . ( $den ? ( $ok ? 'Payment received' : 'Payment not completed' ) : ( $ok ? 'تمت العملية' : 'لم تكتمل العملية' ) ) . '</title>'
			. '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;600;700&display=swap">'
			. '<style>body{margin:0;background:#0d0d0d;font-family:"IBM Plex Sans Arabic",Tahoma,sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px 12px;box-sizing:border-box}.c{width:100%;max-width:420px;background:#fff;border-radius:26px;overflow:hidden;box-shadow:0 24px 60px rgba(0,0,0,.5);text-align:center}.h{background:#000;padding:24px;border-bottom:3px solid #B8962E}.h img{width:62px;height:62px;border-radius:50%;border:2px solid #B8962E}.b{padding:28px 24px;font-size:16px;line-height:2;color:#111}.e{font-size:44px}.a{display:inline-block;margin-top:14px;background:#B8962E;color:#fff;text-decoration:none;font-weight:700;padding:12px 26px;border-radius:999px;font-size:15px}</style></head><body><div class="c">'
			. '<div class="h"><img src="' . $logo . '" alt=""></div><div class="b">'
			. ( $ok
				? ( $den
					? '<div class="e">✅</div><b>We received your payment request</b><br>A confirmation reaches your inbox in moments, and a membership activates automatically once the bank confirms.<br><b>Your account is ready and you are signed in automatically</b> — open the assistant from its icon at the bottom of the site and everything is under your name.<br><a class="a" href="' . esc_url( home_url( '/' ) ) . '">Back to the site</a>'
					: '<div class="e">✅</div><b>وصلنا طلب دفعك بنجاح</b><br>سيصلك تأكيد على بريدك خلال لحظات، وإن كانت عضوية فستتفعّل تلقائيًا فور تأكيد البنك.<br><b>حسابك جاهز وأنت مسجّل الدخول تلقائيًا</b> — افتح المساعد من أيقونته أسفل الموقع وستجد كل شيء باسمك.<br><a class="a" href="' . esc_url( home_url( '/' ) ) . '">العودة للموقع</a>' )
				: ( $den
					? '<div class="e">🙏</div><b>The payment was not completed</b><br>Most likely nothing was charged — you can try again.<br>If you registered your details first, your account is <b>saved</b> and a welcome mail reached your inbox: sign in with it and complete the payment any time.<br><a class="a" href="' . esc_url( home_url( '/?vai-pay&lang=en' ) ) . '">Back to the pay page</a>'
					: '<div class="e">🙏</div><b>لم تكتمل عملية الدفع</b><br>لم يُخصم منك شيء غالبًا — يمكنك المحاولة مرة أخرى.<br>وإن كنت سجّلت بياناتك قبلها فحسابك <b>محفوظ</b> ووصلتك رسالة ترحيب على بريدك: تدخل به وتُكمل الدفع في أي وقت.<br><a class="a" href="' . esc_url( home_url( '/?vai-pay' ) ) . '">العودة لصفحة الدفع</a>' ) )
			. '</div></div>'
			// The Paymob redirect carries no lang: if the widget's saved state says English, reload once with ?lang=en.
			. ( $den ? '' : '<script>try{var s=JSON.parse(localStorage.getItem("vai_state_v2")||"null");if(s&&s.lang==="en"&&location.search.indexOf("lang=en")===-1){location.replace(location.href+(location.search?"&":"?")+"lang=en");}}catch(e){}</script>' )
			. '</body></html>';
		exit;
	}

	/* ───────────── account security notifications ───────────── */

	public static function notify_user_event( $c, $what, $site_host = '' ) {
		if ( ! (int) vai_cfg( 'notify_user_events' ) || ! $c || ! is_email( $c->email ) ) {
			return false;
		}
		// 2.20.0: the security notice follows the member's registration language.
		if ( VAI_Hub::lang_of( $c ) === 'en' ) {
			$labels_en = array(
				'login'      => 'A new sign-in to your account',
				'reset'      => 'Your account password was changed',
				'profile'    => 'Your account details were updated',
				'membership' => 'Your annual membership is active',
				'admin'      => 'Your account was upgraded to admin',
			);
			$title_en = isset( $labels_en[ $what ] ) ? $labels_en[ $what ] : 'New activity on your account';
			$body_en  = 'Hello ' . $c->name . ",

" . $title_en . ( $site_host ? ' via ' . $site_host : '' ) . "
Date: " . vai_riyadh( vai_now() ) . " (Riyadh)

If this was not you, change your password right away from “My account” → “Edit my profile” or use “Forgot password”, and contact the management: " . vai_phone_local( vai_cfg( 'mgmt_whatsapp' ) ) . "

Investors Club — Vibes Ventures";
			return VAI_Hub::mail( $c->email, '🔔 ' . $title_en . ' — Investors Club', $body_en );
		}
		$labels = array(
			'login'      => 'تسجيل دخول جديد إلى حسابك',
			'reset'      => 'تم تغيير كلمة مرور حسابك',
			'profile'    => 'تم تحديث بيانات حسابك',
			'membership' => 'تم تفعيل عضويتك السنوية',
			'admin'      => 'تمت ترقية حسابك إلى أدمن',
		);
		$title = isset( $labels[ $what ] ) ? $labels[ $what ] : 'نشاط جديد على حسابك';
		$body  = 'مرحبًا ' . $c->name . "،

" . $title . ( $site_host ? ' عبر ' . $site_host : '' ) . "
التاريخ: " . vai_riyadh( vai_now() ) . " (الرياض)

إن لم تكن أنت من قام بذلك، غيّر كلمة مرورك فورًا من زر «حسابي» → «تعديل ملفي» أو استخدم «نسيت كلمة المرور»، وتواصل مع الإدارة: " . vai_phone_local( vai_cfg( 'mgmt_whatsapp' ) ) . "

نادي المستثمرين — Vibes Ventures";
		return VAI_Hub::mail( $c->email, '🔔 ' . $title . ' — نادي المستثمرين', $body );
	}

	/* ───────────── member e-mails ───────────── */

	public static function placeholders( $c ) {
		$svc  = VAI_Hub::service_by_key( 'membership' );
		$end  = $c && ! empty( $c->member_started_at ) ? vai_riyadh( gmdate( 'Y-m-d H:i:s', strtotime( $c->member_started_at . ' UTC' ) + ( (int) $c->member_days > 0 ? (int) $c->member_days : (int) vai_cfg( 'member_days' ) ) * 86400 ), 'Y-m-d' ) : '';
		$left = 5;
		if ( $c && function_exists( 'pdp_gate_state' ) ) {
			// not on the hub; keep default
		}
		$srv = array();
		foreach ( vai_member_services() as $s ) {
			$srv[] = $s;
		}
		$find = function ( $needle ) use ( $srv ) {
			foreach ( $srv as $s ) {
				if ( mb_stripos( $s['title'], $needle, 0, 'UTF-8' ) !== false ) {
					return $s['url'];
				}
			}
			return '';
		};
		$wa = function ( $u ) { return strpos( $u, 'wa:' ) === 0 ? '+' . substr( $u, 3 ) : $u; };
		return array(
			'{name}'          => $c ? (string) $c->name : '',
			'{phone}'         => $c ? vai_phone_local( $c->phone_norm ?: $c->phone ) : '',
			'{email}'         => $c ? (string) $c->email : '',
			'{end_date}'      => $end,
			'{pb_left}'       => $left . ' مشاريع',
			'{pb_url}'        => $find( 'بنك المشاريع' ) ?: 'https://vibesholding.com/pb',
			'{podcast_wa}'    => $wa( $find( 'بودكاست' ) ?: 'wa:966538461110' ),
			'{pitchdeck_url}' => $find( 'Pitch Deck' ) ?: 'https://vcmem.com/?vai-pay=pitchdeck',
			'{urmeet_url}'    => $find( 'ملتقاك' ) ?: 'https://vcmem.com/?vai-pay=urmeet',
			'{mgmt}'          => vai_phone_local( vai_cfg( 'mgmt_whatsapp' ) ),
			'{pay_url}'       => $svc ? ( $svc['pay_url'] ?: $svc['url'] ) : 'https://vcmem.com/?vai-pay=membership',
		);
	}

	public static function render( $tpl, $c ) {
		$ph = self::placeholders( $c );
		return strtr( (string) $tpl, $ph );
	}

	public static function send_member_welcome( $c ) {
		if ( ! $c || ! is_email( $c->email ) ) {
			return false;
		}
		// 2.20.0: an English member gets a built-in English welcome; the dashboard template stays Arabic.
		if ( VAI_Hub::lang_of( $c ) === 'en' ) {
			$body = self::render( "Hello {name},\n\nYour annual Investors Club membership is active ⭐\n\nYour membership runs until {end_date}. Sign in with your e-mail {email} on any ecosystem site from the assistant icon, and all member services are at your name.\n\nManagement WhatsApp: {mgmt}\nInvestors Club — Vibes Ventures", $c );
			return VAI_Hub::mail( $c->email, 'Your Investors Club membership is active ⭐', $body );
		}
		$subject = self::render( vai_cfg( 'member_email_subject' ), $c );
		$body    = self::render( vai_cfg( 'member_email' ), $c );
		return VAI_Hub::mail( $c->email, $subject, $body );
	}

	/** Any other successful payment gets an instant confirmation e-mail. */
	public static function send_receipt_email( $name, $email, $label, $txn, $c = null ) {
		if ( ! is_email( $email ) || vai_junk_email( vai_norm_email( $email ) ) ) {
			return false;
		}
		// 2.20.0: English receipt for English registrants.
		if ( $c && VAI_Hub::lang_of( $c ) === 'en' ) {
			$body = 'Hello ' . $name . ",\n\nWe received your payment successfully ✅\nService/amount: " . $label . "\nTransaction: " . $txn . "\nDate: " . vai_riyadh( vai_now() ) . " (Riyadh)\n\nThe Investors Club team will contact you shortly to arrange the next step. Management WhatsApp: " . vai_phone_local( vai_cfg( 'mgmt_whatsapp' ) ) . "\n\nInvestors Club — Vibes Ventures";
			return VAI_Hub::mail( $email, '✅ Payment received — ' . $label, $body );
		}
		$body = 'مرحبًا ' . $name . "،\n\nوصلتنا دفعتك بنجاح ✅\nالخدمة/المبلغ: " . $label . "\nرقم المعاملة: " . $txn . "\nالتاريخ: " . vai_riyadh( vai_now() ) . " (الرياض)\n\nسيتواصل معك فريق نادي المستثمرين خلال وقت قصير لترتيب الخطوة التالية. للتواصل مع الإدارة: " . vai_phone_local( vai_cfg( 'mgmt_whatsapp' ) ) . "\n\nنادي المستثمرين — Vibes Ventures";
		return VAI_Hub::mail( $email, '✅ تأكيد استلام دفعتك — ' . $label, $body );
	}

	/** Re-match unlinked membership payments (older ones) → create/activate accounts. Returns count. */
	public static function rematch_payments() {
		global $wpdb;
		$pt   = $wpdb->prefix . 'vai_payments';
		$rows = (array) $wpdb->get_results( "SELECT * FROM $pt WHERE success=1 AND action='membership' AND contact_id=0 ORDER BY id ASC LIMIT 200" );
		$n    = 0;
		foreach ( $rows as $r ) {
			if ( vai_junk_identity( $r->phone, vai_norm_email( $r->email ) ) ) {
				continue; // 2.10.0: a ghost identity stays unmatched — activate it by hand once the real payer is known
			}
			VAI_Hub::member_context( 'paymob', (string) $r->txn_id );
			$c = VAI_Hub::create_account_for( $r->name, $r->phone, vai_junk_email( vai_norm_email( $r->email ) ) ? '' : $r->email, true, 'paymob' );
			if ( $c ) {
				$wpdb->update( $pt, array( 'contact_id' => (int) $c->id ), array( 'id' => $r->id ) );
				$n++;
			}
		}
		return $n;
	}

	private static function send_pending_account_email( $name, $email ) {
		$body = 'مرحبًا ' . ( $name ?: '' ) . "،\n\nوصلتنا دفعتك للعضوية السنوية في نادي المستثمرين ✅ — باقي خطوة واحدة: أنشئ حسابك من مساعد المنظومة (الأيقونة أسفل الصفحة) بنفس هذا البريد أو نفس الجوال الذي دفعت به، وستُفعَّل عضويتك تلقائيًا فور تفعيل الحساب برمز البريد:\n" . home_url( '/?vai=register' ) . "\n\nنادي المستثمرين — Vibes Ventures";
		VAI_Hub::mail( $email, 'وصلتنا دفعتك — أنشئ حسابك لتفعيل عضويتك', $body );
	}

	/* ───────────── queue ───────────── */

	public static function enqueue( $contact_id, $to, $subject, $body, $kind = 'campaign', $batch = '' ) {
		global $wpdb;
		if ( ! is_email( $to ) ) {
			return false;
		}
		return (bool) $wpdb->insert( self::table(), array( 'contact_id' => (int) $contact_id, 'to_email' => $to, 'subject' => $subject, 'body' => $body, 'kind' => $kind, 'batch' => $batch, 'status' => 'pending', 'created_at' => vai_now() ) );
	}

	/** One e-mail per tick (every 5 minutes) — 12 per hour, well below provider limits. */
	public static function mail_tick() {
		global $wpdb;
		$t   = self::table();
		$h    = ( (int) gmdate( 'G' ) + 3 ) % 24; // Riyadh
		$skip = ( $h < 9 || $h >= 21 ) ? " AND kind<>'broadcast'" : '';
		$row  = $wpdb->get_row( "SELECT * FROM $t WHERE status='pending' AND attempts<3{$skip} ORDER BY id ASC LIMIT 1" );
		if ( ! $row ) {
			return;
		}
		$wpdb->update( $t, array( 'attempts' => (int) $row->attempts + 1 ), array( 'id' => $row->id ) );
		$ok = VAI_Hub::mail( $row->to_email, $row->subject, $row->body );
		$wpdb->update( $t, array( 'status' => $ok ? 'sent' : ( (int) $row->attempts + 1 >= 3 ? 'failed' : 'pending' ), 'sent_at' => $ok ? vai_now() : null ), array( 'id' => $row->id ) );
	}

	public static function queue_stats() {
		global $wpdb;
		$t = self::table();
		return array(
			'pending' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $t WHERE status='pending'" ),
			'sent'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $t WHERE status='sent'" ),
			'failed'  => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $t WHERE status='failed'" ),
		);
	}

	public static function audience( $which, $persona = '' ) {
		global $wpdb;
		$ct = VAI_Hub::t( 'contacts' );
		$pf = in_array( $persona, array( 'neutral', 'entrepreneur', 'investor' ), true ) ? $wpdb->prepare( ' AND persona=%s', $persona ) : '';
		if ( $which === 'paid' ) {
			return (array) $wpdb->get_results( "SELECT * FROM $ct WHERE is_member=1 AND email<>''" . $pf );
		}
		if ( $which === 'unpaid' ) {
			return (array) $wpdb->get_results( "SELECT * FROM $ct WHERE is_member=0 AND pass_hash<>'' AND verified=1 AND email<>''" . $pf );
		}
		return (array) $wpdb->get_results( "SELECT * FROM $ct WHERE pass_hash<>'' AND verified=1 AND email<>''" . $pf );
	}

	/** Campaign: render per member and enqueue (sent 1 every 5 minutes). */
	public static function campaign( $which, $subject, $body, $persona = '' ) {
		$batch = 'c' . time();
		$n     = 0;
		foreach ( self::audience( $which, $persona ) as $c ) {
			if ( VAI_Hub::member_active( $c ) || $which !== 'paid' ) {
				if ( self::enqueue( $c->id, $c->email, self::render( $subject, $c ), self::render( $body, $c ), 'campaign', $batch ) ) {
					$n++;
				}
			}
		}
		return array( 'batch' => $batch, 'count' => $n );
	}

	public static function weekly_members() {
		if ( ! (int) vai_cfg( 'weekly_enabled' ) ) {
			return;
		}
		$batch = 'w' . gmdate( 'Ymd' );
		foreach ( self::audience( 'paid' ) as $c ) {
			if ( VAI_Hub::member_active( $c ) ) {
				self::enqueue( $c->id, $c->email, self::render( vai_cfg( 'weekly_subject' ), $c ), self::render( vai_cfg( 'weekly_email' ), $c ), 'weekly', $batch );
			}
		}
	}

	/** 2.15.0 (M54): rotation blocks — first line is the subject, the rest the body, blocks split by a `---` line. */
	public static function broadcast_blocks( $key ) {
		$out = array();
		foreach ( preg_split( '/^\s*---\s*$/m', (string) vai_cfg( $key ) ) as $b ) {
			$b = trim( $b );
			if ( $b === '' ) { continue; }
			$lines = preg_split( '/\r?\n/', $b );
			$subj  = trim( (string) array_shift( $lines ) );
			$body  = trim( implode( "\n", $lines ) );
			if ( $subj !== '' && $body !== '' ) { $out[] = array( 'subject' => $subj, 'body' => $body ); }
		}
		return $out;
	}

	/** M54 (owner: «كل يومين رسالة مختلفة… وغير المسجلين أفكرهم يسجلوا عضويتهم»): one wave, two audiences, rotating topic. */
	public static function broadcast_run( $force = false ) {
		global $wpdb;
		if ( ! $force && ! (int) vai_cfg( 'broadcast_enabled' ) ) {
			return array( 'ok' => false, 'reason' => 'off' );
		}
		$batch = 'b2' . gmdate( 'Ymd' );
		if ( ! $force && (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . self::table() . ' WHERE batch=%s', $batch ) ) ) {
			return array( 'ok' => false, 'reason' => 'dup' );
		}
		$idx = (int) get_option( 'vai_broadcast_idx', 0 );
		$mb  = self::broadcast_blocks( 'broadcast_member_texts' );
		$nb  = self::broadcast_blocks( 'broadcast_nonmember_texts' );
		$m   = $mb ? $mb[ $idx % count( $mb ) ] : null;
		$n   = $nb ? $nb[ $idx % count( $nb ) ] : null;
		$cm  = 0;
		$cn  = 0;
		if ( $m ) {
			foreach ( self::audience( 'paid' ) as $c ) {
				if ( VAI_Hub::member_active( $c ) && self::enqueue( $c->id, $c->email, self::render( $m['subject'], $c ), self::render( $m['body'], $c ), 'broadcast', $batch ) ) { $cm++; }
			}
		}
		if ( $n ) {
			foreach ( self::audience( 'unpaid' ) as $c ) {
				if ( self::enqueue( $c->id, $c->email, self::render( $n['subject'], $c ), self::render( $n['body'], $c ), 'broadcast', $batch ) ) { $cn++; }
			}
		}
		update_option( 'vai_broadcast_idx', $idx + 1, false );
		update_option( 'vai_broadcast_last', vai_riyadh( vai_now() ) . ' — أعضاء: ' . $cm . ' · غير مشتركين: ' . $cn, false );
		// the owner SEES every wave: one summary line to the notify inbox
		$emails = array_filter( array_map( 'trim', explode( ',', (string) vai_opt( 'notify_email', get_option( 'admin_email' ) ) ) ) );
		foreach ( $emails as $to ) {
			VAI_Hub::mail( $to, '📮 دفعة رسائل «كل يومين» انطلقت', 'دخلت دفعة اليوم طابور الإرسال:' . "\n\n" . '• للأعضاء المفعّلين (' . $cm . '): ' . ( $m ? $m['subject'] : '—' ) . "\n" . '• للحسابات غير المشتركة (' . $cn . '): ' . ( $n ? $n['subject'] : '—' ) . "\n\n" . 'تُرسل رسالة كل 5 دقائق، نهارًا فقط (9 صباحًا حتى 9 مساءً بتوقيت الرياض).' );
		}
		return array( 'ok' => true, 'members' => $cm, 'nonmembers' => $cn );
	}

	public static function clear_pending() {
		global $wpdb;
		return (int) $wpdb->query( "DELETE FROM " . self::table() . " WHERE status='pending'" );
	}
}
