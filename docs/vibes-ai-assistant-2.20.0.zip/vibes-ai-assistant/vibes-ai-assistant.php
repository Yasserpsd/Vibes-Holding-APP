<?php
/**
 * Plugin Name: Vibes AI Assistant
 * Plugin URI:  https://vcmem.com/
 * Description: Ù…Ø³Ø§Ø¹Ø¯ Ù…Ù†Ø¸ÙˆÙ…Ø© Ú¤Ø§ÙŠØ¨Ø² Ø§Ù„Ø°ÙƒÙŠ â€” ÙˆÙŠØ¯Ø¬Øª Ù…Ø­Ø§Ø¯Ø«Ø© ÙŠØ¹Ù…Ù„ Ø¹Ù„Ù‰ ÙƒÙ„ Ù…ÙˆØ§Ù‚Ø¹ Ø§Ù„Ù…Ù†Ø¸ÙˆÙ…Ø© (ÙˆØ¶Ø¹ Â«Ù…ÙˆÙ‚Ø¹ ØªØ§Ø¨Ø¹Â») + Ù‚Ø§Ø¹Ø¯Ø© Ø¨ÙŠØ§Ù†Ø§Øª ÙˆØ¯Ø§Ø´Ø¨ÙˆØ±Ø¯ Ù…Ø±ÙƒØ²ÙŠØ© (ÙˆØ¶Ø¹ Â«Ø§Ù„Ù‡Ø¨Â») + Ø±Ø¨Ø· Ø¨Ø¹Ù‚Ù„ n8n.
 * Version:     2.20.0
 * Author:      Vibes Ventures
 * Text Domain: vibes-ai
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'VAI_VERSION', '2.20.0' );
define( 'VAI_FILE', __FILE__ );
define( 'VAI_DIR', plugin_dir_path( __FILE__ ) );
define( 'VAI_URL', plugin_dir_url( __FILE__ ) );

require_once VAI_DIR . 'includes/helpers.php';
require_once VAI_DIR . 'includes/class-vai-hub.php';
require_once VAI_DIR . 'includes/class-vai-site.php';
require_once VAI_DIR . 'includes/class-vai-admin.php';
require_once VAI_DIR . 'includes/class-vai-console.php';
require_once VAI_DIR . 'includes/class-vai-google.php';
require_once VAI_DIR . 'includes/class-vai-payments.php';
require_once VAI_DIR . 'includes/class-vai-gpt.php';
require_once VAI_DIR . 'includes/class-vai-mcp.php';

register_activation_hook( __FILE__, 'vai_on_activate' );
register_deactivation_hook( __FILE__, 'vai_on_deactivate' );

function vai_on_activate() {
	$s = get_option( 'vai_settings', array() );
	if ( ! is_array( $s ) ) {
		$s = array();
	}
	if ( empty( $s['mode'] ) ) {
		$s['mode'] = 'site';
	}
	if ( empty( $s['hub_key'] ) ) {
		$s['hub_key'] = vai_key( 40 );
	}
	if ( empty( $s['webhook_secret'] ) ) {
		$s['webhook_secret'] = vai_key( 32 );
	}
	update_option( 'vai_settings', $s, false );
	if ( $s['mode'] === 'hub' ) {
		VAI_Hub::install();
	}
	if ( ! wp_next_scheduled( 'vai_site_daily_sync' ) ) {
		wp_schedule_event( time() + 300, 'daily', 'vai_site_daily_sync' );
	}
	if ( ! wp_next_scheduled( 'vai_hub_cleanup' ) ) {
		wp_schedule_event( time() + 600, 'daily', 'vai_hub_cleanup' );
	}
	vai_ensure_roles();
}

/** Capability vai_dashboard: admins + the Â«Ù…Ø´Ø±Ù Vibes AIÂ» role (dashboard + replies only). */
function vai_ensure_roles() {
	$admin = get_role( 'administrator' );
	if ( $admin && ! $admin->has_cap( 'vai_dashboard' ) ) {
		$admin->add_cap( 'vai_dashboard' );
	}
	if ( ! get_role( 'vai_agent' ) ) {
		add_role( 'vai_agent', 'Ù…Ø´Ø±Ù Vibes AI', array( 'read' => true, 'vai_dashboard' => true ) );
	}
	update_option( 'vai_roles_v', '1', false );
}

function vai_on_deactivate() {
	wp_clear_scheduled_hook( 'vai_site_daily_sync' );
	wp_clear_scheduled_hook( 'vai_hub_cleanup' );
}

add_action(
	'plugins_loaded',
	function () {
		if ( vai_is_hub() ) {
			VAI_Hub::init();
			VAI_Console::init();
			VAI_Payments::init();
			// The ChatGPT manager link (REST + its 2.15.5 MCP wrapper) stays OFF until the owner himself
			// generates a key in the settings; clearing the key kills both at once.
			if ( trim( (string) vai_opt( 'gpt_api_key', '' ) ) !== '' ) {
				VAI_GPT::init();
				VAI_MCP::init();
			}
		}
		VAI_Site::init();
		if ( is_admin() ) {
			VAI_Admin::init();
		}
	}
);
