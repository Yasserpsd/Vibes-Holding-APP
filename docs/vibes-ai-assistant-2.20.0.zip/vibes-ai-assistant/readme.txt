=== Vibes AI Assistant ===
Contributors: vibesholding
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 2.20.0

مساعد Vibes Ventures الذكي: ويدجت محادثة يعمل على كل مواقع المنظومة (وضع «موقع تابع») + قاعدة بيانات وداشبورد مركزية (وضع «الهب») + ربط بعقل n8n (Vibes Web Agent).

== التثبيت ==
1. ثبّت البلجن على vcmem.com واختر وضع «الهب المركزي».
2. استورد Vibes_Web_Agent_v1.json في n8n واملأ عقدة Config، ثم الصق Production URL في إعدادات الهب.
3. أضف كل موقع من صفحة «المواقع» في الهب، وثبّت البلجن على ذلك الموقع بوضع «موقع تابع» مع مفتاحه.

== سجل التغييرات ==

= 2.18.3 =
* M90: the official management number +966551623111 is now the code default for mgmt_whatsapp and the member_services "تواصل مع الإدارة" line. The owner's personal number left every phone EXAMPLE: the Saudi example in the country list, the worldwide phone-policy sentence (AR + EN), the phone error, and the admin ticket/activation placeholders now show the dummy 0512345678.

= 2.18.2 =
* M69 on the pay page too: the register form asks individual / company under the name; a company registration requires the company name, held with the profile and written to the account on the e-mail confirmation.
* Brand rename: the trade name is written in Latin "Vibes Ventures" everywhere, even inside Arabic copy - the old Arabic names and the transliteration leave every user-visible text (widget, mails, pay pages, console, defaults). Domains and file names are untouched.


= 2.18.0 =
* M69: registration asks whether the account is for an individual or a company ("فرد / شركة") right under the name - choosing company reveals a required company-name field. Stored on the contact (new member_type column, DB 2.5.0; the company name lands in the existing company field), returned by public_contact and the bridge account rows, and shown in the console.

= 2.17.0 =
* The membership facts follow the owner's NEW vcmem membership page (2026-10-14): project assessment within 10 WORKING DAYS (was "3 days max"), the project re-highlighted ONCE A MONTH (was "3 times a month"), the online consultation is with the SMART ADVISOR (was "the club's experts"), the club theatre seats up to 80 (was 60), and the old named coming-soon discounts line became the "Our partners" promo-code benefit. A DB 2.4.0 migration rewrites the LIVE services catalog and every text setting (paymob_direct excluded, as always) so the brain and the mails stop quoting the old facts.
* New membership benefit everywhere it is listed: the member's personal "Our partners" promo code inside the club app (the partners screen and the membership card) - one 5-character code per member, honoured by every club partner.

= 2.16.1 =
* English mode shows every country's ENGLISH name: the list carries an English name per country (hub config + widget selector + phone help/errors + both pay-gate selects), and the worldwide phone-policy sentence joined the widget's EN dictionary - no Arabic leaks in the register sheet.

= 2.16.0 =
* Registration is open worldwide: the country list now holds all 198 countries (GCC first with their exact number rules and examples, then the Arab countries, then the rest sorted by Arabic name). Non-GCC numbers pass a generic length check (5-12 digits after the dial code, E.164 max 15); the hub stays the final word.
* Country flags: the six GCC keep their drawn SVG flags; every other country falls back to its emoji flag (ISO letter pair on Windows) in the widget and on the pay page.
* All "GCC only" wording removed from the widget, hub errors and the pay page; the e-mail wording now says any valid personal or company address (the allowed-domains setting still applies).

= 2.15.5 =
* One-click activation: the activation mail now leads with a single-use 48h link (/?vai-activate=...) that verifies the account instantly on a branded page - pre-paid memberships auto-activate exactly like the code path; the 4-digit code remains the fallback.
* All customer codes are 4 digits now (activation, pay-page proof, member-check, password reset, admin promotion); codes issued before the upgrade stay valid.
* The account sheet shows a loud "enter the activation code" button for any signed-in unactivated account, and hides the pay-membership button until the account is verified.
* The pay page states that all prices include VAT.

= 2.15.4 =
* The manager link now also speaks MCP (streamable HTTP): one URL from the settings page plugs straight into ChatGPT's "Add custom MCP server". Same opt-in key, same masked lists, same preview-then-confirm campaigns, same owner mail on every send; clearing the key kills REST and MCP together. The settings page shows the ready-to-copy MCP URL once a key is saved.

= 2.15.3 =
* Public member-check for the podcast price card: request mails the member his 6-digit code, verify answers active / needs_payment / expired / not_found with name and end date - nothing leaks before the code is proven. Rate-limited per IP and per contact, CORS restricted to the new origins setting (defaults to almoltaqapodcast.com).

= 2.15.2 =
* Pay-page registration completes BEFORE the payment (owner decision): a 6-digit e-mail code proves the payer owns the typed address, then the account is created at once - welcome mail to the member, instant registration notice to the owner, and the account survives an abandoned payment (he signs in and pays any time from the same page). The signed callback remains the only membership activator.
* Duplicate identities are refused with a sign-in hint instead of silently ignoring the typed password.
* Phone fields show a 05XXXXXXXX mask placeholder (the real example moved to a help line) on the pay page and in the widget; the activation-code box is bigger, gold-framed, auto-focused and labelled "type the code here".
* New opt-in manager API for a Custom GPT (ChatGPT): overview, reports, masked lists, and e-mail campaigns behind a preview-then-confirm token; off until a key is generated in the settings, every send is mailed to the owner, key removal cuts access instantly.

= 2.15.1 =
* No automatic mails at all (member complaints): the every-2-days schedule is removed and cleared on upgrade; every send is a manual button.
* Campaign composer gains a category filter (entrepreneurs / investors / neutral) beside the audience pick - like the app.

= 2.15.0 =
* Keyed pay links lock the gate to ONE service (?vai-pay=membership shows only the membership; ?vai-pay=workshop only the workshop).
* Every-2-days broadcast over the mail queue: rotating benefit topics for members, activation reminders for non-member accounts, owner summary mail, daytime-only sending.
* Bonus Projects-Bank balance from the members screen (hub -> PB bridge grant) with new bridge settings.
* English mode keeps the club logo (URLs are never touched by the dictionary).

= 2.14.3 =
* Social-born accounts: the admin notification now waits until the member completes his real data (one full mail, never an empty one).
* Complete-your-account form fixed: country flag + dial code + live phone help + category highlight now work (wireForm was missing).
* US flag on the language toggle in Arabic mode; the flag face always renders a default.

= 2.14.2 =
* English mode with zero fixed Arabic (full UI dictionary, EN timestamps, EN bot name) + Saudi-flag language toggle.
* Real drawn SVG GCC flags in every country selector (widget + pay gate) instead of emoji letter pairs.

= 2.14.1 =
* زر اللغة صار علم بريطانيا المرسوم (SVG حاد على كل الأجهزة — إيموجي الأعلام لا يظهر على ويندوز) وحرف «ع» أنيق للعودة للعربية؛ وشريط تمرير حريري رفيع لحقل الكتابة بدل شكل المتصفح الخام.

= 2.14.0 =
* تجربة مستخدم جديدة (M56): كومبوزر أنيق بحقل مستدير وزر إرسال متدرّج وحركات لمس سلسة (وخط 16px يمنع تقريب iOS أثناء الكتابة — أصل شكوى الكتابة)؛ تفاعلات إيموجي على رسائل المستشار زي واتساب (ضغطة مطولة على الجوال، مرور/دبل كليك على الكمبيوتر — ❤️ 👍 😂 😮 🙏) تظهر على الفقاعة وتصل للفريق كملاحظة في المحادثة ولا توقظ البوت؛ وإصلاح تنسيق خانات النبذة والدولة في صفحة الدفع.

= 2.13.0 =
* الويدجت تتكلم الإنجليزية (M55): زر EN/ع في رأس المساعد يقلب الواجهة كاملة — الترحيب وأزرار البداية والحقول والنماذج واتجاه الكتابة — والمستشار يرد بلغة الزائر كما هو. المحتوى العربي للمالك يبقى كما هو والإنجليزية نظائر مدمجة.

= 2.12.0 =
* صفحة الدفع الموحدة صارت تسجيلًا كاملًا صارمًا: الفئة والوظيفة والنبذة صارت ضمن الحقول وتُحفظ على الحساب مع الدفع؛ رقم الجوال يُفحص بأنماط دول الخليج الحقيقية والاسم العشوائي يُرفض والبريد يخضع لنفس سياسة قبول الويدجت.
* الإنجليزية الكاملة للصفحة عبر ?lang=en وزر تبديل داخل الصفحة.
* «المتابعة بحساب Google» داخل صفحة الدفع نفسها + إكمال إجباري (جوال/فئة/نبذة) لحسابات Google الناقصة قبل الدفع وقبل مراسلة المساعد في الويدجت.
* دخول تلقائي: متصفح الدافع يرتبط بحسابه لحظة تأكيد الدفع فيعود من صفحة الدفع مسجَّل الدخول.
* بريد ترحيب فوري بتفاصيل الحساب لكل من ينشئ حسابه بحساب Google/Apple.
* تقارير الإدارة (الملخص الدوري) تستثني محادثات الأدمن من الأرقام والقوائم.

= 2.11.2 =
* إلغاء قروبات الواتساب نهائيًا (قرار المالك): سطر «الانضمام إلى قروبات/مجموعات النادي» أُزيل من مزايا العضوية في الكتالوج ورسائل الأعضاء وسياق المستشار — والترقية تنظّف الصفوف والإعدادات النصية الحية تلقائيًا.

= 2.11.1 =
* تصحيح رصيد بنك المشاريع في كل النصوص: 2,500 ريال (لا 3,750) — في الكتالوج ورسائل الأعضاء والافتراضيات، والترقية تصحح الصفوف والإعدادات النصية الحية تلقائيًا.

= 2.11.0 =
* توحيد بوابة الدفع (M52): كل روابط الدفع في المنظومة صارت تشير إلى صفحة الدفع الواحدة `?vai-pay=…` — كتالوج الخدمات (والترقية تصحح الصفوف الحية تلقائيًا)، ومتغيرات الرسائل {pay_url} و{pitchdeck_url} و{urmeet_url}، ومكتبة الروابط وخدمات الأعضاء الافتراضية، وأي إعداد نصي محفوظ فيه روابط paymob.link القديمة يُستبدل عند الترقية (عدا خانة الروابط المباشرة نفسها). وعبارة «سنة أو سنتين بالسعر الترويجي» حُذفت من شروط دفع العضوية في الكتالوج — الاشتراك سنوي فقط.

= 2.10.3 =
* إصلاح حفظ «روابط الدفع المباشرة»: الحفظ من صفحة الإعدادات كان يضغط الأسطر في سطر واحد فلا يُقرأ أي رابط. الآن الأسطر تُحفظ كما هي، والقارئ نفسه صار يقرأ الأزواج «مفتاح | رابط» حتى لو التصقت في سطر واحد — القيمة المحفوظة بالفعل تعمل فور الترقية دون إعادة لصق.

= 2.10.2 =
* روابط الدفع المباشرة صارت لكل خدمة: الإعداد أصبح قائمة أسطر «المفتاح | الرابط» (مع سطر رابط فقط كافتراضي اختياري). كل خدمة تنقل لرابطها هي، والخدمة التي بلا رابط تختفي من الصفحة مؤقتًا — لا يمكن أن يصل زائر لرابط بمبلغ خدمة أخرى. القيمة القديمة (رابط واحد) تعمل كما هي كافتراضي للجميع.

= 2.10.1 =
* وضع مؤقت «رابط الدفع المباشر» (إعداد جديد في قسم صفحة الدفع): ما دام معبأً، زر الصفحة ينقل الدافع مباشرة إلى رابط Paymob (بدل خدمة الـ Intention المتوقفة من حساب Paymob). بيانات الزائر التي كتبها — بما فيها كلمة مروره (تُحفظ مشفّرة 48 ساعة) — تُطبَّق تلقائيًا عند وصول إشعار الدفع الموقّع بنفس جواله وبريده: حساب مفعّل بكلمة مروره + تفعيل العضوية + سطر «بدأ الطلب من صفحة الدفع بالموقع» في بريد الإشعار. كلمة المرور لا تُطبَّق أبدًا على حساب موجود. امسح الإعداد بعد إصلاح Paymob فتعود الصفحة للدفع الآلي بلا أي تغيير.

= 2.10.0 =
* نافذة دفع داخل الصفحة (M47): أي رابط في الموقع نفسه إلى ?vai-pay يفتح صفحة الدفع في نافذة منبثقة فوق الصفحة بدل مغادرتها — بزر إغلاق (✕) وبخلفية شفافة، وإدخال البطاقة يظل بالكامل على صفحة Paymob الآمنة في النافذة الرئيسية. الروابط من مواقع المنظومة الأخرى تفتح الصفحة كما هي.
* حارس الهويات المجهولة: دفعة عضوية ببيانات دفع وهمية (NA NA / na@na.com من الروابط القديمة) تُسجَّل ويصل تنبيهها، لكن لا يُنشأ لها حساب تلقائيًا ولا يُرسل رابط كلمة مرور لعناوين وهمية — التفعيل يدوي بعد معرفة صاحبها. لا شيء يتغير لمن يكتب بياناته في صفحة الدفع.

= 2.9.0 =
* زر «المتابعة بحساب Google» داخل الويدجت (تسجيل الدخول وإنشاء الحساب): Google Identity Services في المتصفح، والهب نفسه يتحقق من التوكن (توقيع RS256 عبر مفاتيح Google العلنية + الجمهور + الصلاحية) ثم ينشئ الحساب مفعّلًا فورًا أو يسجّل الدخول للحساب الموجود — بلا رمز بريد. كلمة مرور الحساب الموجود لا تُمس أبدًا.
* إعداد جديد في صفحة الإعدادات: «Google Web Client ID». فارغ = الزر مخفي ولا شيء يتغير في الموقع أو الويدجت.
* المواقع التابعة تمرر العملية عبر مسار /client نفسه — يلزم فقط إضافة أصل الموقع (origin) في Google Cloud على نفس معرّف العميل.
* لا تغيير في قاعدة البيانات ولا في المفاتيح ولا في مسار Paymob ورابط الإشعار. يُرفع فوق 2.8.2 مباشرة.

= 2.8.2 =
* سطر تشخيص في الإعدادات: «آخر محاولة دفع من صفحة الموقع» يبين هل نجح إنشاء عملية الدفع أو سبب الرفض بنص رد Paymob نفسه (HTTP ورسالة البوابة) — لتشخيص أخطاء «تعذّر الاتصال ببوابة الدفع» فورًا. لا تغيير وظيفي آخر.

= 2.8.1 =
* صفحة الدفع صارت تسجيلًا كاملًا (M45): الزائر الجديد يكتب اسمه وجواله وبريده **وكلمة مروره** — والحساب لا يُنشأ إلا بعد تأكيد الدفع الموقّع من Paymob (لا حساب بلا دفع)، وبعدها يدخل مباشرة بكلمة المرور التي اختارها (عضوية = تفعيل فوري؛ خدمة مدفوعة = حساب موثّق بدون عضوية). كلمة مرور موجودة مسبقًا لا تُلمس أبدًا.
* صاحب الحساب المسجّل دخوله (كوكي المساعد vai_uuid) يرى ترحيبًا باسمه ويختار الخدمة فقط — بلا إعادة كتابة أي بيانات؛ هويته تُؤخذ من حسابه على الخادم. ورابط «ادفع ببيانات أخرى» للجهاز المشترك.
* الزائر بلا حساب يرى نموذج «سجّل حسابك وادفع — خطوة واحدة» إجباريًا.
* لا تغيير في المفاتيح ولا الكولباك. يُرفع فوق 2.8.0 أو 2.7.x مباشرة.

= 2.8.0 =
* صفحة دفع من الموقع (M45): رابط جديد /?vai-pay يعرض خدمات جدول المبالغ، والزائر يدفع باسمه وجواله وبريده — البلجن ينشئ عملية الدفع بنفسه (Intention API) فتصل كل دفعة معروفًا صاحبها ويتفعّل تلقائيًا عبر نفس الكولباك الحالي. روابط Paymob القديمة وإعداداتها لم تُمَس. إعدادات جديدة: Secret/Public Key وأرقام الدمج — تُترك فارغة = لا شيء يتغير.
* دخول اجتماعي (M46): عملية جسر جديدة social_login لخادم التطبيق الموثوق فقط — الخادم يتحقق بنفسه من توكن Google/Apple ويطابق الحساب بالبريد أو ينشئه مفعّلًا فورًا (بدون رمز بريد). حساب واحد لكل المنظومة كما هو.
* لا تغيير في المفاتيح ولا في مسار كولباك Paymob ولا في رابط الإشعار. يُرفع فوق 2.7.2 مباشرة.

= 2.7.2 =
* الدعوات (M32 في التطبيق): التسجيل يقبل حقل «referral» اختياريًا = رقم عضوية عضو داعٍ. الهب نفسه يتحقق (حساب موجود ومفعّل وعضويته سارية) ويخزّن الداعي على الحساب الجديد في عمود جديد referred_by، ويرجعه في رد التسجيل وفي صفوف admin_accounts/admin_member. كود غير صحيح يوقف التسجيل برسالة واضحة. تسجيل الموقع (الويدجت) بلا كود كما هو بلا أي تغيير.
* رسالة النظام عند التسجيل تذكر «بدعوة من العضو #…» ليراها الأدمن في المحادثة.
* قاعدة البيانات: عمود referred_by على جدول contacts (ترقية تلقائية عند التفعيل، dbDelta). المفاتيح ومسار Paymob ورابط الإشعار كما هي بلا تغيير. يُرفع فوق 2.7.1 مباشرة.

= 2.7.1 =
* فئات النادي بترتيب واحد في كل مكان: «محايد — أستكشف توجهي» ثم «رائد أعمال — لدي مشروع» ثم «مستثمر — أبحث عن فرص» (نموذج التسجيل، رسائل الخطأ، صفحات الأدمن، بريد إشعار التسجيل، توجيه المستشار).
* الكلمة صارت «فئة» («فئتك في النادي») بدل «صفة» في نموذج التسجيل ورسائل الخطأ وبريد الإشعار وتوجيه المستشار؛ وحقل «الوظيفة أو المنصب».
* لا تغيير في قاعدة البيانات ولا في المفاتيح ولا في مسار Paymob ورابط الإشعار. يُرفع فوق 2.7.0 مباشرة.

= 2.7.0 =
* عقل واحد للموقع والتطبيق: عمليات جديدة لخادم تطبيق نادي المستثمرين (إحصاءات يومية، الحسابات، المدفوعات، التذاكر، الليدز، المحادثات والرد باسم الأدمن، طابور البريد، منح العضوية وتمديدها وإلغاؤها، دور «ناشر»).
* صلاحية «خادم التطبيق (صلاحيات إدارية)» في صفحة «المواقع»: العمليات الإدارية لا يجيبها الهب إلا لهذا الصف، والهب هو من يقرر من هو الأدمن.
* سجل تاريخ العضو (تسجيل، تفعيل بريد، تفعيل عضوية، تجديد، إلغاء، تغيير دور، حذف) مع تعبئة تلقائية لمرة واحدة من بيانات 2.6، وعمود تاريخ تفعيل البريد.
* تفعيل عضوية المتجر (Apple / Google) بلا تكرار عند إعادة الإشعار، والتجديد قبل الانتهاء يضيف الأيام ولا يضيّع المتبقي. مسار Paymob ورابط الإشعار كما هما بلا أي تغيير.
* حذف الحساب من التطبيق (بكلمة المرور): تُمسح البيانات الشخصية والمحادثات وتبقى سجلات الدفع.
* النشر من التطبيق يصل المساعد فورًا ويظهر على المواقع عبر الشورت كود [vai_feed kind="event" limit="6"].
* إشعار فوري موقّع (HMAC) لخادم التطبيق عند أي جديد — الإعداد من «الإعدادات» ← «المزامنة الفورية مع خادم التطبيق»، والسرّ يظهر مرة واحدة.
* المساعد صار اسمه الافتراضي «المستشار»، ويستقبل ما يشير إليه الزائر في الصفحة ونص الصفحة الحي ليجيب عنه بدقة.
* متانة: تغيير العضوية وسجلّه يُحفظان معًا أو لا يُحفظ شيء، والمرجع المستخدم لحساب آخر يُرفض ولا يُحسب تفعيلًا. الإشعار الفوري يُرسل بعد تسليم الرد فلا يؤخّر Paymob ولا المساعد، ويتوقف دقيقة إن لم يُجب خادم التطبيق. الصفحة أو المنشور المعدّل يصل التطبيق كجديد. وعلى موقع خادم التطبيق لا يُربط زائر بحساب قائم إلا بتسجيل الدخول.
* إصلاحات: عدّاد غير المقروء في ملخص الأدمن، أداة save_note صارت تعمل، منع تكرار رد المساعد عند إعادة المحاولة من n8n، زر «أرسل نسخة تجريبية لي» في صفحة البريد، ومفتاح الهب لم يعد يُقبل في رابط الطلب (الهيدر أو جسم الطلب فقط).
