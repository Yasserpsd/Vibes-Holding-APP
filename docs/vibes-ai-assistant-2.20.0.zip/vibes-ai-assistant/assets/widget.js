/* Vibes AI Assistant — website widget «المستشار» (vanilla JS, RTL). No build step: keep ES5 syntax. */
(function () {
	'use strict';
	var B = window.VAI_BOOT;
	if (!B || !B.cfg || !B.rest) { return; }
	if (window.__VAI_LOADED) { return; }
	window.__VAI_LOADED = true;

	var CFG = B.cfg, REST = B.rest;
	var LS = 'vai_state_v2';
	var MQ = window.matchMedia('(max-width: 640px)');
	var MOBILE = MQ.matches;
	var REDUCED = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	var state = load();
	var ui = {};
	var pollTimer = null, awaitingSince = 0, softWait = false, unread = 0, pendingImage = null;
	var pollFails = 0, offline = false;
	var focusCtx = null, focusEl = null; /* what the visitor points at («تسأل عن: …»), memory only */
	var lastSent = null, pendingRef = null, lateRef = null; /* { m, wrap, text, image, audio, ctx, err, cid, base, held } of the last / the gated message / the one whose reply we asked for again */
	var TIMEOUT_MS = Math.max(60, parseInt(CFG.reply_timeout, 10) || 180) * 1000;

	/* ───────── state ───────── */
	function load() {
		var s = null;
		try { s = JSON.parse(localStorage.getItem(LS) || 'null'); } catch (e) { s = null; }
		if (!s || typeof s !== 'object') { s = {}; }
		if (!s.uuid) { s.uuid = uuid(); }
		s.msgs = Array.isArray(s.msgs) ? s.msgs.slice(-80) : [];
		s.lastId = s.lastId || 0;
		s.contact = s.contact || null;
		s.open = !!s.open;
		s.fs = !!s.fs;
		s.pending = s.pending || null;
		s.prefill = s.prefill || null;
		s.seen = !!s.seen;
		s.fresh = !!s.fresh;
		s.awaiting = s.awaiting || 0;
		s.langSet = !!s.langSet; /* 2.20.0: true once the visitor picked a language himself (header toggle) */
		return s;
	}
	var lastAcctSig = '';
	/* ── M55 (owner: «مفيش انجليزي؟») — the widget speaks English: state.lang + a header toggle.
	   Fixed UI strings translate through L(); the owner's Arabic content (welcome/menu/notice) gets
	   built-in English counterparts; the adviser already replies in the visitor's own language. */
	/* 2.20.0 (owner: «مش عايز أي كلمة عربي تظهر لو حولته انجليزي»): until the visitor picks a language himself,
	   the widget FOLLOWS THE PAGE — Polylang /en/ URLs, <html lang="en">, or an explicit ?vai_lang=en
	   (used by the English mails' links). His own toggle choice then sticks (langSet). */
	(function () {
		var pageEN = /^en\b/i.test(document.documentElement.getAttribute('lang') || '') ||
			/(^|\/)en(\/|$)/.test(window.location.pathname) ||
			/[?&]vai_lang=en\b/.test(window.location.search);
		if (/[?&]vai_lang=(en|ar)\b/.test(window.location.search)) { state.langSet = false; } /* a mailed link wins over an old saved choice */
		state.lang = state.langSet ? (state.lang === 'en' ? 'en' : 'ar') : (pageEN ? 'en' : 'ar');
	})();
	var EN_UI = {
		'اكتب رسالتك هنا…': 'Type your message…',
		'المزيد': 'More',
		'دخول': 'Sign in',
		'حساب جديد': 'New account',
		'تسجيل الدخول': 'Sign in',
		'أو سجّل الدخول': 'or sign in',
		'رقم الجوال': 'Mobile number',
		'الاسم الكريم': 'Your name',
		'البريد الإلكتروني': 'E-mail',
		'كلمة المرور': 'Password',
		'التالي': 'Next',
		'أو': 'or',
		'إرسال': 'Send',
		'حفظ ومتابعة': 'Save & continue',
		'أكمل حسابك': 'Complete your account',
		'فئتك في النادي': 'Your club category',
		'الوظيفة أو المنصب': 'Job title',
		'نبذة مختصرة عنك': 'A short bio about you',
		'لخّص لي هذه الصفحة': 'Summarize this page',
		'حسابي': 'My account',
		'خروج': 'Sign out',
		'في خدمتك على مدار الساعة': 'at your service around the clock'
	};
	function L(ar) { return state.lang === 'en' && EN_UI[ar] ? EN_UI[ar] : ar; }
	var EN_TX = {
		'مساعد Vibes Ventures': 'Vibes Ventures Assistant',
		'نادي المستثمرين — شركة المجتمع الافتراضي للاستثمار': 'Investors Club — Virtual Community Investment Co.',
		'شركة المجتمع الافتراضي للاستثمار': 'Virtual Community Investment Co.',
		'نادي المستثمرين': 'Investors Club',
		'فريق نادي المستثمرين': 'Investors Club Team',
		'فريق النادي': 'Club Team',
		'المستشار': 'The Advisor',
		'حسابك بانتظار رمز التفعيل': 'Your account awaits its activation code',
		'أدخل الرمز': 'Enter the code',
		'إنشاء الحساب وإرسال الرمز': 'Create account & send the code',
		'رجوع لتعديل بياناتي': 'Back to edit my details',
		'حفظ والدخول': 'Save & sign in',
		'حفظ ومتابعة': 'Save & continue',
		'أرسل رمز الاستعادة': 'Send the recovery code',
		'تغيير كلمة المرور': 'Change password',
		'أكمل المحادثة': 'Continue the chat',
		'البريد الإلكتروني أو رقم الجوال': 'E-mail or mobile number',
		'البريد الإلكتروني': 'E-mail',
		'رقم الجوال': 'Mobile number',
		'كلمة المرور الجديدة': 'New password',
		'كلمة المرور': 'Password',
		'الاسم الكريم': 'Your name',
		'الاسم الكامل': 'Full name',
		'الوظيفة أو المنصب': 'Job title',
		'نبذة مختصرة عنك': 'A short bio about you',
		'فئتك في النادي': 'Your club category',
		'روابط السوشيال ميديا': 'Social media links',
		'الشركة أو المشروع': 'Company or project',
		'المدينة': 'City',
		'الموقع الإلكتروني': 'Website',
		'نسيت كلمة المرور؟': 'Forgot password?',
		'تذكرني': 'Remember me',
		'رمز التفعيل': 'Activation code',
		'حسابي': 'My account',
		'الحساب': 'Account',
		'خروج': 'Sign out',
		'دخول': 'Sign in',
		'تسجيل الدخول': 'Sign in',
		'حساب جديد': 'New account',
		'أو سجّل الدخول': 'or sign in',
		'التالي': 'Next',
		'إرسال': 'Send',
		'حفظ': 'Save',
		'رجوع': 'Back',
		'إغلاق': 'Close',
		'إلغاء': 'Cancel',
		'المزيد': 'More',
		'لحظة…': 'One moment…',
		'أو': 'or',
		'تسأل عن:': 'Asking about:',
		'إزالة موضوع السؤال': 'Clear the topic',
		'إزالة': 'Remove',
		'محادثة جديدة': 'New chat',
		'ملء الشاشة': 'Full screen',
		'خدمات الأعضاء': 'Member services',
		'واتساب الإدارة': 'Management WhatsApp',
		'أرسل صورة أو سكرين شوت': 'Send a photo or screenshot',
		'إرفاق صورة': 'Attach an image',
		'إزالة الصورة': 'Remove the image',
		'الصورة المرفقة': 'Attached image',
		'صورة مرفقة': 'Attached image',
		'إيموجي': 'Emoji',
		'إدراج': 'Insert',
		'سجّل رسالة صوتية (بالعربية)': 'Record a voice message',
		'تسجيل صوتي': 'Voice recording',
		'اكتب رسالتك هنا…': 'Type your message…',
		'رسالتك إلى': 'Your message to',
		'في خدمتك على مدار الساعة': 'at your service around the clock',
		'المحادثة': 'Conversation',
		'اقتراحات': 'Suggestions',
		'جدول': 'Table',
		'تشغيل': 'Play',
		'فيديو': 'Video',
		'حاول الآن': 'Retry now',
		'أجهّز لك الرد…': 'Preparing your reply…',
		'أراجع الصفحات والمعلومات لك…': 'Checking pages and details for you…',
		'ثوانٍ إضافية… الرد في الطريق': 'A few more seconds… your reply is on the way',
		'بانتظار عودة الاتصال…': 'Waiting for the connection…',
		'زائر — لم تسجّل الدخول بعد': 'Guest — not signed in yet',
		'بانتظار رمز التفعيل من بريدك': 'Awaiting the code from your inbox',
		'العضوية غير مفعّلة': 'Membership not active',
		'التحكم الكامل': 'Full control',
		'عندي عضوية': 'I have a membership',
		'أزرار المواقع': 'Site buttons',
		'الدولة ورمز الاتصال': 'Country and dial code',
		'الدولة': 'Country',
		'نوع الحساب': 'Account type',
		'اسم الشركة أو المنشأة التي يُسجّل الحساب باسمها.': 'The company or establishment this account is registered for.',
		'اسم الشركة': 'Company name',
		'اكتب اسم الشركة لإكمال التسجيل.': 'Enter the company name to continue.',
		'اكتب اسم الشركة لإكمال التسجيل': 'Enter the company name to continue',
		'اختر نوع الحساب: فرد أو شركة': 'Choose the account type: individual or company',
		'اكتب بريدك أو جوالك المسجّل، ونرسل لك رمزًا لتعيين كلمة مرور جديدة.': 'Enter your registered e-mail or mobile and we will send a code to set a new password.',
		'تفقّد مجلد الرسائل غير المرغوبة إن لم تجد الرسالة.': 'Check your spam folder if the message does not arrive.',
		'حساب واحد تدخل به على كل مواقع المنظومة.': 'One account signs you in across every ecosystem site.',
		'حسابك واحد على كل مواقع المنظومة — نفس البريد وكلمة المرور.': 'One account across the whole ecosystem — same e-mail and password.',
		'يصلك رمز التفعيل على هذا البريد — بريدك الشخصي أو بريد شركتك.': 'Your activation code arrives on this address — personal or company mail.',
		'اتركها فارغة إن لم ترد التغيير — 6 أحرف على الأقل.': 'Leave empty to keep it — at least 6 characters.',
		'سطر لكل رابط.': 'One link per line.',
		'سطر واحد يكفي — من أنت وماذا تبحث عنه.': 'One line is enough — who you are and what you seek.',
		'خطوة واحدة لإكمال حسابك — بياناتك تصلنا كاملة وتوصلك خدماتنا باسمك 🌹': 'One step to complete your account — full details mean full service under your name 🌹',
		'أكمل حسابك': 'Complete your account',
		'اختر فئتك في النادي': 'Choose your club category',
		'اكتب نبذة مختصرة حقيقية (سطر على الأقل)': 'Write a short real bio (at least one line)',
		'اكتمل حسابك ✅ أهلًا بك — كيف أقدر أخدمك؟': 'Your account is complete ✅ welcome — how can I help?',
		'محايد — أستكشف توجهي': 'Neutral — exploring my direction',
		'رائد أعمال — لدي مشروع': 'Entrepreneur — I have a project',
		'مستثمر — أبحث عن فرص': 'Investor — seeking opportunities',
		'أستكشف توجهي': 'exploring my direction',
		'لدي مشروع': 'I have a project',
		'أبحث عن فرص': 'seeking opportunities',
		'محايد': 'Neutral',
		'رائد أعمال': 'Entrepreneur',
		'مستثمر': 'Investor',
		'السعودية': 'Saudi Arabia',
		'الإمارات': 'UAE',
		'الكويت': 'Kuwait',
		'قطر': 'Qatar',
		'البحرين': 'Bahrain',
		'عُمان': 'Oman',
		'التسجيل متاح من أي دولة في العالم. اختر دولتك من القائمة واكتب رقم الجوال بدون مسافات وبدون رمز الدولة — في السعودية مثلًا بهذا الشكل: 0512345678.': 'Registration is open from any country in the world. Pick your country from the list and enter your mobile number without spaces and without the country code — in Saudi Arabia, for example: 0512345678.',
		'اكتب الرقم بدون رمز الدولة وبدون مسافات، مثال:': 'Write the number without the country code and without spaces, e.g.:',
		'اكتب الرقم بدون رمز الدولة وبدون مسافات': 'Write the number without the country code and without spaces',
		'اكتب رقمك مثل': 'Write your number like',
		'مثال:': 'e.g.:',
		'تعذّر الدخول بحساب Google — ادخل بالبريد وكلمة المرور.': 'Google sign-in failed — use e-mail and password.',
		'تعذّر تحميل زر Google — استخدم البريد وكلمة المرور.': 'Could not load the Google button — use e-mail and password.',
		'تعذّر إتمام الدخول بحساب Google — حاول مرة ثانية.': 'Google sign-in did not complete — try again.',
		'جارٍ التحقق من حسابك…': 'Verifying your account…',
		'جارٍ التحقق من الرابط…': 'Verifying the link…',
		'تم إنشاء حسابك بحساب Google ✅': 'Your account was created with Google ✅',
		'تم تسجيل الدخول بحساب Google ✅': 'Signed in with Google ✅',
		'تعذّر الاتصال — تأكد من الإنترنت وحاول مرة ثانية.': 'Connection failed — check your internet and try again.',
		'رقم الجوال غير صحيح أو ناقص — اكتبه بدون مسافات وبدون رمز الدولة': 'Invalid or incomplete mobile number — write it without spaces and without the country code',
		' بهذا الشكل: ': ', like this: ',
		' — التحكم الكامل في المنظومة': ' — full control of the ecosystem',
		'عضو نادي المستثمرين': 'Investors Club member',
		' — باقي ': ' — ',
		'انتهت عضويتك السنوية — جدّدها': 'Your annual membership has expired — renew it',
		'عضويتك غير مفعّلة — فعّلها الآن': 'Your membership is not active — activate it now',
		'أدخل الرمز الذي وصلك على ': 'Enter the code sent to ',
		' — اكتبه في الخانة التالية 👇': ' — type it in the box below 👇',
		'اكتب الرمز هنا (4 أرقام)': 'Type the code here (4 digits)',
		'وصلك على بريدك — يتفعّل حسابك تلقائيًا مع آخر رقم. أو افتح الرابط الذي في نفس الرسالة فيتفعّل حسابك بضغطة واحدة.': 'Sent to your inbox — the last digit activates automatically, or open the link in the same mail for one-click activation.',
		'وصلك على بريدك — صالح 20 دقيقة.': 'Sent to your inbox — valid for 20 minutes.',
		'بريدك': 'your inbox',
		'أدمن': 'Admin',
		'يومان': '2 days remaining',
		'يومًا': 'days remaining',
		'أيام': 'days remaining',
		'يوم': 'day remaining',
		'فعّل عضويتك السنوية': 'Activate your annual membership',
		'فعّل عضويتك': 'Activate your membership',
		'العضوية': 'Membership',
		'تصغير النافذة': 'Exit full screen',
		'افتح': 'Open',
		'أغلق': 'Close',
		'رسالة جديدة': 'new message(s)',
		'حساب المنظومة': 'Ecosystem account',
		'ثوانٍ… أفتح لك الصفحة': 'One second… opening the page',
		'اقتراحات أكثر': 'More suggestions',
		'لا يوجد اتصال بالإنترنت — نعيد المحاولة تلقائيًا.': 'No internet connection — retrying automatically.',
		'عاد الاتصال ✅': 'Connection restored ✅',
		'تم تسجيل الخروج.': 'Signed out.',
		'إعادة الإرسال': 'Resend',
		'تغيير الصورة': 'Change photo',
		'إخفاء كلمة المرور': 'Hide password',
		'إظهار كلمة المرور': 'Show password',
		'تعذّر الحفظ — حاول ثانية': 'Could not save — try again',
		'الخطوة ': 'Step ',
		' من 2': ' of 2',
		'بياناتك': 'Your details',
		'فئتك ونبذتك': 'Category & bio',
		'ممتاز': 'Great',
		' من 10 أحرف على الأقل': ' of at least 10 characters',
		'أهلًا ': 'Welcome ',
		'حسابك جاهز ومفعّل ': 'Your account is ready and active ',
		'. اختر كلمة مرور لتدخل بها على كل مواقع المنظومة.': '. Choose a password to sign in with across every ecosystem site.',
		'اسأل المستشار': 'Ask the Advisor',
		' عن: ': ' about: ',
		'إزالة التفاعل': 'Remove the reaction',
		'اختياري': 'optional',
		'لوحة الإدارة — كل المحادثات': 'Admin console — all conversations',
		'موقع شركتك': 'Company website',
		'نبذة قصيرة عنك أو عن مشروعك': 'A short bio about you or your project',
		'كلمة مرور جديدة': 'New password',
		'لا توجد خدمات مضافة بعد.': 'No services added yet.',
		'تقدر ترسل رسالة صوتية بالعربية — اضغط الميكروفون، تكلّم، ثم اضغطه مرة ثانية للإرسال.': 'You can send a voice message — press the microphone, speak, then press it again to send.',
		'حسابك': 'Your account',
		'تبدأ محادثة جديدة؟': 'Start a new chat?',
		'سجلك السابق يبقى محفوظًا عندنا.': 'Your previous history stays saved with us.',
		'ابدأ محادثة جديدة': 'Start a new chat',
		'التسجيل متاح للسعوديين والمقيمين في المملكة ودول مجلس التعاون الخليجي.': 'Registration is open to Saudis and to residents of the Kingdom and the GCC.',
		'اكتب رقم الجوال بدون مسافات وبدون رمز الدولة بهذا الشكل:': 'Write the mobile number without spaces and without the country code, like this:',
		'أو اختر دولتك الخليجية من القائمة.': 'or pick your GCC country from the list.',
		'رقم الجوال غير صحيح — اكتبه بهذا الشكل:': 'Invalid mobile number — write it like this:',
		'أو اختر دولتك الخليجية': 'or pick your GCC country',
		'استعادة كلمة المرور': 'Password recovery',
		'البريد الإلكتروني أو الجوال المسجّل': 'Registered e-mail or mobile',
		'الجوال المسجّل': 'registered mobile',
		/* ── 2.20.0 (owner: «مش عايز أي كلمة عربي تظهر لو حولته انجليزي») — the full sweep:
		   every fixed UI string, every hub response the widget shows, forms, voice, errors. ── */
		'طلبات كثيرة — انتظر قليلًا ثم حاول مرة ثانية.': 'Too many requests — wait a moment and try again.',
		'تعذّر الحفظ': 'Could not save',
		'الخدمة غير متاحة مؤقتًا — حاول بعد قليل.': 'The service is temporarily unavailable — try again shortly.',
		'السلام عليكم، كنت أتحدث مع ': 'Hello, I was chatting with ',
		' على الموقع': ' on the website',
		' — أنا ': ' — I am ',
		' وأحتاج متابعة من الإدارة.': ' and I need a follow-up from the management.',
		'السلام عليكم، أنا ': 'Hello, I am ',
		' — عضو في نادي المستثمرين.\n جوالي: ': ' — an Investors Club member.\nMy mobile: ',
		' — عضو في نادي المستثمرين.': ' — an Investors Club member.',
		'جوالي: ': 'My mobile: ',
		'بريدي: ': 'My e-mail: ',
		'أرغب في الاستفادة من: ': 'I would like to use: ',
		'دفعت اشتراك عضوية النادي وأحتاج تفعيلها في ': 'I paid the club membership subscription and need it activated on ',
		'اسأل ': 'Ask ',
		' عن أي شيء في هذه الصفحة': ' about anything on this page',
		'عن:': 'About:',
		'تسأل الآن عن: ': 'Now asking about: ',
		'هذا العنصر': 'this item',
		'اعرضه في الصفحة': 'Show it on the page',
		'(أرسل صورة)': '(sent a photo)',
		'افتح الرابط': 'Open the link',
		'راسل الإدارة على واتساب': 'Message the management on WhatsApp',
		'راسل الإدارة': 'Message the management',
		'النموذج': 'the form',
		' وأكمل معك هناك ↗': ' and I continue with you there ↗',
		'افتح الصفحة وأكمل معك هناك ↗': 'Open the page — I continue with you there ↗',
		'نفس المحادثة تكمل معك هناك': 'The same conversation continues with you there',
		' يكتب…': ' is typing…',
		'لحظة — ': 'One moment — ',
		' يكتب ردّه، وبعدها أرسل رسالتك.': ' is writing a reply — send your message after it.',
		'الصفحة': 'the page',
		'🔗 جاري فتح ': '🔗 Opening ',
		'التسجيل الصوتي يحتاج اتصالًا آمنًا (https).': 'Voice recording needs a secure connection (https).',
		'انتظر الرد الحالي ثم سجّل صوتك.': 'Wait for the current reply, then record your voice.',
		'تم إلغاء التسجيل.': 'Recording cancelled.',
		'التسجيل قصير جدًا — اضغط الميكروفون وتكلم ثم اضغطه مرة ثانية للإرسال.': 'The recording is too short — press the microphone, speak, then press it again to send.',
		'التسجيل طويل — حاول رسالة أقصر.': 'The recording is too long — try a shorter message.',
		'لم يُسمح بالوصول للميكروفون — اسمح به من إعدادات المتصفح ثم حاول مرة ثانية.': 'Microphone access was not allowed — allow it in your browser settings and try again.',
		'إلغاء التسجيل': 'Cancel the recording',
		'انتظر الرد الحالي ثم أرسل الصوت.': 'Wait for the current reply, then send the voice note.',
		'🎤 رسالة صوتية': '🎤 Voice message',
		'تعذّر إرسال الصوت — حاول مرة ثانية.': 'Could not send the voice note — try again.',
		'الصورة كبيرة جدًا — جرّب صورة أصغر.': 'The image is too large — try a smaller one.',
		'تعذّر قراءة الصورة — جرّب صورة أخرى.': 'Could not read the image — try another one.',
		'تعذّر قراءة الصورة.': 'Could not read the image.',
		'تعذّر الوصول إلى ': 'Could not reach ',
		' — حاول مرة ثانية.': ' — try again.',
		'أحد أعضاء الفريق يتابع محادثتك الآن — بيرد عليك هنا.': 'A team member is following your chat now — they will reply to you here.',
		'لم يصل الرد بعد — رسالتك محفوظة عندنا. انتظر قليلًا، أو اكتب سؤالك بصيغة أخرى.': 'No reply yet — your message is saved with us. Wait a little, or rephrase your question.',
		'تأخر الرد أكثر من المعتاد — رسالتك وصلت، ولو جهز الرد بيظهر هنا تلقائيًا.': 'The reply is taking longer than usual — your message arrived, and the reply will appear here automatically once ready.',
		'تأخر الرد أكثر من المعتاد — لو وصل بيظهر هنا تلقائيًا، أو أعد الإرسال.': 'The reply is taking longer than usual — it will appear here automatically, or resend.',
		'تحقّق الآن': 'Check now',
		'باقي لك اليوم ': 'You have ',
		' رسالة مع ': ' message(s) left today with ',
		' — يتجدد غدًا': ' — it resets tomorrow',
		'✅ عبّيت لك ': '✅ I filled ',
		' من الحقول — راجعها، أرفق الملفات إن وُجدت، ثم اضغط إرسال بنفسك.': ' field(s) for you — review them, attach any files, then press send yourself.',
		'ما قدرت ألاقي حقول النموذج تلقائيًا — البيانات جاهزة في المحادثة، انسخها للنموذج.': 'I could not find the form fields automatically — the details are ready in the chat, copy them into the form.',
		'اشرح لي هذا النص': 'Explain this text to me',
		'ما المقصود به عمليًا؟': 'What does it mean in practice?',
		'لخّصه في نقاط': 'Summarize it in bullet points',
		'حدّثني عن هذا': 'Tell me about this',
		'ما أهم ما يجب أن أعرفه؟': 'What is the most important thing to know?',
		'هل يناسبني؟ ولماذا؟': 'Is it right for me? And why?',
		'، مثال: ': ', e.g.: ',
		'، ': ', ',
		'التحكم الكامل — لوحة الإدارة': 'Full control — admin console',
		'عضو النادي': 'Club member',
		'عضو — باقي ': 'Member — ',
		'فعّل حسابك': 'Activate your account',
		'أدخل رمز البريد': 'Enter the e-mail code',
		'ريال': 'SAR',
		'(حتى ': '(until ',
		'أدخل رمز التفعيل': 'Enter the activation code',
		'تعديل بياناتي': 'Edit my details',
		'تغيير صورتي': 'Change my photo',
		'تسجيل الخروج': 'Sign out',
		'جارٍ الخروج…': 'Signing out…',
		'رفع صورتي وتعديل بياناتي': 'Upload my photo & edit my details',
		'رفع صورتي': 'Upload my photo',
		'تم تحديث ملفك ✅': 'Your profile was updated ✅',
		'ملفي الشخصي': 'My profile',
		'أنشئ كلمة مرورك': 'Create your password',
		'نسيت كلمة المرور': 'Forgot password',
		'الرابط غير صالح — استخدم «نسيت كلمة المرور».': 'The link is not valid — use "Forgot password".',
		'الرابط غير صالح أو انتهت صلاحيته — استخدم «نسيت كلمة المرور» ببريدك': 'The link is not valid or expired — use "Forgot password" with your e-mail',
		'الرابط غير صالح أو انتهت صلاحيته': 'The link is not valid or expired',
		'6 أحرف على الأقل.': 'At least 6 characters.',
		'كلمة المرور 6 أحرف فأكثر.': 'The password must be at least 6 characters.',
		'كلمة المرور 6 أحرف على الأقل': 'The password must be at least 6 characters',
		'تم حفظ كلمة مرورك ودخولك ✅': 'Your password was saved and you are signed in ✅',
		'تعذّر الاتصال — حاول مرة ثانية.': 'Connection failed — try again.',
		'اكتب اسمك الكريم.': 'Enter your name.',
		'الاسم مطلوب': 'The name is required',
		'اختر نوع الحساب: فرد أو شركة': 'Choose the account type: Individual or Company',
		'فرد': 'Individual',
		'شركة': 'Company',
		'البريد الإلكتروني غير صحيح — سيصلك كود التفعيل عليه، فتأكد من كتابته صحيحًا (أي بريد شخصي أو بريد شركة مقبول)': 'The e-mail is not valid — your activation code arrives on it, so write it carefully (any personal or company mail is accepted)',
		'البريد الإلكتروني غير صحيح — سيصلك كود التفعيل عليه، فتأكد من كتابته صحيحًا.': 'The e-mail is not valid — your activation code arrives on it, so write it carefully.',
		'البريد الإلكتروني مطلوب — يصلك عليه رمز التفعيل': 'The e-mail is required — your activation code arrives on it',
		'سيصلك كود التفعيل على هذا البريد — تأكد من كتابته صحيحًا (بريد شخصي أو بريد شركتك، أي دومين مقبول)': 'Your activation code arrives on this e-mail — write it carefully (personal or company mail, any domain is accepted)',
		'اختر فئتك في النادي: محايد، رائد أعمال، أو مستثمر': 'Choose your club category: Neutral, Entrepreneur, or Investor',
		'اكتب نبذة مختصرة عنك (سطر على الأقل).': 'Write a short bio about yourself (at least one line).',
		'اكتب نبذة مختصرة عنك (سطر على الأقل) لنكمل التسجيل': 'Write a short bio about yourself (at least one line) to complete the registration',
		'اختر اهتمامًا واحدًا على الأقل (حتى 3).': 'Pick at least one interest (up to 3).',
		'اهتماماتك (اختر من 1 إلى 3)': 'Your interests (pick 1 to 3)',
		'جارٍ إنشاء الحساب…': 'Creating your account…',
		'تعذّر إنشاء الحساب — حاول مرة ثانية.': 'Could not create the account — try again.',
		'خطوات التسجيل': 'Registration steps',
		'من أنت وماذا تبحث عنه — سطر واحد يكفي.': 'Who you are and what you seek — one line is enough.',
		'كلمة مرور لحسابك': 'A password for your account',
		'تفعيل الحساب': 'Account activation',
		'أرسلنا رمز التفعيل إلى بريدك': 'We sent the activation code to your inbox',
		'أرسلنا رمز التفعيل إلى ': 'We sent the activation code to ',
		'أعدنا إرسال الرمز إلى ': 'We sent the code again to ',
		'تعذّر إرسال البريد الآن — اضغط «إعادة الإرسال» بعد لحظات أو تواصل مع الإدارة': 'Could not send the mail right now — press "Resend" in a few moments or contact the management',
		'تعذّر إرسال البريد — تواصل مع الإدارة': 'Could not send the mail — contact the management',
		'لا يوجد حساب بانتظار التفعيل': 'No account is awaiting activation',
		'انتظر دقيقة قبل إعادة الإرسال': 'Wait a minute before resending',
		'محاولات كثيرة — أعد إرسال رمز جديد': 'Too many attempts — resend a new code',
		'محاولات كثيرة — حاول بعد قليل': 'Too many attempts — try again shortly',
		'محاولات كثيرة — انتظر 15 دقيقة أو استخدم «نسيت كلمة المرور»': 'Too many attempts — wait 15 minutes or use "Forgot password"',
		'الرمز غير صحيح أو انتهت صلاحيته': 'The code is not correct or it expired',
		'عندك حساب بهذا البريد أو الجوال — سجّل الدخول، أو استخدم «نسيت كلمة المرور»': 'You already have an account with this e-mail or mobile — sign in, or use "Forgot password"',
		'معرّف الزائر غير صحيح': 'Invalid visitor id',
		'كود الدعوة غير صحيح أو عضوية صاحبه غير سارية — راجعه مع من دعاك، أو امسحه وأكمل التسجيل': 'The invite code is not valid or its owner\'s membership is not active — check it with whoever invited you, or clear it and continue',
		'نخدم داخل المملكة فقط — نحتاج رقم جوال سعودي (966)': 'We serve inside the Kingdom only — a Saudi mobile number (966) is needed',
		'رقم الجوال غير صحيح أو ناقص — تأكد من اختيار دولتك من القائمة ثم اكتب الرقم بدون مسافات وبدون رمز الدولة': 'Invalid or incomplete mobile number — pick your country from the list, then write the number without spaces and without the country code',
		' (للسعودية)': ' (for Saudi Arabia)',
		' بهذا الشكل: ': ', like this: ',
		'تفعيل حسابي': 'Activate my account',
		'لم يصلك؟ إعادة إرسال الرمز': 'Nothing arrived? Resend the code',
		'تسجيل ببريد آخر': 'Register with another e-mail',
		'إن كان الحساب موجودًا فقد وصلك رمز على بريدك — صالح 20 دقيقة.': 'If the account exists, a code was sent to your inbox — valid for 20 minutes.',
		'تعذّر إعادة الإرسال — حاول بعد قليل.': 'Could not resend — try again shortly.',
		'تمت إعادة الإرسال': 'Sent again',
		'اكتب بريدك الإلكتروني أو رقم جوالك المسجّل.': 'Enter your registered e-mail or mobile number.',
		'اكتب بريدك الإلكتروني أو رقم جوالك.': 'Enter your e-mail or mobile number.',
		'اكتب كلمة المرور.': 'Enter your password.',
		'اكتب الرمز الذي وصلك على بريدك.': 'Enter the code sent to your inbox.',
		'جارٍ الدخول…': 'Signing in…',
		'بيانات الدخول غير صحيحة.': 'Incorrect sign-in details.',
		'البريد/الجوال أو كلمة المرور غير صحيحة': 'The e-mail/mobile or the password is not correct',
		'حسابك بانتظار التفعيل — أرسلنا الرمز إلى ': 'Your account awaits activation — we sent the code to ',
		'تم تسجيل الدخول ✅': 'Signed in ✅',
		'جارٍ التفعيل…': 'Activating…',
		'الرمز غير صحيح.': 'The code is not correct.',
		'تم تفعيل حسابك ✅': 'Your account is activated ✅',
		'من زر «حسابي» تقدر ترفع صورتك وتعدّل بياناتك في أي وقت — حسابك واحد على كل مواقع المنظومة.': 'From the "My account" button you can upload your photo and edit your details any time — one account across the whole ecosystem.',
		'جارٍ الإرسال…': 'Sending…',
		'تعذّر الإرسال — حاول مرة ثانية.': 'Could not send — try again.',
		'جارٍ الحفظ…': 'Saving…',
		'تم تغيير كلمة المرور ✅ سجّل الدخول الآن.': 'Password changed ✅ sign in now.',
		'أنشئ حسابك للمتابعة': 'Create your account to continue',
		'عندي حساب؟ دخول': 'Have an account? Sign in',
		'بصيغة 05… أو 966…': 'in the form 05… or 966…',
		'بياناتك تُستخدم فقط لمتابعة طلبك من فريق نادي المستثمرين.': 'Your details are used only so the Investors Club team can follow up your request.',
		'اكتب رقم جوالك كاملًا.': 'Enter your full mobile number.',
		'تعرّفت عليك ✅': 'Got it — I know you now ✅',
		'تم حفظ بياناتك ✅': 'Your details were saved ✅',
		'عندي عضوية — تحقّق': 'I have a membership — verify',
		'جارٍ التحقق…': 'Verifying…',
		'تم التحقق من عضويتك ✅ نكمل بلا حدود.': 'Your membership is verified ✅ we continue without limits.',
		'تعذّر التحقق الآن — حاول بعد قليل.': 'Could not verify right now — try again shortly.',
		'ما لقيت اشتراكك بعد. لو دفعت الآن، اضغط «عندي عضوية» بعد دقائق، أو راسل الإدارة لتفعيلها فورًا.': 'I could not find your subscription yet. If you just paid, press "I have a membership" in a few minutes, or message the management to activate it right away.',
		'تعذّر نقل محادثتك من الموقع السابق — يمكنك المتابعة من هنا.': 'Could not move your chat from the previous site — you can continue from here.',
		'✅ وصلتنا دفعتك — يفعّل النظام عضويتك تلقائيًا خلال لحظات': '✅ We received your payment — the system activates your membership automatically in moments',
		'، وإن لم يكن لك حساب بعد فأنشئه بنفس الجوال أو البريد الذي دفعت به.': ', and if you have no account yet, create one with the same mobile or e-mail you paid with.',
		'تعذّر تحديث حالة عضويتك الآن — افتح «حسابي» بعد لحظات.': 'Could not refresh your membership status — open "My account" in a few moments.',
		' جاهز لأسئلتك': ' is ready for your questions',
		'الدفع الآمن — نادي المستثمرين': 'Secure checkout — Investors Club',
		'سجّل الدخول أولًا': 'Sign in first',
		'رقم الجوال غير صحيح — اكتبه بهذا الشكل: 0512345678 أو اختر دولتك الخليجية': 'Invalid mobile number — write it like 0512345678 or pick your GCC country',
		'هذا الجوال مسجّل لحساب آخر': 'This mobile belongs to another account',
		'هذا البريد مسجّل لحساب آخر': 'This e-mail belongs to another account',
		'التسجيل غير متاح حاليًا — تواصل مع الإدارة': 'Registration is not available right now — contact the management',
		'هذا الجوال مسجّل ببريد آخر — استخدم نفس البريد المسجّل أو تواصل مع الإدارة': 'This mobile is registered under another e-mail — use that same e-mail or contact the management'
	};
	var TX_KEYS = Object.keys(EN_TX).sort(function (a, b) { return b.length - a.length; });
	function trText(html) {
		if (state.lang !== 'en' || html == null || typeof html !== 'string' || !/[\u0600-\u06FF]/.test(html)) { return html; }
		/* 2.15.0: URLs may carry Arabic (the club logo does) — stash src/href attributes so the dictionary never touches them */
		var stash = [];
		/* 2.20.0: value= joined the stash — checkbox values and the visitor's own typed drafts are DATA, never translated */
		html = html.replace(/(src|href|srcset|poster|value)="[^"]*"/gi, function (m) { stash.push(m); return '\u0001' + (stash.length - 1) + '\u0001'; });
		for (var i = 0; i < TX_KEYS.length; i++) {
			if (html.indexOf(TX_KEYS[i]) !== -1) { html = html.split(TX_KEYS[i]).join(EN_TX[TX_KEYS[i]]); }
		}
		return html.replace(/\u0001(\d+)\u0001/g, function (_, n) { return stash[+n]; });
	}

	var EN_WELCOME = 'Welcome 🌹 I am the assistant of Vibes Ventures and the Investors Club.\nAsk me about anything in the ecosystem — I can open pages, fill forms for you and line up your next step. How can I help?';
	var EN_MENU = ['Join the club', 'Membership & benefits', 'I have a project to present', 'Vibes companies', 'UrMeet — your own forum', 'Professional Pitch Deck', 'Projects Bank', 'Contact management'];
	var EN_UNSAVED = 'This chat is not saved — after closing I may not recall its details. With the annual club membership I become your personal advisor with full memory, around the clock.';
	function applyLangDir() {
		var dir = state.lang === 'en' ? 'ltr' : 'rtl';
		if (ui.root) { ui.root.setAttribute('dir', dir); ui.root.style.direction = dir; }
		if (ui.panel) { ui.panel.setAttribute('dir', dir); }
	}
	var US_FLAG = '<svg class="vai-flag" viewBox="0 0 24 16" width="22" height="15" aria-hidden="true"><defs><clipPath id="vfus"><rect width="24" height="16" rx="2.5"/></clipPath></defs><g clip-path="url(#vfus)"><rect width="24" height="16" fill="#fff"/><path d="M0 0h24v1.231H0zM0 2.462h24v1.231H0zM0 4.923h24v1.231H0zM0 7.385h24v1.231H0zM0 9.846h24v1.231H0zM0 12.308h24v1.231H0zM0 14.769h24v1.231H0z" fill="#B22234"/><rect width="9.6" height="8.615" fill="#3C3B6E"/><g fill="#fff"><circle cx="1" cy="1.1" r=".42"/><circle cx="2.9" cy="1.1" r=".42"/><circle cx="4.8" cy="1.1" r=".42"/><circle cx="6.7" cy="1.1" r=".42"/><circle cx="8.6" cy="1.1" r=".42"/><circle cx="1.95" cy="2.55" r=".42"/><circle cx="3.85" cy="2.55" r=".42"/><circle cx="5.75" cy="2.55" r=".42"/><circle cx="7.65" cy="2.55" r=".42"/><circle cx="1" cy="4" r=".42"/><circle cx="2.9" cy="4" r=".42"/><circle cx="4.8" cy="4" r=".42"/><circle cx="6.7" cy="4" r=".42"/><circle cx="8.6" cy="4" r=".42"/><circle cx="1.95" cy="5.45" r=".42"/><circle cx="3.85" cy="5.45" r=".42"/><circle cx="5.75" cy="5.45" r=".42"/><circle cx="7.65" cy="5.45" r=".42"/><circle cx="1" cy="6.9" r=".42"/><circle cx="2.9" cy="6.9" r=".42"/><circle cx="4.8" cy="6.9" r=".42"/><circle cx="6.7" cy="6.9" r=".42"/><circle cx="8.6" cy="6.9" r=".42"/></g></g></svg>';
	var FLAGS = {
		sa: '<svg class="vai-flag" viewBox="0 0 24 16" width="22" height="15" aria-hidden="true"><defs><clipPath id="vfsa"><rect width="24" height="16" rx="2.5"/></clipPath></defs><g clip-path="url(#vfsa)"><rect width="24" height="16" fill="#006C35"/><text x="12" y="7.1" text-anchor="middle" fill="#fff" font-size="3.1" font-family="IBM Plex Sans Arabic,Tahoma,sans-serif">لا إله إلا الله محمد رسول الله</text><path d="M18.2 10.7H6.4L4.9 11.3l1.5.6h11.8z" fill="#fff"/><rect x="18.5" y="10.35" width=".6" height="1.9" rx=".3" fill="#fff"/><rect x="19.4" y="10.75" width="1.6" height="1.1" rx=".55" fill="#fff"/></g></svg>',
		ae: '<svg class="vai-flag" viewBox="0 0 24 16" width="22" height="15" aria-hidden="true"><defs><clipPath id="vfae"><rect width="24" height="16" rx="2.5"/></clipPath></defs><g clip-path="url(#vfae)"><rect width="24" height="16" fill="#fff"/><rect width="24" height="5.4" fill="#00732F"/><rect y="10.6" width="24" height="5.4" fill="#000"/><rect width="6.4" height="16" fill="#FF0000"/></g></svg>',
		kw: '<svg class="vai-flag" viewBox="0 0 24 16" width="22" height="15" aria-hidden="true"><defs><clipPath id="vfkw"><rect width="24" height="16" rx="2.5"/></clipPath></defs><g clip-path="url(#vfkw)"><rect width="24" height="16" fill="#fff"/><rect width="24" height="5.4" fill="#007A3D"/><rect y="10.6" width="24" height="5.4" fill="#CE1126"/><path d="M0 0l7.5 5.33v5.34L0 16z" fill="#000"/></g></svg>',
		qa: '<svg class="vai-flag" viewBox="0 0 24 16" width="22" height="15" aria-hidden="true"><defs><clipPath id="vfqa"><rect width="24" height="16" rx="2.5"/></clipPath></defs><g clip-path="url(#vfqa)"><rect width="24" height="16" fill="#fff"/><path d="M24 0H9L6.5.9 9 1.8 6.5 2.7 9 3.6 6.5 4.4 9 5.3 6.5 6.2 9 7.1 6.5 8 9 8.9 6.5 9.8 9 10.7 6.5 11.6 9 12.4 6.5 13.3 9 14.2 6.5 15.1 9 16h15z" fill="#8A1538"/></g></svg>',
		bh: '<svg class="vai-flag" viewBox="0 0 24 16" width="22" height="15" aria-hidden="true"><defs><clipPath id="vfbh"><rect width="24" height="16" rx="2.5"/></clipPath></defs><g clip-path="url(#vfbh)"><rect width="24" height="16" fill="#fff"/><path d="M24 0H9L6.5 1.6 9 3.2 6.5 4.8 9 6.4 6.5 8 9 9.6 6.5 11.2 9 12.8 6.5 14.4 9 16h15z" fill="#CE1126"/></g></svg>',
		om: '<svg class="vai-flag" viewBox="0 0 24 16" width="22" height="15" aria-hidden="true"><defs><clipPath id="vfom"><rect width="24" height="16" rx="2.5"/></clipPath></defs><g clip-path="url(#vfom)"><rect width="24" height="16" fill="#fff"/><rect x="6.4" y="10.6" width="17.6" height="5.4" fill="#009A44"/><rect x="6.4" y="5.4" width="17.6" height="5.2" fill="#C8102E"/><rect width="6.4" height="16" fill="#C8102E"/><path d="M2.1 1.5l2.2 2.6M4.3 1.5L2.1 4.1" stroke="#fff" stroke-width=".7" stroke-linecap="round"/></g></svg>'
	};
	function flagSvg(k) {
		if (FLAGS[k]) { return FLAGS[k]; }
		var c = (CFG.countries || []).filter(function (x) { return x.k === k; })[0];
		return c && c.f ? '<span class="vai-flag vai-flag-emoji" aria-hidden="true">' + esc(c.f) + '</span>' : FLAGS.sa;
	}
	function toggleLang() {
		state.lang = state.lang === 'en' ? 'ar' : 'en';
		state.langSet = true; /* 2.20.0: his own choice now beats the page language */
		save();
		try { location.reload(); } catch (e) {}
	}
	function save() {
		try { localStorage.setItem(LS, JSON.stringify(state)); } catch (e) {}
		try { document.cookie = 'vai_uuid=' + encodeURIComponent(state.uuid) + '; path=/; max-age=31536000; SameSite=Lax' + (location.protocol === 'https:' ? '; Secure' : ''); } catch (e) {}
		try {
			var sig = JSON.stringify(state.contact || null);
			if (sig !== lastAcctSig) { lastAcctSig = sig; window.VAI_ACCOUNT = state.contact || null; window.dispatchEvent(new CustomEvent('vai:account', { detail: state.contact || null })); }
		} catch (e) {}
	}
	function uuid() {
		if (window.crypto && crypto.randomUUID) { return crypto.randomUUID(); }
		return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) { var r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16); });
	}

	/* ───────── copy ───────── */
	/* Owner-editable wording: CFG.copy.{key} (or CFG.{key}) with a neutral fallback. No price and no marketing sentence lives in this file. */
	function copy(key, fallback) {
		var c = CFG.copy && typeof CFG.copy === 'object' ? CFG.copy[key] : null;
		if (c == null || c === '') { c = CFG[key]; }
		return (c == null || c === '' || typeof c === 'object') ? fallback : String(c);
	}
	function botName() { return trText(CFG.bot_name || 'المستشار'); }
	function firstName(c) { return c && c.name ? String(c.name).trim().split(/\s+/)[0] : ''; }
	function daysAr(n) { n = parseInt(n, 10) || 0; return n + ' ' + (n === 1 ? 'يوم' : (n === 2 ? 'يومان' : (n >= 3 && n <= 10 ? 'أيام' : 'يومًا'))); }
	function payUrl() { var m = CFG.membership; return m && m.buttons && m.buttons[0] && m.buttons[0].url ? m.buttons[0].url : ''; }
	function payLabel() { var m = CFG.membership; return (m && m.buttons && m.buttons[0] && m.buttons[0].label) || 'العضوية'; }

	/* ───────── api ───────── */
	function httpText(st) {
		if (st === 429) { return 'طلبات كثيرة — انتظر قليلًا ثم حاول مرة ثانية.'; }
		if (st >= 500) { return 'الخدمة غير متاحة مؤقتًا — حاول بعد قليل.'; }
		return '';
	}
	function api(op, data) {
		var body = Object.assign({ uuid: state.uuid, page_url: location.href.split('#')[0], page_title: document.title }, data || {});
		if (op === 'chat') { body.page_text = pageText(); }
		return fetch(REST + op + (REST.indexOf('?') === -1 ? '?_=' : '&_=') + Date.now(), {
			method: 'POST', credentials: 'omit', cache: 'no-store',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify(body)
		}).then(function (res) {
			return res.json().catch(function () { return null; }).then(function (j) {
				if (!j || typeof j !== 'object') { j = { ok: false, error: res.ok ? 'bad_json' : 'http_' + res.status }; }
				if (!res.ok && j.ok === undefined) { j.ok = false; if (!j.error) { j.error = j.code || ('http_' + res.status); } }
				if (j.ok === false && !j.text) { j.text = (j.message && /[\u0600-\u06FF]/.test(j.message)) ? String(j.message) : httpText(res.status); }
				return j;
			});
		});
	}

	/* ───────── helpers ───────── */
	function el(tag, cls, html) { var e = document.createElement(tag); if (cls) { e.className = cls; } if (html != null) { e.innerHTML = (typeof trText === 'function' && (!cls || cls.indexOf('vai-bubble') === -1)) ? trText(html) : html; } return e; }
	function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
	function oneLine(s) { return String(s == null ? '' : s).replace(/\s+/g, ' ').trim(); }
	function latinDigits(s) { return String(s == null ? '' : s).replace(/[\u0660-\u0669]/g, function (c) { return c.charCodeAt(0) - 0x0660; }).replace(/[\u06F0-\u06F9]/g, function (c) { return c.charCodeAt(0) - 0x06F0; }); }
	/* which [text](url) targets become a link (both arrive HTML-escaped): http(s), a path on this very site, or a mailto: / tel: whose label
	   shows that same address or number. A backslash is refused everywhere: browsers read "/\host" and "https://a\.b" as another host
	   than the hub's allow-list check does. Returns 'web', 'app' or ''. */
	function linkKind(u, label) {
		var raw = String(u).replace(/&amp;/g, '&'), shown = String(label).replace(/&amp;/g, '&').toLowerCase(), a, m;
		if (/[\\\x00-\x20]/.test(raw)) { return ''; }
		if ((m = /^mailto:([^?]+)/i.exec(raw))) { return shown.indexOf(m[1].toLowerCase()) !== -1 ? 'app' : ''; }
		if ((m = /^tel:(.+)$/i.exec(raw))) {
			var nd = m[1].replace(/\D/g, ''), ld = latinDigits(shown).replace(/\D/g, '').replace(/^0+/, '');
			return ld.length >= 7 && nd.indexOf(ld) !== -1 ? 'app' : '';
		}
		try { a = new URL(raw, location.href); } catch (e) { return ''; }
		if (!/^https?:$/.test(a.protocol) || !a.hostname) { return ''; }
		if (/^https?:\/\//i.test(raw)) { return 'web'; }
		return /^\/(?!\/)/.test(raw) && a.hostname === location.hostname ? 'web' : '';
	}
	/* markdown subset: bold, italics, code, [text](url), autolinks, lists, headings, tables, rules. The text is HTML-escaped first. */
	function inline(s) {
		var keep = [];
		var hold = function (html) { keep.push(html); return '\u0001' + (keep.length - 1) + '\u0001'; };
		s = s.replace(/`([^`\n]+)`/g, function (m, c) { return hold('<code dir="ltr">' + c + '</code>'); });
		s = s.replace(/\[([^\]\n]{1,200})\]\(([^\s)]+)\)/g, function (m, label, u) {
			var kind = linkKind(u, label);
			if (!kind) { return m; }
			return hold('<a href="' + u + '"' + (kind === 'web' ? ' target="_blank" rel="noopener"' : ' dir="ltr"') + '>' + label + '</a>');
		});
		s = s.replace(/(^|[\s(\[«;>،,:])((?:https?:\/\/[^\s<)\]»\u0001]+)|(?:(?:www\.)?(?:[a-z0-9-]+\.)+(?:com|net|org|sa|link|me|co|io|app|ai|info|dev|store|shop|online|site|tech|biz|tv|ae|kw|qa|bh|om|eg)(?::\d+)?(?:\/[^\s<)\]»\u0001]*)?))/gi, function (m, pre, u) {
			var clean = u.replace(/(?:&quot;|&#39;|&gt;|&lt;|[.,،;:!?؟)])+$/, ''), tail = u.slice(clean.length);
			if (/^(e\.g|i\.e)/i.test(clean) || clean.indexOf('@') !== -1 || clean.indexOf('\\') !== -1) { return m; }
			var href = /^https?:\/\//i.test(clean) ? clean : 'https://' + clean;
			var label = clean.replace(/^https?:\/\//i, '').replace(/&amp;/g, '&');
			if (label.length > 46) { label = label.slice(0, 44) + '…'; }
			return pre + hold('<a href="' + href + '" target="_blank" rel="noopener" dir="ltr">' + label + '</a>') + tail;
		});
		s = s.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');
		s = s.replace(/(^|[\s(«>])\*([^*\s](?:[^*]*[^*\s])?)\*(?=$|[\s.,،؛:!?؟)»<])/g, '$1<i>$2</i>');
		return s.replace(/\u0001(\d+)\u0001/g, function (m, i) { return keep[+i]; });
	}
	function mdTable(rows) {
		var cells = function (l) { return l.replace(/^\s*\|/, '').replace(/\|\s*$/, '').split('|').map(function (c) { return c.trim(); }); };
		var head = rows.length > 1 && /^\s*\|[\s:|-]+\|\s*$/.test(rows[1]) && rows[1].indexOf('-') !== -1;
		var h = '<div class="vai-table-wrap" tabindex="0" role="region" aria-label="جدول"><table class="vai-table">';
		if (head) { h += '<thead><tr>' + cells(rows[0]).map(function (c) { return '<th scope="col">' + inline(c) + '</th>'; }).join('') + '</tr></thead>'; }
		h += '<tbody>';
		rows.slice(head ? 2 : 0).forEach(function (r) { h += '<tr>' + cells(r).map(function (c) { return '<td>' + inline(c) + '</td>'; }).join('') + '</tr>'; });
		return h + '</tbody></table></div>';
	}
	function md(t) {
		var lines = esc(String(t == null ? '' : t).replace(/\u0001/g, '')).split('\n'), out = [], list = null, m, i = 0;
		var closeList = function () { if (list) { out.push(list.o ? '</ol>' : '</ul>'); list = null; } };
		var isRow = function (l) { return /^\s*\|.*\|\s*$/.test(l); };
		while (i < lines.length) {
			var l = lines[i];
			if (isRow(l) && i + 1 < lines.length && isRow(lines[i + 1])) {
				closeList();
				var rows = [];
				while (i < lines.length && isRow(lines[i])) { rows.push(lines[i]); i++; }
				out.push(mdTable(rows));
				continue;
			}
			i++;
			if (/^\s*([-*_])(?:\s*\1){2,}\s*$/.test(l)) { closeList(); out.push('<div class="vai-hr" role="separator"></div>'); continue; }
			if ((m = l.match(/^\s{0,3}(#{1,4})\s+(.+?)\s*#*\s*$/))) {
				closeList();
				out.push('<div class="vai-h vai-h' + m[1].length + '" role="heading" aria-level="' + (m[1].length + 2) + '" dir="auto">' + inline(m[2]) + '</div>');
				continue;
			}
			if ((m = l.match(/^\s*(?:[-•*]|\d+[.)])\s+(.*)$/))) {
				var ordered = /^\s*\d/.test(l);
				if (!list || list.o !== ordered) { closeList(); list = { o: ordered }; out.push(ordered ? '<ol>' : '<ul>'); }
				out.push('<li>' + inline(m[1]) + '</li>');
				continue;
			}
			closeList();
			if (l.trim() === '') { out.push('<div class="vai-sp"></div>'); } else { out.push('<p dir="auto">' + inline(l) + '</p>'); }
		}
		closeList();
		return out.join('');
	}
	function scrollBottom() { requestAnimationFrame(function () { ui.body.scrollTop = ui.body.scrollHeight; }); }
	function samePage(url) {
		try { var a = new URL(url, location.href); return a.hostname.replace(/^www\./, '') === location.hostname.replace(/^www\./, '') && a.pathname.replace(/\/+$/, '') === location.pathname.replace(/\/+$/, ''); } catch (e) { return false; }
	}
	function hostOf(url) { try { return new URL(url, location.href).hostname.replace(/^www\./, ''); } catch (e) { return ''; } }
	function myHost() { return location.hostname.replace(/^www\./, ''); }
	/* hosts of the ecosystem as the hub lists them (links library, membership and member-services buttons); only these may receive a handoff token */
	function ecoHost(h) {
		if (!h) { return false; }
		if (h === myHost()) { return true; }
		var urls = (CFG.links || []).map(function (l) { return l.u; });
		((CFG.membership && CFG.membership.buttons) || []).forEach(function (b) { urls.push(b.url); });
		(CFG.member_services || []).forEach(function (s) { urls.push(s.url); });
		for (var i = 0; i < urls.length; i++) { var x = hostOf(urls[i] || ''); if (x && (x === h || h.slice(-(x.length + 1)) === '.' + x)) { return true; } }
		return false;
	}
	function addParam(url, k, v) {
		try { var u = new URL(url, location.href); u.searchParams.set(k, v); return u.toString(); } catch (e) { return url; }
	}
	function waText() { return encodeURIComponent('السلام عليكم، كنت أتحدث مع ' + botName() + ' على الموقع' + (state.contact && state.contact.name ? ' — أنا ' + state.contact.name : '') + ' وأحتاج متابعة من الإدارة.'); }
	/* dir="auto" resolves an empty field to LTR (caret and placeholder on the wrong side): stay RTL until something is typed */
	function autoDir(node) { node.setAttribute('dir', node.value ? 'auto' : 'rtl'); }
	function say(text) { if (!ui.sr) { return; } ui.sr.textContent = ''; setTimeout(function () { if (ui.sr) { ui.sr.textContent = text; } }, 60); }

	/* ───────── colour tone (AA contrast whatever primary colour a site picks) ───────── */
	function hexRgb(h) {
		var m = /^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(String(h || '').trim());
		if (!m) { return null; }
		var x = m[1];
		if (x.length === 3) { x = x.charAt(0) + x.charAt(0) + x.charAt(1) + x.charAt(1) + x.charAt(2) + x.charAt(2); }
		return [parseInt(x.slice(0, 2), 16), parseInt(x.slice(2, 4), 16), parseInt(x.slice(4, 6), 16)];
	}
	function lum(c) { var f = function (v) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]); }
	function ratio(a, b) { return (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05); }
	function toHex(c) { return '#' + c.map(function (v) { var s = Math.max(0, Math.min(255, Math.round(v))).toString(16); return s.length < 2 ? '0' + s : s; }).join(''); }
	var TONE = { primary: '#B8962E', on: '#14120c', text: '#7d6416' };
	function applyTone() {
		var p = hexRgb(CFG.primary_color) || [184, 150, 46], L = lum(p), ink = [20, 18, 12];
		/* the text tone (links, prices, the focus ring) is measured on --vai-soft, the surface closest to it in either theme:
		   what holds there also holds on the bubbles, the cards and the sheet canvas */
		var dark = CFG.theme === 'dark', bgL = lum(dark ? [34, 31, 23] : [244, 241, 233]), t = p.slice(), n = 0;
		var step = function (v) { return dark ? v + (255 - v) * 0.08 : v * 0.93; };
		while (ratio(lum(t), bgL) < 4.6 && n < 40) { t = [step(t[0]), step(t[1]), step(t[2])]; n++; }
		/* on a narrow band of mid tones neither white nor the ink reaches 4.5:1; pure black always does there */
		var onW = ratio(L, 1), onK = ratio(L, lum(ink));
		TONE = { primary: toHex(p), on: Math.max(onW, onK) < 4.5 ? '#000000' : (onW >= onK ? '#ffffff' : toHex(ink)), text: toHex(t) };
		[ui.root, ui.topbar].forEach(function (box) {
			if (!box) { return; }
			box.style.setProperty('--vai-primary', TONE.primary);
			box.style.setProperty('--vai-on-primary', TONE.on);
			box.style.setProperty('--vai-primary-text', TONE.text);
		});
		/* the page-level accent is used by what we draw on host elements: .vai-flash, .vai-ask-target, .vai-ask-dot */
		document.documentElement.style.setProperty('--vai-accent', TONE.primary);
	}

	/* ───────── build UI ───────── */
	function avatarHtml() { return CFG.avatar_url ? '<img alt="" src="' + esc(CFG.avatar_url) + '">' : '<span class="vai-mono" aria-hidden="true">' + esc(botName().replace(/^ال/, '').charAt(0)) + '</span>'; }
	function hasAccount() { return !!(state.contact && (state.contact.has_account || state.contact.is_member)); }
	function build() {
		var side = B.position === 'right' ? 'right' : 'left';
		var root = el('div', 'vai-root vai-' + side);
		root.setAttribute('dir', 'rtl');
		root.setAttribute('lang', 'ar');
		if (CFG.theme === 'dark') { root.classList.add('vai-dark'); }
		ui.root = root;

		var waStyle = CFG.launcher_style !== 'logo';
		ui.launcher = el('button', 'vai-launcher' + (waStyle ? ' vai-launcher-wa' : ''), '<span class="vai-l-main">' + (waStyle ? ICON.waBig : avatarHtml()) + '</span><span class="vai-l-x" aria-hidden="true">' + ICON.down + '</span><span class="vai-badge" hidden>1</span>');
		ui.launcher.type = 'button';
		ui.launcher.setAttribute('aria-label', trText('افتح ') + botName());
		ui.launcher.setAttribute('aria-haspopup', 'dialog');
		ui.launcher.setAttribute('aria-expanded', 'false');
		ui.launcher.setAttribute('aria-controls', 'vai-panel');
		ui.launcher.addEventListener('click', function () { toggle(); });

		ui.teaser = el('button', 'vai-teaser', '<span>' + esc(copy('teaser', 'اسأل ' + botName() + ' عن أي شيء في هذه الصفحة')) + '</span>');
		ui.teaser.type = 'button';
		ui.teaser.addEventListener('click', function () { openPanel(); });

		ui.panel = el('div', 'vai-panel');
		ui.panel.id = 'vai-panel';
		ui.panel.setAttribute('role', 'dialog');
		ui.panel.setAttribute('aria-modal', 'false');
		ui.panel.setAttribute('aria-label', botName());
		ui.panel.setAttribute('tabindex', '-1');
		ui.panel.innerHTML = trText(
			'<div class="vai-head">' +
			'<div class="vai-head-id"><span class="vai-head-av">' + avatarHtml() + '</span><div class="vai-head-tx"><div class="vai-name">' + esc(botName()) + '</div><div class="vai-sub"><i aria-hidden="true"></i>' + esc(CFG.bot_subtitle || '') + '</div></div></div>' +
			'<div class="vai-head-btns">' + '<button type="button" class="vai-hbtn vai-lang" title="' + (state.lang === 'en' ? 'العربية' : 'English') + '" aria-label="language">' + (state.lang === 'en' ? FLAGS.sa : US_FLAG) + '</button>' +
			'<button type="button" class="vai-ib vai-services" title="خدمات الأعضاء" aria-label="خدمات الأعضاء" hidden>' + ICON.star + '</button>' +
			'<a class="vai-ib vai-wa-admin" title="واتساب الإدارة" aria-label="واتساب الإدارة" target="_blank" rel="noopener" href="https://wa.me/' + esc(CFG.mgmt_whatsapp) + '?text=' + waText() + '"' + (CFG.wa_members_only ? ' hidden' : '') + '>' + ICON.wa + '</a>' +
			'<button type="button" class="vai-ib vai-fs" title="ملء الشاشة" aria-label="ملء الشاشة" aria-pressed="false">' + ICON.fs + '</button>' +
			'<button type="button" class="vai-ib vai-new" title="محادثة جديدة" aria-label="محادثة جديدة">' + ICON.plus + '</button>' +
			'<button type="button" class="vai-ib vai-close" title="إغلاق" aria-label="إغلاق ' + esc(botName()) + '">' + ICON.x + '</button>' +
			'</div></div>' +
			'<div class="vai-acct"></div>' +
			'<div class="vai-net" role="status" hidden><span class="vai-net-i" aria-hidden="true">' + ICON.offline + '</span><span class="vai-net-t"></span><button type="button" class="vai-net-b">حاول الآن</button></div>' +
			'<div class="vai-body" role="log" aria-live="polite" aria-relevant="additions" aria-label="المحادثة" tabindex="-1"></div>' +
			'<div class="vai-quick" role="group" aria-label="اقتراحات"></div>' +
			'<div class="vai-focus" hidden></div>' +
			'<div class="vai-preview" hidden><img alt="الصورة المرفقة"><button type="button" class="vai-preview-x" aria-label="إزالة الصورة">' + ICON.x + '</button></div>' +
			'<div class="vai-foot"><textarea rows="1" dir="' + (state.lang === 'en' ? 'ltr' : 'rtl') + '" placeholder="' + esc(L('اكتب رسالتك هنا…')) + '" aria-label="رسالتك إلى ' + esc(botName()) + '"></textarea><div class="vai-bar"><button type="button" class="vai-attach" title="أرسل صورة أو سكرين شوت" aria-label="إرفاق صورة">' + ICON.clip + '</button><input type="file" accept="image/*" class="vai-file" hidden tabindex="-1" aria-hidden="true"><button type="button" class="vai-emo" title="إيموجي" aria-label="إيموجي" aria-expanded="false">' + ICON.smile + '</button><button type="button" class="vai-mic" title="سجّل رسالة صوتية (بالعربية)" aria-label="تسجيل صوتي" hidden>' + ICON.mic + '</button><button type="button" class="vai-send" aria-label="إرسال">' + ICON.send + '</button></div><div class="vai-emoji" role="group" aria-label="إيموجي" hidden></div></div>' +
			'<div class="vai-tip" role="status" hidden></div>' +
			'<div class="vai-note">' + esc(state.lang === 'en' ? botName() + ' ' + EN_UI['في خدمتك على مدار الساعة'] : copy('footer_note', botName() + ' في خدمتك على مدار الساعة')) + '</div>' +
			'<div class="vai-confirm" role="alertdialog" aria-modal="true" aria-labelledby="vai-confirm-t" hidden><div class="vai-confirm-box"><div class="vai-confirm-t" id="vai-confirm-t">تبدأ محادثة جديدة؟</div><div class="vai-confirm-d">سجلك السابق يبقى محفوظًا عندنا.</div><div class="vai-confirm-btns"><button type="button" class="vai-btn vai-btn-p vai-confirm-ok">ابدأ محادثة جديدة</button><button type="button" class="vai-btn vai-confirm-no">إلغاء</button></div></div></div>' +
			'<div class="vai-sheet" role="group" aria-labelledby="vai-sheet-t" hidden><div class="vai-sheet-head"><button type="button" class="vai-sheet-back" aria-label="رجوع" hidden>' + ICON.back + '</button><div class="vai-sheet-t" id="vai-sheet-t" tabindex="-1"></div><button type="button" class="vai-sheet-x" aria-label="إغلاق">' + ICON.x + '</button></div><div class="vai-sheet-body"></div></div>' +
			'<div class="vai-sr" aria-live="polite"></div>');

		ui.head = ui.panel.querySelector('.vai-head');
		var langBtn = ui.panel.querySelector('.vai-lang');
		if (langBtn) { langBtn.addEventListener('click', toggleLang); }
		applyLangDir();
		ui.body = ui.panel.querySelector('.vai-body');
		ui.acct = ui.panel.querySelector('.vai-acct');
		ui.net = ui.panel.querySelector('.vai-net');
		ui.net.querySelector('.vai-net-b').addEventListener('click', function () { clearTimeout(pollTimer); poll(); });
		ui.svcBtn = ui.panel.querySelector('.vai-services');
		ui.svcBtn.addEventListener('click', showServices);
		ui.quick = ui.panel.querySelector('.vai-quick');
		ui.focus = ui.panel.querySelector('.vai-focus');
		ui.tip = ui.panel.querySelector('.vai-tip');
		ui.sr = ui.panel.querySelector('.vai-sr');
		ui.foot = ui.panel.querySelector('.vai-foot');
		ui.input = ui.panel.querySelector('.vai-foot textarea');
		ui.sendBtn = ui.panel.querySelector('.vai-send');
		ui.fsBtn = ui.panel.querySelector('.vai-fs');
		ui.file = ui.panel.querySelector('.vai-file');
		ui.preview = ui.panel.querySelector('.vai-preview');
		ui.panel.querySelector('.vai-attach').addEventListener('click', function () { ui.file.click(); });
		ui.file.addEventListener('change', function () { if (ui.file.files && ui.file.files[0]) { loadImage(ui.file.files[0]); } ui.file.value = ''; });
		ui.preview.querySelector('.vai-preview-x').addEventListener('click', function () { pendingImage = null; ui.preview.hidden = true; ui.input.focus(); });
		ui.emoji = ui.panel.querySelector('.vai-emoji');
		ui.emoBtn = ui.panel.querySelector('.vai-emo');
		var EMO = ['😊', '🙏', '👍', '❤️', '🌹', '✨', '🤝', '💡', '👏', '💪', '🔥', '🎯', '📈', '💰', '🏆', '⭐', '😍', '🤔', '😅', '😂', '🙌', '✅', '📌', '🚀', '🎉', '☕', '🇸🇦', '👋', '😎', '🥰', '🤲', '💎'];
		ui.emoji.innerHTML = trText('<div class="vai-emoji-grid">' + EMO.map(function (e) { return '<button type="button" class="vai-emo-i" aria-label="إدراج ' + e + '">' + e + '</button>'; }).join('') + '</div>');
		ui.emoji.querySelectorAll('.vai-emo-i').forEach(function (b) {
			b.addEventListener('click', function (e) {
				e.preventDefault(); e.stopPropagation();
				var t = ui.input, ch = b.textContent, st = typeof t.selectionStart === 'number' ? t.selectionStart : t.value.length, en = typeof t.selectionEnd === 'number' ? t.selectionEnd : st;
				t.value = t.value.slice(0, st) + ch + t.value.slice(en);
				try { t.focus(); t.selectionStart = t.selectionEnd = st + ch.length; } catch (err) {}
				autoGrow();
			});
		});
		ui.emoBtn.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); setEmoji(ui.emoji.hidden); });
		ui.panel.addEventListener('click', function (e) { if (!ui.emoji.hidden && !e.target.closest('.vai-emoji') && !e.target.closest('.vai-emo')) { setEmoji(false); } });
		ui.mic = ui.panel.querySelector('.vai-mic');
		bindVoice();
		ui.input.addEventListener('focus', function () { if (MOBILE && CFG.mobile_mode === 'compact' && !state.fs) { kbFull = true; applyFs(); setTimeout(scrollBottom, 250); } });
		/* stay full-screen while the visitor is still inside the panel (tapping «إرسال» must not make the layout jump) */
		ui.input.addEventListener('blur', function () { if (kbFull) { setTimeout(function () { if (kbFull && !ui.panel.contains(document.activeElement)) { kbFull = false; applyFs(); } }, 250); } });
		ui.input.addEventListener('paste', function (e) { var items = (e.clipboardData && e.clipboardData.items) || []; for (var i = 0; i < items.length; i++) { if (items[i].type && items[i].type.indexOf('image/') === 0) { e.preventDefault(); loadImage(items[i].getAsFile()); break; } } });
		ui.panel.querySelector('.vai-close').addEventListener('click', closePanel);
		ui.fsBtn.addEventListener('click', function () { state.fs = !state.fs; applyFs(); save(); });
		ui.panel.querySelector('.vai-new').addEventListener('click', newChat);
		ui.confirm = ui.panel.querySelector('.vai-confirm');
		ui.confirm.querySelector('.vai-confirm-ok').addEventListener('click', doNewChat);
		ui.confirm.querySelector('.vai-confirm-no').addEventListener('click', closeConfirm);
		ui.confirm.addEventListener('click', function (e) { if (e.target === ui.confirm) { closeConfirm(); } });
		ui.sheet = ui.panel.querySelector('.vai-sheet');
		ui.sheetT = ui.sheet.querySelector('.vai-sheet-t');
		ui.sheetBody = ui.sheet.querySelector('.vai-sheet-body');
		ui.sheetBack = ui.sheet.querySelector('.vai-sheet-back');
		ui.sheetX = ui.sheet.querySelector('.vai-sheet-x');
		ui.sheetX.addEventListener('click', function () { closeSheet(); });
		ui.sheetBack.addEventListener('click', function () { if (ui.sheetBackFn) { ui.sheetBackFn(); } });
		/* keep the keyboard (and the focus) in the composer when «إرسال» is pressed */
		ui.sendBtn.addEventListener('mousedown', function (e) { if (document.activeElement === ui.input) { e.preventDefault(); } });
		ui.sendBtn.addEventListener('click', function () { if (rec.active) { stopRecording(); return; } submit(); });
		ui.input.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); if (rec.active) { stopRecording(); } else { submit(); } } });
		ui.input.addEventListener('input', function () { autoDir(ui.input); autoGrow(); if (!ui.tip.hidden) { tip(''); } });
		document.addEventListener('keydown', onKey);
		document.addEventListener('mousedown', function (e) { ui.lastInside = ui.root.contains(e.target); }, true);

		root.appendChild(ui.teaser);
		root.appendChild(ui.launcher);
		root.appendChild(ui.panel);
		document.body.appendChild(root);
		if (CFG.account_bar && CFG.account_bar !== '0' && B.autoOpen !== 'account') {
			ui.topbar = el('div', 'vai-topbar');
			ui.topbar.setAttribute('role', 'region');
			ui.topbar.setAttribute('aria-label', trText('حساب المنظومة'));
			ui.topbar.setAttribute('dir', 'rtl');
			document.body.appendChild(ui.topbar);
			document.documentElement.classList.add('vai-topbar-on');
			if (document.body.classList.contains('admin-bar')) { document.documentElement.classList.add('vai-topbar-adminbar'); }
		}
		applyTone();
		if (ui.topbar) { renderTopbar(); }
		if (CFG.account_pill && CFG.account_pill !== '0' && B.autoOpen !== 'account') {
			ui.pill = el('button', 'vai-pill vai-pill-' + (CFG.pill_position || 'opposite'));
			ui.pill.type = 'button';
			ui.pill.setAttribute('aria-label', trText('حسابي'));
			ui.pill.addEventListener('click', function () { openPanel(); if (hasAccount()) { showAccount(); } else { showAccountForm('register'); } });
			root.appendChild(ui.pill);
			renderPill();
		}

		document.addEventListener('click', function (e) {
			var a = e.target.closest && e.target.closest('a[href="#vai-open"], .vai-open');
			if (a) { e.preventDefault(); openPanel(); }
		});
		/* links inside a reply: ecosystem sites continue the same conversation there; anything else opens natively in a new tab and never receives a token */
		ui.body.addEventListener('click', function (e) {
			var a = e.target.closest && e.target.closest('.vai-bubble a[href^="http"]');
			if (!a) { return; }
			var h = hostOf(a.href);
			if (!h || h === myHost() || !ecoHost(h) || /paymob\.link|youtube\.com|youtu\.be|wa\.me|maps\.app\.goo\.gl|chat\.whatsapp\.com/.test(h)) { return; }
			e.preventDefault();
			navigate(a.href, null, true);
		});
		window.VAI = {
			open: openPanel, close: closePanel,
			send: function (t) { openPanel(); closeSheet(); send(String(t || '')); },
			/* ask(text, context): context = { type, id, title, text, selection } — shows the «تسأل عن» pill; an empty text only opens the chat on that subject */
			ask: function (t, context) { askAbout(context, String(t || '')); },
			register: function () { openPanel(); showAccountForm('register', CFG.account_gate_text || ''); },
			login: function () { openPanel(); showAccountForm('login'); },
			account: function () { openPanel(); if (hasAccount()) { showAccount(); } else { showAccountForm('login'); } },
			membership: function () { openPanel(); closeSheet(); showGate({ type: 'membership', text: CFG.member_gate_text, card: CFG.membership, mgmt: CFG.mgmt_whatsapp }); },
			contact: function () { return state.contact || null; },
			uuid: function () { return state.uuid; }
		};
	}
	function setEmoji(on) { ui.emoji.hidden = !on; ui.emoBtn.setAttribute('aria-expanded', on ? 'true' : 'false'); }
	function tip(text) { ui.tip.textContent = trText(text || ''); ui.tip.hidden = !text; }
	function autoGrow() { autoDir(ui.input); var max = parseInt(window.getComputedStyle(ui.input).maxHeight, 10) || 140; ui.input.style.height = 'auto'; ui.input.style.height = Math.min(max, ui.input.scrollHeight) + 'px'; }
	var kbFull = false;
	function applyFs() {
		var full = !!(state.fs || kbFull || (MOBILE && (CFG.mobile_mode !== 'compact' || ui.sheetOpen))); /* a form on a phone gets the whole screen */
		ui.panel.classList.toggle('vai-full', full);
		ui.panel.classList.toggle('vai-compact', MOBILE && !full);
		ui.panel.classList.toggle('vai-nofs', MOBILE && CFG.mobile_mode !== 'compact');
		ui.panel.setAttribute('aria-modal', full ? 'true' : 'false');
		ui.fsBtn.setAttribute('aria-pressed', state.fs ? 'true' : 'false');
		ui.fsBtn.innerHTML = state.fs ? ICON.unfs : ICON.fs;
		ui.fsBtn.title = trText(state.fs ? 'تصغير النافذة' : 'ملء الشاشة');
		ui.fsBtn.setAttribute('aria-label', ui.fsBtn.title);
		/* a full-screen panel on a phone owns the scroll; the page behind stays still */
		document.documentElement.classList.toggle('vai-lock', !!(state.open && full && MOBILE));
		fitViewport();
	}
	function fitViewport() {
		if (!MOBILE || !ui.panel) { if (ui.panel) { ui.panel.style.top = ''; } return; }
		var vv = window.visualViewport, vh = vv ? vv.height : window.innerHeight;
		document.documentElement.style.setProperty('--vai-vvh', Math.round(vh) + 'px');
		var h = Math.max(300, Math.min(560, Math.round(vh - 110)));
		document.documentElement.style.setProperty('--vai-h', h + 'px');
		if (vv && ui.panel.classList.contains('vai-full')) { ui.panel.style.top = Math.round(vv.offsetTop) + 'px'; } else { ui.panel.style.top = ''; }
	}
	if (window.visualViewport) { window.visualViewport.addEventListener('resize', function () { fitViewport(); if (state.open) { scrollBottom(); } }); }
	var onMq = function () { MOBILE = MQ.matches; if (ui.panel) { applyFs(); } };
	if (MQ.addEventListener) { MQ.addEventListener('change', onMq); } else if (MQ.addListener) { MQ.addListener(onMq); }
	function toggle() { if (state.open) { closePanel(); } else { openPanel(); } }
	function focusSoft(node) { try { node.focus({ preventScroll: true }); } catch (e) { try { node.focus(); } catch (e2) {} } }
	function openPanel() {
		var was = ui.root.classList.contains('vai-opened');
		if (!was) { ui.returnTo = document.activeElement && !ui.root.contains(document.activeElement) && document.activeElement !== document.body ? document.activeElement : null; }
		state.open = true; state.seen = true; save();
		ui.root.classList.add('vai-opened');
		ui.launcher.setAttribute('aria-expanded', 'true');
		ui.launcher.setAttribute('aria-label', trText('أغلق ') + botName());
		ui.teaser.classList.remove('vai-show');
		hideChip(true);
		applyFs();
		unread = 0; badge();
		if (!ui.rendered) { renderAll(); }
		renderAcct();
		scrollBottom();
		if (!was) { setTimeout(function () { if (!state.open || ui.sheetOpen || ui.root.contains(document.activeElement) && document.activeElement !== ui.launcher) { return; } focusSoft(MOBILE ? ui.panel : ui.input); }, 150); }
		schedulePoll(true);
	}
	function closePanel() {
		state.open = false; save();
		kbFull = false;
		setEmoji(false); closeConfirm();
		var inside = ui.root.contains(document.activeElement);
		ui.root.classList.remove('vai-opened');
		ui.launcher.setAttribute('aria-expanded', 'false');
		ui.launcher.setAttribute('aria-label', trText('افتح ') + botName());
		document.documentElement.classList.remove('vai-lock');
		if (inside) { focusSoft(ui.returnTo && document.body.contains(ui.returnTo) ? ui.returnTo : ui.launcher); }
		ui.returnTo = null;
		schedulePoll(true);
	}
	function badge() {
		var b = ui.launcher.querySelector('.vai-badge');
		b.textContent = unread; b.hidden = !unread;
		ui.launcher.classList.toggle('vai-ping', !!unread);
		if (!state.open) { ui.launcher.setAttribute('aria-label', trText('افتح ') + botName() + (unread ? ' — ' + unread + trText(' رسالة جديدة') : '')); }
	}
	/* new chat: an in-panel confirmation instead of the blocking native confirm() */
	function newChat() {
		if (!state.msgs.length) { doNewChat(); return; }
		ui.confirm.hidden = false;
		focusSoft(ui.confirm.querySelector('.vai-confirm-ok'));
	}
	function closeConfirm() { if (ui.confirm && !ui.confirm.hidden) { ui.confirm.hidden = true; if (state.open) { focusSoft(ui.panel.querySelector('.vai-new')); } } }
	function doNewChat() {
		ui.confirm.hidden = true;
		state.msgs = []; state.pending = null; state.fresh = true; save();
		pendingRef = null; lastSent = null; lateRef = null;
		clearFocus();
		hideTyping();
		ui.body.innerHTML = ''; ui.quick.innerHTML = ''; ui.gate = null;
		welcome();
		if (awaitingSince) { showTyping(); }
		focusSoft(MOBILE ? ui.panel : ui.input);
	}

	/* ───────── sheet (account, forms, services): a layer over the chat, so new replies never push a half-filled form away ───────── */
	function setInert(on) {
		[ui.acct, ui.body, ui.quick, ui.focus, ui.foot].forEach(function (n) { if (!n) { return; } if (on) { n.setAttribute('inert', ''); n.setAttribute('aria-hidden', 'true'); } else { n.removeAttribute('inert'); n.removeAttribute('aria-hidden'); } });
	}
	function openSheet(o) {
		ui.sheetT.textContent = trText(o.title || '');
		ui.sheetBackFn = o.back || null;
		ui.sheetBack.hidden = !o.back;
		ui.sheetBody.innerHTML = '';
		ui.sheetBody.appendChild(o.node);
		ui.sheetBody.scrollTop = 0;
		ui.sheetEscOnce = false;
		if (!ui.sheetOpen) { ui.sheet.hidden = false; ui.sheetOpen = true; ui.panel.classList.add('vai-sheet-on'); setInert(true); applyFs(); }
		setEmoji(false);
		var first = o.node.querySelector('input:not([type=hidden]):not([type=file]):not([type=radio]),select,textarea');
		focusSoft(!MOBILE && first && o.focus !== false ? first : ui.sheetT);
		return o.node;
	}
	function closeSheet() {
		if (!ui.sheetOpen) { return; }
		var inside = ui.sheet.contains(document.activeElement);
		ui.sheetOpen = false; ui.sheet.hidden = true; ui.sheetBody.innerHTML = ''; ui.sheetBackFn = null;
		ui.panel.classList.remove('vai-sheet-on');
		setInert(false);
		applyFs();
		scrollBottom();
		if (inside && state.open) { focusSoft(MOBILE ? ui.panel : ui.input); }
	}
	function sheetDirty() {
		var list = ui.sheetBody.querySelectorAll('input:not([type=hidden]):not([type=file]):not([type=radio]),textarea'), i;
		for (i = 0; i < list.length; i++) { if (list[i].value !== list[i].defaultValue) { return true; } }
		return false;
	}

	/* ───────── keyboard: layered Escape, focus kept inside the dialog ───────── */
	function focusables(box) {
		var list = box.querySelectorAll('a[href],button:not([disabled]),input:not([disabled]):not([type=hidden]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])'), out = [], i;
		for (i = 0; i < list.length; i++) { if (list[i].offsetParent !== null && !list[i].closest('[inert]') && !list[i].closest('[hidden]')) { out.push(list[i]); } }
		return out;
	}
	function onKey(e) {
		if (e.key === 'Escape' || e.key === 'Esc') {
			if (chipShown()) { ask.dismissed = ask.target; hideChip(); return; }
			if (!state.open) { return; }
			/* an Escape meant for the host page (its own pop-ups) is not ours */
			if (!ui.root.contains(document.activeElement) && !ui.lastInside && !ui.panel.classList.contains('vai-full')) { return; }
			if (!ui.emoji.hidden) { setEmoji(false); focusSoft(ui.input); return; }
			if (!ui.confirm.hidden) { closeConfirm(); return; }
			if (ui.sheetOpen) {
				if (sheetDirty() && !ui.sheetEscOnce) { ui.sheetEscOnce = true; focusSoft(ui.sheetX); return; } /* a half-filled form needs a second Escape */
				closeSheet(); return;
			}
			closePanel();
			return;
		}
		if (e.key !== 'Tab' || !state.open || !ui.panel.contains(document.activeElement)) { return; }
		var box = !ui.confirm.hidden ? ui.confirm : (ui.sheetOpen ? ui.sheet : ui.panel);
		var f = focusables(box);
		if (!f.length) { return; }
		var a = document.activeElement, first = f[0], last = f[f.length - 1];
		if (!box.contains(a) || a === ui.panel) { e.preventDefault(); focusSoft(e.shiftKey ? last : first); }
		else if (e.shiftKey && a === first) { e.preventDefault(); focusSoft(last); }
		else if (!e.shiftKey && a === last) { e.preventDefault(); focusSoft(first); }
	}

	/* ───────── rendering ───────── */
	function renderAll() {
		ui.rendered = true;
		hideTyping();
		ui.body.setAttribute('aria-busy', 'true'); /* a restored history is not read out message by message */
		ui.body.innerHTML = '';
		ui.gate = null;
		if (!state.msgs.length) { welcome(); }
		else {
			var last = null;
			state.msgs.forEach(function (m) { last = m; addBubble(m, false); });
			if (last && last.role === 'assistant') { renderQuick(pickQuick(last.actions)); if (wantsContact(last.actions)) { showGate({ type: 'contact', invite: true }); } }
		}
		if (bootNotes.length) { bootNotes.forEach(function (t) { sysLine(t); }); bootNotes = []; }
		if (awaitingSince) { showTyping(); }
		setTimeout(function () { ui.body.removeAttribute('aria-busy'); }, 400);
	}
	/* starter chips: the hub's «أزرار البداية» (config.menu), plus one chip about the page the visitor is reading */
	function starters() {
		if (state.lang === 'en') { return EN_MENU.slice(0, 8); }
		var list = [], pc = copy('page_chip', L('لخّص لي هذه الصفحة'));
		if (state.lang === 'en') { pc = EN_UI['لخّص لي هذه الصفحة']; }
		if (pc && pc !== '-' && B.autoOpen !== 'account' && pageText().length > 400) { list.push(pc); }
		(Array.isArray(CFG.menu) ? CFG.menu : []).forEach(function (s) { s = oneLine(s); if (s && list.indexOf(s) === -1) { list.push(s); } });
		return list;
	}
	function welcome() {
		ui.body.appendChild(el('div', 'vai-hero', '<span class="vai-hero-av">' + avatarHtml() + '</span><div class="vai-hero-n">' + esc(botName()) + '</div>' + (CFG.bot_subtitle ? '<div class="vai-hero-s">' + esc(CFG.bot_subtitle) + '</div>' : '')));
		if (CFG.welcome) { addBubble({ id: 0, role: 'assistant', content: state.lang === 'en' ? EN_WELCOME : CFG.welcome, actions: [], local: true }, false); }
		if (focusCtx) { renderQuick(focusIdeas(focusCtx)); } else { renderQuick(starters(), true); }
		var cc = state.contact;
		if (cc && cc.has_account && cc.verified && !cc.is_member && CFG.unpaid_note) { sysLine(CFG.unpaid_note); }
		else if (CFG.unsaved_note && !(cc && cc.is_member)) { sysLine(state.lang === 'en' ? EN_UNSAVED : CFG.unsaved_note); }
	}
	function pickQuick(actions) { var q = null; (actions || []).forEach(function (a) { if (a.type === 'quick_replies') { q = a.options; } }); return q; }
	/* M56 (owner: «زي واتساب بالظبط»): the visitor reacts with an emoji on the adviser's messages —
	   hover (desktop) or long-press (touch) shows the bar; the pick lands as a chip on the bubble,
	   is remembered locally, and reaches the hub as a light system note (never triggers the bot). */
	var REACTS = ['❤️', '👍', '😂', '😮', '🙏'];
	function reactChip(wrap, m) {
		var old = wrap.querySelector('.vai-react-chip');
		if (old) { old.remove(); }
		wrap.classList.toggle('vai-has-react', !!m.react);
		if (!m.react) { return; }
		var chip = el('button', 'vai-react-chip', m.react);
		chip.type = 'button';
		chip.setAttribute('aria-label', trText('إزالة التفاعل'));
		chip.addEventListener('click', function (ev) { ev.stopPropagation(); setReact(wrap, m, ''); });
		wrap.appendChild(chip);
	}
	function setReact(wrap, m, emoji) {
		m.react = m.react === emoji ? '' : emoji;
		save();
		reactChip(wrap, m);
		closeReactBar();
		if (m.id) { api('react', { uuid: state.uuid, message_id: m.id, emoji: m.react }).catch(function () {}); }
	}
	var openBar = null;
	function closeReactBar() { if (openBar) { openBar.remove(); openBar = null; } }
	function showReactBar(wrap, m) {
		closeReactBar();
		var bar = el('div', 'vai-react-bar');
		REACTS.forEach(function (e) {
			var b = el('button', '', e);
			b.type = 'button';
			b.addEventListener('click', function (ev) { ev.stopPropagation(); setReact(wrap, m, e); });
			bar.appendChild(b);
		});
		wrap.appendChild(bar);
		openBar = bar;
		setTimeout(function () { document.addEventListener('click', closeReactBar, { once: true }); }, 0);
	}
	function bindReactions(wrap, m) {
		if (!m || m.role === 'user' || m.local || !m.id) { return; }
		var timer = null, moved = false;
		wrap.addEventListener('dblclick', function (ev) { ev.preventDefault(); showReactBar(wrap, m); });
		wrap.addEventListener('touchstart', function () { moved = false; timer = setTimeout(function () { if (!moved) { showReactBar(wrap, m); } }, 420); }, { passive: true });
		wrap.addEventListener('touchmove', function () { moved = true; if (timer) { clearTimeout(timer); } }, { passive: true });
		wrap.addEventListener('touchend', function () { if (timer) { clearTimeout(timer); } }, { passive: true });
		if (!MOBILE) {
			var hoverT = null;
			wrap.addEventListener('mouseenter', function () { hoverT = setTimeout(function () { showReactBar(wrap, m); }, 550); });
			wrap.addEventListener('mouseleave', function () { if (hoverT) { clearTimeout(hoverT); } });
		}
		reactChip(wrap, m);
	}

	function addBubble(m, fresh) {
		if (m.role === 'system') { return null; }
		var wrap = el('div', 'vai-msg vai-' + (m.role === 'user' ? 'me' : (m.role === 'human' ? 'human' : 'bot')) + (fresh ? ' vai-new-msg' : ''));
		if (m.id) { wrap.setAttribute('data-id', m.id); }
		if (m.role === 'human') { wrap.appendChild(el('div', 'vai-who', esc(m.by ? m.by + ' — فريق النادي' : 'فريق نادي المستثمرين'))); }
		if (m.role === 'user' && m.about) { wrap.appendChild(el('div', 'vai-about', '<span>عن:</span> <b dir="auto">' + esc(m.about) + '</b>')); }
		var bubble = el('div', 'vai-bubble', (m.image ? '<a class="vai-img-wrap" href="' + esc(m.image) + '" target="_blank" rel="noopener"><img class="vai-img" alt="صورة مرفقة" src="' + esc(m.image) + '"></a>' : '') + (m.audio ? '<audio class="vai-audio" controls preload="none" src="' + esc(m.audio) + '"></audio>' : '') + (m.content && m.content !== '(أرسل صورة)' ? md(m.content) : (m.image ? '' : md(m.content || ''))));
		wrap.appendChild(bubble);
		bindReactions(wrap, m);
		var acts = (m.actions || []).slice();
		if (m.role === 'assistant' && !m.local) { acts = acts.concat(clientLinks(m, acts)); }
		acts.forEach(function (a) {
			if (a.type === 'card' && a.card) { wrap.appendChild(cardEl(a.card)); }
			else if (a.type === 'video' && a.yt) { wrap.appendChild(videoEl(a)); }
			else if (a.type === 'link' && a.url) { wrap.appendChild(a.carry ? navBtn({ type: 'open_page', url: a.url, carry: true, label: a.label }) : btnEl(a.label || 'افتح الرابط', a.url, false)); }
			else if (a.type === 'handoff' && a.number) { wrap.appendChild(btnEl(a.label || 'راسل الإدارة على واتساب', 'https://wa.me/' + a.number + (a.text ? '?text=' + encodeURIComponent(a.text) : '?text=' + waText()), true, 'wa')); }
			else if ((a.type === 'open_page' || a.type === 'prefill_form') && a.url && !samePage(a.url) && (!fresh || CFG.nav_mode !== 'auto')) { wrap.appendChild(navBtn(a)); }
		});
		if (m.at || m.local) { var t = el('div', 'vai-time', m.at ? fmtTime(m.at) : ''); wrap.appendChild(t); }
		ui.body.appendChild(wrap);
		scrollBottom();
		return wrap;
	}
	function normAr(t) { return String(t || '').replace(/[\u064B-\u0652\u0640]/g, '').replace(/[أإآ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').toLowerCase(); }
	/* one «افتح: …» button when the visitor asks for a page the hub's links library knows (config.links; nothing is built in here) */
	function clientLinks(m, acts) {
		var lib = Array.isArray(CFG.links) ? CFG.links : [];
		if (!lib.length) { return []; }
		var has = {};
		acts.forEach(function (a) { if ((a.type === 'open_page' || a.type === 'prefill_form' || a.type === 'link') && a.url) { has[hostOf(a.url) + (a.url.split(hostOf(a.url))[1] || '').split('#')[0]] = 1; } });
		var prevUser = '';
		for (var i = state.msgs.length - 1; i >= 0; i--) { if (state.msgs[i].role === 'user') { prevUser = state.msgs[i].content || ''; break; } }
		var un = normAr(prevUser), rn = normAr(m.content), scored = [];
		var asks = /(رابط|لينك|link|url|ابعت|ارسل|ارسلي|افتح|افتحي|وديني|ودني|خذني|وريني|ورني|صفحه|موقع)/.test(un);
		var claims = /(ارسلت لك|هذا رابط|هذا هو الرابط|اليك الرابط|فتحت لك|اضغط الزر|اضغط الرابط|الرابط:)/.test(rn);
		lib.forEach(function (l, idx) {
			var kws = (l.k || []).concat([l.l]), su = 0, sr = 0;
			String(l.l || '').split(/[^\u0600-\u06FFa-zA-Z0-9]+/).forEach(function (wd) { if (wd.length >= 4 && !/^(عرض|الشراكة|صفحة|خدمة|برنامج|الرئيسية|تصفح|جميع)$/.test(wd)) { kws.push(wd); } });
			kws.forEach(function (k) { var kn = normAr(k); if (kn.length < 3) { return; } var wgt = (kn.length >= 6 || kn.indexOf(' ') !== -1) ? 2 : 1; if (un && un.indexOf(kn) !== -1) { su += 10 * wgt; } if (rn.indexOf(kn) !== -1) { sr += 4 * wgt; } });
			if (su > 0 || ((asks || claims) && sr > 0)) { scored.push({ s: su * 3 + sr, i: idx }); }
		});
		scored.sort(function (a, b) { return b.s - a.s; });
		var out = [], maxAdd = 1;
		scored.forEach(function (x) {
			if (out.length >= maxAdd) { return; }
			var l = lib[x.i], h = hostOf(l.u), key = h + (l.u.split(h)[1] || '').split('#')[0];
			if (has[key]) { return; }
			has[key] = 1;
			out.push({ type: 'link', label: 'افتح: ' + l.l + ' ↗', url: l.u, carry: h !== myHost() && h !== 'paymob.link' });
		});
		return out;
	}
	function navBtn(a) {
		var label = a.type === 'prefill_form' ? 'افتح ' + (a.label || 'النموذج') + ' وأكمل معك هناك ↗' : (a.label ? a.label : 'افتح الصفحة وأكمل معك هناك ↗');
		var b = el('button', 'vai-btn vai-btn-p vai-btn-nav', esc(label));
		b.type = 'button';
		b.addEventListener('click', function () {
			b.disabled = true; b.textContent = trText('ثوانٍ… أفتح لك الصفحة');
			navigate(a.url, a.type === 'prefill_form' ? { url: a.url, form: a.form, fields: a.fields || {}, map: a.map || {}, label: a.label || '' } : null, a.carry);
		});
		var host = hostOf(a.url);
		var wrap = el('div', 'vai-nav');
		wrap.appendChild(b);
		wrap.appendChild(el('div', 'vai-nav-note', esc((host ? host + ' — ' : '') + 'نفس المحادثة تكمل معك هناك')));
		return wrap;
	}
	function fmtTime(iso) { try { var d = new Date(iso); return d.toLocaleTimeString(state.lang === 'en' ? 'en-US' : 'ar-SA', { hour: '2-digit', minute: '2-digit' }); } catch (e) { return ''; } }
	function btnEl(label, url, primary, kind) {
		var a = el('a', 'vai-btn' + (primary ? ' vai-btn-p' : '') + (kind ? ' vai-btn-' + kind : ''), (kind === 'wa' ? ICON.wa : '') + esc(label));
		a.href = url; a.target = '_blank'; a.rel = 'noopener';
		return a;
	}
	function cardEl(c) {
		var d = el('div', 'vai-card');
		var h = '<div class="vai-card-t">' + esc(c.title) + '</div>';
		if (c.price || c.note) { h += '<div class="vai-card-p">' + esc(c.price) + (c.note ? ' <small>' + esc(c.note) + '</small>' : '') + '</div>'; }
		if (c.bullets && c.bullets.length) { h += '<ul>' + c.bullets.map(function (b) { return '<li>' + esc(b) + '</li>'; }).join('') + '</ul>'; }
		if (c.discount) { h += '<div class="vai-card-d">' + esc(c.discount) + '</div>'; }
		if (c.terms) { h += '<div class="vai-card-terms">' + esc(c.terms) + '</div>'; }
		d.innerHTML = trText(h);
		if (c.buttons && c.buttons.length) {
			var row = el('div', 'vai-card-btns');
			c.buttons.forEach(function (b) { row.appendChild(btnEl(b.label, b.url, !!b.primary)); });
			d.appendChild(row);
		}
		return d;
	}
	function videoEl(a) {
		var d = el('div', 'vai-video', '<img alt="" src="https://img.youtube.com/vi/' + esc(a.yt) + '/hqdefault.jpg"><button type="button" class="vai-play" aria-label="تشغيل' + (a.title ? ': ' + esc(a.title) : '') + '">' + ICON.play + '</button><div class="vai-video-t">' + esc(a.title || '') + '</div>');
		d.querySelector('.vai-play').addEventListener('click', function () {
			d.innerHTML = '<iframe title="' + esc(a.title || 'فيديو') + '" src="https://www.youtube-nocookie.com/embed/' + esc(a.yt) + '?autoplay=1&rel=0" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe><div class="vai-video-t">' + esc(a.title || '') + '</div>';
		});
		return d;
	}
	/* quick replies: up to 4 at once; the starter menu keeps the rest (up to 8) behind «المزيد» */
	function renderQuick(options, starter) {
		ui.quick.innerHTML = '';
		if (!options || !options.length) { return; }
		var max = 4, all = options.slice(0, starter ? 8 : max);
		var add = function (o, i) {
			var b = el('button', 'vai-chip', esc(o));
			b.type = 'button'; b.setAttribute('dir', 'auto'); b.style.setProperty('--vai-i', i);
			/* the chips go away with the send: the focus they held moves into the dialog instead of falling back to the page */
			b.addEventListener('click', function () { var had = document.activeElement === b; send(o); if (had && !document.body.contains(b)) { focusSoft(MOBILE ? ui.panel : ui.input); } });
			ui.quick.appendChild(b);
			return b;
		};
		all.slice(0, max).forEach(add);
		if (all.length > max) {
			var more = el('button', 'vai-chip vai-chip-more', L('المزيد'));
			more.type = 'button'; more.setAttribute('aria-label', trText('اقتراحات أكثر'));
			more.addEventListener('click', function () { more.remove(); var firstNew = null; all.slice(max).forEach(function (o, i) { var b = add(o, i); if (!firstNew) { firstNew = b; } }); if (firstNew) { focusSoft(firstNew); } });
			ui.quick.appendChild(more);
		}
	}
	function sysLine(text) { var d = el('div', 'vai-sys', esc(text)); d.setAttribute('dir', 'auto'); ui.body.appendChild(d); scrollBottom(); return d; }
	function showTyping() {
		if (ui.typing) { return; }
		ui.typing = el('div', 'vai-msg vai-bot vai-typing', '<div class="vai-bubble" aria-hidden="true"><span></span><span></span><span></span></div><div class="vai-typing-note"></div>');
		ui.body.appendChild(ui.typing); scrollBottom();
		say(botName() + ' يكتب…');
		var note = ui.typing.querySelector('.vai-typing-note'), t0 = Date.now();
		ui.typingTimer = setInterval(function () {
			if (!ui.typing) { clearInterval(ui.typingTimer); return; }
			var s = (Date.now() - t0) / 1000;
			var txt = offline ? 'بانتظار عودة الاتصال…' : (s > 40 ? 'ثوانٍ إضافية… الرد في الطريق' : (s > 15 ? 'أراجع الصفحات والمعلومات لك…' : (s > 6 ? 'أجهّز لك الرد…' : '')));
			var txe = trText(txt); if (note.textContent !== txe) { note.textContent = txe; }
		}, 3000);
	}
	function hideTyping() { if (ui.typing) { ui.typing.remove(); ui.typing = null; } if (ui.typingTimer) { clearInterval(ui.typingTimer); ui.typingTimer = null; } }

	function bindVoice() {
		if (!ui.mic) { return; }
		var canRecord = !!(window.MediaRecorder && navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
		if (!(CFG.voice && canRecord)) { ui.mic.hidden = true; ui.mic.style.display = 'none'; return; }
		ui.mic.hidden = false; ui.mic.style.display = '';
		if (!ui.mic.dataset.bound) {
			ui.mic.dataset.bound = '1';
			ui.mic.addEventListener('click', function (e) { e.preventDefault(); if (rec.active) { stopRecording(); } else { startRecording(); } });
		}
		if (ui.hint) { return; }
		var seenHint = false; try { seenHint = localStorage.getItem('vai_hint_voice') === '1'; } catch (e) {}
		if (seenHint) { return; }
		ui.hint = el('div', 'vai-hint', 'تقدر ترسل رسالة صوتية بالعربية — اضغط الميكروفون، تكلّم، ثم اضغطه مرة ثانية للإرسال.');
		ui.foot.insertAdjacentElement('afterend', ui.hint);
		setTimeout(function () { if (ui.hint) { ui.hint.classList.add('vai-hint-off'); } try { localStorage.setItem('vai_hint_voice', '1'); } catch (e) {} }, 12000);
	}
	function refreshConfig() {
		api('config', {}).then(function (r) {
			if (!r || !r.config) { return; }
			r.config.primary_color = CFG.primary_color; /* the site's own colour override lives in the boot config only */
			CFG = r.config; B.cfg = CFG;
			bindVoice();
			var nm = ui.panel.querySelector('.vai-name'); if (nm) { nm.textContent = botName(); }
			ui.panel.setAttribute('aria-label', botName());
			renderAcct();
		}).catch(function () {}); /* silent on purpose: the next poll asks again while cfg_rev still differs */
	}

	/* ───────── voice notes ───────── */
	var rec = { active: false, chunks: [], recorder: null, timer: null, started: 0, cancel: false };
	function startRecording() {
		if (!window.isSecureContext) { sysLine('التسجيل الصوتي يحتاج اتصالًا آمنًا (https).'); return; }
		if (awaitingSince) { sysLine('انتظر الرد الحالي ثم سجّل صوتك.'); return; }
		navigator.mediaDevices.getUserMedia({ audio: true }).then(function (stream) {
			var mime = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg'].filter(function (t) { return window.MediaRecorder.isTypeSupported && window.MediaRecorder.isTypeSupported(t); })[0] || '';
			rec.recorder = mime ? new window.MediaRecorder(stream, { mimeType: mime }) : new window.MediaRecorder(stream);
			rec.chunks = []; rec.active = true; rec.started = Date.now();
			rec.recorder.ondataavailable = function (e) { if (e.data && e.data.size) { rec.chunks.push(e.data); } };
			rec.recorder.onstop = function () {
				stream.getTracks().forEach(function (t) { t.stop(); });
				var blob = new Blob(rec.chunks, { type: rec.recorder.mimeType || 'audio/webm' });
				rec.active = false; ui.mic.classList.remove('vai-rec'); ui.mic.innerHTML = ICON.mic; hideWave();
				if (rec.cancel) { rec.cancel = false; sysLine('تم إلغاء التسجيل.'); return; }
				if (Date.now() - rec.started < 700 || blob.size < 1500) { sysLine('التسجيل قصير جدًا — اضغط الميكروفون وتكلم ثم اضغطه مرة ثانية للإرسال.'); return; }
				if (blob.size > 5.5 * 1024 * 1024) { sysLine('التسجيل طويل — حاول رسالة أقصر.'); return; }
				var reader = new FileReader();
				reader.onload = function () { sendAudio(String(reader.result)); };
				reader.readAsDataURL(blob);
			};
			rec.recorder.start(250);
			ui.mic.classList.add('vai-rec'); ui.mic.innerHTML = ICON.stop;
			showWave(stream);
			rec.timer = setTimeout(function () { if (rec.active) { stopRecording(); } }, 60000);
		}).catch(function (err) { sysLine('لم يُسمح بالوصول للميكروفون — اسمح به من إعدادات المتصفح ثم حاول مرة ثانية.' + (err && err.name ? ' (' + err.name + ')' : '')); });
	}
	function stopRecording() { clearTimeout(rec.timer); if (rec.recorder && rec.active) { rec.recorder.stop(); } }
	var wave = { raf: 0, ctx: null, el: null, tick: null };
	function showWave(stream) {
		hideWave();
		var box = el('div', 'vai-wave', '<button type="button" class="vai-wave-x" title="إلغاء التسجيل" aria-label="إلغاء التسجيل">✕</button><span class="vai-wave-dot"></span><canvas class="vai-wave-c" width="200" height="34"></canvas><span class="vai-wave-t">0:00</span><button type="button" class="vai-wave-send">■ إرسال</button>');
		ui.panel.querySelector('.vai-foot').appendChild(box);
		ui.input.style.visibility = 'hidden';
		if (ui.mic) { ui.mic.style.visibility = 'hidden'; }
		box.querySelector('.vai-wave-send').addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); stopRecording(); });
		box.querySelector('.vai-wave-x').addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); rec.cancel = true; stopRecording(); });
		wave.el = box;
		var t0 = Date.now(), tEl = box.querySelector('.vai-wave-t');
		wave.tick = setInterval(function () { var sec = Math.floor((Date.now() - t0) / 1000); tEl.textContent = Math.floor(sec / 60) + ':' + ('0' + (sec % 60)).slice(-2); }, 250);
		try {
			var AC = window.AudioContext || window.webkitAudioContext;
			if (!AC) { return; }
			wave.ctx = new AC();
			var src = wave.ctx.createMediaStreamSource(stream), an = wave.ctx.createAnalyser();
			an.fftSize = 128; src.connect(an);
			var data = new Uint8Array(an.frequencyBinCount), cv = box.querySelector('canvas'), g = cv.getContext('2d');
			var draw = function () {
				wave.raf = requestAnimationFrame(draw);
				an.getByteFrequencyData(data);
				g.clearRect(0, 0, cv.width, cv.height);
				var bars = 28, bw = cv.width / bars;
				for (var i = 0; i < bars; i++) { var v = data[Math.floor(i * data.length / bars)] / 255, h = Math.max(3, v * cv.height); g.fillStyle = TONE.primary; g.fillRect(i * bw + 1, (cv.height - h) / 2, bw - 2, h); }
			};
			draw();
		} catch (e) {}
	}
	function hideWave() {
		if (wave.raf) { cancelAnimationFrame(wave.raf); wave.raf = 0; }
		if (wave.tick) { clearInterval(wave.tick); wave.tick = null; }
		if (wave.ctx) { try { wave.ctx.close(); } catch (e) {} wave.ctx = null; }
		if (wave.el) { wave.el.remove(); wave.el = null; }
		if (ui.input) { ui.input.style.visibility = ''; }
		if (ui.mic) { ui.mic.style.visibility = ''; }
	}
	function sendAudio(dataUrl) {
		if (awaitingSince) { sysLine('انتظر الرد الحالي ثم أرسل الصوت.'); return; }
		renderQuick(null);
		var m = { id: 0, role: 'user', content: '🎤 رسالة صوتية', audio: dataUrl, at: new Date().toISOString() };
		if (focusCtx && focusCtx.title) { m.about = focusCtx.title; }
		state.msgs.push(m); state.fresh = false; m.audio = ''; save(); m.audio = dataUrl;
		dispatch({ m: m, wrap: addBubble(m, true), text: '', image: '', audio: dataUrl, ctx: focusCtx });
	}

	/* ───────── images ───────── */
	function loadImage(file) {
		if (!file || !/^image\//.test(file.type)) { return; }
		if (file.size > 12 * 1024 * 1024) { sysLine('الصورة كبيرة جدًا — جرّب صورة أصغر.'); return; }
		var reader = new FileReader();
		reader.onload = function () {
			var img = new Image();
			img.onload = function () {
				var max = 1400, w = img.width, h = img.height, k = Math.min(1, max / Math.max(w, h));
				var c = document.createElement('canvas'); c.width = Math.round(w * k); c.height = Math.round(h * k);
				var ctx = c.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height); ctx.drawImage(img, 0, 0, c.width, c.height);
				var data = c.toDataURL('image/jpeg', 0.82);
				if (data.length > 3.9 * 1024 * 1024) { data = c.toDataURL('image/jpeg', 0.6); }
				pendingImage = data;
				ui.preview.querySelector('img').src = data;
				ui.preview.hidden = false;
				ui.input.focus();
			};
			img.onerror = function () { sysLine('تعذّر قراءة الصورة.'); };
			img.src = reader.result;
		};
		reader.readAsDataURL(file);
	}

	/* ───────── sending ───────── */
	function submit() {
		var t = ui.input.value.trim();
		if (!t && !pendingImage) { return; }
		if (awaitingSince) { waitTip(); return; } /* the text stays in the composer */
		ui.input.value = ''; autoGrow();
		send(t || '', pendingImage);
		pendingImage = null; ui.preview.hidden = true;
	}
	function waitTip() {
		tip('لحظة — ' + botName() + ' يكتب ردّه، وبعدها أرسل رسالتك.');
		ui.sendBtn.classList.remove('vai-nudge'); void ui.sendBtn.offsetWidth; ui.sendBtn.classList.add('vai-nudge');
	}
	function send(text, image, ctx) {
		text = String(text || '').trim();
		if (!text && !image) { return; }
		if (profileIncomplete()) { if (text && !ui.input.value.trim()) { ui.input.value = text; autoGrow(); } showCompleteForm(); return; }
		if (awaitingSince) { if (text && !ui.input.value.trim()) { ui.input.value = text; autoGrow(); } waitTip(); return; }
		renderQuick(null); tip('');
		ctx = ctx || focusCtx || null;
		var m = { id: 0, role: 'user', content: text || '(أرسل صورة)', image: image || '', at: new Date().toISOString() };
		if (ctx && (ctx.title || ctx.selection)) { m.about = ctx.title || ctx.selection.slice(0, 80); }
		state.msgs.push(m); state.fresh = false;
		if (image) { m.image = ''; }
		save();
		m.image = image || '';
		dispatch({ m: m, wrap: addBubble(m, true), text: text, image: image || '', audio: '', ctx: ctx });
	}
	/* one message, one bubble, one row on the hub. Every attempt carries the same client_id (plus retry_of once the hub's id is known), so the
	   hub can recognise a repeat; and a retry never posts again what the hub already holds: see retrySend() and recheck(). */
	function idBefore(m) { var n = 0, i; for (i = 0; i < state.msgs.length && state.msgs[i] !== m; i++) { if (state.msgs[i].id > n) { n = state.msgs[i].id; } } return n; }
	function dispatch(ref) {
		var m = ref.m;
		if (ref.err) { ref.err.remove(); ref.err = null; }
		if (ref.wrap) { ref.wrap.classList.remove('vai-failed'); }
		if (!ref.cid) { ref.cid = uuid(); }
		if (ref.base == null) { ref.base = Math.max(state.lastId || 0, idBefore(m)); } /* the hub's newest id before this message existed */
		lastSent = ref; lateRef = null; ref.held = false;
		setAwaiting(true);
		var data = ref.audio ? { message: '', audio: ref.audio } : { message: ref.text, image: ref.image || '' };
		if (ref.ctx) { data.context = ref.ctx; }
		data.client_id = ref.cid;
		if (m.id) { data.retry_of = m.id; }
		var fail = function (msg) {
			setAwaiting(false);
			if (ref.wrap) { ref.wrap.classList.add('vai-failed'); }
			ref.err = failLine(msg, function () { retrySend(ref); });
		};
		api('chat', data).then(function (r) {
			if (r && r.contact) { state.contact = r.contact; }
			if (r && r.message_id) { m.id = r.message_id; if (ref.wrap) { ref.wrap.setAttribute('data-id', m.id); } }
			if (r && r.image_url) { m.image = r.image_url; var im = ref.wrap && ref.wrap.querySelector('img.vai-img'); if (im) { im.src = r.image_url; } }
			if (r && r.audio_url) { m.audio = r.audio_url; var au = ref.wrap && ref.wrap.querySelector('audio'); if (au) { au.src = r.audio_url; } }
			if (r && r.transcript) { m.content = '🎤 ' + r.transcript; var bb = ref.wrap && ref.wrap.querySelector('.vai-bubble p'); if (bb) { bb.textContent = m.content; } }
			if (r && (r.message_id || r.image_url || r.audio_url || r.transcript)) { save(); }
			if (r && r.gated) { setAwaiting(false); if (!ref.audio) { state.pending = ref.text; pendingRef = ref; save(); } showGate(r.gate); return; }
			if (!r || r.ok === false) { fail((r && r.text) || (ref.audio ? 'تعذّر إرسال الصوت — حاول مرة ثانية.' : 'تعذّر الوصول إلى ' + botName() + ' — حاول مرة ثانية.')); return; }
			ref.held = true; /* stored and handed to the model or to the team: from here on a retry only asks for the reply */
			if (r.human) { setAwaiting(false); sysLine('أحد أعضاء الفريق يتابع محادثتك الآن — بيرد عليك هنا.'); schedulePoll(true); return; }
			schedulePoll(true);
		}).catch(function () {
			if (navigator.onLine === false) { setOffline(true); }
			fail('تعذّر الاتصال — تأكد من الإنترنت وحاول مرة ثانية.');
		});
	}
	/* did the message reach the hub although its answer never reached us? The hub's own history is the only witness. */
	function findStored(ref) {
		return api('history', {}).then(function (r) {
			var rows = (r && r.messages) || [], want = oneLine(ref.m.content), i, x;
			for (i = rows.length - 1; i >= 0; i--) {
				x = rows[i];
				if (x.role === 'user' && x.id > (ref.base || 0) && (ref.audio ? !!x.audio : (oneLine(x.content) === want && !!x.image === !!ref.image))) { return x; }
			}
			return null;
		}).catch(function () { return null; });
	}
	/* «إعادة الإرسال». With the hub's id in hand the same row goes again (the hub kept it but could not reach the model). Without it the answer
	   was lost on the way, so the hub is asked first: a message it already holds is adopted and we wait for its reply instead of posting a copy. */
	function retrySend(ref) {
		if (ref.m.id) { dispatch(ref); return; }
		if (ref.err) { ref.err.remove(); ref.err = null; }
		if (ref.wrap) { ref.wrap.classList.remove('vai-failed'); }
		lastSent = ref; lateRef = null;
		setAwaiting(true, true);
		findStored(ref).then(function (row) {
			if (lastSent !== ref) { return; } /* a new chat or a sign-out came first */
			if (!row) { dispatch(ref); return; }
			ref.m.id = row.id;
			if (ref.wrap) { ref.wrap.setAttribute('data-id', row.id); }
			if (row.image) { ref.m.image = row.image; }
			if (row.audio) { ref.m.audio = row.audio; }
			save();
			lateRef = ref;
			setAwaiting(true, true);
		});
	}
	/* «تحقّق الآن»: the hub holds the message, so we only ask for its reply once more; the notice returns when there is still none */
	function recheck(ref) {
		ref.err = null; ref.checks = (ref.checks || 0) + 1;
		lastSent = ref; lateRef = ref;
		setAwaiting(true, true);
	}
	function bubbleOf(m) {
		var w = m && m.id ? ui.body.querySelector('.vai-me[data-id="' + m.id + '"]') : null;
		if (!w) { var all = ui.body.querySelectorAll('.vai-me'); w = all.length ? all[all.length - 1] : null; }
		return w;
	}
	/* the message that hit a gate goes out once more after sign-in: its old copy and bubble are dropped first, so nothing shows twice */
	function resendPending() {
		var pend = state.pending, ref = pendingRef, i;
		state.pending = null; pendingRef = null;
		if (!pend && !ref) { save(); schedulePoll(true); return; }
		for (i = state.msgs.length - 1; i >= 0; i--) {
			var x = state.msgs[i];
			if (x.role === 'user' && (ref ? x === ref.m : x.content === pend)) { var w = bubbleOf(x); if (w) { w.remove(); } state.msgs.splice(i, 1); break; }
		}
		save();
		setAwaiting(false);
		send(ref ? ref.text : pend, ref ? ref.image : '', ref ? ref.ctx : null);
	}
	function failLine(text, retry, label) {
		var d = el('div', 'vai-msg vai-bot vai-fail');
		var b = el('div', 'vai-bubble vai-err', '<span class="vai-err-i" aria-hidden="true">' + ICON.alert + '</span><span class="vai-err-t"></span>');
		b.setAttribute('role', 'alert');
		b.querySelector('.vai-err-t').textContent = trText(text);
		d.appendChild(b);
		if (retry) {
			var btn = el('button', 'vai-btn vai-retry', ICON.retry + trText(esc(label || 'إعادة الإرسال')));
			btn.type = 'button';
			btn.addEventListener('click', function () { d.remove(); retry(); });
			d.appendChild(btn);
		}
		ui.body.appendChild(d); scrollBottom();
		return d;
	}
	function sendLock(on) { ui.sendBtn.setAttribute('aria-disabled', on ? 'true' : 'false'); ui.sendBtn.classList.toggle('vai-locked', !!on); }
	/* soft = we only expect a greeting (after sign-in); it ends quietly when the hub has nothing to say */
	function setAwaiting(on, soft) {
		awaitingSince = on ? Date.now() : 0;
		softWait = !!(on && soft);
		state.awaiting = softWait ? 0 : awaitingSince; save();
		sendLock(on);
		if (on) { showTyping(); } else { hideTyping(); tip(''); }
		schedulePoll(true);
	}

	/* ───────── polling (with back-off and an offline notice) ───────── */
	function engaged() { return !!(state.contact || awaitingSince || state.msgs.length); }
	function schedulePoll(now) {
		clearTimeout(pollTimer);
		if (!engaged()) { return; }
		var wait = awaitingSince ? ((Date.now() - awaitingSince) < 20000 ? 700 : 1500) : (state.open ? 12000 : 60000);
		if (pollFails) { wait = Math.min(60000, Math.max(wait, 1500 * Math.pow(2, Math.min(pollFails, 6)))) + Math.round(Math.random() * 500); now = false; }
		pollTimer = setTimeout(poll, now ? (awaitingSince ? 500 : 300) : wait);
	}
	function setOffline(on) {
		on = !!on;
		if (offline === on || !ui.net) { return; }
		offline = on;
		ui.net.hidden = !on;
		ui.net.querySelector('.vai-net-t').textContent = on ? trText('لا يوجد اتصال بالإنترنت — نعيد المحاولة تلقائيًا.') : '';
		if (!on && ui.rendered) { var ok = sysLine('عاد الاتصال ✅'); setTimeout(function () { ok.remove(); }, 4000); }
	}
	function pollFailed(network) {
		pollFails++;
		if (network && (pollFails >= 2 || navigator.onLine === false)) { setOffline(true); }
		if (!offline && awaitingSince && Date.now() - awaitingSince > TIMEOUT_MS) { replyLate(); }
		schedulePoll(false);
	}
	/* no reply in time. A message the hub holds (held) is never posted again: the visitor can only ask for its reply once more.
	   Only a message whose fate is unknown, or one the hub could not hand to the model, offers «إعادة الإرسال». */
	function replyLate() {
		var soft = softWait, ref = lateRef;
		lateRef = null;
		setAwaiting(false);
		if (soft && !ref) { return; }
		var last = state.msgs.length ? state.msgs[state.msgs.length - 1] : null, line;
		ref = ref || lastSent;
		if (!ref && last && last.role === 'user') { /* after a page change: rebuilt from the saved conversation (a picture or a voice note is not kept, so it cannot go again) */
			var plain = !!last.content && last.content !== '(أرسل صورة)' && !last.audio && last.content.indexOf('🎤') !== 0;
			if (last.id || plain) { ref = { m: last, wrap: bubbleOf(last), text: plain ? last.content : '', image: '', audio: '', ctx: null, held: !!last.id, base: idBefore(last) }; }
		}
		if (ref && ref.held) { line = failLine(ref.checks ? 'لم يصل الرد بعد — رسالتك محفوظة عندنا. انتظر قليلًا، أو اكتب سؤالك بصيغة أخرى.' : 'تأخر الرد أكثر من المعتاد — رسالتك وصلت، ولو جهز الرد بيظهر هنا تلقائيًا.', function () { recheck(ref); }, 'تحقّق الآن'); }
		else { line = failLine('تأخر الرد أكثر من المعتاد — لو وصل بيظهر هنا تلقائيًا، أو أعد الإرسال.', ref ? function () { retrySend(ref); } : null); }
		if (ref) { ref.err = line; lastSent = ref; }
	}
	function poll() {
		if (document.hidden && !awaitingSince) { schedulePoll(false); return; }
		api('poll', { after: state.lastId }).then(function (r) {
			if (!r || r.ok === false) { pollFailed(false); return; }
			if (pollFails || offline) { pollFails = 0; setOffline(false); }
			if (r.contact) { state.contact = r.contact; renderAcct(); if (r.contact.is_member && r.contact.daily_left != null && r.contact.daily_left <= (CFG.counter_show_at || 100) && state.lowWarned !== new Date().toDateString()) { state.lowWarned = new Date().toDateString(); save(); sysLine('⚡ باقي لك اليوم ' + r.contact.daily_left + ' رسالة مع ' + botName() + ' — يتجدد غدًا.'); } }
			if (r.cfg_rev && CFG.rev !== undefined && r.cfg_rev !== CFG.rev) { refreshConfig(); }
			var fresh = false;
			(r.messages || []).forEach(function (m) {
				if (m.id <= state.lastId) { return; }
				state.lastId = m.id;
				if (m.role === 'system') { return; }
				fresh = true;
				hideTyping();
				state.msgs.push(m);
				addBubble(m, true);
				if (m.role === 'assistant') { renderQuick(pickQuick(m.actions)); runActions(m.actions || []); }
				if (!state.open) { unread++; badge(); }
			});
			if (lateRef && (r.waiting || r.human)) { lateRef.held = true; } /* the hub is working on the message we found in its history */
			if (fresh) {
				awaitingSince = 0; softWait = false; lateRef = null; state.awaiting = 0; sendLock(false); tip(''); save();
				if (lastSent && lastSent.err) { lastSent.err.remove(); lastSent.err = null; if (lastSent.wrap) { lastSent.wrap.classList.remove('vai-failed'); } } /* the late reply made it */
			}
			else if (awaitingSince && softWait && !r.waiting && Date.now() - awaitingSince > 8000) { replyLate(); } /* quiet after a greeting wait; the notice again after «تحقّق الآن» */
			else if (awaitingSince && (r.timeout || (!r.waiting && Date.now() - awaitingSince > TIMEOUT_MS))) { replyLate(); }
			schedulePoll(false);
		}).catch(function () { pollFailed(true); });
	}
	window.addEventListener('online', function () { if (!ui.net) { return; } pollFails = 0; if (engaged()) { clearTimeout(pollTimer); poll(); } else { setOffline(false); } });
	window.addEventListener('offline', function () { if (ui.net && engaged()) { setOffline(true); } });

	/* ───────── actions ───────── */
	/* request_contact rides on a polled reply: it leaves an invitation under that reply and never opens the panel or a sheet by itself */
	function wantsContact(actions) {
		var asked = false;
		(actions || []).forEach(function (a) { if (a.type === 'request_contact') { asked = true; } });
		return asked && (!state.contact || state.contact.stage < 1);
	}
	function runActions(actions) {
		if (wantsContact(actions)) { showGate({ type: 'contact', invite: true }); }
		actions.forEach(function (a) {
			if (a.type === 'scroll_to' && a.selector) { scrollToSel(a.selector); }
			else if (a.type === 'open_page' && a.url && (CFG.nav_mode === 'auto' || samePage(a.url))) { navigate(a.url, null, a.carry); }
			else if (a.type === 'prefill_form' && a.url && (CFG.nav_mode === 'auto' || samePage(a.url))) { navigate(a.url, { url: a.url, form: a.form, fields: a.fields || {}, map: a.map || {}, label: a.label || '' }, a.carry); }
		});
	}
	function scrollToSel(sel) {
		try { var t = document.querySelector(sel); if (t) { t.scrollIntoView({ behavior: REDUCED ? 'auto' : 'smooth', block: 'center' }); flash(t); } } catch (e) {}
	}
	function flash(t) { t.classList.add('vai-flash'); setTimeout(function () { t.classList.remove('vai-flash'); }, 3500); }
	function navigate(url, prefill, carry) {
		if (prefill) { state.prefill = prefill; save(); }
		if (samePage(url)) {
			if (prefill) { applyPrefill(); }
			try { var h = new URL(url, location.href).hash; if (h) { scrollToSel(h); } } catch (e) {}
			return;
		}
		var line = sysLine('🔗 جاري فتح ' + (prefill && prefill.label ? prefill.label : 'الصفحة') + '…');
		var go = function (target) { setTimeout(function () { location.href = target; }, 600); };
		var host = hostOf(url);
		/* the handoff token travels only when the hub asked for it (carry) or the host is one the hub lists; a third-party URL never gets one */
		if (carry || (host !== myHost() && ecoHost(host))) {
			api('token', { url: url, prefill: prefill, open: true, fs: state.fs }).then(function (r) {
				if (r && r.ok && r.token) { go(addParam(url, 'vai', r.token)); } else { go(url); }
			}).catch(function () { go(url); });
		} else { go(url); }
		if (line) { setTimeout(function () { line.remove(); }, 4000); }
	}


	/* ───────── prefill ───────── */
	var HEUR = {
		name: ['input[name="names[first_name]"]', 'input[name="names[middle_name]"]', 'input[name*="full_name" i]', 'input[name*="fullname" i]', 'input[name*="name" i]:not([name*="user" i]):not([name*="company" i]):not([name*="project" i]):not([type="hidden"])'],
		first_name: ['input[name="names[first_name]"]', 'input[name*="first" i]'],
		last_name: ['input[name="names[last_name]"]', 'input[name*="last" i]'],
		phone: ['input[type="tel"]', 'input[name*="phone" i]', 'input[name*="mobile" i]', 'input[name*="jawal" i]', 'input[name*="whatsapp" i]'],
		email: ['input[type="email"]', 'input[name*="email" i]'],
		nationality: ['select[name*="national" i]', 'input[name*="national" i]'],
		id_number: ['input[name*="id_number" i]', 'input[name*="identity" i]', 'input[name*="national_id" i]', 'input[name*="iqama" i]', 'input[name*="hawiya" i]'],
		project: ['input[name*="project" i]', 'input[name*="company" i]', 'input[name*="business" i]'],
		company: ['input[name*="company" i]', 'input[name*="business" i]'],
		city: ['input[name*="city" i]', 'select[name*="city" i]'],
		notes: ['textarea', 'input[name*="message" i]', 'input[name*="notes" i]'],
		message: ['textarea']
	};
	var LABELS = { name: ['الاسم', 'اسمك', 'name'], phone: ['الجوال', 'رقم الهاتف', 'رقم التواصل', 'موبايل', 'phone', 'mobile'], email: ['البريد', 'الإيميل', 'ايميل', 'email'], nationality: ['الجنسية', 'nationality'], id_number: ['الهوية', 'الإقامة', 'رقم الهوية', 'id number'], project: ['المشروع', 'اسم المشروع', 'project'], company: ['الشركة', 'المنشأة', 'company'], city: ['المدينة', 'city'], notes: ['ملاحظات', 'نبذة', 'وصف', 'رسالتك', 'message'] };
	function visible(e) { return !!(e && e.offsetParent !== null && e.type !== 'hidden' && !e.disabled && !e.readOnly); }
	function findByLabel(key) {
		var words = LABELS[key] || [];
		var labels = document.querySelectorAll('label');
		for (var i = 0; i < labels.length; i++) {
			var t = (labels[i].textContent || '').trim().toLowerCase();
			for (var w = 0; w < words.length; w++) {
				if (t.indexOf(words[w].toLowerCase()) !== -1) {
					var inp = null;
					if (labels[i].htmlFor) { inp = document.getElementById(labels[i].htmlFor); }
					if (!inp) { inp = labels[i].querySelector('input,select,textarea'); }
					if (!inp) { var wrap = labels[i].closest('.ff-el-group, .ff-el-input--content, .elementor-field-group, .form-group, div'); if (wrap) { inp = wrap.querySelector('input:not([type=hidden]),select,textarea'); } }
					if (visible(inp)) { return inp; }
				}
			}
		}
		return null;
	}
	function findField(key, sel) {
		var e = null;
		if (sel) { try { var list = document.querySelectorAll(sel); for (var i = 0; i < list.length; i++) { if (visible(list[i])) { e = list[i]; break; } } } catch (err) {} }
		if (e) { return e; }
		var cands = HEUR[key] || [];
		for (var j = 0; j < cands.length; j++) { try { var q = document.querySelectorAll(cands[j]); for (var k = 0; k < q.length; k++) { if (visible(q[k])) { return q[k]; } } } catch (err2) {} }
		return findByLabel(key);
	}
	function setVal(e, v) {
		if (e.tagName === 'SELECT') {
			var nv = String(v).toLowerCase(), best = null;
			for (var i = 0; i < e.options.length; i++) { var ot = (e.options[i].textContent || '').toLowerCase(); if (ot === nv || ot.indexOf(nv) !== -1 || nv.indexOf(ot) !== -1 && ot.length > 2) { best = e.options[i]; break; } }
			if (!best) { return false; }
			e.value = best.value;
		} else {
			var proto = e.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
			var setter = Object.getOwnPropertyDescriptor(proto, 'value');
			if (setter && setter.set) { setter.set.call(e, v); } else { e.value = v; }
		}
		['input', 'change', 'blur'].forEach(function (ev) { e.dispatchEvent(new Event(ev, { bubbles: true })); });
		flash(e);
		return true;
	}
	function applyPrefill(tries) {
		var p = state.prefill;
		if (!p || !p.url || !samePage(p.url)) { return; }
		tries = tries || 0;
		var fields = p.fields || {}, map = p.map || {}, filled = 0, first = null, missing = 0;
		if (fields.name && !fields.first_name) {
			var fn = findField('first_name', map.first_name), ln = findField('last_name', map.last_name);
			if (fn && ln && fn !== ln) { var parts = String(fields.name).trim().split(/\s+/); fields.first_name = parts.shift(); fields.last_name = parts.join(' ') || parts[0] || ''; }
		}
		Object.keys(fields).forEach(function (k) {
			if (!fields[k] || k === 'name' && fields.first_name) { return; }
			var e = findField(k, map[k] && map[k].selector !== undefined ? map[k].selector : map[k]);
			if (!e) { missing++; return; }
			if (e.value && String(e.value).trim() !== '' && e.tagName !== 'SELECT') { return; }
			if (setVal(e, fields[k])) { filled++; if (!first) { first = e; } }
		});
		if (!filled && tries < 16) { setTimeout(function () { applyPrefill(tries + 1); }, 500); return; }
		state.prefill = null; save();
		if (filled) {
			var target = null;
			try { var h = new URL(p.url, location.href).hash; if (h) { target = document.querySelector(h); } } catch (e) {}
			(target || first).scrollIntoView({ behavior: REDUCED ? 'auto' : 'smooth', block: 'start' });
			sysLine('✅ عبّيت لك ' + filled + ' من الحقول — راجعها، أرفق الملفات إن وُجدت، ثم اضغط إرسال بنفسك.');
			if (!state.open) { openPanel(); }
		} else {
			sysLine('ما قدرت ألاقي حقول النموذج تلقائيًا — البيانات جاهزة في المحادثة، انسخها للنموذج.');
		}
	}

	/* ───────── page text: what the visitor is reading (sent with every chat message as page_text, ≤ 6000 chars, line breaks kept) ───────── */
	var SKIP_TAGS = { SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, TEMPLATE: 1, IFRAME: 1, CANVAS: 1, VIDEO: 1, AUDIO: 1, OBJECT: 1, SELECT: 1, TEXTAREA: 1, INPUT: 1, HEAD: 1, svg: 1, SVG: 1 };
	var BLOCK_TAGS = /^(P|DIV|SECTION|ARTICLE|LI|UL|OL|H[1-6]|TR|TABLE|BLOCKQUOTE|BR|HR|DT|DD|FIGURE|FIGCAPTION|HEADER|FOOTER|MAIN|ASIDE|NAV|FORM|PRE|ADDRESS|DETAILS|SUMMARY)$/;
	/* site chrome: navigation, the theme's header and footer, the WordPress admin bar */
	function isChromeEl(c) {
		var tag = c.tagName, role = c.getAttribute('role') || '', cls = typeof c.className === 'string' ? c.className : '';
		if (tag === 'NAV' || role === 'navigation' || role === 'banner' || role === 'contentinfo' || role === 'menu' || role === 'menubar' || c.id === 'wpadminbar') { return true; }
		if (/(^|\s)(elementor-location-(header|footer)|elementor-nav-menu|site-header|site-footer|navbar)(\s|$)/.test(cls)) { return true; }
		return (tag === 'HEADER' || tag === 'FOOTER') && !(c.parentElement && c.parentElement.closest('article,main,[role="main"]'));
	}
	function inChrome(n) { while (n && n.nodeType === 1 && n !== document.body) { if (isChromeEl(n)) { return true; } n = n.parentElement; } return false; }
	function isOurs(c) { var cls = typeof c.className === 'string' ? c.className : ''; return /(^|\s)vai-(root|topbar|ask-dot)(\s|$)/.test(cls); }
	function collectText(root, max, mainOnly) {
		var out = [], len = 0, stop = false;
		var walk = function (n) {
			for (var c = n.firstChild; c && !stop; c = c.nextSibling) {
				if (c.nodeType === 3) {
					var t = c.nodeValue.replace(/\s+/g, ' ');
					if (t) { out.push(t); len += t.length; if (len > max + 400) { stop = true; } }
				} else if (c.nodeType === 1) {
					var tag = c.tagName;
					if (SKIP_TAGS[tag] || c.hidden || c.getAttribute('aria-hidden') === 'true' || isOurs(c) || (mainOnly && isChromeEl(c))) { continue; }
					var block = BLOCK_TAGS.test(tag);
					if (block) { out.push('\n'); } else if (tag === 'TD' || tag === 'TH') { out.push(' | '); }
					walk(c);
					if (block) { out.push('\n'); }
				}
			}
		};
		walk(root);
		return out.join('').replace(/[ \t]*\n[ \t]*/g, '\n').replace(/\n{3,}/g, '\n\n').replace(/ {2,}/g, ' ').trim().slice(0, max);
	}
	function pageText() {
		var t = '';
		try {
			var root = document.querySelector('main,[role="main"],#main,#content,.site-main,.entry-content') || document.body;
			t = collectText(root, 6000, true);
			if (t.length < 200 && root !== document.body) { t = collectText(document.body, 6000, true); }
		} catch (e) {}
		return t;
	}

	/* ───────── ask about this: hover / keyboard focus / long-press / text selection ─────────
	   [data-vai-ask] marks an element (value = its title, "off" = never); optional data-vai-title, data-vai-text, data-vai-id, data-vai-type, data-vai-q.
	   Heuristics cover cards, packages, projects, headings and prices. Listeners are delegated and passive: host clicks are never touched,
	   dynamically inserted content works as it is, and nothing shows on the widget, on form fields or on the site chrome. */
	var ask = { on: false, chip: null, target: null, ctx: null, mode: '', showT: 0, hideT: 0, pressT: 0, selT: 0, scrollT: 0, scanT: 0, rearmT: 0, quiet: 0, mx: 0, my: 0, kb: false, visited: null, dismissed: null, mute: false, origin: null, lastTouch: 0, down: false, dots: 0, px: 0, py: 0 };
	var ASK_LEAF_OFF = 'input,textarea,select,option,button,label,form,[contenteditable=""],[contenteditable="true"],[role="dialog"],.vai-root,.vai-topbar,.vai-ask-dot,.vai-no-ask,[data-vai-ask="off"],[data-vai-ask="0"],[data-vai-ask="false"]';
	var ASK_CARDS = 'article,.product,.card,[class*="card"],[class*="package"],[class*="pricing"],[class*="price-table"],[class*="project"],[class*="plan-"],.elementor-widget-price-table,.elementor-widget-image-box,.elementor-widget-icon-box,.elementor-widget-call-to-action,.elementor-widget-flip-box,.elementor-post,.e-loop-item,.wp-block-media-text,.wc-block-grid__product';
	function chipShown() { return !!(ask.chip && !ask.chip.hidden); }
	function untarget() { if (ask.target) { ask.target.classList.remove('vai-ask-target'); } }
	function hideChip() {
		clearTimeout(ask.hideT);
		var back = null;
		if (ask.chip && !ask.chip.hidden) {
			if (document.activeElement === ask.chip && ask.origin && document.body.contains(ask.origin)) { back = ask.origin; }
			ask.chip.hidden = true; ask.chip.classList.remove('vai-ask-in');
		}
		untarget();
		ask.target = null; ask.ctx = null; ask.mode = ''; ask.visited = null; /* the next visit of the same element offers the chip to the keyboard again */
		/* everything is reset before the focus goes home, and that focus move is ours: it must not bring the chip straight back */
		if (back) { ask.mute = true; focusSoft(back); ask.mute = false; }
	}
	function isPrice(n) {
		if (!n || n.children.length > 3) { return false; }
		var s = oneLine(n.textContent);
		return s.length > 1 && s.length <= 60 && /[\d\u0660-\u0669]/.test(s) && /(ريال|ر\.س|﷼|SAR|USD|\$|درهم|AED|دينار|KWD|BHD|OMR|QAR)/i.test(s);
	}
	function cardOk(n) {
		var cls = typeof n.className === 'string' ? n.className : '';
		if (/(card|package|pricing|project|plan)s?[_-]+(title|header|head|body|text|content|img|image|icon|footer|btn|button|label|badge|meta|price|desc|list|grid|row|wrap|wrapper|container|carousel|slider)(?=\s|$)/i.test(cls)) { return false; } /* a part or a wrapper, not the card */
		var r = n.getBoundingClientRect(), vw = document.documentElement.clientWidth;
		if (vw > 700 && r.width > vw * 0.92) { return false; } /* a full-width row of cards, not one card */
		return r.width >= 120 && r.height >= 48 && r.height <= Math.max(900, window.innerHeight * 1.5) && oneLine(n.textContent).length >= 8;
	}
	function findCand(t) {
		if (!t || t.nodeType !== 1 || !t.closest || t.closest(ASK_LEAF_OFF)) { return null; }
		var c = t.closest('[data-vai-ask]'), n = t, depth = 0;
		while (!c && n && n !== document.body && depth < 8) {
			if (n.matches(ASK_CARDS) && cardOk(n)) { c = n; }
			n = n.parentElement; depth++;
		}
		if (!c) { c = t.closest('h1,h2,h3,h4'); if (c && oneLine(c.textContent).length < 3) { c = null; } }
		if (!c && isPrice(t)) { c = t; }
		return c && !inChrome(c) ? c : null;
	}
	function sectionText(h) {
		var lvl = +h.tagName.charAt(1), out = oneLine(h.textContent);
		var grab = function (n) {
			var guard = 0;
			while (n && guard < 12 && out.length < 1500) {
				if (/^H[1-6]$/.test(n.tagName) && +n.tagName.charAt(1) <= lvl) { break; }
				if (n.querySelector && n.querySelector('h1,h2,h3') && guard > 0) { break; }
				var t = collectText(n, 1500 - out.length, true);
				if (t) { out += '\n' + t; }
				n = n.nextElementSibling; guard++;
			}
		};
		grab(h.nextElementSibling);
		if (out.length < 60) { var w = h.closest('.elementor-widget'); if (w) { grab(w.nextElementSibling); } } /* Elementor keeps a heading alone in its widget */
		return out;
	}
	function normCtx(c) {
		if (!c || typeof c !== 'object') { return null; }
		var out = { type: String(c.type || 'element').toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 24) || 'element' };
		var put = function (k, max, lines) {
			var v = c[k];
			if (v == null || typeof v === 'object') { return; }
			v = lines ? String(v).replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim() : oneLine(v);
			if (v) { out[k] = v.slice(0, max); }
		};
		put('id', 64); put('title', 160); put('text', 6000, true); put('selection', 1000, true);
		return (out.id || out.title || out.text || out.selection) ? out : null;
	}
	function ctxOf(node) {
		var flag = node.getAttribute('data-vai-ask'), title = node.getAttribute('data-vai-title') || '', text = node.getAttribute('data-vai-text') || '';
		if (!title && flag && !/^(1|true|on|yes)$/i.test(flag)) { title = flag; }
		if (/^H[1-6]$/.test(node.tagName)) { title = title || oneLine(node.textContent); text = text || sectionText(node); }
		else if (flag == null && isPrice(node)) {
			var box = node.parentElement, up = 0;
			while (box && box.parentElement && box.parentElement !== document.body && up < 3 && oneLine(box.textContent).length < 80) { box = box.parentElement; up++; }
			var hd = box && box.querySelector ? box.querySelector('h1,h2,h3,h4,h5,h6') : null;
			title = title || oneLine((hd ? hd.textContent + ' — ' : '') + node.textContent);
			text = text || collectText(box || node, 2000, false);
		} else {
			if (!title) { var h = node.querySelector('h1,h2,h3,h4,h5,h6,[class*="title"],[class*="heading"]'); title = oneLine(h ? h.textContent : '') || node.getAttribute('aria-label') || ''; }
			text = text || collectText(node, 6000, false);
		}
		if (!title) { title = oneLine(text).slice(0, 80); }
		return normCtx({ type: node.getAttribute('data-vai-type') || 'element', id: node.getAttribute('data-vai-id') || node.id || '', title: title, text: text });
	}
	function askChip() {
		if (ask.chip) { return ask.chip; }
		var b = el('button', 'vai-ask', ICON.spark + '<span>' + esc(copy('ask_label', 'اسأل المستشار')) + '</span>');
		b.type = 'button'; b.hidden = true;
		b.addEventListener('mousedown', function (e) { e.preventDefault(); }); /* keeps the text selection and the page's own focus */
		b.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); askGo(); });
		b.addEventListener('mouseenter', function () { clearTimeout(ask.hideT); });
		b.addEventListener('mouseleave', function () { if (ask.mode === 'hover') { ask.hideT = setTimeout(hideChip, 260); } });
		b.addEventListener('blur', function () { if (ask.mode === 'kb') { ask.hideT = setTimeout(hideChip, 220); } });
		b.addEventListener('keydown', function (e) {
			/* Tab leaves the chip as if it sat right after the element it belongs to; Shift+Tab goes back to that element */
			if (e.key === 'Tab' && ask.origin && document.body.contains(ask.origin)) { if (e.shiftKey) { e.preventDefault(); } focusSoft(ask.origin); }
		});
		ui.root.appendChild(b);
		ask.chip = b;
		return b;
	}
	/* A chip that follows the mouse never lands under the resting pointer: the visitor's next click belongs to the page, not to us.
	   Places are tried in order (the element's top edge, its bottom edge, inside its top corner, just below or above the pointer, the far end);
	   the first one that fits the viewport and leaves the pointer free wins. Returns false when none does. */
	function placeChip(mode, rect, pt) {
		var c = ask.chip;
		c.hidden = false; c.style.visibility = ''; c.classList.remove('vai-ask-in');
		var cw = c.offsetWidth, ch = c.offsetHeight, vw = document.documentElement.clientWidth, vh = window.innerHeight;
		var top0 = (ui.topbar ? 46 : 0) + 8, maxY = vh - ch - 8, tries = [], i, x, y;
		var touchy = Date.now() - ask.lastTouch < 4000, avoid = mode === 'hover' || (mode === 'selection' && !touchy);
		if (mode === 'touch' && pt) {
			tries.push([pt.x - cw / 2, pt.y - ch - 30 < top0 ? pt.y + 30 : pt.y - ch - 30]);
		} else if (mode === 'selection') {
			var sx = rect.left + rect.width / 2 - cw / 2, up = rect.top - ch - 8, down = rect.bottom + (touchy ? 14 : 10);
			/* the native selection toolbar of a phone sits above the text, so there the chip goes below it */
			if (touchy) { tries.push([sx, down <= maxY ? down : rect.top - ch - 48]); }
			else { if (up >= top0) { tries.push([sx, up]); } tries.push([sx, down <= maxY ? down : rect.top - ch - 48], [sx, ask.my + 22], [sx, ask.my - ch - 16]); }
		} else {
			var rtl = window.getComputedStyle(ask.target).direction === 'rtl';
			var x0 = rtl ? rect.right - cw - 10 : rect.left + 10, x1 = rtl ? rect.left + 10 : rect.right - cw - 10, ys = [];
			if (rect.top - ch + 12 >= top0) { ys.push(rect.top - ch + 12); } /* rides the top edge, mostly outside the element */
			if (rect.bottom - 12 >= top0 && rect.bottom - 12 <= maxY) { ys.push(rect.bottom - 12); } /* no room above: the bottom edge */
			ys.push(Math.max(top0, rect.top + 8));
			for (i = 0; i < ys.length; i++) { tries.push([x0, ys[i]]); }
			if (avoid) {
				tries.push([x0, ask.my + 22], [x0, ask.my - ch - 16]);
				for (i = 0; i < ys.length; i++) { tries.push([x1, ys[i]]); }
			}
		}
		for (i = 0; i < tries.length; i++) {
			x = Math.round(Math.max(8, Math.min(vw - cw - 8, tries[i][0])));
			y = Math.round(Math.max(top0, Math.min(maxY, tries[i][1])));
			if (avoid && ask.mx >= x - 10 && ask.mx <= x + cw + 10 && ask.my >= y - 10 && ask.my <= y + ch + 10) { continue; }
			c.style.left = x + 'px'; c.style.top = y + 'px';
			void c.offsetWidth;
			c.classList.add('vai-ask-in');
			return true;
		}
		c.hidden = true;
		return false;
	}
	function showFor(c, mode, pt) {
		if (!document.body.contains(c)) { return; }
		var r = c.getBoundingClientRect();
		if (r.width === 0 || r.bottom < 0 || r.top > window.innerHeight) { return; }
		askChip();
		clearTimeout(ask.hideT);
		untarget();
		if (c !== ask.target) { ask.visited = null; }
		ask.target = c; ask.mode = mode; ask.ctx = null;
		if (!placeChip(mode, r, pt)) { hideChip(); return; }
		c.classList.add('vai-ask-target');
		if (mode === 'touch') { ask.hideT = setTimeout(hideChip, 5000); }
	}
	function armHover(t) {
		clearTimeout(ask.showT);
		if (ask.down || Date.now() < ask.quiet || !t || t.nodeType !== 1 || ui.root.contains(t)) { return; }
		ask.showT = setTimeout(function () {
			if (ask.down || state.open && ui.panel.classList.contains('vai-full')) { return; }
			var c = findCand(t);
			if (c !== ask.dismissed) { ask.dismissed = null; } /* Escape sent the chip away from that element; it returns once the visitor has been elsewhere */
			if (c && c !== ask.dismissed) { showFor(c, 'hover'); }
		}, 380);
	}
	function onOver(e) {
		var t = e.target;
		ask.mx = e.clientX; ask.my = e.clientY;
		if (Date.now() - ask.lastTouch < 1200) { return; } /* mouse events a tap emulates */
		if (ask.chip && ask.chip.contains(t)) { clearTimeout(ask.hideT); clearTimeout(ask.showT); return; } /* the pointer reached the chip: whatever it crossed on the way does not take it over */
		if (ask.mode === 'selection') { return; }
		if (ask.target && ask.target.contains(t)) { clearTimeout(ask.hideT); return; }
		clearTimeout(ask.showT);
		if (chipShown() && ask.mode === 'hover') { clearTimeout(ask.hideT); ask.hideT = setTimeout(hideChip, 260); }
		armHover(t);
	}
	function onSelection() {
		var sel = window.getSelection ? window.getSelection() : null;
		var none = function () { if (ask.mode === 'selection') { hideChip(); } };
		if (!sel || sel.isCollapsed || !sel.rangeCount) { none(); return; }
		if (ask.down) { return; } /* still dragging: wait for mouseup */
		var txt = String(sel).replace(/[ \t]+/g, ' ').trim();
		if (txt.length < 3) { none(); return; }
		var range = sel.getRangeAt(0), node = range.commonAncestorContainer;
		if (node.nodeType !== 1) { node = node.parentElement; }
		if (!node || !node.closest || node.closest(ASK_LEAF_OFF) || inChrome(node)) { none(); return; }
		var rects = range.getClientRects(), touchy = Date.now() - ask.lastTouch < 4000;
		var r = rects.length ? rects[touchy ? rects.length - 1 : 0] : range.getBoundingClientRect();
		if (!r || (r.width === 0 && r.height === 0)) { none(); return; }
		var host = findCand(node), hc = host ? ctxOf(host) : null;
		askChip();
		clearTimeout(ask.hideT); clearTimeout(ask.showT);
		untarget();
		ask.target = null; ask.mode = 'selection';
		ask.ctx = normCtx({ type: 'selection', id: hc && hc.id, title: (hc && hc.title) || document.title, text: hc ? hc.text : collectText(node.closest('p,li,td,blockquote,section,article,div') || node, 3000, false), selection: txt });
		if (!placeChip('selection', r)) { hideChip(); }
	}
	function askGo() {
		var ctx = ask.ctx, t = ask.target, q = '';
		if (!ctx && t) { ctx = ctxOf(t); q = t.getAttribute('data-vai-q') || ''; }
		hideChip();
		if (ctx) { askAbout(ctx, '', t, q); }
	}
	/* opens the chat on a subject; with a text it is sent at once. Also behind window.VAI.ask(text, context). */
	function askAbout(context, text, node, q) {
		var ctx = normCtx(context);
		openPanel(); closeSheet();
		if (ctx) { setFocus(ctx, node || null, q || ''); }
		if (text) { send(text); } else if (!MOBILE) { focusSoft(ui.input); }
		if (ctx) { try { window.dispatchEvent(new CustomEvent('vai:ask', { detail: ctx })); } catch (e) {} }
	}
	function focusIdeas(ctx, q) {
		var list = q ? [oneLine(q)] : [];
		return list.concat(ctx.selection ? ['اشرح لي هذا النص', 'ما المقصود به عمليًا؟', 'لخّصه في نقاط'] : ['حدّثني عن هذا', 'ما أهم ما يجب أن أعرفه؟', 'هل يناسبني؟ ولماذا؟']).slice(0, 4);
	}
	function setFocus(ctx, node, q) {
		focusCtx = ctx; focusEl = node || null;
		renderFocus();
		renderQuick(focusIdeas(ctx, q)); ui.quickFocus = true;
		say('تسأل الآن عن: ' + (ctx.title || ctx.selection || ''));
	}
	function clearFocus() {
		focusCtx = null; focusEl = null;
		if (!ui.focus) { return; }
		renderFocus();
		if (ui.quickFocus) { ui.quickFocus = false; if (state.msgs.length) { renderQuick(null); } else { renderQuick(starters(), true); } }
	}
	/* the visible «تسأل عن: …» pill above the composer; it stays until the visitor removes it, asks about something else or starts a new chat */
	function renderFocus() {
		if (!focusCtx) { ui.focus.hidden = true; ui.focus.innerHTML = ''; return; }
		var label = focusCtx.selection ? '«' + (focusCtx.selection.length > 70 ? focusCtx.selection.slice(0, 68) + '…' : focusCtx.selection) + '»' : (focusCtx.title || 'هذا العنصر');
		ui.focus.innerHTML = trText('<div class="vai-focus-in"><span class="vai-focus-i" aria-hidden="true">' + ICON.spark + '</span><span class="vai-focus-l">تسأل عن:</span><button type="button" class="vai-focus-t" dir="auto"></button><button type="button" class="vai-focus-x" aria-label="إزالة موضوع السؤال" title="إزالة">' + ICON.x + '</button></div>');
		var t = ui.focus.querySelector('.vai-focus-t');
		t.textContent = label;
		if (focusEl) { t.title = 'اعرضه في الصفحة'; }
		t.addEventListener('click', function () {
			if (!focusEl || !document.body.contains(focusEl) || ui.panel.classList.contains('vai-full')) { return; }
			try { focusEl.scrollIntoView({ behavior: REDUCED ? 'auto' : 'smooth', block: 'center' }); flash(focusEl); } catch (e) {}
		});
		ui.focus.querySelector('.vai-focus-x').addEventListener('click', function () { clearFocus(); focusSoft(ui.input); });
		ui.focus.hidden = false;
	}
	/* a small button inside every [data-vai-ask] element: always visible on touch screens, shown on keyboard focus elsewhere. Where there is a mouse
	   it takes no pointer events at all (widget.css), so it never swallows a click meant for the card: mouse users get the hover chip. */
	function addDot(node) {
		if (node.closest(ASK_LEAF_OFF) || inChrome(node) || ask.dots >= 80) { return; }
		var cs = window.getComputedStyle(node);
		if (!/^(block|flex|grid|inline-block|inline-flex|inline-grid|list-item|flow-root)$/.test(cs.display)) { return; }
		if (cs.position === 'static') { node.classList.add('vai-ask-host'); }
		var b = document.createElement('button'), c = ctxOf(node);
		b.type = 'button'; b.className = 'vai-ask-dot'; b.innerHTML = ICON.spark;
		b.setAttribute('aria-label', trText(copy('ask_label', 'اسأل المستشار')) + (c && c.title ? trText(' عن: ') + c.title : ''));
		b.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); hideChip(); askAbout(ctxOf(node), '', node, node.getAttribute('data-vai-q') || ''); });
		node.appendChild(b);
		ask.dots++;
	}
	function scanDots() {
		var list = document.querySelectorAll('[data-vai-ask]:not([data-vai-dot])'), i;
		for (i = 0; i < list.length; i++) { list[i].setAttribute('data-vai-dot', '1'); try { addDot(list[i]); } catch (e) {} }
	}
	function initAsk() {
		if (ask.on || CFG.ask === 0 || CFG.ask === '0' || CFG.ask === false || B.ask === false || B.autoOpen === 'account') { return; }
		if (document.body.classList.contains('elementor-editor-active')) { return; }
		ask.on = true;
		var passive = { passive: true }, passiveCapture = { passive: true, capture: true };
		document.addEventListener('mouseover', onOver, passive);
		document.addEventListener('mousemove', function (e) { ask.mx = e.clientX; ask.my = e.clientY; }, passive);
		document.documentElement.addEventListener('mouseleave', function () { clearTimeout(ask.showT); if (ask.mode === 'hover') { ask.hideT = setTimeout(hideChip, 260); } });
		document.addEventListener('mousedown', function (e) { if (Date.now() - ask.lastTouch < 1200) { return; } ask.kb = false; ask.down = true; if (chipShown() && !ask.chip.contains(e.target) && ask.mode !== 'selection') { hideChip(); } }, passiveCapture);
		document.addEventListener('mouseup', function () { ask.down = false; clearTimeout(ask.selT); ask.selT = setTimeout(onSelection, 30); }, passiveCapture);
		document.addEventListener('selectionchange', function () { clearTimeout(ask.selT); ask.selT = setTimeout(onSelection, 280); });
		/* long-press: links keep their native menu, text gets the selection chip, anything else gets the chip at the finger */
		document.addEventListener('touchstart', function (e) {
			ask.lastTouch = Date.now(); ask.kb = false;
			clearTimeout(ask.pressT);
			var t = e.target;
			if (ask.chip && ask.chip.contains(t)) { return; }
			if (chipShown() && ask.mode !== 'selection') { hideChip(); }
			if (!e.touches || e.touches.length !== 1 || !t.closest || t.closest('a[href]') || ui.root.contains(t)) { return; }
			ask.px = e.touches[0].clientX; ask.py = e.touches[0].clientY;
			ask.pressT = setTimeout(function () {
				var s = window.getSelection ? window.getSelection() : null;
				if (s && !s.isCollapsed) { return; }
				var c = findCand(t);
				if (c) { showFor(c, 'touch', { x: ask.px, y: ask.py }); }
			}, 560);
		}, passive);
		document.addEventListener('touchmove', function (e) { var p = e.touches && e.touches[0]; if (p && (Math.abs(p.clientX - ask.px) > 10 || Math.abs(p.clientY - ask.py) > 10)) { clearTimeout(ask.pressT); } }, passive);
		document.addEventListener('touchend', function () { ask.lastTouch = Date.now(); clearTimeout(ask.pressT); }, passive);
		document.addEventListener('touchcancel', function () { clearTimeout(ask.pressT); }, passive);
		/* keyboard: the chip follows the focus into a card; one Tab reaches it, the next Tab continues through the page */
		document.addEventListener('keydown', function (e) {
			if (e.key !== 'Tab') { return; }
			ask.kb = true;
			if (e.shiftKey || ask.mode !== 'kb' || !chipShown() || ask.visited === ask.target || document.activeElement !== ask.origin) { return; }
			e.preventDefault(); ask.visited = ask.target; focusSoft(ask.chip);
		}, true);
		document.addEventListener('focusin', function (e) {
			var t = e.target;
			if (ask.mute || !ask.kb || !t || t.nodeType !== 1 || ui.root.contains(t)) { return; }
			var c = findCand(t);
			if (c !== ask.dismissed) { ask.dismissed = null; }
			if (!c || c === ask.dismissed || c.querySelector('.vai-ask-dot')) { if (ask.mode === 'kb') { hideChip(); } return; }
			ask.origin = t;
			if (c !== ask.target || !chipShown()) { showFor(c, 'kb'); } else { clearTimeout(ask.hideT); }
		});
		/* scrolling: a hover chip goes away at once; a selection or keyboard chip steps aside and returns where the element now is */
		window.addEventListener('scroll', function (e) {
			if (e.target && e.target.nodeType === 1 && ui.root.contains(e.target)) { return; }
			ask.quiet = Date.now() + 220;
			clearTimeout(ask.showT); clearTimeout(ask.pressT);
			/* when the page comes to rest, whatever now lies under the still pointer gets its chance */
			clearTimeout(ask.rearmT);
			ask.rearmT = setTimeout(function () {
				if (chipShown() || !(ask.mx || ask.my) || Date.now() - ask.lastTouch < 1200) { return; }
				var n = document.elementFromPoint(ask.mx, ask.my);
				if (n) { armHover(n); }
			}, 260);
			if (!chipShown()) { return; }
			if (ask.mode === 'hover' || ask.mode === 'touch') { hideChip(); return; }
			ask.chip.style.visibility = 'hidden';
			clearTimeout(ask.scrollT);
			ask.scrollT = setTimeout(function () {
				if (!chipShown()) { return; }
				if (ask.mode === 'selection') { onSelection(); } else if (ask.target) { placeChip('kb', ask.target.getBoundingClientRect()); }
			}, 160);
		}, passiveCapture);
		window.addEventListener('resize', function () { if (chipShown()) { hideChip(); } }, passive);
		window.addEventListener('blur', function () { ask.down = false; });
		scanDots();
		if (window.MutationObserver) {
			/* throttled, not debounced: a page that never stops changing (a ticker, a countdown) must not starve the scan. Only a change that
			   brings a marked element counts, and the widget's own DOM never does. */
			new MutationObserver(function (recs) {
				if (ask.scanT) { return; }
				var hit = false, i, j, n, r;
				for (i = 0; i < recs.length && !hit; i++) {
					r = recs[i];
					if (ui.root.contains(r.target)) { continue; }
					if (r.type === 'attributes') { hit = true; break; }
					for (j = 0; j < r.addedNodes.length && !hit; j++) { n = r.addedNodes[j]; hit = n.nodeType === 1 && !isOurs(n) && (n.hasAttribute('data-vai-ask') || !!n.querySelector('[data-vai-ask]')); }
				}
				if (hit) { ask.scanT = setTimeout(function () { ask.scanT = 0; scanDots(); }, 400); }
			}).observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['data-vai-ask'] });
		}
	}


	/* ───────── form kit: labelled fields, inline errors, password reveal, busy buttons ───────── */
	var fieldSeq = 0;
	function field(o) {
		var id = 'vai-f' + (++fieldSeq), type = o.type || 'text';
		var attrs = ' id="' + id + '" name="' + o.name + '" dir="' + (o.dir || 'auto') + '" aria-describedby="' + id + '-h ' + id + '-e"' +
			(o.placeholder ? ' placeholder="' + esc(trText(o.placeholder)) + '"' : '') + (o.autocomplete ? ' autocomplete="' + o.autocomplete + '"' : '') +
			(o.inputmode ? ' inputmode="' + o.inputmode + '"' : '') + (o.maxlength ? ' maxlength="' + o.maxlength + '"' : '') + (o.required ? ' aria-required="true"' : '');
		var control;
		if (type === 'textarea') { control = '<textarea rows="' + (o.rows || 3) + '"' + attrs + '>' + esc(o.value || '') + '</textarea>'; }
		else if (type === 'password') { control = '<div class="vai-pw"><input type="password"' + attrs + '><button type="button" class="vai-reveal" aria-label="إظهار كلمة المرور" aria-pressed="false">' + ICON.eye + '</button></div>'; }
		else { control = '<input type="' + type + '"' + attrs + ' value="' + esc(o.value || '') + '">'; }
		return '<div class="vai-field' + (o.cls ? ' ' + o.cls : '') + '" data-f="' + o.name + '"><label class="vai-label" for="' + id + '">' + esc(trText(o.label)) + (o.optional ? ' <span class="vai-opt">' + trText('اختياري') + '</span>' : '') + '</label>' + control +
			'<div class="vai-help" id="' + id + '-h">' + esc(trText(o.help || '')) + '</div><div class="vai-field-err" id="' + id + '-e" role="alert"></div></div>';
	}
	/* 2.16.1: the English mode shows each country's ENGLISH name (served by the hub) — never the Arabic one */
	function cname(c) { return state.lang === 'en' && c && c.en ? c.en : (c ? c.n : ''); }
	function phoneField(value) {
		var id = 'vai-f' + (++fieldSeq);
		var cs = (CFG.countries || []).map(function (x) { return '<option value="' + esc(x.k) + '"' + (x.k === 'sa' ? ' selected' : '') + '>' + esc(cname(x) + ' +' + x.c) + '</option>'; }).join('');
		return '<div class="vai-field" data-f="phone"><label class="vai-label" for="' + id + '">' + esc(L('رقم الجوال')) + '</label><div class="vai-phone-row"><span class="vai-cc"><span class="vai-cc-face" aria-hidden="true">' + flagSvg('sa') + '<b>+966</b></span><select name="country" class="vai-select vai-country" aria-label="' + esc(trText('الدولة ورمز الاتصال')) + '"' + (cs ? '' : ' hidden') + '>' + cs + '</select></span><input id="' + id + '" name="phone" type="tel" dir="ltr" inputmode="numeric" autocomplete="tel-national" aria-required="true" aria-describedby="' + id + '-h ' + id + '-e" value="' + esc(value || '') + '"><span class="vai-ok" aria-hidden="true">' + ICON.check + '</span></div>' +
			'<div class="vai-help" id="' + id + '-h"></div><div class="vai-field-err" id="' + id + '-e" role="alert"></div></div>';
	}
	/* phone help follows the chosen country (name, example); Arabic-Indic digits are turned into 0–9 while typing; a tick shows when the hub's rule is met */
	function bindPhone(f) {
		var sel = f.querySelector('select[name=country]'), ph = f.querySelector('input[name=phone]');
		if (!ph) { return; }
		var box = ph.closest('.vai-field'), help = box.querySelector('.vai-help');
		var live = function () { var v = ph.value.trim(); box.classList.toggle('vai-valid', !!v && phoneCheck((sel && sel.value) || 'sa', v).ok); };
		var upd = function () {
			var c = (CFG.countries || []).filter(function (x) { return sel && x.k === sel.value; })[0] || null;
			var k = (sel && sel.value) || 'sa';
			var face = box.querySelector('.vai-cc-face'); if (face) { face.innerHTML = flagSvg(k) + '<b>+' + esc((c && c.c) || '966') + '</b>'; }
			/* 2.15.2 (owner): the placeholder is a MASK (05XXXXXXXX) so nobody mistakes it for a prefilled number; the real example stays in the help line */
			ph.placeholder = (k === 'sa' || k === 'ae') ? '05XXXXXXXX' : (c ? c.e.replace(/[0-9]/g, 'X') : '');
			help.textContent = (c ? cname(c) + ' — ' : '') + trText('اكتب الرقم بدون رمز الدولة وبدون مسافات' + (c && c.e ? '، مثال: ' + c.e : ''));
			live();
		};
		ph.addEventListener('input', function () { var n = latinDigits(ph.value); if (n !== ph.value) { ph.value = n; } live(); });
		if (sel) { sel.addEventListener('change', upd); }
		upd();
	}
	function val(f, n) {
		if (f.querySelector('input[type=radio][name="' + n + '"]')) { var c = f.querySelector('input[type=radio][name="' + n + '"]:checked'); return c ? c.value : ''; }
		var i = f.querySelector('[name="' + n + '"]');
		return i ? i.value.trim() : '';
	}
	function clearErr(box) {
		box.classList.remove('vai-invalid');
		var c = box.querySelectorAll('input,textarea,select'), i;
		for (i = 0; i < c.length; i++) { c[i].removeAttribute('aria-invalid'); }
		var e = box.querySelector('.vai-field-err'); if (e) { e.textContent = ''; }
	}
	function setErr(f, name, msg) {
		var box = f.querySelector('.vai-field[data-f="' + name + '"]');
		if (!box) { return false; }
		box.classList.add('vai-invalid'); box.classList.remove('vai-valid');
		var c = box.querySelector('input:not([type=radio]),textarea') || box.querySelector('input,select');
		if (c) { c.setAttribute('aria-invalid', 'true'); }
		box.querySelector('.vai-field-err').textContent = trText(msg);
		return true;
	}
	/* errs: [[field, message], …] — all shown at once, the first one focused and scrolled into view */
	function showErrs(f, errs) {
		if (!errs.length) { return false; }
		errs.forEach(function (e) { setErr(f, e[0], e[1]); });
		var box = f.querySelector('.vai-field.vai-invalid');
		if (box) {
			var c = box.querySelector('input,textarea,select');
			if (c) { focusSoft(c); }
			try { box.scrollIntoView({ block: 'center', behavior: REDUCED ? 'auto' : 'smooth' }); } catch (x) {}
		}
		return true;
	}
	function formErr(f, msg, actions) {
		var e = f.querySelector('.vai-form-err');
		if (!e) { return; }
		e.innerHTML = '';
		if (!msg) { e.hidden = true; return; }
		e.appendChild(el('span', 'vai-form-err-i', ICON.alert));
		var t = el('span', 'vai-form-err-t'); t.textContent = trText(msg); e.appendChild(t);
		(actions || []).forEach(function (a) { var b = el('button', 'vai-link', esc(a.label)); b.type = 'button'; b.addEventListener('click', a.fn); e.appendChild(b); });
		e.hidden = false;
		try { e.scrollIntoView({ block: 'nearest', behavior: REDUCED ? 'auto' : 'smooth' }); } catch (x) {}
	}
	function busy(btn, on, label) {
		if (!btn) { return; }
		if (on) { if (btn.getAttribute('aria-busy') === 'true') { return; } btn.vaiLabel = btn.innerHTML; btn.disabled = true; btn.setAttribute('aria-busy', 'true'); btn.innerHTML = '<span class="vai-spin" aria-hidden="true"></span>' + trText(esc(label || 'لحظة…')); }
		else { btn.disabled = false; btn.removeAttribute('aria-busy'); if (btn.vaiLabel != null) { btn.innerHTML = btn.vaiLabel; btn.vaiLabel = null; } }
	}
	function isBusy(btn) { return !!(btn && btn.getAttribute('aria-busy') === 'true'); }
	/* our Arabic messages replace the browser's own validation bubbles (novalidate); an error clears as soon as its field changes */
	function wireForm(f) {
		f.setAttribute('novalidate', '');
		var onEdit = function (e) {
			var box = e.target.closest && e.target.closest('.vai-field');
			if (box && box.classList.contains('vai-invalid')) { clearErr(box); }
			var fe = f.querySelector('.vai-form-err'); if (fe && !fe.hidden) { fe.hidden = true; fe.innerHTML = ''; }
		};
		f.addEventListener('input', onEdit); f.addEventListener('change', onEdit);
		f.querySelectorAll('input[dir=auto],textarea[dir=auto]').forEach(function (i) { autoDir(i); i.addEventListener('input', function () { autoDir(i); }); });
		f.querySelectorAll('.vai-reveal').forEach(function (b) {
			b.addEventListener('click', function () {
				var i = b.parentNode.querySelector('input'), show = i.type === 'password';
				i.type = show ? 'text' : 'password';
				b.setAttribute('aria-pressed', show ? 'true' : 'false');
				b.setAttribute('aria-label', trText(show ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'));
				b.innerHTML = show ? ICON.eyeOff : ICON.eye;
				focusSoft(i);
			});
		});
		f.querySelectorAll('.vai-choices input[type=radio]').forEach(function (r) {
			r.addEventListener('change', function () { f.querySelectorAll('.vai-choice').forEach(function (c) { c.classList.toggle('vai-on', c.querySelector('input').checked); }); });
		});
		bindPhone(f);
	}
	var ERR_NET = 'تعذّر الاتصال — تأكد من الإنترنت وحاول مرة ثانية.';

	/* ───────── phone check — GCC strict, every other country by length; the hub's rules stay the final word ───────── */
	var PHONE_RULES = { sa: /^0?5\d{8}$/, ae: /^0?5\d{8}$/, kw: /^[569]\d{7}$/, qa: /^[3567]\d{7}$/, bh: /^[3679]\d{7}$/, om: /^[79]\d{7}$/ };
	function phoneCheck(country, raw) {
		var d = latinDigits(raw).replace(/\D/g, '');
		var c = (CFG.countries || []).filter(function (x) { return x.k === country; })[0] || { c: '966', e: '05XXXXXXXX', n: 'السعودية' };
		if (d.indexOf('00' + c.c) === 0) { d = d.slice(2 + c.c.length); } else if (d.indexOf(c.c) === 0 && d.length > c.c.length + 7) { d = d.slice(c.c.length); }
		var rule = PHONE_RULES[country], g = d.replace(/^0+/, '');
		var ok = rule ? rule.test(d) : (/^\d{5,12}$/.test(g) && (c.c + g).length <= 15);
		if (!ok) { return { ok: false, msg: 'رقم الجوال غير صحيح أو ناقص — اكتبه بدون مسافات وبدون رمز الدولة' + (c.e ? ' بهذا الشكل: ' + c.e : '') + ' (' + cname(c) + ').' }; }
		return { ok: true, d: d };
	}

	/* ───────── account ───────── */
	function trialLabel(c) {
		if (!c) { return ''; }
		if (c.is_admin) { return (firstName(c) || 'أدمن') + ' — التحكم الكامل في المنظومة'; }
		if (c.is_member) { return 'عضو نادي المستثمرين' + (c.member_left != null ? ' — باقي ' + daysAr(c.member_left) : (c.name ? ' — ' + c.name : '')); }
		if (c.member_expired) { return 'انتهت عضويتك السنوية — جدّدها'; }
		if (c.has_account) { return c.verified ? 'عضويتك غير مفعّلة — فعّلها الآن' : 'حسابك بانتظار رمز التفعيل'; }
		return '';
	}
	function codeIntro(c) { return 'أدخل الرمز الذي وصلك على ' + ((c && c.email) || 'بريدك'); }
	function renderTopbar() {
		if (!ui.topbar) { return; }
		var c = state.contact, right = '', left = '';
		var av = c && c.avatar ? '<img class="vai-tb-av" alt="" src="' + esc(c.avatar) + '">' : '<span class="vai-tb-av vai-tb-av-ph">' + (c && c.name ? esc(c.name.trim().charAt(0)) : ICON.user) + '</span>';
		var cta = function (key) { var t = copy(key, ''); return t ? '<span class="vai-tb-cta">' + esc(t) + '</span>' : ''; };
		if (c && c.is_member) {
			right = '<button type="button" class="vai-tb-main">' + av + '<span><b>' + esc(c.name || 'حسابي') + '</b><small>' + esc('عضو نادي المستثمرين' + (c.member_left != null ? ' — باقي ' + daysAr(c.member_left) : '')) + '</small></span></button>';
			left = '<button type="button" class="vai-tb-btn vai-tb-acct">حسابي</button>';
		} else if (c && c.has_account && c.verified) {
			right = '<button type="button" class="vai-tb-main">' + av + '<span><b>' + esc(c.name || 'حسابي') + '</b><small>العضوية غير مفعّلة</small></span></button>';
			left = cta('topbar_unpaid') + (payUrl() ? '<button type="button" class="vai-tb-btn vai-tb-p vai-tb-sub">' + esc(payLabel()) + '</button>' : '') + '<button type="button" class="vai-tb-btn vai-tb-acct">حسابي</button>';
		} else if (c && c.has_account) {
			right = '<button type="button" class="vai-tb-main">' + av + '<span><b>' + esc(c.name || 'حسابك') + '</b><small>بانتظار رمز التفعيل من بريدك</small></span></button>';
			left = '<button type="button" class="vai-tb-btn vai-tb-p vai-tb-code">أدخل الرمز</button>';
		} else {
			right = '<button type="button" class="vai-tb-main">' + av + '<span><b>الحساب</b><small>زائر — لم تسجّل الدخول بعد</small></span></button>';
			left = cta('topbar_guest') + '<button type="button" class="vai-tb-btn vai-tb-p vai-tb-reg">' + esc(L('حساب جديد')) + '</button><button type="button" class="vai-tb-btn vai-tb-login">' + esc(L('دخول')) + '</button>';
		}
		ui.topbar.innerHTML = trText('<div class="vai-tb-in"><div class="vai-tb-right">' + right + '</div><div class="vai-tb-left">' + left + '</div></div>');
		var q = function (sel, fn) { var e = ui.topbar.querySelector(sel); if (e) { e.addEventListener('click', function () { openPanel(); fn(); }); } };
		q('.vai-tb-main', function () { if (c && (c.has_account || c.is_member)) { if (c.has_account && !c.verified && !c.is_member) { showAccountForm('code', codeIntro(c)); } else { showAccount(); } } else { showAccountForm('login'); } });
		q('.vai-tb-acct', function () { showAccount(); });
		q('.vai-tb-reg', function () { showAccountForm('register', CFG.account_gate_text || ''); });
		q('.vai-tb-login', function () { showAccountForm('login'); });
		q('.vai-tb-code', function () { showAccountForm('code', codeIntro(c)); });
		var sub = ui.topbar.querySelector('.vai-tb-sub'); if (sub) { sub.addEventListener('click', function () { window.open(payUrl(), '_blank', 'noopener'); }); }
	}
	function renderPill() {
		renderTopbar();
		if (!ui.pill) { return; }
		var c = state.contact;
		var av = c && c.avatar ? '<img class="vai-pill-av" alt="" src="' + esc(c.avatar) + '">' : '<span class="vai-pill-av vai-pill-av-ph">' + (c && c.name ? esc(c.name.trim().charAt(0)) : ICON.user) + '</span>';
		var txt, sub = '';
		if (c && c.is_admin) { txt = firstName(c) || 'أدمن'; sub = 'التحكم الكامل — لوحة الإدارة'; }
		else if (c && c.is_member) { txt = firstName(c) || 'عضو النادي'; sub = c.member_left != null ? 'عضو — باقي ' + daysAr(c.member_left) : 'عضو نادي المستثمرين'; }
		else if (c && c.has_account && c.verified) { txt = firstName(c) || 'حسابي'; sub = 'العضوية غير مفعّلة'; }
		else if (c && c.has_account) { txt = 'فعّل حسابك'; sub = 'أدخل رمز البريد'; }
		else { txt = L('حساب جديد'); sub = L('أو سجّل الدخول'); }
		ui.pill.innerHTML = trText(av + '<span class="vai-pill-t"><b>' + esc(txt) + '</b><small>' + esc(sub) + '</small></span>');
		ui.pill.setAttribute('aria-label', trText('حسابي — ' + txt + '، ' + sub));
	}
	function renderAcct() {
		renderPill();
		if (ui.svcBtn) { ui.svcBtn.hidden = !(state.contact && state.contact.is_member); }
		var wab = ui.panel && ui.panel.querySelector('.vai-wa-admin');
		if (wab) { var showWa = !CFG.wa_members_only || (state.contact && (state.contact.is_member || state.contact.is_admin)); wab.hidden = !showWa; wab.classList.toggle('vai-wa-glow', !!showWa); }
		if (!ui.acct) { return; }
		var c = state.contact;
		ui.acct.classList.toggle('vai-acct-admin', !!(c && c.is_admin));
		if (c && c.has_account && !c.verified && !c.is_member) {
			ui.acct.innerHTML = trText('<span class="vai-acct-l">حسابك بانتظار رمز التفعيل</span><span class="vai-acct-r"><button type="button" class="vai-acct-btn vai-acct-p vai-acct-code">أدخل الرمز</button></span>');
			ui.acct.querySelector('.vai-acct-code').addEventListener('click', function () { showAccountForm('code', codeIntro(c)); });
		} else if (c && c.is_admin) {
			ui.acct.innerHTML = trText('<span class="vai-acct-l">' + esc(trialLabel(c)) + '</span><span class="vai-acct-r"><a class="vai-acct-btn vai-acct-p" target="_blank" rel="noopener" href="' + esc(CFG.console_url || '#') + '">التحكم الكامل</a><button type="button" class="vai-acct-btn vai-acct-me">حسابي</button></span>');
			ui.acct.querySelector('.vai-acct-me').addEventListener('click', showAccount);
		} else if (c && (c.has_account || c.is_member)) {
			ui.acct.innerHTML = trText('<span class="vai-acct-l">' + esc(trialLabel(c)) + '</span><span class="vai-acct-r">' + (!c.is_member && payUrl() ? '<a class="vai-acct-btn vai-acct-p" target="_blank" rel="noopener" href="' + esc(payUrl()) + '">فعّل عضويتك</a>' : '') + '<button type="button" class="vai-acct-btn vai-acct-me">حسابي</button></span>');
			ui.acct.querySelector('.vai-acct-me').addEventListener('click', showAccount);
		} else {
			/* the title and the price come from the hub's membership card; without it the strip only offers an account */
			var ms = CFG.membership, lbl = state.lang === 'en' ? 'Annual Club Membership' + (ms && ms.price ? ' — ' + String(ms.price).replace('ريال', '').trim() + ' SAR' : '') : (ms && ms.title ? ms.title + (ms.price ? ' — ' + ms.price : '') : L('حساب جديد'));
			ui.acct.innerHTML = trText('<button type="button" class="vai-acct-btn vai-acct-p vai-acct-reg">' + esc(copy('strip_cta', lbl)) + '</button><button type="button" class="vai-acct-btn vai-acct-login">' + esc(L('دخول')) + '</button>');
			ui.acct.querySelector('.vai-acct-reg').addEventListener('click', function () { showAccountForm('register'); });
			ui.acct.querySelector('.vai-acct-login').addEventListener('click', function () { showAccountForm('login'); });
		}
	}
	function waPrefill(number, title) {
		var c = state.contact || {};
		var txt = 'السلام عليكم، أنا ' + (c.name || '') + ' — عضو في نادي المستثمرين.\nجوالي: ' + (c.phone || '') + (c.email ? '\nبريدي: ' + c.email : '') + (title ? '\nأرغب في الاستفادة من: ' + title : '');
		return 'https://wa.me/' + number + '?text=' + encodeURIComponent(txt);
	}
	function showServices() {
		var c = state.contact;
		if (!c || !c.is_member) { openPanel(); closeSheet(); showGate({ type: 'membership', text: CFG.member_gate_text, card: CFG.membership, mgmt: CFG.mgmt_whatsapp, needs_account: !(c && c.has_account) }); return; }
		var d = el('div', 'vai-svc'), sub = copy('services_sub', ''), list = CFG.member_services || [];
		var html = (sub ? '<div class="vai-meta-s">' + esc(sub) + '</div>' : '') + '<div class="vai-svc-list">';
		list.forEach(function (sv) {
			var href = String(sv.url || '').indexOf('wa:') === 0 ? waPrefill(sv.url.slice(3), sv.title) : sv.url;
			html += '<a class="vai-svc-item" href="' + esc(href) + '" target="_blank" rel="noopener"><span class="vai-svc-t">' + esc(sv.title) + '</span><span class="vai-svc-d">' + esc(sv.desc) + '</span><span class="vai-svc-b">' + esc(sv.btn || 'افتح') + ' ↗</span></a>';
		});
		html += '</div>' + (list.length ? '' : '<div class="vai-empty">لا توجد خدمات مضافة بعد.</div>');
		d.innerHTML = trText(html);
		openPanel();
		openSheet({ title: 'خدمات الأعضاء' + (firstName(c) ? ' — ' + firstName(c) : ''), node: d, focus: false });
	}
	function showAccount() {
		var c = state.contact || {};
		var d = el('div', 'vai-me-card');
		d.innerHTML = trText('<div class="vai-me-head">' + (c.avatar ? '<img class="vai-avatar" alt="" src="' + esc(c.avatar) + '">' : '<div class="vai-avatar vai-avatar-ph">' + esc((c.name || '?').trim().charAt(0)) + '</div>') + '<div><div class="vai-card-t">' + esc(c.name || 'حسابي') + '</div>' + (c.company || c.city ? '<div class="vai-meta-s">' + esc([c.company, c.city].filter(Boolean).join(' · ')) + '</div>' : '') + '</div></div>' +
			'<div class="vai-status' + (c.is_member || c.is_admin ? ' vai-status-ok' : '') + '">' + esc(trialLabel(c)) + (c.is_member && c.member_end ? ' <small>(حتى ' + esc(c.member_end) + ')</small>' : '') + '</div>' +
			'<div class="vai-acct-info">' + (c.phone ? '<div dir="ltr">' + esc(c.phone) + '</div>' : '') + (c.email ? '<div dir="ltr">' + esc(c.email) + '</div>' : '') + (c.bio ? '<div dir="auto">' + esc(c.bio) + '</div>' : '') + (c.is_member && c.daily_left != null && c.daily_left <= (CFG.counter_show_at || 100) ? '<div>باقي لك اليوم <b>' + esc(c.daily_left) + '</b> رسالة مع ' + esc(botName()) + ' — يتجدد غدًا</div>' : '') + '</div>' +
			'<div class="vai-card-btns"></div><div class="vai-form-note">حسابك واحد على كل مواقع المنظومة — نفس البريد وكلمة المرور.</div>');
		var row = d.querySelector('.vai-card-btns');
		var add = function (label, cls, fn) { var b = el('button', 'vai-btn' + (cls ? ' ' + cls : ''), esc(label)); b.type = 'button'; b.addEventListener('click', fn); row.appendChild(b); return b; };
		if (c.is_member) { add('خدمات الأعضاء', 'vai-btn-p', showServices); }
		/* 2.15.5 (owner): an unactivated account sees a LOUD enter-the-code button right inside «حسابي» */
		if (c.has_account && !c.verified && !c.is_member) { add('أدخل رمز التفعيل', 'vai-btn-p', function () { showAccountForm('code', codeIntro(c)); }); }
		if (c.is_admin && CFG.console_url) { row.appendChild(btnEl('لوحة الإدارة — كل المحادثات', CFG.console_url, true)); }
		else if (!c.is_member && c.verified && payUrl()) { row.appendChild(btnEl('فعّل عضويتك السنوية', payUrl(), true)); }
		add('تعديل بياناتي', '', function () { showProfileForm(); });
		var pic = add('تغيير صورتي', '', function () { showProfileForm(); var fi = ui.sheetBody.querySelector('.vai-avatar-file'); if (fi) { fi.click(); } });
		var avEl = d.querySelector('.vai-me-head .vai-avatar'); if (avEl) { avEl.style.cursor = 'pointer'; avEl.title = trText('تغيير الصورة'); avEl.addEventListener('click', function () { pic.click(); }); }
		var out = add('تسجيل الخروج', 'vai-btn-quiet', function () {
			busy(out, true, 'جارٍ الخروج…');
			/* the visitor id is renewed locally, so the sign-out holds even when the hub could not be reached */
			api('logout', {}).catch(function () {}).then(function () {
				state = { uuid: uuid(), contact: null, msgs: [], open: true, fs: state.fs, lastId: 0, pending: null, prefill: null, seen: true, fresh: true, awaiting: 0 };
				awaitingSince = 0; softWait = false; pendingRef = null; lastSent = null; lateRef = null; focusCtx = null; focusEl = null;
				save(); closeSheet(); sendLock(false); renderFocus();
				hideTyping(); ui.body.innerHTML = ''; ui.quick.innerHTML = ''; ui.gate = null; welcome(); renderAcct(); sysLine('تم تسجيل الخروج.');
			});
		});
		openPanel();
		openSheet({ title: 'حسابي', node: d, focus: false });
	}
	function showProfileForm() {
		var c = state.contact || {};
		var d = el('div', 'vai-auth');
		d.innerHTML = '<form class="vai-form">' +
			'<div class="vai-avatar-row">' + (c.avatar ? '<img class="vai-avatar" alt="" src="' + esc(c.avatar) + '">' : '<div class="vai-avatar vai-avatar-ph">' + esc((c.name || '?').trim().charAt(0)) + '</div>') + '<button type="button" class="vai-btn vai-pick-avatar">' + (c.avatar ? 'تغيير الصورة' : 'رفع صورتي') + '</button><input type="file" accept="image/*" hidden class="vai-avatar-file" tabindex="-1" aria-hidden="true"></div>' +
			field({ name: 'name', label: 'الاسم', value: c.name, autocomplete: 'name' }) + phoneField(c.phone) +
			field({ name: 'email', label: 'البريد الإلكتروني', type: 'email', dir: 'ltr', value: c.email, autocomplete: 'email', inputmode: 'email' }) +
			field({ name: 'company', label: 'الشركة أو المشروع', optional: true, value: c.company, autocomplete: 'organization' }) +
			field({ name: 'city', label: 'المدينة', optional: true, value: c.city, autocomplete: 'address-level2' }) +
			field({ name: 'job_title', label: 'الوظيفة أو المنصب', optional: true, value: c.job_title, autocomplete: 'organization-title' }) +
			field({ name: 'website', label: 'موقع شركتك', optional: true, dir: 'ltr', value: c.website, autocomplete: 'url', inputmode: 'url' }) +
			field({ name: 'social', label: 'روابط السوشيال ميديا', optional: true, type: 'textarea', rows: 2, dir: 'ltr', value: c.social, help: 'سطر لكل رابط.' }) +
			field({ name: 'bio', label: 'نبذة قصيرة عنك أو عن مشروعك', optional: true, type: 'textarea', rows: 2, value: c.bio }) +
			field({ name: 'password', label: 'كلمة مرور جديدة', optional: true, type: 'password', dir: 'ltr', autocomplete: 'new-password', help: 'اتركها فارغة إن لم ترد التغيير — 6 أحرف على الأقل.' }) +
			'<div class="vai-form-err" role="alert" hidden></div><button type="submit" class="vai-btn vai-btn-p vai-btn-block">' + trText('حفظ') + '</button></form>';
		var f = d.querySelector('form'), avatarData = null, sb = f.querySelector('[type=submit]');
		wireForm(f);
		var fileIn = d.querySelector('.vai-avatar-file');
		d.querySelector('.vai-avatar').style.cursor = 'pointer'; d.querySelector('.vai-avatar').addEventListener('click', function () { fileIn.click(); });
		d.querySelector('.vai-pick-avatar').addEventListener('click', function () { fileIn.click(); });
		fileIn.addEventListener('change', function () {
			var file = fileIn.files && fileIn.files[0]; if (!file) { return; }
			var reader = new FileReader();
			reader.onload = function () { var img = new Image(); img.onload = function () { var size = 320, cv = document.createElement('canvas'); cv.width = size; cv.height = size; var ctx = cv.getContext('2d'); var m = Math.min(img.width, img.height); ctx.drawImage(img, (img.width - m) / 2, (img.height - m) / 2, m, m, 0, 0, size, size); avatarData = cv.toDataURL('image/jpeg', 0.85); var im = d.querySelector('.vai-avatar'); var ni = document.createElement('img'); ni.className = 'vai-avatar'; ni.alt = ''; ni.src = avatarData; im.replaceWith(ni); }; img.onerror = function () { formErr(f, 'تعذّر قراءة الصورة — جرّب صورة أخرى.'); }; img.src = reader.result; };
			reader.readAsDataURL(file);
		});
		f.addEventListener('submit', function (e) {
			e.preventDefault();
			if (isBusy(sb)) { return; }
			var pc = phoneCheck(val(f, 'country') || 'sa', val(f, 'phone'));
			if (!pc.ok) { showErrs(f, [['phone', pc.msg]]); return; }
			var data = { name: val(f, 'name'), country: val(f, 'country') || 'sa', phone: latinDigits(val(f, 'phone')), email: val(f, 'email'), company: val(f, 'company'), city: val(f, 'city'), bio: val(f, 'bio'), job_title: val(f, 'job_title'), website: val(f, 'website'), social: val(f, 'social') };
			if (val(f, 'password')) { data.password = val(f, 'password'); }
			if (avatarData) { data.avatar = avatarData; }
			busy(sb, true, 'جارٍ الحفظ…');
			api('profile', data).then(function (r) {
				if (!r || r.ok === false) {
					busy(sb, false);
					var m = (r && r.text) || 'تعذّر الحفظ — حاول مرة ثانية.', code = r && r.error;
					var to = code === 'phone' ? 'phone' : (code === 'email_domain' ? 'email' : (code === 'exists' ? (/جوال/.test(m) ? 'phone' : 'email') : (/كلمة المرور/.test(m) ? 'password' : '')));
					if (!to || !showErrs(f, [[to, m]])) { formErr(f, m); }
					return;
				}
				state.contact = r.contact || state.contact; save(); renderAcct(); closeSheet(); sysLine('تم تحديث ملفك ✅');
			}).catch(function () { busy(sb, false); formErr(f, ERR_NET); });
		});
		openPanel();
		openSheet({ title: 'ملفي الشخصي', node: d, back: function () { showAccount(); }, focus: false });
	}
	/* greet = the hub may send a welcome line after sign-in: wait for it softly (no error when nothing comes) */
	/* 2.12.0 (owner): a Google-born account chats or pays only AFTER completing جواله وفئته ونبذته. */
	function profileIncomplete() {
		var c = state.contact;
		return !!(c && c.has_account && (!(c.phone || '').trim() || ['neutral', 'entrepreneur', 'investor'].indexOf(c.persona || '') === -1));
	}
	function showCompleteForm() {
		var d = el('div', 'vai-auth');
		var need_phone = !(state.contact && (state.contact.phone || '').trim());
		var need_pers = !(state.contact && ['neutral', 'entrepreneur', 'investor'].indexOf(state.contact.persona || '') !== -1);
		var body = '<div class="vai-auth-intro">' + esc('' + trText('خطوة واحدة لإكمال حسابك — بياناتك تصلنا كاملة وتوصلك خدماتنا باسمك 🌹') + '') + '</div>' +
			'<form class="vai-form vai-complete">' +
			(need_phone ? phoneField('') : '') +
			(need_pers ? '<div class="vai-field" data-f="persona"><div class="vai-label" id="vai-pc-l">' + esc(L('فئتك في النادي')) + '</div><div class="vai-choices" role="radiogroup" aria-labelledby="vai-pc-l">' +
				PERSONAS.map(function (p) { return '<label class="vai-choice"><input type="radio" name="persona" value="' + p[0] + '" required><span class="vai-choice-t">' + p[1] + '</span><span class="vai-choice-d">' + p[2] + '</span></label>'; }).join('') + '</div></div>' : '') +
			field({ name: 'job_title', label: L('الوظيفة أو المنصب'), optional: true, value: state.contact ? state.contact.job_title : '' }) +
			field({ name: 'bio', label: L('نبذة مختصرة عنك'), type: 'textarea', rows: 2, required: true, value: state.contact ? state.contact.bio : '', help: state.lang === 'en' ? 'One line is enough — who you are and what you seek.' : 'سطر واحد يكفي — من أنت وماذا تبحث عنه.' }) +
			'<div class="vai-form-err" role="alert" hidden></div>' +
			'<button type="submit" class="vai-btn vai-btn-p vai-btn-block">' + esc(L('حفظ ومتابعة')) + '</button></form>';
		d.innerHTML = body;
		var f = d.querySelector('form');
		wireForm(f);
		f.addEventListener('submit', function (ev) {
			ev.preventDefault();
			var eb = f.querySelector('.vai-form-err');
			var data = { uuid: state.uuid, job_title: val(f, 'job_title'), bio: val(f, 'bio') };
			if (need_phone) { data.country = val(f, 'country') || 'sa'; data.phone = latinDigits(val(f, 'phone')); }
			if (need_pers) { data.persona = val(f, 'persona'); if (!data.persona) { eb.textContent = trText('اختر فئتك في النادي'); eb.hidden = false; return; } }
			if ((data.bio || '').trim().length < 10) { eb.textContent = trText('اكتب نبذة مختصرة حقيقية (سطر على الأقل)'); eb.hidden = false; return; }
			eb.hidden = true;
			api('profile', data).then(function (r) {
				if (!r || r.ok === false) { eb.textContent = trText((r && r.text) || 'تعذّر الحفظ — حاول ثانية'); eb.hidden = false; return; }
				state.contact = r.contact || state.contact; save(); closeSheet(); renderAcct();
				sysLine('اكتمل حسابك ✅ أهلًا بك — كيف أقدر أخدمك؟');
			}).catch(function () { eb.textContent = trText(ERR_NET); eb.hidden = false; });
		});
		openSheet({ title: L('أكمل حسابك'), node: d });
	}

	function afterAuth(r, resend, greet) {
		state.contact = r.contact || state.contact;
		if (r.messages && r.messages.length) {
			var ids = state.msgs.map(function (x) { return x.id; });
			r.messages.forEach(function (m) { if (m.role !== 'system' && (!m.id || ids.indexOf(m.id) === -1)) { state.msgs.push(m); } if (m.id > state.lastId) { state.lastId = m.id; } });
			state.msgs.sort(function (a, b) { return (a.id || 1e12) - (b.id || 1e12); });
		}
		state.fresh = false; save();
		closeSheet();
		renderAll(); renderAcct();
		if (profileIncomplete()) { setTimeout(showCompleteForm, 350); }
		var cc = state.contact;
		if (cc && cc.has_account && cc.verified && !cc.is_member && CFG.unpaid_note) { sysLine(CFG.unpaid_note); if (CFG.membership) { var dm0 = el('div', 'vai-msg vai-bot'); dm0.appendChild(cardEl(CFG.membership)); ui.body.appendChild(dm0); scrollBottom(); } }
		if (resend && (state.pending || pendingRef)) { setTimeout(resendPending, 400); }
		else { state.pending = null; save(); if (greet) { setAwaiting(true, true); } else { schedulePoll(true); } }
	}
	function showSetPass(token) {
		var d = el('div', 'vai-auth', '<div class="vai-auth-intro vai-setpass-note">جارٍ التحقق من الرابط…</div>');
		openPanel();
		openSheet({ title: 'أنشئ كلمة مرورك', node: d, focus: false });
		var note = d.querySelector('.vai-setpass-note');
		var dead = function (msg) {
			note.textContent = msg;
			var lg = el('button', 'vai-btn vai-btn-block', 'نسيت كلمة المرور'); lg.type = 'button';
			lg.addEventListener('click', function () { showAccountForm('reset'); });
			d.appendChild(lg);
		};
		api('setpass_check', { token: token }).then(function (r) {
			if (!r || r.ok === false) { dead((r && r.text) || 'الرابط غير صالح — استخدم «نسيت كلمة المرور».'); return; }
			d.innerHTML = trText('<div class="vai-auth-intro"><b>أهلًا ' + esc(r.name || '') + '</b><br>حسابك جاهز ومفعّل ' + esc(r.email ? '(' + r.email + ')' : '') + '. اختر كلمة مرور لتدخل بها على كل مواقع المنظومة.</div><form class="vai-form">' +
				field({ name: 'password', label: 'كلمة المرور', type: 'password', dir: 'ltr', autocomplete: 'new-password', required: true, help: '6 أحرف على الأقل.' }) +
				'<div class="vai-form-err" role="alert" hidden></div><button type="submit" class="vai-btn vai-btn-p vai-btn-block">حفظ والدخول</button></form>');
			var f = d.querySelector('form'), sb = f.querySelector('[type=submit]');
			wireForm(f);
			if (!MOBILE) { focusSoft(f.querySelector('input')); }
			f.addEventListener('submit', function (e) {
				e.preventDefault();
				if (isBusy(sb)) { return; }
				var pw = f.querySelector('[name=password]').value;
				if (pw.length < 6) { showErrs(f, [['password', 'كلمة المرور 6 أحرف فأكثر.']]); return; }
				busy(sb, true, 'جارٍ الحفظ…');
				api('setpass', { token: token, password: pw }).then(function (r2) {
					if (!r2 || r2.ok === false) { busy(sb, false); formErr(f, (r2 && r2.text) || 'تعذّر الحفظ — حاول مرة ثانية.'); return; }
					afterAuth(r2, false); sysLine('تم حفظ كلمة مرورك ودخولك ✅');
					if (state.contact && state.contact.is_member) { showServices(); }
				}).catch(function () { busy(sb, false); formErr(f, ERR_NET); });
			});
		}).catch(function () { dead('تعذّر الاتصال — حاول مرة ثانية.'); });
	}

	/* ───────── sign-in, two-step sign-up, activation code, password reset ─────────
	   The hub's rules and the op payloads are untouched: register {name, country, phone, email, job_title, persona, bio, password}, login {login, password},
	   verify {code}, resend_code {}, reset_request {login}, reset_confirm {login, code, password}. */
	var regDraft = {}; /* what the visitor typed so far (never the password), kept while switching between the two tabs */
	/* 2.7.1 — the owner's order and wording, the same three lines as the app's portals: neutral, entrepreneur, investor */
	var PERSONAS_AR = [['neutral', 'محايد', 'أستكشف توجهي'], ['entrepreneur', 'رائد أعمال', 'لدي مشروع'], ['investor', 'مستثمر', 'أبحث عن فرص']];
	var PERSONAS_EN = [['neutral', 'Neutral', 'exploring my direction'], ['entrepreneur', 'Entrepreneur', 'I have a project'], ['investor', 'Investor', 'seeking opportunities']];
	var PERSONAS = state.lang === 'en' ? PERSONAS_EN : PERSONAS_AR;
	/* 2.18.0 (M69): «فرد / شركة» right under the name — a company registration carries the company name */
	var MTYPES = state.lang === 'en' ? [['individual', 'Individual'], ['company', 'Company']] : [['individual', 'فرد'], ['company', 'شركة']];
	/* 2.20.0 (owner): the app's unified registration interests (M107 list) — mandatory on the site too (1 to 3).
	   The hub RECEIVES the Arabic labels (joined by «، ») so the admin mail and the dashboard stay Arabic. */
	var INTERESTS = [
		['ريادة الأعمال والشركات الناشئة', 'Entrepreneurship & Startups'],
		['التقنية والذكاء الاصطناعي', 'Technology & AI'],
		['الاستثمار والتمويل والأسواق المالية', 'Investment, Finance & Markets'],
		['العقار والإنشاءات', 'Real Estate & Construction'],
		['التجارة والتجزئة والتجارة الإلكترونية', 'Trade, Retail & E-commerce'],
		['الصناعة واللوجستيات', 'Industry & Logistics'],
		['السياحة والترفيه والرياضة', 'Tourism, Entertainment & Sports'],
		['الصحة والتعليم', 'Health & Education'],
		['الطاقة والتعدين', 'Energy & Mining'],
		['أخرى', 'Other']
	];
	function pickedInterests(f) { return [].slice.call(f.querySelectorAll('input[name=interest]:checked')).map(function (i) { return i.value; }); }
	function authTabs(mode) {
		var tab = function (m, label) { return '<button type="button" data-m="' + m + '" aria-pressed="' + (mode === m ? 'true' : 'false') + '"' + (mode === m ? ' class="vai-on"' : '') + '>' + label + '</button>'; };
		return '<div class="vai-tabs" role="group" aria-label="الحساب">' + tab('register', L('حساب جديد')) + tab('login', L('تسجيل الدخول')) + '</div>';
	}
	function cooldown(btn, secs) {
		var label = btn.vaiText || btn.textContent, left = secs;
		btn.vaiText = label; btn.disabled = true;
		clearInterval(btn.vaiTimer);
		var tick = function () {
			if (!document.body.contains(btn) || left <= 0) { clearInterval(btn.vaiTimer); btn.disabled = false; btn.textContent = trText(label); return; }
			btn.textContent = trText(label) + ' (' + Math.floor(left / 60) + ':' + ('0' + (left % 60)).slice(-2) + ')';
			left--;
		};
		btn.vaiTimer = setInterval(tick, 1000); tick();
	}
	function regRoute(r) {
		var code = r && r.error, t = (r && r.text) || '';
		if (code === 'phone' || code === 'saudi') { return { s: 1, f: 'phone' }; }
		if (code === 'company_name') { return { s: 1, f: 'company_name' }; }
		if (code === 'email_domain') { return { s: 1, f: 'email' }; }
		if (code === 'exists') { return { s: 1, f: '', exists: true }; }
		if (/بريد|email/i.test(t)) { return { s: 1, f: 'email' }; }
		if (/جوال|phone/i.test(t)) { return { s: 1, f: 'phone' }; }
		if (/الاسم/.test(t)) { return { s: 1, f: 'name' }; }
		if (/فئت|صفت/.test(t)) { return { s: 2, f: 'persona' }; }
		if (/نبذة/.test(t)) { return { s: 2, f: 'bio' }; }
		if (/كلمة المرور/.test(t)) { return { s: 2, f: 'password' }; }
		return { s: 2, f: '' };
	}
	function showRegister(d) {
		var f1 = d.querySelector('.vai-reg1'), f2 = d.querySelector('.vai-reg2'), sb = f2.querySelector('[type=submit]');
		var bar = d.querySelector('.vai-prog-bar span'), pn = d.querySelector('.vai-prog-n'), pt = d.querySelector('.vai-prog-t'), prog = d.querySelector('.vai-prog');
		wireForm(f1); wireForm(f2);
		var step = function (n, focus) {
			f1.hidden = n !== 1; f2.hidden = n !== 2;
			bar.style.width = n === 1 ? '50%' : '100%';
			pn.textContent = trText('الخطوة ') + n + trText(' من 2'); pt.textContent = trText(n === 1 ? 'بياناتك' : 'فئتك ونبذتك');
			prog.setAttribute('aria-valuenow', n);
			ui.sheetBackFn = n === 2 ? function () { step(1, true); } : null; ui.sheetBack.hidden = n !== 2;
			ui.sheetBody.scrollTop = 0;
			say('الخطوة ' + n + ' من 2');
			if (focus) { focusSoft(n === 1 ? f1.querySelector('input') : (f2.querySelector('input[type=radio]:checked') || f2.querySelector('input[type=radio]'))); }
		};
		var keep = function () { ['name', 'member_type', 'company_name', 'email', 'country', 'phone'].forEach(function (k) { regDraft[k] = val(f1, k); }); ['persona', 'bio', 'job_title'].forEach(function (k) { regDraft[k] = val(f2, k); }); regDraft.interests = pickedInterests(f2); };
		d.addEventListener('input', keep); d.addEventListener('change', keep);
		if (regDraft.country && f1.querySelector('select[name=country]')) { f1.querySelector('select[name=country]').value = regDraft.country; bindPhoneRefresh(f1); }
		/* «شركة» reveals the required company-name field; «فرد» (the default) hides it */
		var coField = f1.querySelector('.vai-field[data-f="company_name"]');
		var coSync = function () { coField.hidden = val(f1, 'member_type') !== 'company'; };
		f1.addEventListener('change', function (e) { if (e.target && e.target.name === 'member_type') { coSync(); } });
		coSync();
		/* 2.20.0: interests — a fourth tick bounces back; the box highlights like the radio choices */
		f2.addEventListener('change', function (e) {
			if (!e.target || e.target.name !== 'interest') { return; }
			if (e.target.checked && pickedInterests(f2).length > 3) { e.target.checked = false; }
			f2.querySelectorAll('input[name=interest]').forEach(function (i) { var c = i.closest('.vai-choice'); if (c) { c.classList.toggle('vai-on', i.checked); } });
		});
		var count = f2.querySelector('.vai-count'), bio = f2.querySelector('[name=bio]');
		var cnt = function () { var n = bio.value.trim().length; count.textContent = n >= 10 ? trText('ممتاز') : n + trText(' من 10 أحرف على الأقل'); count.classList.toggle('vai-count-ok', n >= 10); };
		bio.addEventListener('input', cnt); cnt();
		f1.addEventListener('submit', function (e) {
			e.preventDefault();
			var errs = [];
			if (!val(f1, 'name')) { errs.push(['name', 'اكتب اسمك الكريم.']); }
			if (val(f1, 'member_type') === 'company' && val(f1, 'company_name').length < 2) { errs.push(['company_name', 'اكتب اسم الشركة لإكمال التسجيل.']); }
			if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(val(f1, 'email'))) { errs.push(['email', 'البريد الإلكتروني غير صحيح — سيصلك كود التفعيل عليه، فتأكد من كتابته صحيحًا.']); }
			var pv = phoneCheck(val(f1, 'country') || 'sa', val(f1, 'phone')); if (!pv.ok) { errs.push(['phone', pv.msg]); }
			if (showErrs(f1, errs)) { return; }
			step(2, true);
		});
		f2.querySelector('.vai-back').addEventListener('click', function () { step(1, true); });
		f2.addEventListener('submit', function (e) {
			e.preventDefault();
			if (isBusy(sb)) { return; }
			var errs = [];
			var ints = pickedInterests(f2);
			if (!val(f2, 'persona')) { errs.push(['persona', 'اختر فئتك في النادي: محايد، رائد أعمال، أو مستثمر.']); }
			if (!ints.length) { errs.push(['interests', 'اختر اهتمامًا واحدًا على الأقل (حتى 3).']); }
			if (val(f2, 'bio').length < 10) { errs.push(['bio', 'اكتب نبذة مختصرة عنك (سطر على الأقل).']); }
			if (val(f2, 'password').length < 6) { errs.push(['password', 'كلمة المرور 6 أحرف فأكثر.']); }
			if (showErrs(f2, errs)) { return; }
			busy(sb, true, 'جارٍ إنشاء الحساب…');
			api('register', { name: val(f1, 'name'), member_type: val(f1, 'member_type') || 'individual', company_name: val(f1, 'member_type') === 'company' ? val(f1, 'company_name') : '', country: val(f1, 'country') || 'sa', phone: latinDigits(val(f1, 'phone')), email: val(f1, 'email'), job_title: val(f2, 'job_title'), persona: val(f2, 'persona'), bio: val(f2, 'bio'), interests: ints.join('، '), lang: state.lang === 'en' ? 'en' : '', password: val(f2, 'password') }).then(function (r) {
				if (!r || r.ok === false) {
					busy(sb, false);
					var m = (r && r.text) || 'تعذّر إنشاء الحساب — حاول مرة ثانية.', to = regRoute(r), form = to.s === 1 ? f1 : f2;
					if (to.s === 1) { step(1, false); }
					if (to.exists) { formErr(f1, m, [{ label: 'تسجيل الدخول', fn: function () { showAccountForm('login'); } }, { label: 'نسيت كلمة المرور', fn: function () { showAccountForm('reset'); } }]); return; }
					if (!to.f || !showErrs(form, [[to.f, m]])) { formErr(form, m); }
					return;
				}
				regDraft = {};
				if (r.pending) { state.contact = r.contact || state.contact; save(); renderAcct(); showAccountForm('code', r.text || ''); return; }
				afterAuth(r, true, true);
			}).catch(function () { busy(sb, false); formErr(f2, ERR_NET); });
		});
		step(1, false);
	}
	function bindPhoneRefresh(f) { var sel = f.querySelector('select[name=country]'); if (sel) { try { sel.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) {} } }
	/* ───────── «المتابعة بحساب Google» (2.9.0): GIS button → ID token → the hub verifies it itself ───────── */
	function loadGsi() {
		if (loadGsi.p) { return loadGsi.p; }
		loadGsi.p = new Promise(function (res, rej) {
			if (window.google && window.google.accounts && window.google.accounts.id) { res(); return; }
			var s = document.createElement('script');
			s.src = 'https://accounts.google.com/gsi/client'; s.async = true; s.defer = true;
			s.onload = function () { res(); };
			s.onerror = function () { loadGsi.p = null; rej(new Error('gsi')); };
			document.head.appendChild(s);
		});
		return loadGsi.p;
	}
	function gNote(text) {
		var box = ui.sheetBody ? ui.sheetBody.querySelector('.vai-auth .vai-gnote') : null;
		if (box) { box.textContent = trText(text || ''); box.hidden = !text; }
	}
	function onGoogleCredential(resp) {
		var cred = resp && resp.credential;
		if (!cred) { gNote('تعذّر إتمام الدخول بحساب Google — حاول مرة ثانية.'); return; }
		gNote('جارٍ التحقق من حسابك…');
		api('google', { credential: cred, lang: state.lang === 'en' ? 'en' : '' }).then(function (r) {
			if (!r || r.ok === false) { gNote((r && r.text) || 'تعذّر الدخول بحساب Google — ادخل بالبريد وكلمة المرور.'); return; }
			gNote('');
			regDraft = {};
			afterAuth(r, true, true);
			sysLine(r.created ? 'تم إنشاء حسابك بحساب Google ✅' : 'تم تسجيل الدخول بحساب Google ✅');
		}).catch(function () { gNote(ERR_NET); });
	}
	function mountGoogle(d) {
		var slot = d.querySelector('.vai-gslot');
		if (!slot || !CFG.google_client_id) { return; }
		loadGsi().then(function () {
			var g = window.google && window.google.accounts && window.google.accounts.id;
			if (!g || !document.body.contains(slot)) { return; }
			if (!mountGoogle.init) {
				g.initialize({ client_id: CFG.google_client_id, callback: onGoogleCredential, ux_mode: 'popup' });
				mountGoogle.init = true;
			}
			g.renderButton(slot, { type: 'standard', theme: 'outline', size: 'large', text: 'continue_with', shape: 'pill', logo_alignment: 'center', locale: state.lang === 'en' ? 'en' : 'ar', width: Math.max(200, Math.min(320, slot.clientWidth || 300)) });
		}).catch(function () { gNote('تعذّر تحميل زر Google — استخدم البريد وكلمة المرور.'); });
	}
	function showAccountForm(mode, text) {
		var d = el('div', 'vai-auth'), body = '', title = L('تسجيل الدخول');
		var intro = text && mode !== 'reset2' && mode !== 'code' ? '<div class="vai-auth-intro">' + md(text) + '</div>' : '';
		var errBox = '<div class="vai-form-err" role="alert" hidden></div>';
		if (mode === 'register') {
			title = L('حساب جديد');
			body = '<div class="vai-prog" role="progressbar" aria-label="خطوات التسجيل" aria-valuemin="1" aria-valuemax="2" aria-valuenow="1"><div class="vai-prog-bar"><span></span></div><div class="vai-prog-l"><b class="vai-prog-n"></b><span class="vai-prog-t"></span></div></div>' +
				'<form class="vai-form vai-reg1">' +
				field({ name: 'name', label: L('الاسم الكريم'), autocomplete: 'name', required: true, value: regDraft.name }) +
				'<div class="vai-field" data-f="member_type"><div class="vai-label" id="vai-mtype-l">' + esc(L('نوع الحساب')) + '</div><div class="vai-choices" role="radiogroup" aria-labelledby="vai-mtype-l">' +
				MTYPES.map(function (p) { var on = (regDraft.member_type || 'individual') === p[0]; return '<label class="vai-choice' + (on ? ' vai-on' : '') + '"><input type="radio" name="member_type" value="' + p[0] + '"' + (on ? ' checked' : '') + '><span class="vai-choice-t">' + p[1] + '</span></label>'; }).join('') +
				'</div><div class="vai-field-err" role="alert"></div></div>' +
				field({ name: 'company_name', label: 'اسم الشركة', autocomplete: 'organization', required: true, value: regDraft.company_name, help: 'اسم الشركة أو المنشأة التي يُسجّل الحساب باسمها.' }) +
				field({ name: 'email', label: L('البريد الإلكتروني'), type: 'email', dir: 'ltr', autocomplete: 'email', inputmode: 'email', required: true, value: regDraft.email, help: state.lang === 'en' ? 'Your activation code arrives on this address — personal or company mail.' : 'يصلك رمز التفعيل على هذا البريد — بريدك الشخصي أو بريد شركتك.' }) +
				phoneField(regDraft.phone) +
				(CFG.phone_policy ? '<div class="vai-form-note">' + esc(CFG.phone_policy) + '</div>' : '') +
				errBox + '<button type="submit" class="vai-btn vai-btn-p vai-btn-block">' + esc(L('التالي')) + '</button></form>' +
				'<form class="vai-form vai-reg2" hidden>' +
				'<div class="vai-field" data-f="persona"><div class="vai-label" id="vai-persona-l">فئتك في النادي</div><div class="vai-choices" role="radiogroup" aria-labelledby="vai-persona-l">' +
				PERSONAS.map(function (p) { var on = regDraft.persona === p[0]; return '<label class="vai-choice' + (on ? ' vai-on' : '') + '"><input type="radio" name="persona" value="' + p[0] + '"' + (on ? ' checked' : '') + '><span class="vai-choice-t">' + p[1] + '</span><span class="vai-choice-d">' + p[2] + '</span></label>'; }).join('') +
				'</div><div class="vai-field-err" role="alert"></div></div>' +
				'<div class="vai-field" data-f="interests"><div class="vai-label" id="vai-int-l">' + esc(state.lang === 'en' ? 'Your interests (pick 1 to 3)' : 'اهتماماتك (اختر من 1 إلى 3)') + '</div><div class="vai-choices" role="group" aria-labelledby="vai-int-l">' +
				INTERESTS.map(function (p) { var on = (regDraft.interests || []).indexOf(p[0]) !== -1; return '<label class="vai-choice' + (on ? ' vai-on' : '') + '"><input type="checkbox" name="interest" value="' + esc(p[0]) + '"' + (on ? ' checked' : '') + '><span class="vai-choice-t">' + esc(state.lang === 'en' ? p[1] : p[0]) + '</span></label>'; }).join('') +
				'</div><div class="vai-field-err" role="alert"></div></div>' +
				field({ name: 'bio', label: 'نبذة مختصرة عنك', type: 'textarea', rows: 3, required: true, value: regDraft.bio, help: 'من أنت وماذا تبحث عنه — سطر واحد يكفي.' }) +
				'<div class="vai-count" aria-hidden="true"></div>' +
				field({ name: 'job_title', label: 'الوظيفة أو المنصب', optional: true, value: regDraft.job_title, autocomplete: 'organization-title' }) +
				field({ name: 'password', label: 'كلمة مرور لحسابك', type: 'password', dir: 'ltr', autocomplete: 'new-password', required: true, help: '6 أحرف على الأقل.' }) +
				errBox + '<button type="submit" class="vai-btn vai-btn-p vai-btn-block">إنشاء الحساب وإرسال الرمز</button><button type="button" class="vai-link vai-back">رجوع لتعديل بياناتي</button>' +
				'<div class="vai-form-note">حساب واحد تدخل به على كل مواقع المنظومة.</div></form>';
		} else if (mode === 'login') {
			body = '<form class="vai-form">' +
				field({ name: 'login', label: 'البريد الإلكتروني أو رقم الجوال', dir: 'ltr', autocomplete: 'username', required: true }) +
				field({ name: 'password', label: 'كلمة المرور', type: 'password', dir: 'ltr', autocomplete: 'current-password', required: true }) +
				errBox + '<button type="submit" class="vai-btn vai-btn-p vai-btn-block">' + esc(L('دخول')) + '</button><button type="button" class="vai-link vai-forgot">' + esc(state.lang === 'en' ? 'Forgot password?' : 'نسيت كلمة المرور؟') + '</button></form>';
		} else if (mode === 'code') {
			title = 'تفعيل الحساب';
			body = '<form class="vai-form"><div class="vai-auth-intro">' + esc(text || 'أرسلنا رمز التفعيل إلى بريدك') + ' — اكتبه في الخانة التالية 👇</div>' +
				field({ name: 'code', label: 'اكتب الرمز هنا (4 أرقام)', cls: 'vai-otp', dir: 'ltr', inputmode: 'numeric', autocomplete: 'one-time-code', maxlength: 4, required: true, placeholder: '· · · ·', help: 'وصلك على بريدك — يتفعّل حسابك تلقائيًا مع آخر رقم. أو افتح الرابط الذي في نفس الرسالة فيتفعّل حسابك بضغطة واحدة.' }) +
				errBox + '<button type="submit" class="vai-btn vai-btn-p vai-btn-block">تفعيل حسابي</button><button type="button" class="vai-link vai-resend">لم يصلك؟ إعادة إرسال الرمز</button><button type="button" class="vai-link vai-change">تسجيل ببريد آخر</button>' +
				'<div class="vai-form-note">تفقّد مجلد الرسائل غير المرغوبة إن لم تجد الرسالة.</div></form>';
		} else if (mode === 'reset') {
			title = 'استعادة كلمة المرور';
			body = '<form class="vai-form"><div class="vai-auth-intro">اكتب بريدك أو جوالك المسجّل، ونرسل لك رمزًا لتعيين كلمة مرور جديدة.</div>' +
				field({ name: 'login', label: 'البريد الإلكتروني أو الجوال المسجّل', dir: 'ltr', autocomplete: 'username', required: true }) +
				errBox + '<button type="submit" class="vai-btn vai-btn-p vai-btn-block">أرسل رمز الاستعادة</button></form>';
		} else if (mode === 'reset2') {
			title = 'كلمة مرور جديدة';
			body = '<form class="vai-form"><input name="login" type="hidden" value="' + esc(text || '') + '"><div class="vai-auth-intro">إن كان الحساب موجودًا فقد وصلك رمز على بريدك — صالح 20 دقيقة.</div>' +
				field({ name: 'code', label: 'اكتب الرمز هنا (4 أرقام)', cls: 'vai-otp', dir: 'ltr', inputmode: 'numeric', autocomplete: 'one-time-code', maxlength: 4, required: true, placeholder: '· · · ·', help: 'وصلك على بريدك — صالح 20 دقيقة.' }) +
				field({ name: 'password', label: 'كلمة المرور الجديدة', type: 'password', dir: 'ltr', autocomplete: 'new-password', required: true, help: '6 أحرف على الأقل.' }) +
				errBox + '<button type="submit" class="vai-btn vai-btn-p vai-btn-block">تغيير كلمة المرور</button></form>';
		}
		var gBlock = (mode === 'register' || mode === 'login') && CFG.google_client_id ? '<div class="vai-gwrap"><div class="vai-gslot"></div><div class="vai-gnote" role="alert" hidden></div><div class="vai-or"><span>أو</span></div></div>' : '';
		d.innerHTML = trText((mode === 'register' || mode === 'login' ? authTabs(mode) : '') + gBlock + intro + body);
		d.querySelectorAll('.vai-tabs button').forEach(function (b) { b.addEventListener('click', function () { if (b.getAttribute('data-m') !== mode) { showAccountForm(b.getAttribute('data-m'), text); } }); });
		openPanel();
		openSheet({ title: title, node: d, back: mode === 'reset' || mode === 'reset2' ? function () { showAccountForm('login'); } : null });
		if (gBlock) { mountGoogle(d); }
		if (mode === 'register') { showRegister(d); return; }
		var f = d.querySelector('form'), sb = f.querySelector('[type=submit]');
		wireForm(f);
		var fail = function (r, fallback, fieldName) {
			busy(sb, false);
			var m = (r && r.text) || fallback;
			if (!fieldName || (r && r.error === 'rate') || !showErrs(f, [[fieldName, m]])) { formErr(f, m); }
		};
		var forgot = d.querySelector('.vai-forgot'); if (forgot) { forgot.addEventListener('click', function () { showAccountForm('reset'); }); }
		var change = d.querySelector('.vai-change'); if (change) { change.addEventListener('click', function () { showAccountForm('register'); }); }
		var resend = d.querySelector('.vai-resend');
		if (resend) {
			cooldown(resend, 60); /* a code has just been sent; the hub accepts one resend per minute */
			resend.addEventListener('click', function () {
				resend.disabled = true;
				api('resend_code', {}).then(function (r) {
					if (!r || r.ok === false) { resend.disabled = false; formErr(f, (r && r.text) || 'تعذّر إعادة الإرسال — حاول بعد قليل.'); if (r && r.error === 'rate') { cooldown(resend, 60); } return; }
					formErr(f, ''); say((r && r.text) || 'تمت إعادة الإرسال');
					var ok = f.querySelector('.vai-auth-intro'); if (ok && r.text) { ok.textContent = trText(r.text); }
					cooldown(resend, 60);
				}).catch(function () { resend.disabled = false; formErr(f, ERR_NET); });
			});
		}
		var codeIn = f.querySelector('[name=code]');
		if (codeIn) {
			codeIn.setAttribute('pattern', '[0-9]*');
			codeIn.addEventListener('input', function () {
				var n = latinDigits(codeIn.value).replace(/\D/g, '').slice(0, 4);
				if (n !== codeIn.value) { codeIn.value = n; }
				if (mode === 'code' && n.length === 4 && !isBusy(sb)) { go(); } /* the fourth digit submits by itself */
			});
			if (mode === 'code') { focusSoft(codeIn); } /* 2.15.2: the cursor is already in the box — «اكتب هنا» needs no hunting */
		}
		var go = function () {
			if (isBusy(sb)) { return; }
			var errs = [];
			if (mode === 'login') { if (!val(f, 'login')) { errs.push(['login', 'اكتب بريدك الإلكتروني أو رقم جوالك.']); } if (!val(f, 'password')) { errs.push(['password', 'اكتب كلمة المرور.']); } }
			else if (mode === 'code' || mode === 'reset2') { if (val(f, 'code').length < 4) { errs.push(['code', 'اكتب الرمز الذي وصلك على بريدك.']); } if (mode === 'reset2' && val(f, 'password').length < 6) { errs.push(['password', 'كلمة المرور 6 أحرف فأكثر.']); } }
			else if (mode === 'reset') { if (!val(f, 'login')) { errs.push(['login', 'اكتب بريدك الإلكتروني أو رقم جوالك المسجّل.']); } }
			if (showErrs(f, errs)) { return; }
			if (mode === 'login') {
				busy(sb, true, 'جارٍ الدخول…');
				api('login', { login: val(f, 'login'), password: val(f, 'password') }).then(function (r) {
					if (!r || r.ok === false) { return fail(r, 'بيانات الدخول غير صحيحة.', 'password'); }
					if (r.pending) { state.contact = r.contact || state.contact; save(); renderAcct(); showAccountForm('code', r.text || ''); return; }
					afterAuth(r, true, true); sysLine('تم تسجيل الدخول ✅');
				}).catch(function () { fail(null, ERR_NET); });
			} else if (mode === 'code') {
				busy(sb, true, 'جارٍ التفعيل…');
				api('verify', { code: val(f, 'code') }).then(function (r) {
					if (!r || r.ok === false) { fail(r, 'الرمز غير صحيح.', 'code'); codeIn.select(); return; }
					afterAuth(r, true, true); sysLine('تم تفعيل حسابك ✅');
					var cc = state.contact, note = copy('after_verify', '');
					/* the wording of the membership step belongs to the hub: unpaid_note + the membership card (afterAuth) or copy.after_verify */
					if (note && CFG.membership && cc && !cc.is_member && !CFG.unpaid_note) { var dm = el('div', 'vai-msg vai-bot'); dm.appendChild(el('div', 'vai-bubble', md(note))); dm.appendChild(cardEl(CFG.membership)); ui.body.appendChild(dm); }
					var d2 = el('div', 'vai-msg vai-bot', '<div class="vai-bubble"><p dir="auto">من زر «حسابي» تقدر ترفع صورتك وتعدّل بياناتك في أي وقت — حسابك واحد على كل مواقع المنظومة.</p></div>');
					var b2 = el('button', 'vai-btn', 'رفع صورتي وتعديل بياناتي'); b2.type = 'button'; b2.addEventListener('click', function () { showProfileForm(); });
					d2.appendChild(b2); ui.body.appendChild(d2); scrollBottom();
				}).catch(function () { fail(null, ERR_NET); });
			} else if (mode === 'reset') {
				busy(sb, true, 'جارٍ الإرسال…');
				api('reset_request', { login: val(f, 'login') }).then(function (r) {
					if (!r || r.ok === false) { return fail(r, 'تعذّر الإرسال — حاول مرة ثانية.', 'login'); }
					showAccountForm('reset2', val(f, 'login'));
				}).catch(function () { fail(null, ERR_NET); });
			} else if (mode === 'reset2') {
				busy(sb, true, 'جارٍ الحفظ…');
				api('reset_confirm', { login: val(f, 'login'), code: val(f, 'code'), password: val(f, 'password') }).then(function (r) {
					if (!r || r.ok === false) { return fail(r, 'الرمز غير صحيح.', r && r.error === 'invalid' ? 'password' : 'code'); }
					showAccountForm('login', 'تم تغيير كلمة المرور ✅ سجّل الدخول الآن.');
				}).catch(function () { fail(null, ERR_NET); });
			}
		};
		f.addEventListener('submit', function (e) { e.preventDefault(); go(); });
	}

	/* ───────── gates ───────── */
	function accountBtns(box, text) {
		var reg = el('button', 'vai-btn vai-btn-p', 'أنشئ حسابك للمتابعة'); reg.type = 'button'; reg.addEventListener('click', function () { showAccountForm('register', text || CFG.account_gate_text || ''); }); box.appendChild(reg);
		var lg = el('button', 'vai-link', 'عندي حساب؟ دخول'); lg.type = 'button'; lg.addEventListener('click', function () { showAccountForm('login'); }); box.appendChild(lg);
	}
	function showGate(g) {
		if (!g) { return; }
		hideTyping();
		if (ui.gate) { ui.gate.remove(); ui.gate = null; }
		var gateText = g.text || CFG.account_gate_text || CFG.contact_gate_text || '';
		/* the visitor's own message hit the gate: the sign-up sheet answers it at once. Whatever comes in the background (a polled reply,
		   a closed panel, a sheet already open) only leaves an invitation in the conversation: the visitor opens the form. */
		if (g.type === 'contact' && !g.invite && state.open && !ui.sheetOpen) { showAccountForm('register', gateText); return; }
		var d = el('div', 'vai-msg vai-bot vai-gate');
		if (g.type === 'contact') {
			if (gateText) { d.innerHTML = '<div class="vai-bubble">' + md(gateText) + '</div>'; }
			accountBtns(d, gateText);
		} else if (g.type === 'contact_legacy') {
			d.innerHTML = '<div class="vai-bubble">' + md(g.text || CFG.contact_gate_text) + '</div><div class="vai-card"><form class="vai-form">' +
				field({ name: 'name', label: 'الاسم الكريم', autocomplete: 'name', required: true }) +
				field({ name: 'phone', label: 'رقم الجوال', type: 'tel', dir: 'ltr', inputmode: 'numeric', autocomplete: 'tel', required: true, help: g.saudi ? 'بصيغة 05… أو 966…' : '' }) +
				field({ name: 'email', label: 'البريد الإلكتروني', optional: true, type: 'email', dir: 'ltr', autocomplete: 'email', inputmode: 'email' }) +
				'<div class="vai-form-err" role="alert" hidden></div><button type="submit" class="vai-btn vai-btn-p vai-btn-block">أكمل المحادثة</button><div class="vai-form-note">بياناتك تُستخدم فقط لمتابعة طلبك من فريق نادي المستثمرين.</div></form></div>';
			var f = d.querySelector('form'), sb = f.querySelector('[type=submit]');
			wireForm(f);
			f.addEventListener('submit', function (e) {
				e.preventDefault();
				if (isBusy(sb)) { return; }
				var fd = { name: val(f, 'name'), phone: latinDigits(val(f, 'phone')), email: val(f, 'email') }, errs = [];
				if (!fd.name) { errs.push(['name', 'اكتب اسمك الكريم.']); }
				if (fd.phone.replace(/\D/g, '').length < 9) { errs.push(['phone', 'اكتب رقم جوالك كاملًا.']); }
				if (showErrs(f, errs)) { return; }
				busy(sb, true, 'جارٍ الحفظ…');
				api('identify', fd).then(function (r) {
					if (!r || r.ok === false) { busy(sb, false); formErr(f, (r && r.text) || 'تعذّر الحفظ — حاول مرة ثانية.'); return; }
					state.contact = r.contact || state.contact; save();
					d.remove(); ui.gate = null;
					sysLine(r.returning ? 'تعرّفت عليك ✅' : 'تم حفظ بياناتك ✅');
					if (state.pending || pendingRef) { setTimeout(resendPending, r.returning ? 2500 : 500); if (r.returning) { setAwaiting(true, true); } }
					else if (r.returning) { setAwaiting(true, true); } else { schedulePoll(true); }
				}).catch(function () { busy(sb, false); formErr(f, ERR_NET); });
			});
		} else if (g.type === 'membership') {
			d.innerHTML = '<div class="vai-bubble">' + md(g.text || CFG.member_gate_text) + '</div>';
			renderAcct();
			if (g.needs_account) { accountBtns(d, ''); }
			if (g.card && !g.needs_account) { d.appendChild(cardEl(g.card)); }
			var row = el('div', 'vai-card-btns');
			var have = el('button', 'vai-btn', 'عندي عضوية — تحقّق'); have.type = 'button';
			have.addEventListener('click', function () {
				busy(have, true, 'جارٍ التحقق…');
				api('member', {}).then(function (r) {
					busy(have, false);
					if (r && r.member) { state.contact = r.contact || state.contact; save(); renderAcct(); d.remove(); ui.gate = null; sysLine('تم التحقق من عضويتك ✅ نكمل بلا حدود.'); resendPending(); }
					else if (r && r.ok === false) { sysLine((r && r.text) || 'تعذّر التحقق الآن — حاول بعد قليل.'); }
					else { sysLine('ما لقيت اشتراكك بعد. لو دفعت الآن، اضغط «عندي عضوية» بعد دقائق، أو راسل الإدارة لتفعيلها فورًا.'); }
				}).catch(function () { busy(have, false); sysLine(ERR_NET); });
			});
			row.appendChild(have);
			if (g.mgmt) { row.appendChild(btnEl('راسل الإدارة', 'https://wa.me/' + g.mgmt + '?text=' + encodeURIComponent('دفعت اشتراك عضوية النادي وأحتاج تفعيلها في ' + botName()), false, 'wa')); }
			d.appendChild(row);
		} else {
			d.innerHTML = '<div class="vai-bubble">' + md(g.text || '') + '</div>';
			if (g.mgmt) { d.appendChild(btnEl('راسل الإدارة على واتساب', 'https://wa.me/' + g.mgmt + '?text=' + waText(), true, 'wa')); }
		}
		ui.gate = d;
		ui.body.appendChild(d);
		scrollBottom();
	}

	/* ───────── claim (cross-site handoff) ───────── */
	var bootNotes = [];
	function claimToken(token) {
		return api('claim', { token: token }).then(function (r) {
			if (!r || !r.ok) { bootNotes.push('تعذّر نقل محادثتك من الموقع السابق — يمكنك المتابعة من هنا.'); return; }
			state.contact = r.contact || state.contact;
			state.msgs = (r.messages || []).filter(function (m) { return m.role !== 'system'; });
			var maxId = 0; state.msgs.forEach(function (m) { if (m.id > maxId) { maxId = m.id; } });
			state.lastId = Math.max(state.lastId, maxId);
			var p = r.payload || {};
			if (p.prefill) { state.prefill = p.prefill; }
			state.open = !!p.open; state.fs = !!p.fs; state.seen = true;
			save();
		}).catch(function () { bootNotes.push('تعذّر نقل محادثتك من الموقع السابق — يمكنك المتابعة من هنا.'); });
	}
	function cleanUrl() {
		try { var u = new URL(location.href); if (u.searchParams.has('vai')) { u.searchParams.delete('vai'); history.replaceState(null, '', u.toString()); } } catch (e) {}
	}

	/* ───────── boot ───────── */
	function boot() {
		build();
		var params = new URLSearchParams(location.search);
		var raw = params.get('vai') || '';
		var cmd = '';
		if (/^(open|chat|register|signup|login|account|paid|setpass)$/i.test(raw)) { cmd = raw.toLowerCase(); raw = ''; }
		var spTok = params.get('t') || '';
		if (params.has('vai-open')) { cmd = 'open'; }
		if (params.has('vai-register')) { cmd = 'register'; }
		if (params.has('vai-login')) { cmd = 'login'; }
		if (location.hash === '#vai-open' || location.hash === '#vai-register') { cmd = location.hash === '#vai-register' ? 'register' : 'open'; }
		var token = raw;
		var start = function () {
			if (state.awaiting && Date.now() - state.awaiting < TIMEOUT_MS) { awaitingSince = state.awaiting; sendLock(true); } else { state.awaiting = 0; }
			if (cmd) {
				state.open = true; state.seen = true; save(); openPanel();
				if (cmd === 'register' || cmd === 'signup') { if (hasAccount()) { showAccount(); } else { showAccountForm('register', CFG.account_gate_text || ''); } }
				else if (cmd === 'login' || cmd === 'account') { if (hasAccount()) { showAccount(); } else { showAccountForm('login'); } }
				else if (cmd === 'setpass') { showSetPass(spTok); }
				else if (cmd === 'paid') {
					sysLine('✅ وصلتنا دفعتك — يفعّل النظام عضويتك تلقائيًا خلال لحظات' + (hasAccount() ? '.' : '، وإن لم يكن لك حساب بعد فأنشئه بنفس الجوال أو البريد الذي دفعت به.'));
					if (!hasAccount()) { showAccountForm('register', CFG.account_gate_text || ''); }
					else {
						setTimeout(function () {
							api('account', {}).then(function (r) {
								if (r && r.contact) { state.contact = r.contact; save(); renderAcct(); if (r.contact.is_member) { showServices(); } }
								else { sysLine('تعذّر تحديث حالة عضويتك الآن — افتح «حسابي» بعد لحظات.'); }
							}).catch(function () { sysLine('تعذّر تحديث حالة عضويتك الآن — افتح «حسابي» بعد لحظات.'); });
						}, 4000);
					}
				}
				try { var u = new URL(location.href); ['vai', 'vai-open', 'vai-register', 'vai-login'].forEach(function (k) { u.searchParams.delete(k); }); if (/^#vai-/.test(u.hash)) { u.hash = ''; } history.replaceState(null, '', u.toString()); } catch (e) {}
			}
			if (B.autoOpen === 'account') { state.open = true; state.fs = true; save(); openPanel(); if (hasAccount()) { showAccount(); } else { showAccountForm('login'); } }
			if (state.contact && state.contact.name && hasAccount()) { ui.teaser.innerHTML = '<span>' + esc('أهلًا ' + firstName(state.contact) + ' 👋 ' + botName() + ' جاهز لأسئلتك') + '</span>'; }
			if (state.open) { openPanel(); } else if (!state.seen || (state.contact && state.contact.has_account)) { setTimeout(function () { if (!state.open) { ui.teaser.classList.add('vai-show'); } }, 2500); setTimeout(function () { ui.teaser.classList.remove('vai-show'); }, 14000); }
			if (state.prefill) { setTimeout(function () { applyPrefill(); }, 400); }
			initAsk();
			schedulePoll(true);
		};
		if (token) { claimToken(token).then(function () { cleanUrl(); start(); }); }
		else if (!state.msgs.length && state.contact && !state.fresh) {
			api('history', {}).then(function (r) {
				if (r && r.messages && r.messages.length) { state.msgs = r.messages.filter(function (m) { return m.role !== 'system'; }); r.messages.forEach(function (m) { if (m.id > state.lastId) { state.lastId = m.id; } }); if (r.contact) { state.contact = r.contact; } save(); }
				start();
			}).catch(start); /* no history this time: the chat still opens, and the poll brings what is new */
		} else { start(); }
		document.addEventListener('visibilitychange', function () { if (!document.hidden) { schedulePoll(true); } });
	}

	var ICON = {
		star: '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><path d="M12 2.5l2.9 6.1 6.6.8-4.9 4.6 1.3 6.6L12 17.4l-5.9 3.2 1.3-6.6L2.5 9.4l6.6-.8z"/></svg>',
		smile: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="9.5"/><path d="M8.5 14.5c1 1.3 2.2 1.9 3.5 1.9s2.5-.6 3.5-1.9"/><circle cx="9" cy="10" r=".9" fill="currentColor"/><circle cx="15" cy="10" r=".9" fill="currentColor"/></svg>',
		mic: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3M9 21h6"/></svg>',
		stop: '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><rect x="6" y="6" width="12" height="12" rx="2"/></svg>',
		user: '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor" aria-hidden="true"><path d="M12 12a5 5 0 1 0 0-10 5 5 0 0 0 0 10zm0 2c-4.4 0-8 2.2-8 5v3h16v-3c0-2.8-3.6-5-8-5z"/></svg>',
		clip: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21.4 11.1l-8.5 8.5a5.5 5.5 0 0 1-7.8-7.8l9.2-9.2a3.7 3.7 0 0 1 5.2 5.2l-9.2 9.2a1.8 1.8 0 0 1-2.6-2.6l8.5-8.5"/></svg>',
		waBig: '<svg viewBox="0 0 24 24" width="36" height="36" fill="currentColor" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.885-9.885 9.885m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>',
		wa: '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.885-9.885 9.885m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>',
		fs: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 3H3v5M16 3h5v5M8 21H3v-5M16 21h5v-5"/></svg>',
		unfs: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 8h5V3M21 8h-5V3M3 16h5v5M21 16h-5v5"/></svg>',
		plus: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>',
		x: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>',
		down: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>',
		back: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>',
		send: '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><path d="M3 11.5 21 3l-8.5 18-2-7.5-7.5-2z"/></svg>',
		play: '<svg viewBox="0 0 24 24" width="26" height="26" fill="currentColor" aria-hidden="true"><path d="M8 5v14l11-7z"/></svg>',
		spark: '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true"><path d="M12 2l1.9 5.6a3 3 0 0 0 1.9 1.9L21.4 11l-5.6 1.9a3 3 0 0 0-1.9 1.9L12 20.4l-1.9-5.6a3 3 0 0 0-1.9-1.9L2.6 11l5.6-1.5a3 3 0 0 0 1.9-1.9zM19 16l.7 1.8 1.8.7-1.8.7L19 21l-.7-1.8-1.8-.7 1.8-.7z"/></svg>',
		eye: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/></svg>',
		eyeOff: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 3l18 18M10.6 5.1A9.7 9.7 0 0 1 12 5c6.4 0 10 7 10 7a17 17 0 0 1-3.2 4M6.5 6.6C3.7 8.5 2 12 2 12s3.6 7 10 7a9.6 9.6 0 0 0 4.3-1M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>',
		check: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
		alert: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9.5"/><path d="M12 7.5v5.5M12 16.5v.1"/></svg>',
		retry: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7"/></svg>',
		offline: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 3l18 18M8.5 16.5a5 5 0 0 1 7 0M5 13a10 10 0 0 1 4-2.5M19 13a10 10 0 0 0-5-2.8M2 9.5a15 15 0 0 1 4.2-2.8M22 9.5A15 15 0 0 0 10.5 5.6M12 20h.01"/></svg>'
	};

	/* ───────── pay modal (2.10.0 / M47): a link to this site's /?vai-pay opens INSIDE the page ─────────
	   The iframe is same-origin only (satellites keep normal navigation to the hub's page, where the
	   visitor's vai_uuid cookie actually lives). Card entry never happens in the frame: the pay page
	   breaks out to Paymob's own secure page at the top window the moment the payment starts. */
	var payFrame = null;
	function payHref(a) {
		var href = a.getAttribute('href') || '';
		if (!href || href.charAt(0) === '#') { return ''; }
		var u = document.createElement('a');
		u.href = href;
		if (u.host !== window.location.host) { return ''; }
		var q = u.search || '';
		if (q.indexOf('vai-pay-done') !== -1 || q.indexOf('vai-embed') !== -1) { return ''; }
		return (/[?&]vai-pay(=|&|$)/).test(q) ? u.href : '';
	}
	function openPay(url) {
		closePay();
		var f = document.createElement('iframe');
		f.className = 'vai-payframe';
		f.setAttribute('title', trText('الدفع الآمن — نادي المستثمرين'));
		f.setAttribute('allow', 'payment');
		/* 2.20.0: an English widget opens the pay page in English too */
		f.src = url + (url.indexOf('?') === -1 ? '?' : '&') + 'vai-embed=1' + (state.lang === 'en' && url.indexOf('lang=en') === -1 ? '&lang=en' : '');
		payFrame = f;
		document.body.appendChild(f);
		document.body.classList.add('vai-pay-lock');
		try { f.focus(); } catch (e) {}
	}
	function closePay() {
		if (!payFrame) { return; }
		try { payFrame.parentNode.removeChild(payFrame); } catch (e) {}
		payFrame = null;
		document.body.classList.remove('vai-pay-lock');
	}
	window.addEventListener('message', function (ev) {
		if (ev.origin === window.location.origin && ev.data === 'vai-pay-close') { closePay(); }
	});
	document.addEventListener('keydown', function (ev) {
		if (payFrame && (ev.key === 'Escape' || ev.key === 'Esc')) { closePay(); }
	});
	document.addEventListener('click', function (ev) {
		if (ev.defaultPrevented || ev.button !== 0 || ev.metaKey || ev.ctrlKey || ev.shiftKey || ev.altKey) { return; }
		var a = ev.target && ev.target.closest ? ev.target.closest('a[href]') : null;
		if (!a) { return; }
		var url = payHref(a);
		if (!url) { return; }
		ev.preventDefault();
		openPay(url);
	}, true);
	window.VAIPay = { open: openPay, close: closePay };

	if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', boot); } else { boot(); }
})();
