<?php
/**
 * 2.15.2 (owner): «حساب المدير سالم على ChatGPT يقدر يعرف كل شيء ويبعت إيميلات لكل فئة ويطلب تقارير».
 * A small admin REST API for a Custom GPT (ChatGPT Actions): aggregate numbers and MASKED lists, plus
 * e-mail campaigns to a chosen audience. Privacy by design: raw e-mail addresses and phone numbers never
 * leave the hub — ChatGPT only names the audience and the hub's own mail queue does the sending; every
 * send needs a PREVIEW first (a confirm token, 15 minutes), so ChatGPT cannot blast e-mails in one step.
 * Secured by a bearer key the owner generates in the settings page (option gpt_api_key — same storage
 * rules as the Paymob secret, never in code); the owner is notified by mail about every campaign send.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class VAI_GPT {

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function routes() {
		$r = function ( $path, $methods, $cb ) {
			register_rest_route(
				'vibes-ai/v1',
				$path,
				array(
					'methods'             => $methods,
					'callback'            => array( __CLASS__, $cb ),
					'permission_callback' => array( __CLASS__, 'auth' ),
				)
			);
		};
		$r( '/gpt/overview', 'GET', 'overview' );
		$r( '/gpt/members', 'GET', 'members' );
		$r( '/gpt/report', 'GET', 'report' );
		$r( '/gpt/campaign/preview', 'POST', 'campaign_preview' );
		$r( '/gpt/campaign/send', 'POST', 'campaign_send' );
	}

	/** Bearer key auth + a gentle per-key rate limit (120 calls/hour). The key never appears in responses. */
	public static function auth( WP_REST_Request $req ) {
		$key = trim( (string) vai_opt( 'gpt_api_key', '' ) );
		if ( $key === '' || strlen( $key ) < 20 ) {
			return new WP_Error( 'off', 'خدمة ChatGPT غير مفعّلة — ولّد المفتاح من إعدادات Vibes AI', array( 'status' => 503 ) );
		}
		$h = (string) $req->get_header( 'authorization' );
		if ( stripos( $h, 'bearer ' ) === 0 ) {
			$h = trim( substr( $h, 7 ) );
		}
		if ( $h === '' ) {
			$h = trim( (string) $req->get_header( 'x_api_key' ) );
		}
		if ( $h === '' || ! hash_equals( $key, $h ) ) {
			return new WP_Error( 'unauthorized', 'مفتاح غير صحيح', array( 'status' => 401 ) );
		}
		$tk  = 'vai_gpt_rate';
		$hit = (int) get_transient( $tk );
		if ( $hit >= 120 ) {
			return new WP_Error( 'rate', 'محاولات كثيرة — حاول بعد قليل', array( 'status' => 429 ) );
		}
		set_transient( $tk, $hit + 1, HOUR_IN_SECONDS );
		return true;
	}

	/** Every action lands in a small rolling log the owner can read in the settings page. */
	private static function log( $what ) {
		$log = get_option( 'vai_gpt_log', array() );
		if ( ! is_array( $log ) ) {
			$log = array();
		}
		array_unshift( $log, vai_riyadh( vai_now() ) . ' — ' . $what );
		update_option( 'vai_gpt_log', array_slice( $log, 0, 20 ), false );
	}

	private static function persona_label( $p ) {
		$m = array( 'neutral' => 'محايد', 'entrepreneur' => 'رائد أعمال', 'investor' => 'مستثمر' );
		return isset( $m[ (string) $p ] ) ? $m[ (string) $p ] : 'غير محدد';
	}

	/** Raw identities stay on the hub: ChatGPT sees s***@g***.com and 05XXXX1110 only. */
	private static function mask_email( $em ) {
		$em = (string) $em;
		if ( $em === '' || strpos( $em, '@' ) === false ) {
			return '';
		}
		list( $u, $d ) = explode( '@', $em, 2 );
		return mb_substr( $u, 0, 1, 'UTF-8' ) . '***@' . mb_substr( $d, 0, 1, 'UTF-8' ) . '***' . strrchr( $d, '.' );
	}

	private static function mask_phone( $pn ) {
		$p = vai_phone_local( (string) $pn );
		return strlen( $p ) > 4 ? substr( $p, 0, 2 ) . str_repeat( 'X', strlen( $p ) - 6 ) . substr( $p, -4 ) : '';
	}

	/** Membership end date + remaining days for a contact row (same arithmetic as the hub pages). */
	private static function member_window( $c ) {
		if ( ! $c || empty( $c->member_started_at ) ) {
			return array( null, null );
		}
		$days = (int) $c->member_days > 0 ? (int) $c->member_days : (int) vai_cfg( 'member_days' );
		$end  = strtotime( $c->member_started_at . ' UTC' ) + $days * 86400;
		return array( gmdate( 'Y-m-d', $end ), (int) floor( ( $end - time() ) / 86400 ) );
	}

	/* ───────────── read endpoints ───────────── */

	public static function overview() {
		global $wpdb;
		$ct  = VAI_Hub::t( 'contacts' );
		$pt  = $wpdb->prefix . 'vai_payments';
		$tt  = VAI_Payments::tickets_table();
		$per = array();
		foreach ( $wpdb->get_results( "SELECT persona, COUNT(*) n FROM $ct WHERE pass_hash<>'' AND verified=1 GROUP BY persona" ) as $row ) {
			$per[ self::persona_label( $row->persona ) ] = (int) $row->n;
		}
		$out = array(
			'generated_at'        => vai_riyadh( vai_now() ),
			'accounts_total'      => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ct WHERE pass_hash<>'' AND verified=1" ),
			'accounts_by_persona' => $per,
			'members_active'      => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ct WHERE is_member=1" ),
			'members_expired'     => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ct WHERE is_member=0 AND member_started_at IS NOT NULL AND member_started_at<>''" ),
			'accounts_unpaid'     => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ct WHERE is_member=0 AND pass_hash<>'' AND verified=1" ),
			'payments_30d'        => array(
				'count'     => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $pt WHERE success=1 AND created_at > DATE_SUB(UTC_TIMESTAMP(), INTERVAL 30 DAY)" ),
				'total_sar' => round( (float) $wpdb->get_var( "SELECT COALESCE(SUM(amount_cents),0) FROM $pt WHERE success=1 AND created_at > DATE_SUB(UTC_TIMESTAMP(), INTERVAL 30 DAY)" ) / 100 ),
			),
			'event_tickets'       => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $tt" ),
			'mail_queue'          => VAI_Payments::queue_stats(),
			'latest_accounts'     => array(),
		);
		foreach ( $wpdb->get_results( "SELECT name, persona, is_member, created_at FROM $ct WHERE pass_hash<>'' ORDER BY id DESC LIMIT 10" ) as $c ) {
			$out['latest_accounts'][] = array(
				'name'    => (string) $c->name,
				'persona' => self::persona_label( $c->persona ),
				'member'  => (bool) (int) $c->is_member,
				'at'      => vai_riyadh( $c->created_at, 'Y-m-d' ),
			);
		}
		self::log( 'قراءة النظرة العامة' );
		return $out;
	}

	public static function members( WP_REST_Request $req ) {
		$aud = sanitize_key( (string) $req->get_param( 'audience' ) ) ?: 'paid';
		if ( ! in_array( $aud, array( 'paid', 'unpaid', 'all' ), true ) ) {
			return new WP_Error( 'invalid', 'audience: paid أو unpaid أو all', array( 'status' => 400 ) );
		}
		$persona = sanitize_key( (string) $req->get_param( 'persona' ) );
		$q       = mb_strtolower( trim( (string) $req->get_param( 'q' ) ), 'UTF-8' );
		$page    = max( 1, (int) $req->get_param( 'page' ) );
		$rows    = array();
		foreach ( VAI_Payments::audience( $aud, $persona ) as $c ) {
			if ( $q !== '' && mb_stripos( $c->name . ' ' . $c->email . ' ' . $c->phone_norm, $q, 0, 'UTF-8' ) === false ) {
				continue;
			}
			list( $end, $left ) = self::member_window( $c );
			$rows[] = array(
				'name'        => (string) $c->name,
				'email'       => self::mask_email( $c->email ),
				'phone'       => self::mask_phone( $c->phone_norm ),
				'persona'     => self::persona_label( $c->persona ),
				'member'      => (bool) (int) $c->is_member,
				'member_end'  => (int) $c->is_member ? $end : null,
				'member_left' => (int) $c->is_member ? $left : null,
			);
		}
		$total = count( $rows );
		self::log( 'قراءة قائمة (' . $aud . ( $persona ? '/' . $persona : '' ) . ') — ' . $total . ' حساب' );
		return array(
			'audience' => $aud,
			'persona'  => $persona ?: 'all',
			'total'    => $total,
			'page'     => $page,
			'pages'    => (int) ceil( $total / 50 ),
			'note'     => 'البريد والجوال يظهران مقنّعين للخصوصية — الإرسال يتم من الهب نفسه فلا حاجة للبيانات الكاملة هنا؛ التفاصيل الكاملة في لوحة Vibes AI.',
			'rows'     => array_slice( $rows, ( $page - 1 ) * 50, 50 ),
		);
	}

	public static function report( WP_REST_Request $req ) {
		global $wpdb;
		$days = min( 365, max( 1, (int) ( $req->get_param( 'days' ) ?: 30 ) ) );
		$ct   = VAI_Hub::t( 'contacts' );
		$pt   = $wpdb->prefix . 'vai_payments';
		$regs = $wpdb->get_results( $wpdb->prepare( "SELECT DATE(created_at) d, COUNT(*) n FROM $ct WHERE pass_hash<>'' AND created_at > DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY) GROUP BY DATE(created_at) ORDER BY d", $days ) );
		$pays = $wpdb->get_results( $wpdb->prepare( "SELECT DATE(created_at) d, COUNT(*) n, SUM(amount_cents) s FROM $pt WHERE success=1 AND created_at > DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY) GROUP BY DATE(created_at) ORDER BY d", $days ) );
		$out  = array(
			'days'          => $days,
			'registrations' => array(),
			'payments'      => array(),
			'totals'        => array( 'registrations' => 0, 'payments' => 0, 'revenue_sar' => 0 ),
		);
		foreach ( $regs as $x ) {
			$out['registrations'][] = array( 'date' => $x->d, 'count' => (int) $x->n );
			$out['totals']['registrations'] += (int) $x->n;
		}
		foreach ( $pays as $x ) {
			$out['payments'][] = array( 'date' => $x->d, 'count' => (int) $x->n, 'sar' => round( (float) $x->s / 100 ) );
			$out['totals']['payments'] += (int) $x->n;
			$out['totals']['revenue_sar'] += round( (float) $x->s / 100 );
		}
		self::log( 'تقرير ' . $days . ' يوم' );
		return $out;
	}

	/* ───────────── campaigns: preview → confirm → send ───────────── */

	public static function campaign_preview( WP_REST_Request $req ) {
		$aud = sanitize_key( (string) $req->get_param( 'audience' ) );
		if ( ! in_array( $aud, array( 'paid', 'unpaid', 'all' ), true ) ) {
			return new WP_Error( 'invalid', 'audience: paid (الأعضاء المفعّلون) أو unpaid (حسابات لم تدفع) أو all (كل الحسابات)', array( 'status' => 400 ) );
		}
		$persona = sanitize_key( (string) $req->get_param( 'persona' ) );
		if ( $persona !== '' && ! in_array( $persona, array( 'neutral', 'entrepreneur', 'investor' ), true ) ) {
			return new WP_Error( 'invalid', 'persona: neutral أو entrepreneur أو investor أو اتركها فارغة', array( 'status' => 400 ) );
		}
		$subject = sanitize_text_field( mb_substr( (string) $req->get_param( 'subject' ), 0, 180, 'UTF-8' ) );
		$body    = trim( (string) $req->get_param( 'body' ) );
		if ( mb_strlen( $subject, 'UTF-8' ) < 4 || mb_strlen( $body, 'UTF-8' ) < 20 ) {
			return new WP_Error( 'invalid', 'اكتب عنوانًا ونصًا حقيقيين للرسالة', array( 'status' => 400 ) );
		}
		$list = VAI_Payments::audience( $aud, $persona );
		if ( ! $list ) {
			return new WP_Error( 'empty', 'لا يوجد مستلمون في هذه الفئة', array( 'status' => 400 ) );
		}
		$sample = array();
		foreach ( array_slice( $list, 0, 3 ) as $c ) {
			$sample[] = (string) $c->name;
		}
		$token = strtolower( vai_key( 24 ) );
		set_transient( 'vai_gpt_c_' . $token, array( 'audience' => $aud, 'persona' => $persona, 'subject' => $subject, 'body' => $body ), 15 * MINUTE_IN_SECONDS );
		self::log( 'معاينة حملة (' . $aud . ( $persona ? '/' . $persona : '' ) . ') لـ ' . count( $list ) . ' مستلمًا: ' . vai_clip( $subject, 50 ) );
		return array(
			'recipients'    => count( $list ),
			'sample_names'  => $sample,
			'subject'       => $subject,
			'confirm_token' => $token,
			'note'          => 'لن يُرسل شيء الآن. اعرض العدد والعنوان والنص على المدير، وبعد موافقته الصريحة استدعِ campaign/send بهذا الـ token خلال 15 دقيقة.',
		);
	}

	public static function campaign_send( WP_REST_Request $req ) {
		$token = strtolower( preg_replace( '/[^a-z0-9]/', '', (string) $req->get_param( 'confirm_token' ) ) );
		$held  = $token !== '' ? get_transient( 'vai_gpt_c_' . $token ) : false;
		if ( ! is_array( $held ) ) {
			return new WP_Error( 'expired', 'لا توجد معاينة بهذا الرمز — اعمل preview جديدة (صلاحيتها 15 دقيقة)', array( 'status' => 400 ) );
		}
		delete_transient( 'vai_gpt_c_' . $token );
		$r = VAI_Payments::campaign( $held['audience'], $held['subject'], $held['body'], $held['persona'] );
		self::log( 'إرسال حملة (' . $held['audience'] . ( $held['persona'] ? '/' . $held['persona'] : '' ) . ') — ' . (int) $r['count'] . ' رسالة: ' . vai_clip( $held['subject'], 50 ) );
		// the owner SEES every ChatGPT send: one summary to the notify inbox
		$emails = array_filter( array_map( 'trim', explode( ',', (string) vai_opt( 'notify_email', get_option( 'admin_email' ) ) ) ) );
		foreach ( $emails as $to ) {
			if ( is_email( $to ) ) {
				VAI_Hub::mail( $to, '🤖 حملة بريدية من مساعد ChatGPT', "أطلق مساعد ChatGPT (حساب المدير) حملة بريدية الآن:\n\nالعنوان: " . $held['subject'] . "\nالفئة: " . $held['audience'] . ( $held['persona'] ? ' / ' . $held['persona'] : '' ) . "\nعدد المستلمين: " . (int) $r['count'] . "\n\nتُرسل رسالة كل 5 دقائق من طابور الإرسال. لو لم تكن تتوقعها: أوقف الطابور من صفحة «الرسائل البريدية» وبدّل مفتاح ChatGPT من الإعدادات فورًا." );
			}
		}
		return array( 'ok' => true, 'queued' => (int) $r['count'], 'batch' => (string) $r['batch'], 'note' => 'دخلت طابور الإرسال — رسالة كل 5 دقائق.' );
	}
}
