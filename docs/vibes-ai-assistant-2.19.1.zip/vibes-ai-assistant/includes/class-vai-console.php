<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Staff console at https://<hub>/?vai-console=1
 * Admin-role member accounts (promoted from the dashboard) log in with their own e-mail + password,
 * activate once with the 4-digit code they received by e-mail, then see every conversation across
 * all sites and reply under their own name. Lives on the hub only.
 */
class VAI_Console {

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_render' ), 1 );
	}

	public static function routes() {
		register_rest_route(
			'vibes-ai/v1',
			'/console/(?P<op>[a-z_]+)',
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'callback'            => array( __CLASS__, 'rest' ),
			)
		);
	}

	public static function rest( WP_REST_Request $req ) {
		nocache_headers();
		$op = $req->get_param( 'op' );
		$d  = vai_body( $req );
		$ip = vai_ip();
		switch ( $op ) {
			case 'login':
				return VAI_Hub::console_login( vai_str( $d, 'login', 190 ), isset( $d['password'] ) && is_string( $d['password'] ) ? $d['password'] : '', $ip );
			case 'activate':
				return VAI_Hub::console_activate( (string) ( $d['token'] ?? '' ), (string) ( $d['code'] ?? '' ) );
			case 'logout':
				VAI_Hub::console_logout( (string) ( $d['token'] ?? '' ) );
				return array( 'ok' => true );
		}
		return vai_error( 'not_found', 'غير معروف', 404 );
	}

	public static function maybe_render() {
		if ( ! isset( $_GET['vai-console'] ) ) {
			return;
		}
		if ( ! vai_is_hub() ) {
			wp_safe_redirect( rtrim( (string) vai_opt( 'hub_url', home_url() ), '/' ) . '/?vai-console=1' );
			exit;
		}
		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		header( 'X-Robots-Tag: noindex, nofollow' );
		echo self::html();
		exit;
	}

	private static function html() {
		$rest    = esc_url( rest_url( 'vibes-ai/v1/' ) );
		$css     = esc_url( VAI_URL . 'assets/admin.css?v=' . VAI_VERSION );
		$js      = esc_url( VAI_URL . 'assets/admin.js?v=' . VAI_VERSION );
		$logo    = esc_url( vai_cfg( 'avatar_url' ) );
		$title   = esc_html( vai_cfg( 'bot_name' ) . ' — لوحة الإدارة' );
		$host    = esc_html( vai_home_host() );
		$widget  = esc_url( home_url( '/' ) );
		return <<<HTML
<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>{$title}</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&display=swap">
<link rel="stylesheet" href="{$css}">
<style>
body{margin:0;background:#F4F3EF;font-family:"IBM Plex Sans Arabic",system-ui,sans-serif;color:#111}
.vc-top{background:#000;color:#fff;padding:10px 18px;display:flex;align-items:center;justify-content:space-between;border-bottom:2px solid #B8962E}
.vc-top img{height:38px;vertical-align:middle;margin-left:10px}
.vc-top b{font-size:16px}
.vc-top .vc-right{display:flex;gap:10px;align-items:center;font-size:13px}
.vc-top button,.vc-top a{background:transparent;border:1px solid #B8962E;color:#fff;border-radius:8px;padding:5px 12px;cursor:pointer;font:inherit;text-decoration:none}
.vc-wrap{padding:18px;max-width:1500px;margin:0 auto}
.vc-login{max-width:420px;margin:60px auto;background:#fff;border:1px solid #E6E4DE;border-radius:16px;padding:26px}
.vc-login h1{font-size:20px;margin:0 0 6px}
.vc-login p{color:#5c5953;font-size:14px;margin:0 0 16px}
.vc-login input{width:100%;box-sizing:border-box;border:1px solid #d5d2cb;border-radius:10px;padding:11px 12px;font:inherit;font-size:15px;margin-bottom:10px}
.vc-login input[dir=ltr]{text-align:left}
.vc-login .vc-btn{width:100%;background:#B8962E;color:#fff;border:0;border-radius:10px;padding:12px;font:inherit;font-size:15px;font-weight:700;cursor:pointer}
.vc-err{color:#A32A22;font-size:13px;min-height:18px;margin-bottom:8px}
.vc-note{font-size:12px;color:#8a877f}
.vai-wrap{font-family:inherit}
</style>
</head>
<body>
<div class="vc-top"><div><img src="{$logo}" alt=""><b>{$title}</b> <span style="color:#cfcac0;font-size:12px">— {$host}</span></div><div class="vc-right" id="vc-right"><a href="{$widget}" target="_blank" rel="noopener">الموقع</a></div></div>
<div id="vc-root" class="vc-wrap"></div>
<script>
(function(){
  var REST='{$rest}', KEY='vai_console_session', root=document.getElementById('vc-root'), right=document.getElementById('vc-right');
  var token=localStorage.getItem(KEY)||'', name=localStorage.getItem(KEY+'_name')||'';
  function post(op,data){return fetch(REST+'console/'+op,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data||{})}).then(function(r){return r.json();});}
  function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function showLogin(msg){
    root.innerHTML='<div class="vc-login"><h1>دخول الإدارة</h1><p>سجّل بنفس بريدك وكلمة مرور حسابك في المساعد. الدخول للأدمن فقط، وعلى موقع vcmem الأم.</p><div class="vc-err">'+esc(msg||'')+'</div><input id="vc-login" placeholder="البريد الإلكتروني أو الجوال" dir="ltr" autocomplete="username"><input id="vc-pass" type="password" placeholder="كلمة المرور" dir="ltr" autocomplete="current-password"><button class="vc-btn" id="vc-go">دخول</button><p class="vc-note" style="margin-top:12px">ليست لك صلاحية؟ اطلب الترقية إلى أدمن من الإدارة.</p></div>';
    document.getElementById('vc-go').onclick=function(){
      var l=document.getElementById('vc-login').value.trim(), p=document.getElementById('vc-pass').value;
      post('login',{login:l,password:p}).then(function(r){
        if(!r||r.ok===false){showLogin((r&&r.message)||'بيانات غير صحيحة');return;}
        token=r.token; name=r.name||''; localStorage.setItem(KEY,token); localStorage.setItem(KEY+'_name',name);
        if(!r.verified){showActivate('');} else {boot();}
      }).catch(function(){showLogin('تعذّر الاتصال');});
    };
  }
  function showActivate(msg){
    root.innerHTML='<div class="vc-login"><h1>تفعيل صلاحية الأدمن</h1><p>أدخل رمز التفعيل المكوّن من 4 أرقام الذي وصلك على بريدك مع رسالة الترقية.</p><div class="vc-err">'+esc(msg||'')+'</div><input id="vc-code" placeholder="رمز التفعيل" dir="ltr" inputmode="numeric"><button class="vc-btn" id="vc-act">تفعيل</button><p class="vc-note" style="margin-top:12px"><a href="#" id="vc-out">تسجيل الخروج</a></p></div>';
    document.getElementById('vc-act').onclick=function(){
      post('activate',{token:token,code:document.getElementById('vc-code').value.trim()}).then(function(r){ if(!r||r.ok===false){showActivate((r&&r.message)||'الرمز غير صحيح');return;} boot(); }).catch(function(){showActivate('تعذّر الاتصال');});
    };
    document.getElementById('vc-out').onclick=function(e){e.preventDefault();logout();};
  }
  function logout(){ post('logout',{token:token}).catch(function(){}); localStorage.removeItem(KEY); localStorage.removeItem(KEY+'_name'); location.reload(); }
  function boot(){
    right.innerHTML='<span>'+esc(name||'أدمن')+'</span><button id="vc-logout">خروج</button><a href="{$widget}" target="_blank" rel="noopener">الموقع</a>';
    document.getElementById('vc-logout').onclick=logout;
    root.innerHTML='<div class="wrap vai-wrap" dir="rtl"><div class="vai-head"><h1>لوحة المتابعة</h1><p class="vai-sub">كل من يكلّم المساعد على أي موقع في المنظومة — مباشر. ردك يظهر للعميل فورًا باسمك ويوقف البوت له مؤقتًا.</p></div><div id="vai-app" data-export=""><div class="vai-loading">جارٍ التحميل…</div></div></div>';
    window.VAI_ADMIN={rest:REST+'hub/admin/',nonce:'',hub:true,open:0,session:token,console:true};
    var s=document.createElement('script'); s.src='{$js}'; document.body.appendChild(s);
    // verify session quickly; if rejected → back to login
    fetch(REST+'hub/admin/me?_='+Date.now(),{headers:{'X-VAI-Session':token}}).then(function(r){ if(r.status===401||r.status===403){ return r.json().then(function(){ throw new Error('unauth'); }); } return r.json(); }).then(function(j){ if(j&&j.name){ name=j.name; localStorage.setItem(KEY+'_name',name); right.querySelector('span').textContent=name; } }).catch(function(){ localStorage.removeItem(KEY); showLogin('انتهت الجلسة أو لم يُفعَّل الحساب — سجّل الدخول من جديد'); });
  }
  if(token){ boot(); } else { showLogin(''); }
})();
</script>
</body>
</html>
HTML;
	}
}
