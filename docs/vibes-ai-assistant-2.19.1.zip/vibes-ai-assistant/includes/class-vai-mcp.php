<?php
/**
 * 2.15.4 (owner): ChatGPT's new UI offers «Add custom MCP server» instead of the old GPT Actions,
 * so the manager link ships as a standard MCP endpoint (streamable HTTP, JSON-RPC) that merely WRAPS
 * the existing VAI_GPT handlers — same opt-in gpt_api_key, same masked lists, same preview→confirm
 * campaigns, same owner mail on every send. The key travels as a URL segment because ChatGPT custom
 * connectors offer no bearer field; the endpoint only exists while the key option is set, and the
 * whole thing dies the moment the owner clears the key in the settings.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class VAI_MCP {

	const PROTO = '2025-06-18';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function routes() {
		register_rest_route(
			'vibes-ai/v1',
			'/mcp/(?P<key>[A-Za-z0-9_\-]{20,120})',
			array(
				'methods'             => array( 'GET', 'POST', 'DELETE' ),
				'permission_callback' => '__return_true',
				'callback'            => array( __CLASS__, 'serve' ),
			)
		);
	}

	public static function serve( WP_REST_Request $req ) {
		nocache_headers();
		$key = trim( (string) vai_opt( 'gpt_api_key', '' ) );
		if ( $key === '' || strlen( $key ) < 20 || ! hash_equals( $key, (string) $req->get_param( 'key' ) ) ) {
			return new WP_REST_Response( array( 'jsonrpc' => '2.0', 'id' => null, 'error' => array( 'code' => -32001, 'message' => 'unauthorized' ) ), 401 );
		}
		if ( $req->get_method() === 'GET' ) {
			// We answer plain JSON per request — no server-initiated SSE stream (the spec allows 405 here).
			return new WP_REST_Response( null, 405 );
		}
		if ( $req->get_method() === 'DELETE' ) {
			return new WP_REST_Response( null, 200 ); // stateless: nothing to end
		}
		$tk  = 'vai_gpt_rate';
		$hit = (int) get_transient( $tk );
		if ( $hit >= 120 ) {
			return new WP_REST_Response( array( 'jsonrpc' => '2.0', 'id' => null, 'error' => array( 'code' => -32000, 'message' => 'rate limited — try later' ) ), 429 );
		}
		set_transient( $tk, $hit + 1, HOUR_IN_SECONDS );
		$body = $req->get_json_params();
		if ( ! is_array( $body ) ) {
			return new WP_REST_Response( array( 'jsonrpc' => '2.0', 'id' => null, 'error' => array( 'code' => -32700, 'message' => 'parse error' ) ), 400 );
		}
		// A batch is an array of messages; a single message is an object with 'method'.
		if ( isset( $body['method'] ) ) {
			$out = self::handle( $body );
			return $out === null ? new WP_REST_Response( null, 202 ) : new WP_REST_Response( $out, 200 );
		}
		$results = array();
		foreach ( $body as $msg ) {
			if ( is_array( $msg ) && isset( $msg['method'] ) ) {
				$one = self::handle( $msg );
				if ( $one !== null ) {
					$results[] = $one;
				}
			}
		}
		return $results ? new WP_REST_Response( $results, 200 ) : new WP_REST_Response( null, 202 );
	}

	/** One JSON-RPC message → response array, or null for notifications. */
	private static function handle( $msg ) {
		$method = (string) $msg['method'];
		$id     = array_key_exists( 'id', $msg ) ? $msg['id'] : null;
		$params = isset( $msg['params'] ) && is_array( $msg['params'] ) ? $msg['params'] : array();
		if ( strpos( $method, 'notifications/' ) === 0 ) {
			return null;
		}
		$ok = function ( $result ) use ( $id ) {
			return array( 'jsonrpc' => '2.0', 'id' => $id, 'result' => $result );
		};
		switch ( $method ) {
			case 'initialize':
				return $ok(
					array(
						'protocolVersion' => isset( $params['protocolVersion'] ) && is_string( $params['protocolVersion'] ) ? $params['protocolVersion'] : self::PROTO,
						'capabilities'    => array( 'tools' => array( 'listChanged' => false ) ),
						'serverInfo'      => array( 'name' => 'مساعد نادي المستثمرين — Vibes AI', 'version' => VAI_VERSION ),
						'instructions'    => 'أدوات نادي المستثمرين للمدير. القواعد الملزمة: (1) أي رقم يُذكر يأتي من استدعاء فعلي للأدوات، لا تخمينًا. (2) الفئات تُذكر دائمًا بالترتيب: محايد ثم رائد الأعمال ثم المستثمر، والكلمة المستخدمة «فئة». (3) الحملات البريدية خطوتان إلزاميتان: campaign_preview أولًا، ثم اعرض عدد المستلمين والعنوان والنص كاملًا على المدير واسأله صراحة «أأرسل؟»، ولا تستدعِ campaign_send إلا بعد موافقته الصريحة في نفس المحادثة؛ أي تعديل يستلزم معاينة جديدة. (4) البريد والجوال في القوائم مقنّعان عمدًا للخصوصية — التفاصيل الكاملة في لوحة Vibes AI على vcmem.com. (5) اكتب بالعربية، استخدم «بدون رسوم» لا «مجانًا»، و«رصيد» و«الشراكات».',
					)
				);
			case 'ping':
				return $ok( new stdClass() );
			case 'tools/list':
				return $ok( array( 'tools' => self::tools() ) );
			case 'resources/list':
				return $ok( array( 'resources' => array() ) );
			case 'resources/templates/list':
				return $ok( array( 'resourceTemplates' => array() ) );
			case 'prompts/list':
				return $ok( array( 'prompts' => array() ) );
			case 'tools/call':
				return $ok( self::call( isset( $params['name'] ) ? (string) $params['name'] : '', isset( $params['arguments'] ) && is_array( $params['arguments'] ) ? $params['arguments'] : array() ) );
			default:
				return array( 'jsonrpc' => '2.0', 'id' => $id, 'error' => array( 'code' => -32601, 'message' => 'method not found: ' . $method ) );
		}
	}

	private static function tools() {
		$aud = array( 'type' => 'string', 'enum' => array( 'paid', 'unpaid', 'all' ), 'description' => 'paid = الأعضاء المفعّلون، unpaid = حسابات لم تدفع العضوية، all = كل الحسابات الموثّقة' );
		$per = array( 'type' => 'string', 'enum' => array( 'neutral', 'entrepreneur', 'investor' ), 'description' => 'فئة واحدة اختيارية: neutral محايد، entrepreneur رائد أعمال، investor مستثمر' );
		return array(
			array(
				'name'        => 'club_overview',
				'description' => 'نظرة عامة على نادي المستثمرين: إجمالي الحسابات وتوزيعها على الفئات، الأعضاء المفعّلون والمنتهون، حسابات لم تدفع، مدفوعات آخر 30 يومًا، تذاكر الفعالية، طابور البريد، وآخر 10 تسجيلات.',
				'inputSchema' => array( 'type' => 'object', 'properties' => new stdClass() ),
			),
			array(
				'name'        => 'list_members',
				'description' => 'قائمة حسابات لجمهور محدد (50 في الصفحة). البريد والجوال يظهران مقنّعين للخصوصية عمدًا.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'audience' => $aud,
						'persona'  => $per,
						'q'        => array( 'type' => 'string', 'description' => 'بحث حر في الاسم والبريد والجوال' ),
						'page'     => array( 'type' => 'integer', 'minimum' => 1 ),
					),
				),
			),
			array(
				'name'        => 'club_report',
				'description' => 'تقرير آخر N يومًا: التسجيلات اليومية والمدفوعات الناجحة اليومية بالريال، مع الإجماليات.',
				'inputSchema' => array( 'type' => 'object', 'properties' => array( 'days' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 365, 'description' => 'افتراضي 30' ) ) ),
			),
			array(
				'name'        => 'campaign_preview',
				'description' => 'الخطوة 1 من إرسال حملة بريدية: تُرجع عدد المستلمين وعينة أسماء ورمز تأكيد صالحًا 15 دقيقة. لا يُرسَل شيء هنا. اعرض العدد والعنوان والنص كاملًا على المدير وانتظر موافقته الصريحة قبل campaign_send. المتغيرات المتاحة في النص: {name} {end_date} {pay_url} {mgmt}.',
				'inputSchema' => array(
					'type'       => 'object',
					'required'   => array( 'audience', 'subject', 'body' ),
					'properties' => array(
						'audience' => $aud,
						'persona'  => $per,
						'subject'  => array( 'type' => 'string', 'description' => 'عنوان الإيميل' ),
						'body'     => array( 'type' => 'string', 'description' => 'نص الإيميل' ),
					),
				),
			),
			array(
				'name'        => 'campaign_send',
				'description' => 'الخطوة 2: يُدخل الحملة المُعاينة طابور الإرسال فعليًا (رسالة كل 5 دقائق) ويُخطر المالك بالبريد. لا تستدعِها أبدًا إلا بعد موافقة المدير الصريحة على نفس المعاينة.',
				'inputSchema' => array( 'type' => 'object', 'required' => array( 'confirm_token' ), 'properties' => array( 'confirm_token' => array( 'type' => 'string' ) ) ),
			),
		);
	}

	/** Run one tool through the EXISTING VAI_GPT handlers (same masking, same confirm flow). */
	private static function call( $name, $args ) {
		$map = array(
			'club_overview'    => 'overview',
			'list_members'     => 'members',
			'club_report'      => 'report',
			'campaign_preview' => 'campaign_preview',
			'campaign_send'    => 'campaign_send',
		);
		if ( ! isset( $map[ $name ] ) ) {
			return array( 'content' => array( array( 'type' => 'text', 'text' => 'أداة غير معروفة: ' . $name ) ), 'isError' => true );
		}
		$r = new WP_REST_Request( 'POST', '' );
		foreach ( $args as $k => $v ) {
			$r->set_param( (string) $k, $v );
		}
		$res = call_user_func( array( 'VAI_GPT', $map[ $name ] ), $r );
		if ( is_wp_error( $res ) ) {
			return array( 'content' => array( array( 'type' => 'text', 'text' => $res->get_error_message() ) ), 'isError' => true );
		}
		if ( $res instanceof WP_REST_Response ) {
			$data  = $res->get_data();
			$isErr = $res->get_status() >= 400;
			return array( 'content' => array( array( 'type' => 'text', 'text' => wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ) ) ), 'isError' => $isErr );
		}
		return array( 'content' => array( array( 'type' => 'text', 'text' => wp_json_encode( $res, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ) ) ) );
	}
}
