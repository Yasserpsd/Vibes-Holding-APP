<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Runs on EVERY site (including the hub itself): injects the widget, proxies the
 * widget's calls to the hub, and pushes the site's content to the hub's knowledge base.
 */
class VAI_Site {

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_account_page' ), 2 );
		add_action( 'vai_site_daily_sync', array( __CLASS__, 'sync_all' ) );
		add_action( 'vai_site_sync_post', array( __CLASS__, 'sync_post' ) );
		add_action( 'transition_post_status', array( __CLASS__, 'on_transition' ), 10, 3 );
		add_shortcode( 'vai_feed', array( __CLASS__, 'shortcode_feed' ) );
		if ( ! wp_next_scheduled( 'vai_site_daily_sync' ) ) {
			wp_schedule_event( time() + 300, 'daily', 'vai_site_daily_sync' );
		}
	}

	public static function connected() {
		if ( vai_is_hub() ) {
			return true;
		}
		return trim( (string) vai_opt( 'hub_url', '' ) ) !== '' && trim( (string) vai_opt( 'site_key', '' ) ) !== '';
	}

	/* ─────────────── calls to the hub ─────────────── */

	public static function client( $op, array $data, $timeout = 25 ) {
		if ( vai_is_hub() ) {
			$site = VAI_Hub::self_site();
			$res  = VAI_Hub::op( $op, $site, $data );
			if ( is_wp_error( $res ) ) {
				return $res;
			}
			if ( $res instanceof WP_REST_Response ) {
				return $res->get_data();
			}
			return $res;
		}
		$hub = rtrim( trim( (string) vai_opt( 'hub_url', '' ) ), '/' );
		$key = trim( (string) vai_opt( 'site_key', '' ) );
		if ( $hub === '' || $key === '' ) {
			return vai_error( 'not_connected', 'الموقع غير مرتبط بالهب بعد' );
		}
		list( $code, $json, $err ) = vai_http_json( 'POST', $hub . '/wp-json/vibes-ai/v1/hub/' . $op, $data, array( 'X-VAI-Site-Key' => $key ), $timeout );
		if ( $code >= 200 && $code < 300 && is_array( $json ) ) {
			return $json;
		}
		if ( is_array( $json ) && isset( $json['message'] ) ) {
			return vai_error( isset( $json['code'] ) ? $json['code'] : 'hub_error', $json['message'], $code ?: 500 );
		}
		return vai_error( 'hub_error', 'تعذّر الاتصال بالهب (' . ( $code ?: 'network' ) . ') ' . $err, 502 );
	}

	public static function config() {
		$cfg = get_transient( 'vai_widget_config_' . VAI_VERSION );
		if ( is_array( $cfg ) && ! empty( $cfg['bot_name'] ) ) {
			return $cfg;
		}
		$res = self::client( 'config', array(), 12 );
		if ( ! is_wp_error( $res ) && ! empty( $res['config'] ) ) {
			$cfg = $res['config'];
			set_transient( 'vai_widget_config_' . VAI_VERSION, $cfg, 10 * MINUTE_IN_SECONDS );
			return $cfg;
		}
		return null;
	}

	/** /?vai-account=1 — a fixed "حسابي" page on every site: opens the assistant full-screen on the account panel. */
	public static function maybe_account_page() {
		if ( ! isset( $_GET['vai-account'] ) || ! self::connected() ) {
			return;
		}
		$cfg = self::config();
		if ( ! $cfg ) {
			return;
		}
		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		$boot = array(
			'rest'     => esc_url_raw( rest_url( 'vibes-ai/v1/client/' ) ),
			'host'     => vai_home_host(),
			'position' => vai_opt( 'widget_position', 'right' ) === 'left' ? 'left' : 'right',
			'cfg'      => $cfg,
			'autoOpen' => 'account',
		);
		$name = esc_html( $cfg['bot_name'] );
		$site = esc_html( get_bloginfo( 'name' ) );
		$home = esc_url( home_url( '/' ) );
		echo '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex"><title>حسابي — ' . $name . '</title>';
		echo '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&display=swap"><link rel="stylesheet" href="' . esc_url( VAI_URL . 'assets/widget.css?v=' . VAI_VERSION ) . '">';
		echo '<style>body{margin:0;min-height:100vh;background:#111 url("' . esc_url( $cfg['avatar_url'] ) . '") no-repeat center 40px;background-size:160px;font-family:"IBM Plex Sans Arabic",system-ui,sans-serif;color:#fff;text-align:center}.vai-acct-page{padding:230px 20px 40px}.vai-acct-page h1{font-size:22px;margin:0 0 6px}.vai-acct-page p{color:#cfcac0;font-size:14px}.vai-acct-page a{color:#B8962E}</style></head><body>';
		echo '<div class="vai-acct-page"><h1>حسابي في Vibes Ventures</h1><p>' . $site . ' — حساب واحد على كل مواقع المنظومة.<br><a href="' . $home . '">← العودة إلى الموقع</a></p></div>';
		echo '<script>window.VAI_BOOT=' . wp_json_encode( $boot, JSON_UNESCAPED_UNICODE ) . ';</script><script src="' . esc_url( VAI_URL . 'assets/widget.js?v=' . VAI_VERSION ) . '"></script></body></html>';
		exit;
	}

	/* ─────────────── widget ─────────────── */

	public static function enqueue() {
		if ( is_admin() || is_feed() || ! self::connected() ) {
			return;
		}
		if ( (int) vai_opt( 'widget_off', 0 ) ) {
			return;
		}
		$hide = (string) vai_opt( 'hide_paths', '' );
		if ( $hide !== '' ) {
			$path = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '/';
			foreach ( preg_split( '/\r\n|\r|\n/', $hide ) as $h ) {
				$h = trim( $h );
				if ( $h !== '' && strpos( $path, $h ) !== false ) {
					return;
				}
			}
		}
		$cfg = self::config();
		if ( ! $cfg ) {
			return;
		}
		$pos = vai_opt( 'widget_position', 'right' ) === 'left' ? 'left' : 'right';
		if ( ! empty( vai_opt( 'widget_color', '' ) ) ) {
			$cfg['primary_color'] = vai_opt( 'widget_color', '' );
		}
		wp_enqueue_style( 'vai-font', 'https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&display=swap', array(), null );
		wp_enqueue_style( 'vai-widget', VAI_URL . 'assets/widget.css', array(), VAI_VERSION );
		wp_enqueue_script( 'vai-widget', VAI_URL . 'assets/widget.js', array(), VAI_VERSION, true );
		$boot = array(
			'rest'     => esc_url_raw( rest_url( 'vibes-ai/v1/client/' ) ),
			'host'     => vai_home_host(),
			'position' => $pos,
			'cfg'      => $cfg,
		);
		wp_add_inline_script( 'vai-widget', 'window.VAI_BOOT=' . wp_json_encode( $boot, JSON_UNESCAPED_UNICODE ) . ';', 'before' );
	}

	/* ─────────────── public REST (widget → this site → hub) ─────────────── */

	public static function routes() {
		register_rest_route(
			'vibes-ai/v1',
			'/client/(?P<op>[a-z_]+)',
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'callback'            => array( __CLASS__, 'rest_client' ),
			)
		);
	}

	public static function rest_client( WP_REST_Request $req ) {
		nocache_headers();
		$op      = $req->get_param( 'op' );
		// «feed» is read-only. Privileged hub ops (activate_member, changes, publish, admin_*) must never be listed here.
		$allowed = array( 'chat', 'poll', 'identify', 'member', 'token', 'claim', 'history', 'config', 'register', 'login', 'logout', 'account', 'reset_request', 'reset_confirm', 'profile', 'verify', 'resend_code', 'member_status', 'setpass_check', 'setpass', 'feed', 'google', 'react' );
		if ( ! in_array( $op, $allowed, true ) ) {
			return vai_error( 'not_found', 'عملية غير معروفة', 404 );
		}
		$d = vai_body( $req );
		$d = is_array( $d ) ? $d : array();
		$d['ip'] = vai_ip();
		$uuid = isset( $d['uuid'] ) ? preg_replace( '/[^a-zA-Z0-9\-]/', '', (string) $d['uuid'] ) : '';
		$d['uuid'] = $uuid;

		if ( $op === 'config' ) {
			delete_transient( 'vai_widget_config_' . VAI_VERSION );
			$cfg = self::config();
			return $cfg ? array( 'ok' => true, 'config' => $cfg ) : vai_error( 'hub_error', 'تعذّر جلب الإعدادات', 502 );
		}

		if ( $op === 'chat' ) {
			$ip_key = 'vai_rl_ip_' . md5( $d['ip'] );
			$n_ip   = (int) get_transient( $ip_key );
			if ( $n_ip >= 120 ) {
				return array( 'ok' => true, 'gated' => true, 'gate' => array( 'type' => 'rate', 'text' => 'رسائل كثيرة من هذا الاتصال — حاول بعد قليل.' ) );
			}
			set_transient( $ip_key, $n_ip + 1, HOUR_IN_SECONDS );
			$op = 'message';
		}
		$timeout = in_array( $op, array( 'message', 'identify', 'register', 'login', 'profile', 'verify', 'resend_code', 'google' ), true ) ? 30 : 15;
		$res     = self::client( $op, $d, $timeout );
		if ( is_wp_error( $res ) ) {
			$st = $res->get_error_data();
			return new WP_REST_Response( array( 'ok' => false, 'error' => $res->get_error_code(), 'text' => $res->get_error_message() ), is_array( $st ) && ! empty( $st['status'] ) ? (int) $st['status'] : 500 );
		}
		return $res;
	}

	/* ─────────────── [vai_feed] — what the club published (posts / events), the same cards as the app ─────────────── */

	/** [vai_feed kind="event" limit="6"] — kind: post | event | empty for both. Cached 60 s per site; silent when the hub is unreachable. */
	public static function shortcode_feed( $atts ) {
		$atts  = shortcode_atts( array( 'kind' => '', 'limit' => 6 ), $atts, 'vai_feed' );
		$kind  = in_array( $atts['kind'], array( 'post', 'event' ), true ) ? $atts['kind'] : '';
		$limit = max( 1, min( 12, (int) $atts['limit'] ) );
		if ( ! self::connected() ) {
			return '';
		}
		$key   = 'vai_feed_sc_' . ( $kind !== '' ? $kind : 'all' ) . '_' . $limit;
		$items = get_transient( $key );
		if ( ! is_array( $items ) ) {
			$res   = self::client( 'feed', array( 'kind' => $kind, 'limit' => $limit ), 8 );
			$items = ( ! is_wp_error( $res ) && ! empty( $res['items'] ) && is_array( $res['items'] ) ) ? $res['items'] : array();
			set_transient( $key, $items, 60 );
		}
		if ( ! $items ) {
			return '';
		}
		$html = self::feed_style() . '<div class="vai-feed" dir="rtl">';
		foreach ( $items as $it ) {
			$html .= self::feed_card( is_array( $it ) ? $it : array() );
		}
		return $html . '</div>';
	}

	private static function feed_card( array $it ) {
		$title = isset( $it['title'] ) ? (string) $it['title'] : '';
		if ( $title === '' ) {
			return '';
		}
		$url   = isset( $it['url'] ) ? esc_url( (string) $it['url'] ) : '';
		$img   = isset( $it['image'] ) ? esc_url( (string) $it['image'] ) : '';
		$event = ( isset( $it['event'] ) && is_array( $it['event'] ) ) ? $it['event'] : array();
		$meta  = array();
		if ( ! empty( $event['date'] ) ) {
			$meta[] = '📅 ' . esc_html( (string) $event['date'] );
		}
		if ( ! empty( $event['place'] ) ) {
			$meta[] = '📍 ' . esc_html( (string) $event['place'] );
		}
		$open  = $url !== '' ? '<a href="' . $url . '">' : '';
		$close = $url !== '' ? '</a>' : '';
		$html  = '<article class="vai-feed-card" data-vai-ask="' . esc_attr( $title ) . '">';
		if ( $img !== '' ) {
			$html .= '<div class="vai-feed-img">' . $open . '<img src="' . $img . '" alt="' . esc_attr( $title ) . '" loading="lazy">' . $close . '</div>';
		}
		$html .= '<div class="vai-feed-body"><span class="vai-feed-kind">' . ( ( isset( $it['kind'] ) && $it['kind'] === 'event' ) ? 'فعالية' : 'جديد النادي' ) . '</span>';
		$html .= '<h3 class="vai-feed-title">' . $open . esc_html( $title ) . $close . '</h3>';
		if ( $meta ) {
			$html .= '<p class="vai-feed-meta">' . implode( ' · ', $meta ) . '</p>';
		}
		if ( ! empty( $it['excerpt'] ) ) {
			$html .= '<p class="vai-feed-text">' . esc_html( (string) $it['excerpt'] ) . '</p>';
		}
		if ( $url !== '' ) {
			$html .= '<a class="vai-feed-more" href="' . $url . '">التفاصيل ←</a>';
		}
		return $html . '</div></article>';
	}

	/** The cards' own small stylesheet, printed once per page (the widget stylesheet is not loaded where the widget is hidden). */
	private static function feed_style() {
		static $done = false;
		if ( $done ) {
			return '';
		}
		$done = true;
		return '<style>.vai-feed{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:18px;margin:18px 0;font-family:"IBM Plex Sans Arabic",system-ui,sans-serif}.vai-feed-card{background:#fff;border:1px solid #e6e4de;border-radius:14px;overflow:hidden;display:flex;flex-direction:column;box-shadow:0 2px 10px rgba(0,0,0,.05)}.vai-feed-img img{display:block;width:100%;height:170px;object-fit:cover}.vai-feed-body{padding:14px 16px 16px;display:flex;flex-direction:column;gap:6px;flex:1}.vai-feed-kind{align-self:flex-start;background:#7A611A;color:#fff;border-radius:6px;padding:1px 8px;font-size:12px}.vai-feed-title{margin:0;font-size:17px;line-height:1.5}.vai-feed-title a{color:#1d1b16;text-decoration:none}.vai-feed-meta{margin:0;color:#6b665c;font-size:13px}.vai-feed-text{margin:0;color:#3d3a33;font-size:14px;line-height:1.7}.vai-feed-more{margin-top:auto;color:#8a6f1f;font-weight:600;font-size:14px;text-decoration:none}</style>';
	}

	/* ─────────────── knowledge sync ─────────────── */

	public static function on_transition( $new, $old, $post ) {
		if ( ! $post || $new !== 'publish' ) {
			return;
		}
		$types = self::post_types();
		if ( ! in_array( $post->post_type, $types, true ) ) {
			return;
		}
		if ( ! wp_next_scheduled( 'vai_site_sync_post', array( (int) $post->ID ) ) ) {
			wp_schedule_single_event( time() + 45, 'vai_site_sync_post', array( (int) $post->ID ) );
		}
	}

	public static function post_types() {
		$types = get_post_types( array( 'public' => true ), 'names' );
		unset( $types['attachment'], $types['elementor_library'], $types['e-landing-page'] );
		$extra = (string) vai_opt( 'sync_exclude_types', '' );
		foreach ( preg_split( '/[\s,]+/', $extra ) as $x ) {
			if ( $x !== '' ) {
				unset( $types[ $x ] );
			}
		}
		return array_values( $types );
	}

	public static function sync_post( $post_id ) {
		if ( ! self::connected() ) {
			return;
		}
		$post = get_post( (int) $post_id );
		if ( ! $post || $post->post_status !== 'publish' ) {
			return;
		}
		$page = self::page_payload( $post );
		if ( $page ) {
			self::client( 'knowledge', array( 'pages' => array( $page ), 'sync_id' => '', 'final' => false ), 30 );
		}
	}

	public static function sync_all() {
		if ( ! self::connected() ) {
			return array( 'ok' => false, 'error' => 'not_connected' );
		}
		$types   = self::post_types();
		$sync_id = 'sync-' . gmdate( 'YmdHis' ) . '-' . wp_rand( 100, 999 );
		$ids     = get_posts(
			array(
				'post_type'      => $types,
				'post_status'    => 'publish',
				'posts_per_page' => 600,
				'fields'         => 'ids',
				'orderby'        => 'modified',
				'order'          => 'DESC',
				'no_found_rows'  => true,
			)
		);
		$batch = array();
		$sent  = 0;
		$errs  = 0;
		$total = count( $ids );
		foreach ( $ids as $i => $id ) {
			$post = get_post( $id );
			if ( ! $post ) {
				continue;
			}
			$p = self::page_payload( $post );
			if ( $p ) {
				$batch[] = $p;
			}
			$last = ( $i === $total - 1 );
			if ( count( $batch ) >= 15 || $last ) {
				$res = self::client( 'knowledge', array( 'pages' => $batch, 'sync_id' => $sync_id, 'final' => $last ), 40 );
				if ( is_wp_error( $res ) ) {
					$errs++;
				} else {
					$sent += count( $batch );
				}
				$batch = array();
			}
		}
		if ( $total === 0 ) {
			self::client( 'knowledge', array( 'pages' => array(), 'sync_id' => $sync_id, 'final' => true ), 20 );
		}
		update_option( 'vai_last_sync', array( 'at' => vai_now(), 'sent' => $sent, 'errors' => $errs, 'total' => $total ), false );
		return array( 'ok' => $errs === 0, 'sent' => $sent, 'errors' => $errs, 'total' => $total );
	}

	public static function page_payload( $post ) {
		$url = get_permalink( $post );
		if ( ! $url ) {
			return null;
		}
		$text = self::post_text( $post );
		if ( function_exists( 'mb_strlen' ) && mb_strlen( $text, 'UTF-8' ) < 40 ) {
			$fetched = self::fetch_rendered( $url );
			if ( $fetched && mb_strlen( $fetched, 'UTF-8' ) > mb_strlen( $text, 'UTF-8' ) ) {
				$text = $fetched;
			}
		}
		$desc = get_post_meta( $post->ID, 'rank_math_description', true );
		if ( $desc ) {
			$text = trim( $desc ) . "\n" . $text;
		}
		$text = trim( preg_replace( "/[ \t]+/u", ' ', preg_replace( "/\n{3,}/u", "\n\n", $text ) ) );
		if ( function_exists( 'mb_substr' ) && mb_strlen( $text, 'UTF-8' ) > 18000 ) {
			$text = mb_substr( $text, 0, 18000, 'UTF-8' );
		}
		return array(
			'url'      => $url,
			'title'    => html_entity_decode( get_the_title( $post ), ENT_QUOTES, 'UTF-8' ),
			'content'  => $text,
			'kind'     => in_array( $post->post_type, array( 'post', 'page' ), true ) ? $post->post_type : preg_replace( '/[^a-z_]/', '', strtolower( $post->post_type ) ),
			'modified' => $post->post_modified_gmt,
		);
	}

	public static function post_text( $post ) {
		$parts = array();
		$el    = get_post_meta( $post->ID, '_elementor_data', true );
		if ( $el ) {
			$data = is_string( $el ) ? json_decode( $el, true ) : $el;
			if ( is_array( $data ) ) {
				self::walk_elementor( $data, $parts );
			}
		}
		$raw = (string) $post->post_content;
		if ( $raw !== '' ) {
			$raw = preg_replace( '/\[\/?[a-zA-Z0-9_\-]+[^\]]*\]/', ' ', $raw );
			$raw = preg_replace( '/<!--.*?-->/s', ' ', $raw );
			$raw = wp_strip_all_tags( $raw );
			$raw = html_entity_decode( $raw, ENT_QUOTES, 'UTF-8' );
			if ( trim( $raw ) !== '' ) {
				$parts[] = trim( $raw );
			}
		}
		$txt = implode( "\n", $parts );
		return trim( preg_replace( '/[ \t]+/u', ' ', $txt ) );
	}

	private static function walk_elementor( $node, &$parts, $depth = 0 ) {
		if ( $depth > 40 ) {
			return;
		}
		if ( ! is_array( $node ) ) {
			return;
		}
		$keys = array( 'title', 'editor', 'text', 'description', 'html', 'heading', 'sub_heading', 'button_text', 'tab_title', 'tab_content', 'item_title', 'item_description', 'content', 'caption', 'testimonial_content', 'name', 'label', 'field_label', 'placeholder', 'title_text', 'description_text', 'subtitle', 'price', 'period', 'ribbon_title', 'inner_text', 'feature_text', 'question', 'answer', 'slide_heading', 'slide_description', 'counter_title', 'suffix', 'prefix', 'link_text', 'alt' );
		foreach ( $node as $k => $v ) {
			if ( is_array( $v ) ) {
				self::walk_elementor( $v, $parts, $depth + 1 );
			} elseif ( is_string( $v ) && in_array( (string) $k, $keys, true ) ) {
				$s = wp_strip_all_tags( html_entity_decode( $v, ENT_QUOTES, 'UTF-8' ) );
				$s = trim( preg_replace( '/\s+/u', ' ', $s ) );
				if ( $s !== '' && ( function_exists( 'mb_strlen' ) ? mb_strlen( $s, 'UTF-8' ) : strlen( $s ) ) > 1 && ! preg_match( '/^(https?:\/\/|#|\d+px|yes|no|true|false|left|right|center|default|none)$/i', $s ) ) {
					$parts[] = $s;
				}
			}
		}
	}

	private static function fetch_rendered( $url ) {
		$res = wp_remote_get( $url, array( 'timeout' => 12, 'user-agent' => 'VibesAI-sync/' . VAI_VERSION ) );
		if ( is_wp_error( $res ) || (int) wp_remote_retrieve_response_code( $res ) !== 200 ) {
			return '';
		}
		$html = (string) wp_remote_retrieve_body( $res );
		$html = preg_replace( '/<(script|style|noscript|svg|iframe|header|footer|nav|form)[^>]*>.*?<\/\1>/is', ' ', $html );
		if ( preg_match( '/<main[^>]*>(.*?)<\/main>/is', $html, $m ) ) {
			$html = $m[1];
		} elseif ( preg_match( '/<body[^>]*>(.*?)<\/body>/is', $html, $m ) ) {
			$html = $m[1];
		}
		$html = preg_replace( '/<\/(p|div|li|h[1-6]|section|article|br)>/i', "\n", $html );
		$txt  = wp_strip_all_tags( $html );
		$txt  = html_entity_decode( $txt, ENT_QUOTES, 'UTF-8' );
		$txt  = preg_replace( '/[ \t]+/u', ' ', $txt );
		$txt  = preg_replace( '/\n\s*\n+/u', "\n", $txt );
		return trim( $txt );
	}
}
