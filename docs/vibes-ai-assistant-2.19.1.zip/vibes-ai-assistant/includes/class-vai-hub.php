<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Hub mode — central database + APIs.
 *
 *  Site-facing ops  (auth: X-VAI-Site-Key)  : config, message, poll, identify, member, token, claim, history, knowledge, ping
 *  n8n-facing tools (auth: X-VAI-Key)       : reply, search, page, projects, form, services, contact
 *  Admin ops        (cookie + nonce)        : overview, threads, thread, send, contact, delete
 *  Bridge ops       (X-VAI-Site-Key of a TRUSTED site, 2.7.0): activate_member, changes, publish, admin_*
 */
class VAI_Hub {

	const DB_VERSION = '2.6.0';

	/** Source / reference of the next set_member() call (see member_context()). */
	private static $member_ctx = null;

	/** Webhook events waiting for the end of the request (see webhook()). */
	private static $webhook_queue = array();

	public static function init() {
		self::maybe_install();
		self::migrate_v27();
		add_action( 'update_option_vai_cfg_rev', array( __CLASS__, 'on_cfg_rev' ), 10, 2 );
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'vai_hub_cleanup', array( __CLASS__, 'cleanup' ) );
		add_action( 'admin_post_vai_export', array( __CLASS__, 'export_csv' ) );
		add_action( 'wp_mail_failed', function ( $err ) { update_option( 'vai_last_mail_error', is_wp_error( $err ) ? $err->get_error_message() : 'error', false ); } );
		add_filter( 'cron_schedules', array( __CLASS__, 'cron_schedules' ) );
		add_action( 'vai_hub_digest', array( __CLASS__, 'send_digest' ) );
		add_action( 'template_redirect', function () {
			if ( isset( $_GET['vai-ticket'] ) && class_exists( 'VAI_Payments' ) ) {
				VAI_Payments::render_ticket_page( sanitize_text_field( wp_unslash( $_GET['vai-ticket'] ) ) );
			}
			// 2.8.0 (M45): the site's own pay page and its return page.
			if ( isset( $_GET['vai-pay'] ) && class_exists( 'VAI_Payments' ) ) {
				VAI_Payments::render_pay_page( sanitize_text_field( wp_unslash( $_GET['vai-pay'] ) ) );
			}
			if ( isset( $_GET['vai-pay-done'] ) && class_exists( 'VAI_Payments' ) ) {
				VAI_Payments::render_pay_done_page();
			}
			// 2.15.5 (owner): the activation mail's one-click link.
			if ( isset( $_GET['vai-activate'] ) ) {
				self::render_activate_page( sanitize_text_field( wp_unslash( $_GET['vai-activate'] ) ) );
			}
		}, 1 );
		if ( ! wp_next_scheduled( 'vai_hub_digest' ) ) {
			wp_schedule_event( time() + 3600, 'vai_digest', 'vai_hub_digest' );
		}
	}

	public static function cron_schedules( $s ) {
		$h = max( 1, (int) vai_cfg( 'digest_hours' ) );
		$s['vai_digest'] = array( 'interval' => $h * 3600, 'display' => 'Vibes AI digest' );
		return $s;
	}

	/* ─────────────────────────── tables ─────────────────────────── */

	public static function t( $name ) {
		global $wpdb;
		return $wpdb->prefix . 'vai_' . $name;
	}

	public static function maybe_install() {
		if ( get_option( 'vai_db_version' ) !== self::DB_VERSION ) {
			self::install();
		}
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();

		$sql = array();

		$sql[] = 'CREATE TABLE ' . self::t( 'sites' ) . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(190) NOT NULL DEFAULT '',
			host VARCHAR(190) NOT NULL DEFAULT '',
			key_hash CHAR(64) NOT NULL DEFAULT '',
			color VARCHAR(20) NOT NULL DEFAULT '',
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			is_self TINYINT NOT NULL DEFAULT 0,
			trusted TINYINT NOT NULL DEFAULT 0,
			knowledge_count INT NOT NULL DEFAULT 0,
			last_sync DATETIME NULL,
			last_seen DATETIME NULL,
			created_at DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY host (host),
			KEY key_hash (key_hash)
		) $c;";

		$sql[] = 'CREATE TABLE ' . self::t( 'contacts' ) . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(190) NOT NULL DEFAULT '',
			phone VARCHAR(40) NOT NULL DEFAULT '',
			phone_norm VARCHAR(40) NOT NULL DEFAULT '',
			email VARCHAR(190) NOT NULL DEFAULT '',
			email_norm VARCHAR(190) NOT NULL DEFAULT '',
			stage TINYINT NOT NULL DEFAULT 0,
			is_member TINYINT NOT NULL DEFAULT 0,
			memo TEXT NULL,
			first_at DATETIME NULL,
			last_at DATETIME NULL,
			msg_count INT NOT NULL DEFAULT 0,
			reply_count INT NOT NULL DEFAULT 0,
			sites TEXT NULL,
			last_site_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			last_page TEXT NULL,
			human_until DATETIME NULL,
			awaiting_since DATETIME NULL,
			admin_seen_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			lead_type VARCHAR(40) NOT NULL DEFAULT '',
			notes TEXT NULL,
			ip_hash CHAR(64) NOT NULL DEFAULT '',
			pass_hash VARCHAR(255) NOT NULL DEFAULT '',
			trial_started_at DATETIME NULL,
			last_login_at DATETIME NULL,
			reset_code VARCHAR(64) NOT NULL DEFAULT '',
			reset_expires DATETIME NULL,
			avatar_url VARCHAR(500) NOT NULL DEFAULT '',
			company VARCHAR(190) NOT NULL DEFAULT '',
			member_type VARCHAR(20) NOT NULL DEFAULT '',
			city VARCHAR(120) NOT NULL DEFAULT '',
			bio TEXT NULL,
			job_title VARCHAR(150) NOT NULL DEFAULT '',
			website VARCHAR(300) NOT NULL DEFAULT '',
			social TEXT NULL,
			verified TINYINT NOT NULL DEFAULT 0,
			verified_at DATETIME NULL,
			verify_code VARCHAR(64) NOT NULL DEFAULT '',
			verify_expires DATETIME NULL,
			role VARCHAR(20) NOT NULL DEFAULT 'member',
			admin_code VARCHAR(64) NOT NULL DEFAULT '',
			admin_verified TINYINT NOT NULL DEFAULT 0,
			notify_pending TINYINT NOT NULL DEFAULT 0,
			member_started_at DATETIME NULL,
			member_days INT NOT NULL DEFAULT 0,
			member_welcomed TINYINT NOT NULL DEFAULT 0,
			persona VARCHAR(40) NOT NULL DEFAULT '',
			pass_token VARCHAR(64) NOT NULL DEFAULT '',
			pass_token_expires DATETIME NULL,
			created_at DATETIME NULL,
			referred_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			KEY phone_norm (phone_norm),
			KEY email_norm (email_norm),
			KEY last_at (last_at),
			KEY stage (stage),
			KEY referred_by (referred_by)
		) $c;";

		$sql[] = 'CREATE TABLE ' . self::t( 'visitors' ) . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			uuid VARCHAR(64) NOT NULL DEFAULT '',
			site_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			contact_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			first_at DATETIME NULL,
			last_at DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY uuid_site (uuid, site_id),
			KEY contact_id (contact_id)
		) $c;";

		$sql[] = 'CREATE TABLE ' . self::t( 'messages' ) . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			contact_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			site_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			role VARCHAR(12) NOT NULL DEFAULT 'user',
			content LONGTEXT NULL,
			actions LONGTEXT NULL,
			page_url TEXT NULL,
			meta TEXT NULL,
			created_at DATETIME NULL,
			PRIMARY KEY  (id),
			KEY contact_id (contact_id, id),
			KEY site_created (site_id, created_at),
			KEY created_at (created_at),
			KEY role (role)
		) $c;";

		$sql[] = 'CREATE TABLE ' . self::t( 'knowledge' ) . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			site_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			url VARCHAR(600) NOT NULL DEFAULT '',
			url_hash CHAR(32) NOT NULL DEFAULT '',
			title TEXT NULL,
			content LONGTEXT NULL,
			content_norm LONGTEXT NULL,
			kind VARCHAR(20) NOT NULL DEFAULT 'page',
			hash CHAR(32) NOT NULL DEFAULT '',
			sync_id VARCHAR(40) NOT NULL DEFAULT '',
			updated_at DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY site_url (site_id, url_hash),
			KEY kind (kind)
		) $c;";

		$sql[] = 'CREATE TABLE ' . self::t( 'services' ) . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			skey VARCHAR(60) NOT NULL DEFAULT '',
			name VARCHAR(190) NOT NULL DEFAULT '',
			price VARCHAR(60) NOT NULL DEFAULT '',
			currency VARCHAR(10) NOT NULL DEFAULT 'ريال',
			vat_note VARCHAR(190) NOT NULL DEFAULT '',
			payment_terms VARCHAR(255) NOT NULL DEFAULT '',
			url VARCHAR(500) NOT NULL DEFAULT '',
			pay_url VARCHAR(500) NOT NULL DEFAULT '',
			member_discount VARCHAR(120) NOT NULL DEFAULT '',
			includes TEXT NULL,
			pitch TEXT NULL,
			active TINYINT NOT NULL DEFAULT 1,
			sort INT NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			UNIQUE KEY skey (skey)
		) $c;";

		$sql[] = 'CREATE TABLE ' . self::t( 'forms' ) . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			fkey VARCHAR(60) NOT NULL DEFAULT '',
			label VARCHAR(190) NOT NULL DEFAULT '',
			url VARCHAR(500) NOT NULL DEFAULT '',
			host VARCHAR(190) NOT NULL DEFAULT '',
			field_map LONGTEXT NULL,
			notes TEXT NULL,
			active TINYINT NOT NULL DEFAULT 1,
			PRIMARY KEY  (id),
			UNIQUE KEY fkey (fkey)
		) $c;";

		$sql[] = 'CREATE TABLE ' . self::t( 'members' ) . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(190) NOT NULL DEFAULT '',
			phone_norm VARCHAR(40) NOT NULL DEFAULT '',
			email_norm VARCHAR(190) NOT NULL DEFAULT '',
			source VARCHAR(60) NOT NULL DEFAULT 'manual',
			expires_at DATE NULL,
			created_at DATETIME NULL,
			PRIMARY KEY  (id),
			KEY phone_norm (phone_norm),
			KEY email_norm (email_norm)
		) $c;";

		$sql[] = 'CREATE TABLE ' . self::t( 'tokens' ) . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			token VARCHAR(64) NOT NULL DEFAULT '',
			contact_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			payload LONGTEXT NULL,
			expires_at DATETIME NULL,
			used TINYINT NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			UNIQUE KEY token (token)
		) $c;";

		$sql[] = 'CREATE TABLE ' . self::t( 'sessions' ) . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			token CHAR(64) NOT NULL DEFAULT '',
			contact_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			ip_hash CHAR(64) NOT NULL DEFAULT '',
			created_at DATETIME NULL,
			last_at DATETIME NULL,
			expires_at DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY token (token),
			KEY contact_id (contact_id)
		) $c;";

		$sql[] = 'CREATE TABLE ' . self::t( 'leads' ) . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			contact_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			site_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			ltype VARCHAR(40) NOT NULL DEFAULT '',
			reason TEXT NULL,
			company VARCHAR(190) NOT NULL DEFAULT '',
			notes TEXT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'new',
			created_at DATETIME NULL,
			PRIMARY KEY  (id),
			KEY contact_id (contact_id),
			KEY created_at (created_at)
		) $c;";

		// 2.7.0 — member history (registered / verified / activated / renewed / revoked / role / deleted).
		$sql[] = 'CREATE TABLE ' . self::t( 'events' ) . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			contact_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			kind VARCHAR(20) NOT NULL DEFAULT '',
			days INT NOT NULL DEFAULT 0,
			source VARCHAR(20) NOT NULL DEFAULT '',
			ref VARCHAR(150) NOT NULL DEFAULT '',
			ref_key VARCHAR(190) NULL,
			actor_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			note VARCHAR(255) NOT NULL DEFAULT '',
			created_at DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY ref_key (ref_key),
			KEY created_at (created_at),
			KEY contact_id (contact_id, id)
		) $c;";

		// 2.7.0 — public cards of what the app published (posts / events), shown by [vai_feed] on every site.
		$sql[] = 'CREATE TABLE ' . self::t( 'feed' ) . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			site_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			pkey VARCHAR(64) NOT NULL DEFAULT '',
			kind VARCHAR(12) NOT NULL DEFAULT 'post',
			title VARCHAR(300) NOT NULL DEFAULT '',
			excerpt TEXT NULL,
			url VARCHAR(600) NOT NULL DEFAULT '',
			image VARCHAR(600) NOT NULL DEFAULT '',
			event_date VARCHAR(40) NOT NULL DEFAULT '',
			event_place VARCHAR(190) NOT NULL DEFAULT '',
			event_online VARCHAR(600) NOT NULL DEFAULT '',
			knowledge_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			author_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NULL,
			updated_at DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY site_pkey (site_id, pkey),
			KEY kind (kind)
		) $c;";

		foreach ( $sql as $q ) {
			dbDelta( $q );
		}
		// 2.11.0 (M52 unify, owner: «نوحد الطريقة في كله»): every pay entry in LIVE data moves to the ONE gate —
		// the site's own pay page (it collects the payer, then hands him to the service's direct link). The
		// two-year promo line dies wherever it survived (owner: «مفيش اشتراك سنتين ده خالص»).
		$gate = 'https://vcmem.com/?vai-pay=';
		$svc  = self::t( 'services' );
		foreach ( array( 'membership', 'pitchdeck', 'urmeet' ) as $sk ) {
			$wpdb->query( $wpdb->prepare( "UPDATE $svc SET pay_url=%s WHERE skey=%s AND (pay_url LIKE '%%paymob%%' OR pay_url='')", $gate . $sk, $sk ) );
		}
		$wpdb->query( $wpdb->prepare( "UPDATE $svc SET payment_terms=REPLACE(payment_terms, %s, %s) WHERE skey='membership'", ' (يمكن الدفع لسنة أو سنتين كحد أقصى بنفس السعر الترويجي)', ' — اشتراك سنوي' ) );
		$wpdb->query( "UPDATE $svc SET includes=REPLACE(includes,'3,750','2,500'), pitch=REPLACE(pitch,'3,750','2,500')" );
		// WhatsApp groups are cancelled (owner 2026-09-24): the benefit line leaves every live text
		foreach ( array( "
الانضمام إلى قروبات النادي", "الانضمام إلى قروبات النادي
", '، والانضمام إلى قروبات النادي', ' والانضمام لمجموعات النادي', '؛ الانضمام لمجموعات النادي (لا انضمام للمجموعات بدون عضوية سنوية)', 'والانضمام إلى قروبات النادي، ', 'الانضمام إلى قروبات النادي', 'الانضمام لمجموعات النادي', "
Joining the club groups", "Joining the club groups
" ) as $gph ) {
			$wpdb->query( $wpdb->prepare( "UPDATE $svc SET includes=REPLACE(includes,%s,''), pitch=REPLACE(pitch,%s,'')", $gph, $gph ) );
		}
		// 2.4.0 (M68, the owner's NEW vcmem membership page of 2026-10-14): the facts that changed —
		// assessment within 10 WORKING DAYS (was «3 أيام كحد أقصى»), re-highlight ONCE A MONTH (was
		// «3 مرات شهريًا»), the consultation is with the SMART ADVISOR (was «خبراء النادي»), the club
		// theatre seats 80 (was 60), and the old named coming-soon list became the «شركاؤنا» promo-code
		// benefit. Longest phrases first so strtr rewrites whole sentences before the catch-alls.
		$m68 = array(
			'أولوية عرض مشروعك على المستثمرين خلال 3 أيام كحد أقصى، ونشره 3 مرات شهريًا' => 'تقييم مشروعك خلال 10 أيام عمل وعرضه على المستثمرين بأولوية، وإعادة إبرازه مرة كل شهر',
			'أولوية عرض مشروعه على المستثمرين خلال 3 أيام كحد أقصى ونشره 3 مرات شهريًا' => 'تقييم مشروعه خلال 10 أيام عمل وعرضه على المستثمرين بأولوية وإعادة إبرازه مرة كل شهر',
			'إدراج مشروعك في بنك المشاريع بأولوية خلال 3 أيام كحد أقصى' => 'تقييم مشروعك خلال 10 أيام عمل، وبعد استيفاء معايير القبول يُدرج في بنك المشاريع بأولوية',
			'إعادة نشر مشروعك 3 مرات شهريًا على مجموعات ومنصات النادي' => 'إعادة إبراز مشروعك مرة كل شهر لكافة أعضاء النادي',
			'أولوية عرض مشروعك خلال أيام' => 'تقييم مشروعك خلال 10 أيام عمل',
			'خلال 3 أيام كحد أقصى' => 'خلال 10 أيام عمل',
			'3 مرات شهريًا' => 'مرة كل شهر',
			'استشارة بدون رسوم أونلاين مع خبراء النادي' => 'استشارة أونلاين بدون رسوم مع مستشار ذكي',
			'استشارة أونلاين مع خبراء النادي بدون رسوم' => 'استشارة أونلاين مع مستشار ذكي بدون رسوم',
			'استشارة أونلاين بدون رسوم مع خبراء النادي' => 'استشارة أونلاين بدون رسوم مع مستشار ذكي',
			'استشارات الخبراء بدون رسوم' => 'استشارة أونلاين مع مستشار ذكي بدون رسوم',
			'مع خبراء النادي' => 'مع مستشار ذكي',
			'حتى 60 شخصًا' => 'حتى 80 شخصًا',
			'وخصومات قادمة تُضاف تلقائيًا (وديني القابضة، تطبيق سكة، وديني سكاي، مساحات PV)' => 'وبرومو كود «شركاؤنا» الشخصي في تطبيق النادي يفتح خصومات شركاء النادي، وخصومات جديدة تُضاف تلقائيًا',
			'خصومات قادمة تُضاف تلقائيًا: وديني القابضة، تطبيق سكة، وديني سكاي، مساحات PV' => 'برومو كود «شركاؤنا» الشخصي في تطبيق النادي يفتح خصومات شركاء النادي، وخصومات جديدة تُضاف تلقائيًا',
			// 2.6.0 (brand, owner 2026-10-15, approved): the trade name is written in LATIN «Vibes Ventures»
			// even inside Arabic copy — «فايبز/ڤايبز القابضة», «منظومة ڤايبز» and the transliteration
			// «فيبس فينشرز» leave every live text through this same sweep (catalog below, settings via $swap).
			// Prefixed forms first («بـ / لـ / و»); domains and file names carry no Arabic, so they are untouched.
			'ومنظومة ڤايبز القابضة' => 'و Vibes Ventures',
			'بمنظومة ڤايبز القابضة' => 'بـ Vibes Ventures',
			'لمنظومة ڤايبز القابضة' => 'لـ Vibes Ventures',
			'منظومة ڤايبز القابضة'  => 'Vibes Ventures',
			'ومنظومة ڤايبز'         => 'و Vibes Ventures',
			'بمنظومة ڤايبز'         => 'بـ Vibes Ventures',
			'لمنظومة ڤايبز'         => 'لـ Vibes Ventures',
			'منظومة ڤايبز'          => 'Vibes Ventures',
			'وڤايبز القابضة'        => 'و Vibes Ventures',
			'بڤايبز القابضة'        => 'بـ Vibes Ventures',
			'لڤايبز القابضة'        => 'لـ Vibes Ventures',
			'ڤايبز القابضة'         => 'Vibes Ventures',
			'وفايبز القابضة'        => 'و Vibes Ventures',
			'بفايبز القابضة'        => 'بـ Vibes Ventures',
			'لفايبز القابضة'        => 'لـ Vibes Ventures',
			'فايبز القابضة'         => 'Vibes Ventures',
			'فيبس فينشرز'           => 'Vibes Ventures',
			'شركة ذبذبات للاستثمار القابضة' => 'Vibes Ventures Company Holding',
			'Vibes Holding ecosystem'       => 'Vibes Ventures',
			'Vibes Holding'                 => 'Vibes Ventures',
		);
		foreach ( $m68 as $old => $new ) {
			$wpdb->query( $wpdb->prepare( "UPDATE $svc SET includes=REPLACE(includes,%s,%s), pitch=REPLACE(pitch,%s,%s), payment_terms=REPLACE(payment_terms,%s,%s)", $old, $new, $old, $new, $old, $new ) );
		}
		$swap = array(
			"
الانضمام إلى قروبات النادي" => '',
			'، والانضمام إلى قروبات النادي' => '',
			' والانضمام لمجموعات النادي' => '',
			'الانضمام إلى قروبات النادي' => '',
			'الانضمام لمجموعات النادي' => '',
			"
Joining the club groups" => '',
			'Joining the club groups' => '',
			'3,750' => '2,500',
			'https://paymob.link/VIRWW' => $gate . 'membership',
			'https://paymob.link/tH3EE' => $gate . 'workshop',
			'https://paymob.link/gSyCE' => $gate . 'pitchdeck',
			'https://paymob.link/2rXb1' => $gate . 'pitchdeck',
			'https://paymob.link/vkfVr' => $gate . 'urmeet',
		) + $m68;
		$stg  = vai_settings();
		$hit  = 0;
		foreach ( $stg as $k => $v ) {
			if ( 'paymob_direct' === $k || ! is_string( $v ) ) {
				continue; // the direct-links setting keeps the REAL Paymob links — everything else is swept
			}
			$nv = strtr( $v, $swap );
			if ( $nv !== $v ) {
				$stg[ $k ] = $nv;
				$hit++;
			}
		}
		if ( $hit ) {
			update_option( 'vai_settings', $stg, false );
		}
		update_option( 'vai_db_version', self::DB_VERSION, false );
		self::seed();
		self::self_site();
		self::migrate_membership_model();
		self::migrate_membership_five();
		self::migrate_gates_v22();
		self::migrate_v23();
		self::migrate_v26();
		if ( class_exists( 'VAI_Payments' ) ) {
			VAI_Payments::install();
		}
	}

	/**
	 * One-time for 2.7: fill contacts.verified_at and the member history (vai_events) from what 2.6 stored.
	 * Idempotent (NOT EXISTS / unique ref_key), bounded (a few batches per request, resumes on the next one), never fatal.
	 */
	public static function migrate_v27() {
		global $wpdb;
		if ( get_option( 'vai_migrated_v27' ) === '1' ) {
			return;
		}
		// Only what 2.6 stored is backfilled. From this moment on every change writes its own history row, so the
		// backfill never touches a payment that a live Paymob callback is still working on.
		if ( ! get_option( 'vai_v27_cutoff' ) ) {
			add_option( 'vai_v27_cutoff', vai_now(), '', false );
		}
		if ( get_transient( 'vai_v27_lock' ) ) {
			return;
		}
		set_transient( 'vai_v27_lock', 1, 60 );
		$tries = (int) get_option( 'vai_v27_tries', 0 ) + 1;
		update_option( 'vai_v27_tries', $tries, false );
		$et = self::t( 'events' );
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $et ) ) !== $et ) {
			if ( $tries >= 20 ) {
				update_option( 'vai_migrated_v27', '1', true ); // the table never appeared: stop asking on every request
			}
			return;
		}
		$done = true;
		foreach ( array( 'verified_at', 'registered', 'verified', 'paymob', 'started' ) as $step ) {
			if ( ! self::migrate_v27_step( $step ) ) {
				$done = false;
				break;
			}
		}
		if ( $done || $tries >= 200 ) {
			update_option( 'vai_migrated_v27', '1', true );
		}
		// The 60-second lock is left to expire: an unfinished backfill resumes at most once a minute.
	}

	/** One backfill step in batches of 500 rows (at most 6 batches per request). Returns true when nothing is left. */
	private static function migrate_v27_step( $step ) {
		global $wpdb;
		$ct   = self::t( 'contacts' );
		$et   = self::t( 'events' );
		$pt   = $wpdb->prefix . 'vai_payments';
		$std  = max( 1, (int) vai_cfg( 'member_days' ) );
		$size = 500;
		$cut  = (string) get_option( 'vai_v27_cutoff' );
		if ( $cut === '' ) {
			return false; // no cutoff stored yet: try again on a later request (bounded by vai_v27_tries)
		}
		if ( $step === 'paymob' && $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $pt ) ) !== $pt ) {
			return true;
		}
		for ( $i = 0; $i < 6; $i++ ) {
			if ( $step === 'verified_at' ) {
				$sql = $wpdb->prepare( "UPDATE $ct SET verified_at=COALESCE(trial_started_at, created_at) WHERE verified=1 AND verified_at IS NULL AND COALESCE(trial_started_at, created_at) IS NOT NULL LIMIT %d", $size );
			} elseif ( $step === 'registered' ) {
				// 2.6 kept no sign-up time: the verification time (else the contact's first day) stands in, so the old days of the series stay coherent.
				$sql = $wpdb->prepare( "INSERT INTO $et (contact_id, kind, days, source, ref, ref_key, actor_id, note, created_at) SELECT c.id, 'registered', 0, 'manual', '', NULL, 0, %s, COALESCE(c.verified_at, c.created_at) FROM $ct c WHERE (c.verified=1 OR c.pass_hash<>'') AND COALESCE(c.verified_at, c.created_at) IS NOT NULL AND COALESCE(c.verified_at, c.created_at)<%s AND NOT EXISTS (SELECT 1 FROM $et e WHERE e.contact_id=c.id AND e.kind='registered') ORDER BY c.id ASC LIMIT %d", 'backfill', $cut, $size );
			} elseif ( $step === 'verified' ) {
				$sql = $wpdb->prepare( "INSERT INTO $et (contact_id, kind, days, source, ref, ref_key, actor_id, note, created_at) SELECT c.id, 'verified', 0, 'manual', '', NULL, 0, %s, c.verified_at FROM $ct c WHERE c.verified=1 AND c.verified_at IS NOT NULL AND c.verified_at<%s AND NOT EXISTS (SELECT 1 FROM $et e WHERE e.contact_id=c.id AND e.kind='verified') ORDER BY c.id ASC LIMIT %d", 'backfill', $cut, $size );
			} elseif ( $step === 'paymob' ) {
				$sql = $wpdb->prepare( "INSERT IGNORE INTO $et (contact_id, kind, days, source, ref, ref_key, actor_id, note, created_at) SELECT p.contact_id, IF((SELECT COUNT(*) FROM $pt p2 WHERE p2.contact_id=p.contact_id AND p2.success=1 AND p2.action='membership' AND p2.id<p.id)>0, 'renewed', 'activated'), %d, 'paymob', p.txn_id, CONCAT('paymob:', p.txn_id), 0, %s, p.created_at FROM $pt p WHERE p.success=1 AND p.action='membership' AND p.contact_id>0 AND p.txn_id<>'' AND p.created_at<%s AND NOT EXISTS (SELECT 1 FROM $et e WHERE e.ref_key=CONCAT('paymob:', p.txn_id)) ORDER BY p.id ASC LIMIT %d", $std, 'backfill', $cut, $size );
			} else {
				$sql = $wpdb->prepare( "INSERT INTO $et (contact_id, kind, days, source, ref, ref_key, actor_id, note, created_at) SELECT c.id, 'activated', IF(c.member_days>0, c.member_days, %d), 'manual', '', NULL, 0, %s, c.member_started_at FROM $ct c WHERE c.is_member=1 AND c.member_started_at IS NOT NULL AND c.member_started_at<%s AND NOT EXISTS (SELECT 1 FROM $et e WHERE e.contact_id=c.id AND e.kind IN ('activated','renewed')) ORDER BY c.id ASC LIMIT %d", $std, 'backfill', $cut, $size );
			}
			$n = $wpdb->query( $sql );
			if ( $n === false ) {
				return false; // SQL error: try again on a later request (bounded by vai_v27_tries)
			}
			if ( (int) $n < $size ) {
				return true;
			}
		}
		return false;
	}

	/** One-time for 2.6: accept any e-mail domain (OTP already proves the mailbox). */
	private static function migrate_v26() {
		if ( get_option( 'vai_migrated_v26' ) === '1' ) {
			return;
		}
		vai_update_settings( array( 'allowed_email_domains' => '*' ) );
		update_option( 'vai_migrated_v26', '1', false );
		update_option( 'vai_cfg_rev', time(), false );
	}

	/** One-time for 2.3: 2,500 daily replies for members, one management number. */
	private static function migrate_v23() {
		if ( get_option( 'vai_migrated_v23' ) === '1' ) {
			return;
		}
		$patch = array( 'member_daily' => 2500 );
		$mgmt  = (string) vai_cfg( 'mgmt_whatsapp' );
		if ( $mgmt !== '' ) {
			$patch['club_whatsapp'] = $mgmt;
		}
		vai_update_settings( $patch );
		update_option( 'vai_migrated_v23', '1', false );
		update_option( 'vai_cfg_rev', time(), false );
	}

	/** One-time migration to the "annual membership only" model: no free/trial wording, strict caps for non-members. */
	private static function migrate_membership_model() {
		global $wpdb;
		if ( get_option( 'vai_migrated_membership_only' ) === '1' ) {
			return;
		}
		$svc = self::t( 'services' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT id, pitch, vat_note FROM $svc WHERE skey=%s", 'membership' ) );
		if ( $row ) {
			$pitch = (string) $row->pitch;
			if ( strpos( $pitch, 'تجريبية' ) !== false || strpos( $pitch, 'مجاني' ) !== false ) {
				$pitch = 'العضوية تدفع ثمنها من أول خدمة: خصم اصنع ملتقاك وحده 15,000 ريال بينما العضوية 1,900، وخصم البودكاست يوفّر أكثر من 1,000 ريال في الساعة الواحدة. لا توجد عضوية مجانية أو تجريبية — العضوية السنوية فقط، وبعد الدفع يفعّلها الفريق ثم يوثّق العضو حسابه عبر أبشر: https://vcmem.com/investors-club/#subscribe';
				$wpdb->update( $svc, array( 'pitch' => $pitch ), array( 'id' => $row->id ) );
			}
		}
		vai_update_settings( array( 'gate_free' => 6, 'gate_identified' => 4, 'trial_days' => 0 ) );
		update_option( 'vai_migrated_membership_only', '1', false );
		update_option( 'vai_cfg_rev', time(), false );
	}

	/** One-time: anonymous visitors get a single reply before the registration form; unpaid accounts get a few more. */
	private static function migrate_gates_v22() {
		if ( get_option( 'vai_migrated_gates_v22' ) === '1' ) {
			return;
		}
		vai_update_settings( array( 'gate_free' => 1, 'gate_identified' => 6, 'gcc_only' => 1 ) );
		update_option( 'vai_migrated_gates_v22', '1', false );
		update_option( 'vai_cfg_rev', time(), false );
	}

	/** One-time: membership credit is 5 projects (2,500 SAR) + refreshed benefit list in the stored catalog row. */
	private static function migrate_membership_five() {
		global $wpdb;
		if ( get_option( 'vai_migrated_five' ) === '1' ) {
			return;
		}
		$svc = self::t( 'services' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT id, includes, pitch FROM $svc WHERE skey=%s", 'membership' ) );
		if ( $row ) {
			$inc = (string) $row->includes;
			$inc = str_replace( array( 'أصحاب 3 مشاريع', '3 مشاريع', '3 مؤسسين' ), array( 'أصحاب 5 مشاريع', '5 مشاريع', '5 مؤسسين' ), $inc );
			foreach ( array(
				'دخول مقر النادي بالرياض (باركود دخول للأعضاء المشتركين بعد حجز الموعد) وأولوية الحضور في الملتقيات وملتقى 5 دقائق',
				'خصم 50% على مسرح النادي (حتى 80 شخصًا) وقاعة الاجتماعات بلا حدود استخدام',
				'خصم 50% على خدمات المنظومة: اصنع ملتقاك، Pitch Deck، مومنتوم (مواقع وتطبيقات)، بودكاست الملتقى، حقائب الامتياز',
				'كود خصم حتى 20% على منتجات «منفذ»',
				'برومو كود «شركاؤنا» الشخصي في تطبيق النادي يفتح خصومات شركاء النادي، وخصومات جديدة تُضاف تلقائيًا',
				'مستشار خاص بالذكاء الاصطناعي برصيد يومي متجدد على مدار الساعة',
			) as $line ) {
				if ( strpos( $inc, mb_substr( $line, 0, 18, 'UTF-8' ) ) === false ) {
					$inc .= "\n" . $line;
				}
			}
			$pitch = str_replace( array( 'أصحاب 3 مشاريع', '3 مشاريع' ), array( 'أصحاب 5 مشاريع', '5 مشاريع' ), (string) $row->pitch );
			$wpdb->update( $svc, array( 'includes' => $inc, 'pitch' => $pitch ), array( 'id' => $row->id ) );
		}
		update_option( 'vai_migrated_five', '1', false );
		update_option( 'vai_cfg_rev', time(), false );
	}

	private static function seed() {
		global $wpdb;
		$svc = self::t( 'services' );
		if ( (int) $wpdb->get_var( "SELECT COUNT(*) FROM $svc" ) === 0 ) {
			$rows = array(
				array(
					'skey'            => 'membership',
					'name'            => 'عضوية نادي المستثمرين (سنوية)',
					'price'           => '1,900',
					'currency'        => 'ريال',
					'vat_note'        => 'سعر ترويجي لفترة محدودة — القيمة الأساسية 3,900 ريال سنويًا',
					'payment_terms'   => 'دفع إلكتروني مباشر عبر صفحة الدفع الآمنة — اشتراك سنوي',
					'url'             => 'https://vcmem.com/payment/',
					'pay_url'         => 'https://vcmem.com/?vai-pay=membership',
					'member_discount' => '',
					'includes'        => "خصم 50% على خدمة اصنع ملتقاك طوال السنة (توفير 15,000 ريال)\nخصم 50% على إعداد Pitch Deck (توفير 2,500 ريال)\nرصيد 2,500 ريال في بنك المشاريع = التواصل المباشر مع أصحاب 5 مشاريع\nتقييم مشروعك خلال 10 أيام عمل، وبعد استيفاء معايير القبول يُدرج في بنك المشاريع بأولوية\nإعادة إبراز مشروعك مرة كل شهر لكافة أعضاء النادي\nظهورك في مبادرة شخصية ومسيرة بدون رسوم\nرصيد يومي متجدد لمستشار ذكي داخل تطبيق النادي\nاستشارة أونلاين بدون رسوم مع مستشار ذكي\nأولوية في ملتقيات النادي وملتقى 5 دقائق\nمسرح النادي بخصم 50% (80 حضوريًا وحتى 1,000 أونلاين) وغرفة اجتماعات لـ8 أشخاص مع Zoom\nخصم 50% على خدمات مومنتوم (مواقع، تطبيقات، تسويق، مؤثرون) وبودكاست الملتقى وأي حقيبة امتياز\nكود خصم حتى 20% على منتجات «منفذ» من QDT\nبرومو كود «شركاؤنا» الشخصي في تطبيق النادي يفتح خصومات شركاء النادي فورًا",
					'pitch'           => 'العضوية تدفع ثمنها من أول خدمة: خصم اصنع ملتقاك وحده 15,000 ريال بينما العضوية 1,900، وخصم البودكاست يوفّر أكثر من 1,000 ريال في الساعة الواحدة. لا توجد عضوية مجانية أو تجريبية — العضوية السنوية فقط، وبعدها التوثيق عبر أبشر: https://vcmem.com/investors-club/#subscribe',
					'sort'            => 1,
				),
				array(
					'skey'            => 'urmeet',
					'name'            => 'اصنع ملتقاك — ملتقى خاص باسم مشروعك',
					'price'           => '30,000',
					'currency'        => 'ريال',
					'vat_note'        => 'السعر الرسمي للخدمة',
					'payment_terms'   => 'المبلغ كاملًا عند الحجز — والمواعيد والتفاصيل مع الإدارة',
					'url'             => 'https://vibesholding.com/urmeet/',
					'pay_url'         => 'https://vcmem.com/?vai-pay=urmeet',
					'member_discount' => 'خصم 50% لأعضاء النادي (15,000 ريال)',
					'includes'        => "مسرح مجهز يتسع حتى 80 شخصًا مع ضيافة كاملة\nشاشات وصوتيات ومايكات احترافية\nتصوير بأربع كاميرات وبث مباشر عبر Zoom\nمونتاج سينمائي ومحتوى نهائي جاهز للنشر\nخصوصية كاملة وحضور نخبة من أعضاء النادي المهتمين بمجال مشروعك",
					'pitch'           => 'بالتعاون بين Vibes Ventures × بودكاست الملتقى × نادي المستثمرين: صاحب المشروع يعرض مشروعه بنفسه أمام نخبة من الأعضاء في ملتقى خاص باسمه — أسرع طريق للوصول المباشر. تبقى فرصة الشراكة مرتبطة بقوة فكرته وطريقة طرحه. عبارة تُستخدم مرة: «أنت تحضّر رسالتك… ونحن نصنع لك الملتقى الذي يليق بها».',
					'sort'            => 2,
				),
				array(
					'skey'            => 'pitchdeck',
					'name'            => 'إعداد Pitch Deck احترافي',
					'price'           => '5,000',
					'currency'        => 'ريال',
					'vat_note'        => 'سعر خاص مخفّض عبر هذه القناة',
					'payment_terms'   => 'الدفع إلكترونيًا عبر الرابط، ويبدأ الفريق فور الدفع',
					'url'             => 'https://pvspaces.com/sp/',
					'pay_url'         => 'https://vcmem.com/?vai-pay=pitchdeck',
					'member_discount' => 'خصم 50% لأعضاء النادي',
					'includes'        => "قصة شراكة قوية من أول شريحة لآخرها\nإبراز قيمة المشروع وفرص التعاون والنمو\nعرض السوق والنموذج والأرقام والمنافسين بوضوح\nملخص جدوى\nتصميم فاخر ونسخة جاهزة للاجتماعات والإرسال\nبإشراف مشرف مالي وإداري واستشاريين متخصصين",
					'pitch'           => 'تقدمه شركة PV لحاضنات ومسرعات الأعمال (ذبذبات إيجابية). القيمة قبل السعر دائمًا: مشروعه قد يكون ممتازًا لكن الشريك المحتمل لن يرى ذلك ما لم يصله بالطريقة الصحيحة — كثير من التأخر في إيجاد شريك سببه ببساطة غياب عرض احترافي. الـ Pitch Deck شرط لإكمال طلب الانضمام لبوابة شركاء النجاح.',
					'sort'            => 3,
				),
				array(
					'skey'            => 'podcast',
					'name'            => 'إنتاج البودكاست — بودكاست الملتقى',
					'price'           => '',
					'currency'        => 'ريال',
					'vat_note'        => 'حسب الباقة',
					'payment_terms'   => 'الباقات والأسعار على موقع بودكاست الملتقى، والتفاصيل مع فريق الاستوديو',
					'url'             => 'https://almoltaqapodcast.com/',
					'pay_url'         => '',
					'member_discount' => 'خصم خاص لأعضاء النادي',
					'includes'        => "استوديوهات احترافية بالرياض\nتخطيط وتسجيل وإخراج ومونتاج\nنسخ قصيرة للمنصات وتصوير خارجي في أي مكان بالمملكة",
					'pitch'           => 'سؤال الفهم: وش موضوع البودكاست ومن جمهوره؟',
					'sort'            => 4,
				),
				array(
					'skey'            => 'marketing',
					'name'            => 'التسويق الرقمي وخدمات الذكاء الاصطناعي — مومنتوم',
					'price'           => '',
					'currency'        => 'ريال',
					'vat_note'        => 'حسب النطاق',
					'payment_terms'   => 'عرض سعر من الفريق بعد فهم الاحتياج',
					'url'             => 'https://momentummix.com/',
					'pay_url'         => '',
					'member_discount' => 'خصم 50% لأعضاء النادي على باقات مومنتوم',
					'includes'        => "حملات إعلانية وإدارة حسابات ومحتوى\nهوية بصرية ومواقع وتطبيقات\nمساعد ذكي يرد على عملائك على مدار الساعة (مثل هذا المساعد)\nأتمتة ومحتوى بالذكاء الاصطناعي",
					'pitch'           => 'سؤال الفهم: وش مجال نشاطك وهدفك — ظهور وعملاء، أو أتمتة خدمة العملاء؟',
					'sort'            => 5,
				),
				array(
					'skey'            => 'consulting',
					'name'            => 'الاستشارات التجارية',
					'price'           => '',
					'currency'        => 'ريال',
					'vat_note'        => 'حسب الجلسة',
					'payment_terms'   => 'أعضاء النادي: استشارة أونلاين بدون رسوم مع مستشار ذكي — التفاصيل مع الإدارة',
					'url'             => 'https://vcmem.com/',
					'pay_url'         => '',
					'member_discount' => 'بدون رسوم للأعضاء (استشارة أونلاين)',
					'includes'        => "نموذج العمل وخطة التوسع\nتنظيم العمليات\nالتحول للامتياز التجاري",
					'pitch'           => 'سؤال الفهم: وش وضع مشروعك الحين، ووش القرار اللي تحتاج مساعدة فيه؟',
					'sort'            => 6,
				),
			);
			foreach ( $rows as $r ) {
				$wpdb->insert( $svc, $r );
			}
		}

		$forms = self::t( 'forms' );
		if ( (int) $wpdb->get_var( "SELECT COUNT(*) FROM $forms" ) === 0 ) {
			$wpdb->insert(
				$forms,
				array(
					'fkey'      => 'sp',
					'label'     => 'بوابة شركاء النجاح — تسجيل مشروع',
					'url'       => 'https://pvspaces.com/sp/#register',
					'host'      => 'pvspaces.com',
					'field_map' => wp_json_encode(
						array(
							'name'        => array( 'label' => 'الاسم الكامل', 'selector' => '' ),
							'nationality' => array( 'label' => 'الجنسية', 'selector' => '' ),
							'id_number'   => array( 'label' => 'رقم الهوية أو الإقامة', 'selector' => '' ),
							'phone'       => array( 'label' => 'رقم الجوال', 'selector' => '' ),
							'email'       => array( 'label' => 'البريد الإلكتروني', 'selector' => '' ),
							'project'     => array( 'label' => 'اسم المشروع أو الشركة', 'selector' => '' ),
						),
						JSON_UNESCAPED_UNICODE
					),
					'notes'     => 'المرفقات (السجل التجاري وعقد التأسيس) وخانة الموافقة وزر الإرسال يكملها العميل بنفسه.',
				)
			);
		}
	}

	/* ─────────────────────────── sites ─────────────────────────── */

	public static function self_site() {
		global $wpdb;
		$host = vai_home_host();
		$t    = self::t( 'sites' );
		$row  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE host=%s", $host ) );
		if ( ! $row ) {
			$wpdb->insert(
				$t,
				array(
					'name'       => get_bloginfo( 'name' ),
					'host'       => $host,
					'key_hash'   => '',
					'is_self'    => 1,
					'created_at' => vai_now(),
				)
			);
			$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE host=%s", $host ) );
		} elseif ( ! (int) $row->is_self ) {
			$wpdb->update( $t, array( 'is_self' => 1 ), array( 'id' => $row->id ) );
		}
		return $row;
	}

	public static function site_by_key( $key ) {
		global $wpdb;
		$key = trim( (string) $key );
		if ( strlen( $key ) < 20 ) {
			return null;
		}
		$t = self::t( 'sites' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE key_hash=%s AND status='active'", vai_hash( $key ) ) );
	}

	public static function site_by_id( $id ) {
		global $wpdb;
		$t = self::t( 'sites' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE id=%d", (int) $id ) );
	}

	public static function site_hosts() {
		global $wpdb;
		$t = self::t( 'sites' );
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $t ) ) !== $t ) {
			return array();
		}
		$rows = $wpdb->get_col( "SELECT host FROM $t" );
		return array_map( 'vai_norm_host', (array) $rows );
	}

	public static function sites_all() {
		global $wpdb;
		$t = self::t( 'sites' );
		return (array) $wpdb->get_results( "SELECT * FROM $t ORDER BY is_self DESC, id ASC" );
	}

	public static function create_site( $name, $host, $color = '' ) {
		global $wpdb;
		$host = vai_norm_host( $host );
		if ( $host === '' ) {
			return vai_error( 'bad_host', 'الدومين غير صحيح' );
		}
		$key = vai_key( 40 );
		$t   = self::t( 'sites' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE host=%s", $host ) );
		if ( $row ) {
			$wpdb->update(
				$t,
				array(
					'name'     => $name ?: $row->name,
					'key_hash' => vai_hash( $key ),
					'color'    => $color,
					'status'   => 'active',
				),
				array( 'id' => $row->id )
			);
		} else {
			$wpdb->insert(
				$t,
				array(
					'name'       => $name ?: $host,
					'host'       => $host,
					'key_hash'   => vai_hash( $key ),
					'color'      => $color,
					'created_at' => vai_now(),
				)
			);
		}
		return $key;
	}

	/* ─────────────────────────── REST ─────────────────────────── */

	public static function routes() {
		register_rest_route(
			'vibes-ai/v1',
			'/hub/(?P<op>[a-z_]+)',
			array(
				'methods'             => array( 'GET', 'POST' ),
				'permission_callback' => '__return_true',
				'callback'            => array( __CLASS__, 'rest_hub' ),
			)
		);
		// 2.15.3 (owner): the podcast price card on almoltaqapodcast.com verifies a member BY HIS OWN e-mail code —
		// request sends the 4-digit code, verify answers active / needs_payment / expired / not_found. Public, CORS-
		// limited to the origins setting, rate-limited, and nothing about the account leaks before the code is proven.
		register_rest_route(
			'vibes-ai/v1',
			'/member-check',
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'callback'            => array( __CLASS__, 'rest_member_check' ),
			)
		);
		add_filter( 'rest_pre_serve_request', array( __CLASS__, 'member_check_cors' ), 15, 4 ); // after core's open-CORS pass
		register_rest_route(
			'vibes-ai/v1',
			'/hub/admin/(?P<op>[a-z_]+)',
			array(
				'methods'             => array( 'GET', 'POST' ),
				'permission_callback' => function ( $req ) {
					return current_user_can( 'vai_dashboard' ) || current_user_can( 'manage_options' ) || (bool) self::session_admin( $req );
				},
				'callback'            => array( __CLASS__, 'rest_admin' ),
			)
		);
	}

	/** 2.15.3: CORS for the member-check route only. WordPress core already echoes ANY origin on public REST
	 * routes, so this runs AFTER core and actively STRIPS the headers for origins outside the setting — the
	 * browser then blocks the response for every site that is not ours. */
	public static function member_check_cors( $served, $result, $req, $server ) {
		if ( strpos( (string) $req->get_route(), '/vibes-ai/v1/member-check' ) !== 0 ) {
			return $served;
		}
		$origin  = isset( $_SERVER['HTTP_ORIGIN'] ) ? esc_url_raw( wp_unslash( $_SERVER['HTTP_ORIGIN'] ) ) : '';
		$allowed = array_filter( array_map( 'trim', explode( ',', (string) vai_opt( 'member_check_origins', 'https://almoltaqapodcast.com,https://www.almoltaqapodcast.com' ) ) ) );
		$self    = untrailingslashit( home_url() );
		$ok      = $origin !== '' && ( untrailingslashit( $origin ) === $self || in_array( untrailingslashit( $origin ), array_map( 'untrailingslashit', $allowed ), true ) );
		if ( $origin === '' ) {
			return $served; // same-origin / server-to-server: nothing to decide
		}
		if ( ! $ok && ! headers_sent() ) {
			header_remove( 'Access-Control-Allow-Origin' );
			header_remove( 'Access-Control-Allow-Credentials' );
			return $served;
		}
		if ( ! headers_sent() ) {
			header( 'Access-Control-Allow-Origin: ' . $origin );
			header_remove( 'Access-Control-Allow-Credentials' ); // no cookies cross-site — the code is the proof
			header( 'Vary: Origin' );
			header( 'Access-Control-Allow-Methods: POST, OPTIONS' );
			header( 'Access-Control-Allow-Headers: Content-Type' );
			header( 'Access-Control-Max-Age: 600' );
		}
		return $served;
	}

	/** 2.15.3: the price-card member check — op=request mails the code, op=verify answers the membership state. */
	public static function rest_member_check( WP_REST_Request $req ) {
		global $wpdb;
		nocache_headers();
		$op    = sanitize_key( (string) $req->get_param( 'op' ) );
		$email = vai_norm_email( sanitize_text_field( (string) $req->get_param( 'email' ) ) );
		$ip    = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '';
		$fail  = function ( $code, $text, $status = 400 ) {
			return new WP_REST_Response( array( 'ok' => false, 'error' => $code, 'text' => $text ), $status );
		};
		if ( $email === '' || ! is_email( $email ) ) {
			return $fail( 'invalid', 'اكتب بريدك الإلكتروني المسجّل في نادي المستثمرين' );
		}
		$tk  = 'vai_mcheck_' . md5( $ip );
		$hit = (int) get_transient( $tk );
		if ( $hit >= 10 ) {
			return $fail( 'rate', 'محاولات كثيرة — حاول بعد ساعة', 429 );
		}
		set_transient( $tk, $hit + 1, HOUR_IN_SECONDS );
		$c = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'contacts' ) . " WHERE email_norm=%s ORDER BY (pass_hash<>'') DESC, verified DESC, is_member DESC, id ASC LIMIT 1", $email ) );
		if ( $op === 'request' ) {
			if ( ! $c ) {
				// The card tells him plainly he is not registered yet — the owner's explicit ask.
				return array( 'ok' => true, 'status' => 'not_found' );
			}
			$sent = self::pay_issue_code( (int) $c->id );
			return array( 'ok' => true, 'status' => 'code_sent', 'sent' => $sent ? 1 : 0, 'text' => $sent ? 'أرسلنا رمزًا من 4 أرقام إلى بريدك — اكتبه هنا لإظهار حالة عضويتك.' : 'تعذّر إرسال الرمز — حاول بعد قليل أو تواصل مع الإدارة' );
		}
		if ( $op === 'verify' ) {
			if ( ! $c ) {
				return array( 'ok' => true, 'status' => 'not_found' );
			}
			$tries = (int) get_transient( 'vai_mcheck_v_' . $c->id );
			if ( $tries >= 8 ) {
				return $fail( 'rate', 'محاولات كثيرة — أعد إرسال رمز جديد بعد قليل', 429 );
			}
			set_transient( 'vai_mcheck_v_' . $c->id, $tries + 1, 15 * MINUTE_IN_SECONDS );
			if ( ! self::pay_check_code( (int) $c->id, (string) $req->get_param( 'code' ) ) ) {
				return $fail( 'bad_code', 'الرمز غير صحيح أو انتهت صلاحيته' );
			}
			delete_transient( 'vai_mcheck_v_' . $c->id );
			if ( self::member_active( $c ) ) {
				$days = (int) $c->member_days > 0 ? (int) $c->member_days : (int) vai_cfg( 'member_days' );
				$end  = gmdate( 'Y-m-d', strtotime( $c->member_started_at . ' UTC' ) + $days * 86400 );
				return array( 'ok' => true, 'status' => 'active', 'name' => (string) $c->name, 'email' => (string) $c->email, 'member_end' => $end, 'member_left' => (int) self::member_days_left( $c ) );
			}
			if ( ! (int) $c->is_member && ! empty( $c->member_started_at ) ) {
				return array( 'ok' => true, 'status' => 'expired', 'name' => (string) $c->name );
			}
			return array( 'ok' => true, 'status' => ( (int) $c->is_member ? 'expired' : 'needs_payment' ), 'name' => (string) $c->name );
		}
		return $fail( 'invalid', 'op: request أو verify' );
	}

	public static function rest_hub( WP_REST_Request $req ) {
		$op = $req->get_param( 'op' );
		nocache_headers();

		$site_ops = array( 'config', 'message', 'poll', 'identify', 'member', 'token', 'claim', 'history', 'knowledge', 'ping', 'register', 'login', 'logout', 'account', 'reset_request', 'reset_confirm', 'profile', 'verify', 'resend_code', 'member_status', 'setpass_check', 'setpass', 'delete_account', 'feed', 'google', 'react' );
		$site_ops = array_merge( $site_ops, self::trusted_ops() );
		$tool_ops = array( 'reply', 'search', 'page', 'projects', 'form', 'services', 'contact', 'save_note' );

		if ( in_array( $op, $site_ops, true ) ) {
			$key  = $req->get_header( 'x-vai-site-key' );
			$site = $key ? self::site_by_key( $key ) : null;
			if ( ! $site ) {
				return vai_error( 'unauthorized', 'مفتاح الموقع غير صحيح', 401 );
			}
			$data = vai_body( $req );
			return self::op( $op, $site, $data );
		}

		if ( in_array( $op, $tool_ops, true ) ) {
			// 2.7.0: the tool key comes in the X-VAI-Key header or in the body — never in the query string (it ends up in access logs).
			$key = $req->get_header( 'x-vai-key' );
			if ( ! $key ) {
				$jb  = $req->get_json_params();
				$pb  = $req->get_body_params();
				$key = is_array( $jb ) && isset( $jb['key'] ) ? $jb['key'] : ( is_array( $pb ) && isset( $pb['key'] ) ? $pb['key'] : '' );
			}
			if ( ! $key || ! is_string( $key ) || ! hash_equals( (string) vai_opt( 'hub_key', '' ), (string) $key ) ) {
				return vai_error( 'unauthorized', 'مفتاح الهب غير صحيح', 401 );
			}
			$data = array_merge( (array) $req->get_query_params(), vai_body( $req ) );
			return self::tool( $op, $data );
		}

		return vai_error( 'not_found', 'عملية غير معروفة', 404 );
	}

	public static function rest_admin( WP_REST_Request $req ) {
		nocache_headers();
		$op   = $req->get_param( 'op' );
		$data = array_merge( (array) $req->get_query_params(), vai_body( $req ) );
		$sess = (string) $req->get_header( 'x-vai-session' );
		if ( $sess ) {
			$data['_session'] = $sess;
		}
		return self::admin( $op, $data );
	}

	/* ───────────────────── site-facing operations ───────────────────── */

	public static function op( $op, $site, array $d ) {
		global $wpdb;
		if ( $site && ! empty( $site->id ) ) {
			$wpdb->update( self::t( 'sites' ), array( 'last_seen' => vai_now() ), array( 'id' => $site->id ) );
		}
		$m = 'op_' . $op;
		if ( ! method_exists( __CLASS__, $m ) ) {
			return vai_error( 'not_found', 'عملية غير معروفة', 404 );
		}
		// Privileged ops answer only the site row marked «خادم التطبيق» (never the hub's own row, never the public /client proxy).
		if ( in_array( $op, self::trusted_ops(), true ) && ( ! $site || empty( $site->trusted ) || ! empty( $site->is_self ) ) ) {
			return vai_error( 'forbidden', 'هذه العملية متاحة لخادم التطبيق الموثوق فقط', 403 );
		}
		return self::$m( $site, $d );
	}

	/** Ops that need a trusted site key (2.7.0). Every admin_* op also checks the admin's own uuid (bridge_actor()).
	 * 2.8.0: social_login is trusted-only — only the app server may vouch for a provider-verified e-mail. */
	public static function trusted_ops() {
		return array( 'activate_member', 'social_login', 'changes', 'publish', 'admin_stats', 'admin_accounts', 'admin_member', 'admin_payments', 'admin_tickets', 'admin_leads', 'admin_threads', 'admin_thread', 'admin_reply', 'admin_mail', 'admin_grant', 'admin_set_role', 'send_mail' );
	}

	private static function op_ping( $site, $d ) {
		return array(
			'ok'      => true,
			'hub'     => vai_home_host(),
			'site'    => $site->host,
			'time'    => vai_now(),
			'version' => VAI_VERSION, // 2.7.0: the app server's bridge check reads it here
		);
	}

	public static function widget_config( $site ) {
		$menu  = array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) vai_cfg( 'menu' ) ) ) ) );
		$color = ! empty( $site->color ) ? $site->color : vai_cfg( 'primary_color' );
		return array(
			'bot_name'          => vai_cfg( 'bot_name' ),
			'bot_subtitle'      => vai_cfg( 'bot_subtitle' ),
			'avatar_url'        => vai_cfg( 'avatar_url' ),
			'primary_color'     => $color,
			'welcome'           => vai_cfg( 'welcome' ),
			'menu'              => array_slice( $menu, 0, 8 ),
			'mgmt_whatsapp'     => preg_replace( '/\D+/', '', (string) vai_cfg( 'mgmt_whatsapp' ) ),
			'contact_gate_text' => vai_cfg( 'contact_gate_text' ),
			'member_gate_text'  => vai_cfg( 'member_gate_text' ),
			'membership'        => self::service_card( 'membership' ),
			'rate_per_hour'     => (int) vai_cfg( 'rate_per_hour' ),
			'reply_timeout'     => (int) vai_cfg( 'reply_timeout' ),
			'saudi_only'        => (int) vai_cfg( 'saudi_only' ) ? 1 : 0,
			'launcher_style'    => vai_cfg( 'launcher_style' ) === 'logo' ? 'logo' : 'whatsapp',
			'trial_days'        => 0,
			'unsaved_note'      => vai_cfg( 'unsaved_note' ),
			'unpaid_note'       => vai_cfg( 'unpaid_note' ),
			'gcc_only'          => (int) vai_cfg( 'gcc_only' ) ? 1 : 0,
			'member_services'   => vai_member_services(),
			'wa_members_only'   => (int) vai_cfg( 'wa_members_only' ) ? 1 : 0,
			'counter_show_at'   => 100,
			'countries'         => array_map( function ( $k, $v ) { return array( 'k' => $k, 'n' => $v['name'], 'en' => $v['en'], 'c' => $v['code'], 'f' => $v['flag'], 'e' => $v['example'] ); }, array_keys( vai_gcc_countries() ), vai_gcc_countries() ),
			'phone_policy'      => vai_phone_policy_text(),
			'account_gate_text' => vai_cfg( 'account_gate_text' ),
			'nav_mode'          => vai_cfg( 'nav_mode' ) === 'auto' ? 'auto' : 'button',
			'console_url'       => home_url( '/?vai-console=1' ),
			'member_days'       => (int) vai_cfg( 'member_days' ),
			'account_pill'      => (int) vai_cfg( 'account_pill' ) ? 1 : 0,
			'account_bar'       => (int) vai_cfg( 'account_bar2' ) ? 1 : 0,
			'mobile_mode'       => vai_cfg( 'mobile_mode' ) === 'full' ? 'full' : 'compact',
			'voice'             => ( (int) vai_cfg( 'voice_enabled' ) && trim( (string) vai_opt( 'openai_key', '' ) ) !== '' ) ? 1 : 0,
			'rev'               => (int) get_option( 'vai_cfg_rev', 0 ),
			'links'             => array_map( function ( $l ) { return array( 'l' => $l['label'], 'u' => $l['url'], 'k' => $l['keywords'] ); }, vai_links() ),
			'welcome_links'     => vai_welcome_links(),
			'pill_position'     => in_array( vai_cfg( 'pill_position' ), array( 'top-left', 'top-right', 'bottom', 'opposite' ), true ) ? vai_cfg( 'pill_position' ) : 'opposite',
			'site_name'         => $site->name,
			// 2.9.0 (M49): a public value; non-empty = the widget shows «المتابعة بحساب Google».
			'google_client_id'  => trim( (string) vai_opt( 'google_client_id', '' ) ),
			'version'           => VAI_VERSION,
		);
	}

	private static function op_config( $site, $d ) {
		return array(
			'ok'     => true,
			'config' => self::widget_config( $site ),
		);
	}

	/* contacts / visitors */

	private static function resolve_contact( $site, $uuid, $create = true, $meta = array() ) {
		global $wpdb;
		$uuid = preg_replace( '/[^a-zA-Z0-9\-]/', '', (string) $uuid );
		if ( strlen( $uuid ) < 8 ) {
			return array( null, null );
		}
		$vt = self::t( 'visitors' );
		$ct = self::t( 'contacts' );
		$v  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $vt WHERE uuid=%s AND site_id=%d", $uuid, $site->id ) );
		if ( $v ) {
			$c = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $ct WHERE id=%d", $v->contact_id ) );
			if ( $c ) {
				return array( $c, $v );
			}
		}
		if ( ! $create ) {
			return array( null, null );
		}
		$now = vai_now();
		$wpdb->insert(
			$ct,
			array(
				'first_at'     => $now,
				'last_at'      => $now,
				'sites'        => wp_json_encode( array( $site->host ) ),
				'last_site_id' => $site->id,
				'ip_hash'      => isset( $meta['ip'] ) ? vai_hash( $meta['ip'] ) : '',
				'created_at'   => $now,
			)
		);
		$cid = (int) $wpdb->insert_id;
		if ( $v ) {
			$wpdb->update( $vt, array( 'contact_id' => $cid, 'last_at' => $now ), array( 'id' => $v->id ) );
		} else {
			$wpdb->insert(
				$vt,
				array(
					'uuid'       => $uuid,
					'site_id'    => $site->id,
					'contact_id' => $cid,
					'first_at'   => $now,
					'last_at'    => $now,
				)
			);
		}
		$c = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $ct WHERE id=%d", $cid ) );
		$v = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $vt WHERE uuid=%s AND site_id=%d", $uuid, $site->id ) );
		return array( $c, $v );
	}

	public static function contact( $id ) {
		global $wpdb;
		$ct = self::t( 'contacts' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $ct WHERE id=%d", (int) $id ) );
	}

	public static function trial_days_left( $c ) {
		if ( ! $c || empty( $c->trial_started_at ) ) {
			return null;
		}
		$days = (int) vai_cfg( 'trial_days' );
		$end  = strtotime( $c->trial_started_at . ' UTC' ) + $days * 86400;
		return (int) ceil( ( $end - time() ) / 86400 );
	}

	public static function member_days_left( $c ) {
		if ( ! $c || ! (int) $c->is_member || empty( $c->member_started_at ) ) {
			return null;
		}
		$days = (int) $c->member_days > 0 ? (int) $c->member_days : (int) vai_cfg( 'member_days' );
		$end  = strtotime( $c->member_started_at . ' UTC' ) + $days * 86400;
		return (int) ceil( ( $end - time() ) / 86400 );
	}

	public static function member_active( $c ) {
		if ( ! $c || ! (int) $c->is_member ) {
			return false;
		}
		$left = self::member_days_left( $c );
		return $left === null || $left > 0;
	}

	/**
	 * Mark a contact as a paid member for N days (default setting), starting now — or cancel the membership.
	 * Same signature and effect as before 2.7.0; it now goes through member_change() so the history is recorded.
	 */
	public static function set_member( $contact_id, $on = true, $days = 0 ) {
		$ctx              = is_array( self::$member_ctx ) ? self::$member_ctx : array( 'source' => 'manual', 'ref' => '', 'actor_id' => 0, 'note' => '' );
		self::$member_ctx = null;
		$res              = self::member_change( $contact_id, $on ? 'activate' : 'revoke', $days, $ctx['source'], $ctx['ref'], $ctx['actor_id'], $ctx['note'] );
		return ( is_array( $res ) && ! empty( $res['ok'] ) ) ? true : false;
	}

	/** Tell the NEXT set_member() call where the change comes from (paymob / list / manual …) and its reference. */
	public static function member_context( $source, $ref = '', $actor_id = 0, $note = '' ) {
		self::$member_ctx = array( 'source' => (string) $source, 'ref' => (string) $ref, 'actor_id' => (int) $actor_id, 'note' => (string) $note );
	}

	/**
	 * The one place that changes a membership (2.7.0). $action: activate | extend | revoke.
	 *  - idempotent on source:ref (a repeated store webhook answers already:true and changes nothing); a reference that
	 *    another contact already used answers ok:false, conflict:true;
	 *  - activate: the counter starts now (what set_member() always did);
	 *  - extend: an active member keeps member_started_at and gets the days added; a new or lapsed one starts now;
	 *  - revoke: membership off.
	 * Returns false when the contact does not exist, else array( ok, already, kind, event_id ) — ok:false carries
	 * error 'db_error' (nothing was written, the caller may try again) or 'reference_used' (conflict).
	 */
	public static function member_change( $contact_id, $action, $days = 0, $source = 'manual', $ref = '', $actor_id = 0, $note = '' ) {
		if ( ! self::contact( $contact_id ) ) {
			return false;
		}
		$std = (int) vai_cfg( 'member_days' );
		$a   = array(
			'action'   => in_array( $action, array( 'activate', 'extend', 'revoke' ), true ) ? $action : 'activate',
			'days'     => (int) $days > 0 ? (int) $days : $std,
			'std'      => $std,
			'source'   => self::clean_source( $source ),
			'ref'      => self::clean_ref( $ref ),
			'actor_id' => (int) $actor_id,
			'note'     => (string) $note,
		);
		$res = self::member_write( (int) $contact_id, $a );
		if ( isset( $res['error'] ) && $res['error'] === 'db_error' ) {
			$res = self::member_write( (int) $contact_id, $a ); // once more: a deadlock or a lock wait is over by now
		}
		if ( ! empty( $res['ok'] ) && empty( $res['already'] ) ) {
			self::member_after( $res, $a );
		}
		unset( $res['contact'], $res['branch'] );
		return $res;
	}

	/**
	 * History row + membership columns in ONE transaction: both are written or neither, and the row lock makes two
	 * changes of the same contact wait for each other (InnoDB; on MyISAM the statements still run one by one and a
	 * failed update takes its history row back). No mail and no HTTP call in here — the lock is held for a moment only.
	 */
	private static function member_write( $contact_id, array $a ) {
		global $wpdb;
		$ct = self::t( 'contacts' );
		$wpdb->query( 'START TRANSACTION' );
		$c   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $ct WHERE id=%d FOR UPDATE", (int) $contact_id ) );
		$res = $c ? self::member_write_locked( $c, $a ) : array( 'ok' => false, 'error' => 'db_error', 'kind' => '', 'event_id' => 0 );
		$wpdb->query( ( ! empty( $res['ok'] ) && empty( $res['already'] ) ) ? 'COMMIT' : 'ROLLBACK' );
		if ( ! empty( $res['undo'] ) ) {
			$wpdb->delete( self::t( 'events' ), array( 'id' => (int) $res['undo'] ) ); // MyISAM has no rollback
		}
		unset( $res['undo'] );
		if ( $c && ! empty( $res['no_event'] ) ) {
			return self::member_write_plain( $c, $a, $res['kind'] );
		}
		return $res;
	}

	/** Inside the transaction of member_write(): reference check, history row, membership columns. */
	private static function member_write_locked( $c, array $a ) {
		$hit = $a['ref'] !== '' ? self::event_by_ref( $a['source'], $a['ref'] ) : null;
		if ( $hit ) {
			return self::ref_hit( $hit, $c );
		}
		$kind = $a['action'] === 'revoke' ? 'revoked' : ( (int) $c->is_member === 1 ? 'renewed' : 'activated' );
		// The history row goes first: its unique ref_key is what stops a parallel duplicate of the same reference.
		$eid = self::insert_event( $c->id, $kind, $a['action'] === 'revoke' ? 0 : $a['days'], $a['source'], $a['ref'], $a['actor_id'], $a['note'] );
		if ( ! $eid ) {
			return array( 'ok' => false, 'no_event' => true, 'kind' => $kind );
		}
		$branch = self::member_apply( $c, $a );
		if ( $branch === '' ) {
			return array( 'ok' => false, 'error' => 'db_error', 'undo' => (int) $eid, 'kind' => '', 'event_id' => 0 );
		}
		return array( 'ok' => true, 'already' => false, 'kind' => $kind, 'event_id' => (int) $eid, 'branch' => $branch, 'contact' => $c );
	}

	/**
	 * The history row could not be written. After the rollback a plain read sees what a parallel request committed: the
	 * same reference → already / conflict. No such row → the history table itself is in trouble, and the membership
	 * still changes, as it did before 2.7.0 (a paid member is never left inactive because of the history).
	 */
	private static function member_write_plain( $c, array $a, $kind ) {
		$hit = $a['ref'] !== '' ? self::event_by_ref( $a['source'], $a['ref'] ) : null;
		if ( $hit ) {
			return self::ref_hit( $hit, $c );
		}
		$branch = self::member_apply( $c, $a );
		if ( $branch === '' ) {
			return array( 'ok' => false, 'error' => 'db_error', 'kind' => '', 'event_id' => 0 );
		}
		return array( 'ok' => true, 'already' => false, 'kind' => (string) $kind, 'event_id' => 0, 'branch' => $branch, 'contact' => $c );
	}

	/** A reference that was used before: by the same contact → already (nothing changes); by another one → conflict. */
	private static function ref_hit( $hit, $c ) {
		if ( (int) $hit->contact_id === (int) $c->id ) {
			return array( 'ok' => true, 'already' => true, 'kind' => '', 'event_id' => 0 );
		}
		return array( 'ok' => false, 'already' => false, 'conflict' => true, 'error' => 'reference_used', 'kind' => '', 'event_id' => 0 );
	}

	/** Write the membership columns. Returns the branch taken (revoke | extend | open | start), or '' when the database refused. */
	private static function member_apply( $c, array $a ) {
		global $wpdb;
		$ct     = self::t( 'contacts' );
		$active = self::member_active( $c );
		if ( $a['action'] === 'revoke' ) {
			$ok = $wpdb->update( $ct, array( 'is_member' => 0, 'stage' => max( 1, (int) $c->stage === 2 ? 1 : (int) $c->stage ), 'member_started_at' => null, 'member_days' => 0, 'member_welcomed' => 0 ), array( 'id' => $c->id ) );
			return $ok === false ? '' : 'revoke';
		}
		if ( $a['action'] === 'extend' && $active && ! empty( $c->member_started_at ) ) {
			// One statement: two renewals at the same moment both count (no read-modify-write).
			$ok = $wpdb->query( $wpdb->prepare( "UPDATE $ct SET member_days=IF(member_days>0, member_days, %d)+%d WHERE id=%d", (int) $a['std'], (int) $a['days'], (int) $c->id ) );
			return $ok === false ? '' : 'extend';
		}
		if ( $a['action'] === 'extend' && $active ) {
			return 'open'; // a member without a start date never expires: nothing to add, the history row is the record
		}
		$ok = $wpdb->update( $ct, array( 'is_member' => 1, 'stage' => 2, 'member_started_at' => vai_now(), 'member_days' => (int) $a['days'], 'member_welcomed' => 0 ), array( 'id' => $c->id ) );
		return $ok === false ? '' : 'start';
	}

	/** After the commit: member.changed for the app server, the system line in the thread, the welcome mail. */
	private static function member_after( array $res, array $a ) {
		$c    = $res['contact'];
		$site = (int) $c->last_site_id;
		$days = (int) $a['days'];
		self::webhook( 'member.changed', array( 'contact_id' => (int) $c->id, 'kind' => (string) $res['kind'] ) );
		if ( $res['branch'] === 'revoke' ) {
			self::insert_message( $c->id, $site, 'system', 'أُلغيت العضوية المدفوعة' );
		} elseif ( $res['branch'] === 'extend' ) {
			self::insert_message( $c->id, $site, 'system', 'مُدّدت العضوية المدفوعة ' . $days . ' يومًا ⭐ (الأيام المتبقية محفوظة)' );
		} elseif ( $res['branch'] === 'open' ) {
			self::insert_message( $c->id, $site, 'system', 'تجديد عضوية (' . $days . ' يومًا) لعضو بلا تاريخ انتهاء ⭐' );
		} else {
			self::insert_message( $c->id, $site, 'system', 'تحوّل إلى عضوية مدفوعة (' . $days . ' يومًا) ⭐' );
			// activate = the 2.6 behaviour (always mails); extend mails only on a first activation.
			if ( ( $a['action'] === 'activate' || (int) $c->is_member !== 1 ) && class_exists( 'VAI_Payments' ) ) {
				VAI_Payments::send_member_welcome( self::contact( $c->id ) );
			}
		}
	}

	/* ───────────── member history (vai_events, 2.7.0) ───────────── */

	private static function clean_source( $source ) {
		$source = preg_replace( '/[^a-z]/', '', strtolower( (string) $source ) );
		return in_array( $source, array( 'paymob', 'store', 'admin', 'list', 'manual', 'app' ), true ) ? $source : 'manual';
	}

	private static function clean_ref( $ref ) {
		return substr( preg_replace( '/[^A-Za-z0-9._:\-]/', '', (string) $ref ), 0, 150 );
	}

	private static function event_by_ref( $source, $ref ) {
		global $wpdb;
		$et = self::t( 'events' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $et WHERE ref_key=%s LIMIT 1", $source . ':' . $ref ) );
	}

	private static function has_event( $contact_id, $kind ) {
		global $wpdb;
		$et = self::t( 'events' );
		return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $et WHERE contact_id=%d AND kind=%s LIMIT 1", (int) $contact_id, (string) $kind ) );
	}

	/** Write one history row and tell the app server (member.changed). Returns the row id, or 0 when nothing was written. */
	public static function log_event( $contact_id, $kind, $days = 0, $source = 'manual', $ref = '', $actor_id = 0, $note = '' ) {
		$id = self::insert_event( $contact_id, $kind, $days, $source, $ref, $actor_id, $note );
		if ( $id ) {
			self::webhook( 'member.changed', array( 'contact_id' => (int) $contact_id, 'kind' => (string) $kind ) );
		}
		return $id;
	}

	/** The history row alone (member_change() tells the app server itself, after its commit). Returns the row id or 0. */
	private static function insert_event( $contact_id, $kind, $days, $source, $ref, $actor_id, $note ) {
		global $wpdb;
		$source = self::clean_source( $source );
		$ref    = self::clean_ref( $ref );
		$ok     = $wpdb->insert(
			self::t( 'events' ),
			array(
				'contact_id' => (int) $contact_id,
				'kind'       => (string) $kind,
				'days'       => (int) $days,
				'source'     => $source,
				'ref'        => $ref,
				'ref_key'    => $ref !== '' ? substr( $source . ':' . $ref, 0, 190 ) : null,
				'actor_id'   => (int) $actor_id,
				'note'       => vai_clip( (string) $note, 250 ),
				'created_at' => vai_now(),
			)
		);
		return $ok ? (int) $wpdb->insert_id : 0;
	}

	/** registered / verified are written once per contact, whatever path the account took. */
	private static function log_event_once( $contact_id, $kind, $source, $note = '' ) {
		if ( self::has_event( $contact_id, $kind ) ) {
			return 0;
		}
		return self::log_event( $contact_id, $kind, 0, $source, '', 0, $note );
	}

	/** The account's e-mail (or payment) is proven: stamp contacts.verified_at once and write the «verified» event. */
	public static function note_verified( $contact_id, $source, $note = '' ) {
		global $wpdb;
		$ct = self::t( 'contacts' );
		$wpdb->query( $wpdb->prepare( "UPDATE $ct SET verified_at=%s WHERE id=%d AND verified_at IS NULL", vai_now(), (int) $contact_id ) );
		self::log_event_once( $contact_id, 'verified', $source, $note );
	}

	/** Event source for a site-facing op: the trusted app server is «app», any website is «manual» (the host goes in the note). */
	private static function site_source( $site ) {
		return ( $site && ! empty( $site->trusted ) ) ? 'app' : 'manual';
	}

	/* ───────────── webhook hub → app server (instant sync, 2.7.0) ───────────── */

	/**
	 * Queue an event for the app server. Sent once at the end of the request (non-blocking, 3 s), signed with
	 * X-VAI-Signature: sha256=hmac_sha256( timestamp . "." . raw_body, app_webhook_secret ). No personal data in the body.
	 */
	public static function webhook( $event, array $data = array() ) {
		if ( trim( (string) vai_opt( 'app_webhook_url', '' ) ) === '' || trim( (string) vai_opt( 'app_webhook_secret', '' ) ) === '' ) {
			return;
		}
		$key = md5( $event . '|' . wp_json_encode( $data ) );
		if ( ! self::$webhook_queue ) {
			add_action( 'shutdown', array( __CLASS__, 'webhook_flush' ), 1000 ); // late: the page and the other shutdown hooks are done
		}
		self::$webhook_queue[ $key ] = array( 'event' => (string) $event, 'at' => vai_now(), 'data' => $data );
	}

	public static function webhook_flush() {
		$queue               = self::$webhook_queue;
		self::$webhook_queue = array();
		$url                 = esc_url_raw( trim( (string) vai_opt( 'app_webhook_url', '' ) ) );
		$secret              = trim( (string) vai_opt( 'app_webhook_secret', '' ) );
		if ( ! $queue || $url === '' || $secret === '' || get_transient( 'vai_webhook_down' ) ) {
			return;
		}
		self::release_client();
		foreach ( array_slice( $queue, 0, 20 ) as $ev ) {
			$body = wp_json_encode( $ev );
			$ts   = (string) time();
			$t0   = microtime( true );
			wp_remote_post(
				$url,
				array(
					'timeout'  => 3,
					'blocking' => false,
					'headers'  => array(
						'Content-Type'    => 'application/json; charset=utf-8',
						'X-VAI-Timestamp' => $ts,
						'X-VAI-Signature' => 'sha256=' . hash_hmac( 'sha256', $ts . '.' . $body, $secret ),
						'User-Agent'      => 'VibesAI/' . VAI_VERSION,
					),
					'body'     => $body,
				)
			);
			// WordPress's cURL transport waits for the answer even with blocking=false. An app server that does not answer
			// costs the whole timeout: stop here and leave it alone for a minute (it catches up with changes / admin_* by itself).
			if ( microtime( true ) - $t0 > 2.5 ) {
				set_transient( 'vai_webhook_down', 1, 60 );
				break;
			}
		}
	}

	/**
	 * Hand the finished response to the caller before the slow follow-up work (PHP-FPM, LiteSpeed; a no-op elsewhere),
	 * so the Paymob callback, n8n and the widget never wait for the app server.
	 */
	private static function release_client() {
		if ( function_exists( 'fastcgi_finish_request' ) ) {
			fastcgi_finish_request();
		} elseif ( function_exists( 'litespeed_finish_request' ) ) {
			litespeed_finish_request();
		}
	}

	/** vai_cfg_rev moves whenever the owner saves settings, instructions or services → config.changed. */
	public static function on_cfg_rev( $old, $new ) {
		self::webhook( 'config.changed', array( 'rev' => (int) $new ) );
	}

	public static function public_contact( $c ) {
		if ( ! $c ) {
			return null;
		}
		$left  = null;
		$daily = (int) vai_cfg( 'member_daily' );
		return array(
			'id'          => (int) $c->id,
			'name'        => (string) $c->name,
			'email'       => (string) $c->email,
			'phone'       => (string) $c->phone,
			'stage'       => (int) $c->stage,
			'is_member'   => self::member_active( $c ) ? 1 : 0,
			'member_left' => self::member_days_left( $c ),
			'member_days' => (int) $c->member_days > 0 ? (int) $c->member_days : (int) vai_cfg( 'member_days' ),
			'member_end'  => ! empty( $c->member_started_at ) ? vai_riyadh( gmdate( 'Y-m-d H:i:s', strtotime( $c->member_started_at . ' UTC' ) + ( (int) $c->member_days > 0 ? (int) $c->member_days : (int) vai_cfg( 'member_days' ) ) * 86400 ), 'Y-m-d' ) : '',
			'member_expired' => ( (int) $c->is_member && ! self::member_active( $c ) ) ? 1 : 0,
			'daily_limit' => $daily,
			'daily_left'  => (int) $c->is_member ? max( 0, $daily - self::count_replies_today( $c->id ) ) : null,
			'has_account' => ! empty( $c->pass_hash ) ? 1 : 0,
			'verified'    => (int) $c->verified ? 1 : 0,
			'role'        => (string) $c->role,
			'is_admin'    => ( $c->role === 'admin' && (int) $c->admin_verified ) ? 1 : 0,
			'job_title'   => (string) $c->job_title,
			'persona'     => (string) $c->persona,
			'website'     => (string) $c->website,
			'social'      => (string) $c->social,
			'avatar'      => (string) $c->avatar_url,
			'company'     => (string) $c->company,
			'member_type' => (string) $c->member_type,
			'city'        => (string) $c->city,
			'bio'         => (string) $c->bio,
			'trial_left'  => null,
			'trial_days'  => 0,
			'trial_end'   => '',
			'pending_pay' => ( ! empty( $c->pass_hash ) && (int) $c->verified && ! (int) $c->is_member ) ? 1 : 0,
		);
	}

	private static function touch_sites( $c, $site ) {
		$sites = json_decode( (string) $c->sites, true );
		if ( ! is_array( $sites ) ) {
			$sites = array();
		}
		if ( ! in_array( $site->host, $sites, true ) ) {
			$sites[] = $site->host;
		}
		return wp_json_encode( array_values( $sites ) );
	}

	private static function count_replies_today( $contact_id ) {
		global $wpdb;
		$mt = self::t( 'messages' );
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $mt WHERE contact_id=%d AND role='assistant' AND created_at>=%s", $contact_id, vai_riyadh_day_start_utc() ) );
	}

	public static function gate_for( $c ) {
		$free  = (int) vai_cfg( 'gate_free' );
		$ident = (int) vai_cfg( 'gate_identified' );
		$daily = (int) vai_cfg( 'member_daily' );
		if ( (int) $c->is_member ) {
			if ( ! self::member_active( $c ) ) {
				return array( 'type' => 'membership', 'left' => 0, 'member_expired' => true );
			}
			if ( $daily > 0 && self::count_replies_today( $c->id ) >= $daily ) {
				return array( 'type' => 'daily', 'left' => 0 );
			}
			return null;
		}
		$registered = ! empty( $c->pass_hash ) && (int) $c->verified;
		if ( ! $registered ) {
			// Anonymous: one reply, then we must know who we are talking to.
			if ( (int) $c->reply_count >= $free ) {
				return array( 'type' => 'contact', 'left' => 0 );
			}
			return null;
		}
		if ( (int) $c->reply_count >= $free + $ident ) {
			return array( 'type' => 'membership', 'left' => 0 );
		}
		return null;
	}

	public static function gate_info( $c ) {
		$free  = (int) vai_cfg( 'gate_free' );
		$ident = (int) vai_cfg( 'gate_identified' );
		if ( (int) $c->is_member && self::member_active( $c ) ) {
			return array( 'next' => 'none', 'mode' => 'paid', 'left' => 999, 'member_days_left' => self::member_days_left( $c ), 'daily_left' => max( 0, (int) vai_cfg( 'member_daily' ) - self::count_replies_today( $c->id ) ), 'member_new' => ! (int) $c->member_welcomed );
		}
		$registered = ! empty( $c->pass_hash ) && (int) $c->verified;
		if ( ! $registered ) {
			return array( 'next' => 'contact', 'mode' => 'anon', 'left' => max( 0, $free - (int) $c->reply_count ), 'first' => (int) $c->reply_count === 0 );
		}
		$every = (int) vai_cfg( 'nudge_every' );
		return array(
			'next'  => 'membership',
			'mode'  => 'free',
			'left'  => max( 0, $free + $ident - (int) $c->reply_count ),
			'nudge' => $every > 0 && (int) $c->reply_count > 0 && ( ( (int) $c->reply_count + 1 ) % $every === 0 ),
			'first' => false,
		);
	}

	private static function gate_payload( $gate, $c ) {
		$type = $gate['type'];
		$out  = array( 'type' => $type );
		if ( $type === 'contact' ) {
			$out['text']  = vai_cfg( 'contact_gate_text' );
			$out['saudi'] = (int) vai_cfg( 'saudi_only' ) ? 1 : 0;
			$out['days']  = 0;
		} elseif ( $type === 'membership' ) {
			$out['text']          = ! empty( $gate['member_expired'] ) ? vai_cfg( 'member_expired_text' ) : vai_cfg( 'member_gate_text' );
			$out['card']          = self::service_card( 'membership' );
			$out['mgmt']          = preg_replace( '/\D+/', '', (string) vai_cfg( 'mgmt_whatsapp' ) );
			$out['needs_account'] = empty( $c->pass_hash ) ? 1 : 0;
		} elseif ( $type === 'daily' ) {
			$out['text'] = 'وصلت لحد الرسائل اليومي للعضوية 🙏 نكمل غدًا بإذن الله — أو تواصل مع الإدارة مباشرة.';
			$out['mgmt'] = preg_replace( '/\D+/', '', (string) vai_cfg( 'mgmt_whatsapp' ) );
		} elseif ( $type === 'site_cap' ) {
			$out['text'] = 'المساعد وصل لحده اليومي على هذا الموقع، تقدر تتواصل مع الإدارة مباشرة أو تعود لاحقًا.';
			$out['mgmt'] = preg_replace( '/\D+/', '', (string) vai_cfg( 'mgmt_whatsapp' ) );
		}
		return $out;
	}

	public static function insert_message( $contact_id, $site_id, $role, $content, $actions = null, $page_url = '', $meta = null ) {
		global $wpdb;
		$wpdb->insert(
			self::t( 'messages' ),
			array(
				'contact_id' => (int) $contact_id,
				'site_id'    => (int) $site_id,
				'role'       => $role,
				'content'    => (string) $content,
				'actions'    => $actions ? wp_json_encode( $actions, JSON_UNESCAPED_UNICODE ) : null,
				'page_url'   => $page_url ? (string) $page_url : null,
				'meta'       => $meta ? wp_json_encode( $meta, JSON_UNESCAPED_UNICODE ) : null,
				'created_at' => vai_now(),
			)
		);
		return (int) $wpdb->insert_id;
	}

	/** Store a data-URL image sent from the widget; returns public URL or ''. */
	private static function store_image( $data_url ) {
		$data_url = (string) $data_url;
		if ( ! preg_match( '~^data:image/(jpeg|jpg|png|webp);base64,([A-Za-z0-9+/=]+)$~', $data_url, $m ) ) {
			return '';
		}
		$ext   = ( $m[1] === 'jpg' || $m[1] === 'jpeg' ) ? 'jpg' : $m[1];
		$bytes = base64_decode( $m[2], true );
		if ( ! $bytes || strlen( $bytes ) > 4 * 1024 * 1024 ) {
			return '';
		}
		$info = @getimagesizefromstring( $bytes );
		if ( ! $info || empty( $info['mime'] ) || strpos( $info['mime'], 'image/' ) !== 0 ) {
			return '';
		}
		$name = 'vai-' . gmdate( 'Ymd' ) . '-' . strtolower( vai_key( 24 ) ) . '.' . $ext;
		$up   = wp_upload_bits( $name, null, $bytes );
		if ( ! empty( $up['error'] ) || empty( $up['url'] ) ) {
			return '';
		}
		return esc_url_raw( $up['url'] );
	}

	/** Quick check of the OpenAI key for voice: lists models (cheap) and reports the HTTP status. */
	public static function voice_test() {
		$key = trim( (string) vai_opt( 'openai_key', '' ) );
		if ( $key === '' ) {
			return array( 'ok' => false, 'msg' => 'مفتاح OpenAI فارغ — الصقه في خانة «مفتاح OpenAI API» واحفظ.' );
		}
		if ( ! (int) vai_cfg( 'voice_enabled' ) ) {
			return array( 'ok' => false, 'msg' => 'المفتاح موجود لكن خيار «تفعيل زر التسجيل الصوتي» غير معلّم — علّمه واحفظ.' );
		}
		$res = wp_remote_get( 'https://api.openai.com/v1/models/whisper-1', array( 'timeout' => 20, 'headers' => array( 'Authorization' => 'Bearer ' . $key ) ) );
		if ( is_wp_error( $res ) ) {
			return array( 'ok' => false, 'msg' => 'تعذّر الوصول إلى OpenAI من الخادم: ' . $res->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		if ( $code === 200 ) {
			return array( 'ok' => true, 'msg' => 'المفتاح صحيح ونموذج التفريغ الصوتي متاح ✅ — الميكروفون سيظهر في الويدجت خلال دقيقة (أو فورًا بعد «اختبار الاتصال بالهب» على الموقع).' );
		}
		$body = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		$err  = is_array( $body ) && isset( $body['error']['message'] ) ? (string) $body['error']['message'] : '';
		return array( 'ok' => false, 'msg' => 'OpenAI رفض المفتاح (كود ' . $code . ')' . ( $err ? ': ' . vai_clip( $err, 160 ) : '' ) . ' — تأكد أنك نسخت المفتاح كاملًا (يبدأ بـ sk-) وأن الحساب فيه رصيد.' );
	}

	/** Store a voice note (data URL) and transcribe it with OpenAI (whisper-1, verbose_json → language). */
	private static function store_audio( $data_url ) {
		$data_url = (string) $data_url;
		if ( ! preg_match( '~^data:(?:audio|video)/([a-z0-9.+-]+)(?:;[^,]*?)?;base64,([A-Za-z0-9+/=]+)$~i', $data_url, $m ) ) {
			update_option( 'vai_last_voice', array( 'at' => vai_now(), 'ok' => 0, 'msg' => 'صيغة الصوت غير مفهومة: ' . vai_clip( substr( $data_url, 0, 60 ), 60 ) ), false );
			return array( 'url' => '', 'text' => '', 'lang' => '', 'error' => 'bad_audio' );
		}
		$mime  = strtolower( $m[1] );
		$bytes = base64_decode( $m[2], true );
		if ( ! $bytes || strlen( $bytes ) > 6 * 1024 * 1024 ) {
			return array( 'url' => '', 'text' => '', 'lang' => '', 'error' => 'too_big' );
		}
		$ext  = strpos( $mime, 'mp4' ) !== false || strpos( $mime, 'm4a' ) !== false ? 'm4a' : ( strpos( $mime, 'ogg' ) !== false ? 'ogg' : ( strpos( $mime, 'mpeg' ) !== false || strpos( $mime, 'mp3' ) !== false ? 'mp3' : 'webm' ) );
		$name = 'vai-voice-' . gmdate( 'Ymd' ) . '-' . strtolower( vai_key( 24 ) ) . '.' . $ext;
		$up   = wp_upload_bits( $name, null, $bytes );
		$url  = empty( $up['error'] ) && ! empty( $up['url'] ) ? esc_url_raw( $up['url'] ) : '';
		$key  = trim( (string) vai_opt( 'openai_key', '' ) );
		if ( $key === '' ) {
			return array( 'url' => $url, 'text' => '', 'lang' => '', 'error' => 'no_key' );
		}
		$boundary = '----vai' . wp_rand( 100000, 999999 );
		$body     = '';
		$fields   = array( 'model' => 'whisper-1', 'response_format' => 'verbose_json', 'temperature' => '0' );
		foreach ( $fields as $k => $v ) {
			$body .= "--$boundary\r\nContent-Disposition: form-data; name=\"$k\"\r\n\r\n$v\r\n";
		}
		$body .= "--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"$name\"\r\nContent-Type: audio/$ext\r\n\r\n" . $bytes . "\r\n--$boundary--\r\n";
		$res = wp_remote_post(
			'https://api.openai.com/v1/audio/transcriptions',
			array(
				'timeout' => 60,
				'headers' => array( 'Authorization' => 'Bearer ' . $key, 'Content-Type' => 'multipart/form-data; boundary=' . $boundary ),
				'body'    => $body,
			)
		);
		if ( is_wp_error( $res ) ) {
			update_option( 'vai_last_voice', array( 'at' => vai_now(), 'ok' => 0, 'msg' => 'تعذّر الاتصال بـ OpenAI: ' . $res->get_error_message() ), false );
			return array( 'url' => $url, 'text' => '', 'lang' => '', 'error' => $res->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$j    = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		if ( $code !== 200 || ! is_array( $j ) || ! isset( $j['text'] ) ) {
			$err = is_array( $j ) && isset( $j['error']['message'] ) ? (string) $j['error']['message'] : '';
			update_option( 'vai_last_voice', array( 'at' => vai_now(), 'ok' => 0, 'msg' => 'OpenAI رفض التفريغ (كود ' . $code . ')' . ( $err ? ': ' . vai_clip( $err, 160 ) : '' ) ), false );
			return array( 'url' => $url, 'text' => '', 'lang' => '', 'error' => 'transcribe_failed:' . $code );
		}
		$txt = trim( (string) $j['text'] );
		update_option( 'vai_last_voice', array( 'at' => vai_now(), 'ok' => 1, 'msg' => 'تم التفريغ ✅ (' . ( $j['language'] ?? '?' ) . '): ' . vai_clip( $txt, 120 ) ), false );
		return array( 'url' => $url, 'text' => $txt, 'lang' => strtolower( (string) ( $j['language'] ?? '' ) ), 'error' => '' );
	}

	private static function op_message( $site, $d ) {
		global $wpdb;
		$text  = vai_text_ok( $d, 'message', 4000 );
		$image = ! empty( $d['image'] ) && is_string( $d['image'] ) ? self::store_image( $d['image'] ) : '';
		$audio = null;
		if ( ! empty( $d['audio'] ) && is_string( $d['audio'] ) && (int) vai_cfg( 'voice_enabled' ) ) {
			$audio = self::store_audio( $d['audio'] );
			if ( $audio['text'] !== '' ) {
				$text = trim( '🎤 ' . $audio['text'] );
			}
		}
		if ( $text === '' && $image === '' && ! $audio ) {
			return vai_error( 'empty', 'الرسالة فارغة' );
		}
		if ( $text === '' ) {
			$text = $audio ? '(رسالة صوتية)' : '(أرسل صورة)';
		}
		list( $c, $v ) = self::resolve_contact( $site, isset( $d['uuid'] ) ? $d['uuid'] : '', true, array( 'ip' => isset( $d['ip'] ) ? $d['ip'] : '' ) );
		if ( ! $c ) {
			return vai_error( 'bad_uuid', 'معرّف الزائر غير صحيح' );
		}
		$ct = self::t( 'contacts' );
		$mt = self::t( 'messages' );

		// Rate limit per contact (per hour).
		$rate = (int) vai_cfg( 'rate_per_hour' );
		if ( $rate > 0 ) {
			$n = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $mt WHERE contact_id=%d AND role='user' AND created_at>=%s", $c->id, gmdate( 'Y-m-d H:i:s', time() - 3600 ) ) );
			if ( $n >= $rate ) {
				return array( 'ok' => true, 'gated' => true, 'gate' => array( 'type' => 'rate', 'text' => 'رسائل كثيرة في وقت قصير 🙏 خذ نفسًا وارجع بعد شوي.' ) );
			}
		}

		// Gate check (before storing).
		$gate = self::gate_for( $c );
		if ( $gate ) {
			return array( 'ok' => true, 'gated' => true, 'gate' => self::gate_payload( $gate, $c ), 'contact' => self::public_contact( $c ) );
		}

		// Site daily cap.
		$cap = (int) vai_cfg( 'site_daily_cap' );
		if ( $cap > 0 ) {
			$n = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $mt WHERE site_id=%d AND role='assistant' AND created_at>=%s", $site->id, vai_riyadh_day_start_utc() ) );
			if ( $n >= $cap ) {
				return array( 'ok' => true, 'gated' => true, 'gate' => self::gate_payload( array( 'type' => 'site_cap' ), $c ) );
			}
		}

		$page_url   = vai_str( $d, 'page_url', 500 );
		$page_title = vai_str( $d, 'page_title', 200 );
		// 2.7.0: what the visitor points at («اسأل المستشار» chip / selection / an app screen) and the live text of the page.
		$focus      = self::clean_focus( isset( $d['context'] ) ? $d['context'] : null );
		$live_text  = vai_text_ok( $d, 'page_text', 6000 );
		$mid        = self::insert_message( $c->id, $site->id, 'user', $text, null, $page_url, array( 'title' => $page_title, 'image' => $image, 'audio' => $audio ? $audio['url'] : '', 'audio_lang' => $audio ? $audio['lang'] : '', 'focus' => $focus ? vai_clip( $focus['title'] !== '' ? $focus['title'] : ( $focus['selection'] !== '' ? $focus['selection'] : $focus['text'] ), 140 ) : '' ) );
		// Voice notes: Arabic only. Anything else (or an undecipherable clip) gets a short canned reply without the model.
		if ( $audio && ( $audio['text'] === '' || ( $audio['lang'] !== '' && $audio['lang'] !== 'arabic' && $audio['lang'] !== 'ar' ) ) ) {
			$canned = $audio['text'] === '' ? ( $audio['error'] === 'no_key' ? 'الرسائل الصوتية غير مفعّلة حاليًا 🙏 اكتب لي رسالتك نصًا.' : 'ما قدرت أفهم الرسالة الصوتية 🙏 أعد تسجيلها بوضوح وبالعربية، أو اكتبها لي نصًا.' ) : 'سمعت رسالتك الصوتية لكن ما فهمتها 🙏 الرسائل الصوتية بالعربية فقط — أعد تسجيلها بالعربية أو اكتب لي بأي لغة تحب.';
			self::insert_message( $c->id, $site->id, 'assistant', $canned );
			$wpdb->update( self::t( 'contacts' ), array( 'msg_count' => (int) $c->msg_count + 1, 'last_at' => vai_now(), 'last_site_id' => $site->id ), array( 'id' => $c->id ) );
			return array( 'ok' => true, 'message_id' => $mid, 'waiting' => true, 'audio_url' => $audio['url'], 'transcript' => $audio['text'], 'contact' => self::public_contact( $c ) );
		}

		$human_active = ! empty( $c->human_until ) && strtotime( $c->human_until . ' UTC' ) > time();
		$now          = vai_now();
		$wpdb->update(
			$ct,
			array(
				'msg_count'      => (int) $c->msg_count + 1,
				'last_at'        => $now,
				'last_site_id'   => $site->id,
				'last_page'      => $page_url,
				'sites'          => self::touch_sites( $c, $site ),
				'awaiting_since' => $human_active ? null : $now,
			),
			array( 'id' => $c->id )
		);
		if ( $v ) {
			$wpdb->update( self::t( 'visitors' ), array( 'last_at' => $now ), array( 'id' => $v->id ) );
		}

		if ( $human_active ) {
			return array( 'ok' => true, 'message_id' => $mid, 'waiting' => false, 'human' => true, 'contact' => self::public_contact( $c ) );
		}

		$c       = self::contact( $c->id );
		$payload = self::n8n_payload( 'message', $c, $site, $mid, $text, $page_url, $page_title );
		$payload['message']['image'] = $image;
		$payload['focus']             = $focus;
		$payload['page']['live_text'] = $live_text;
		$sent = self::call_n8n( $payload );
		if ( ! $sent ) {
			$wpdb->update( $ct, array( 'awaiting_since' => null ), array( 'id' => $c->id ) );
			return array( 'ok' => false, 'message_id' => $mid, 'image_url' => $image, 'error' => 'n8n', 'text' => 'تعذّر الوصول للمساعد الآن — حاول بعد لحظات أو تواصل مع الإدارة.' );
		}
		return array( 'ok' => true, 'message_id' => $mid, 'image_url' => $image, 'audio_url' => $audio ? $audio['url'] : '', 'transcript' => $audio ? $audio['text'] : '', 'waiting' => true, 'contact' => self::public_contact( $c ) );
	}

	/** message.context{type, id, title, text (≤6000), selection (≤1000)} → the «focus» block of the n8n payload, or null. */
	private static function clean_focus( $ctx ) {
		if ( ! is_array( $ctx ) ) {
			return null;
		}
		$out = array(
			'type'      => preg_replace( '/[^a-z_]/', '', strtolower( vai_str( $ctx, 'type', 20 ) ) ),
			'id'        => vai_str( $ctx, 'id', 120 ),
			'title'     => vai_str( $ctx, 'title', 200 ),
			'text'      => vai_text_ok( $ctx, 'text', 6000 ),
			'selection' => vai_text_ok( $ctx, 'selection', 1000 ),
		);
		if ( $out['title'] === '' && $out['text'] === '' && $out['selection'] === '' ) {
			return null;
		}
		return $out;
	}

	private static function turns( $contact_id, $limit = 30, $exclude_id = 0 ) {
		global $wpdb;
		$mt   = self::t( 'messages' );
		$st   = self::t( 'sites' );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT m.role, m.content, m.meta, m.created_at, s.host FROM $mt m LEFT JOIN $st s ON s.id=m.site_id WHERE m.contact_id=%d AND m.id<>%d AND m.role IN ('user','assistant','human') ORDER BY m.id DESC LIMIT %d", (int) $contact_id, (int) $exclude_id, (int) $limit ) );
		$out  = array();
		foreach ( array_reverse( (array) $rows ) as $r ) {
			$meta  = $r->meta ? json_decode( $r->meta, true ) : array();
			$img   = is_array( $meta ) && ! empty( $meta['image'] ) ? '[أرفق صورة] ' : '';
			$out[] = array(
				'r'  => $r->role === 'user' ? 'c' : ( $r->role === 'human' ? 'h' : 'b' ),
				't'  => $img . vai_clip( $r->content, 500 ),
				'at' => vai_iso( $r->created_at ),
				's'  => (string) $r->host,
			);
		}
		return $out;
	}

	public static function services_all( $active_only = true ) {
		global $wpdb;
		$t    = self::t( 'services' );
		$rows = $wpdb->get_results( 'SELECT * FROM ' . $t . ( $active_only ? ' WHERE active=1' : '' ) . ' ORDER BY sort ASC, id ASC', ARRAY_A );
		$out  = array();
		foreach ( (array) $rows as $r ) {
			$r['includes_list'] = array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) $r['includes'] ) ) ) );
			$out[]              = $r;
		}
		return $out;
	}

	public static function service_by_key( $key ) {
		foreach ( self::services_all( true ) as $s ) {
			if ( $s['skey'] === $key ) {
				return $s;
			}
		}
		return null;
	}

	public static function service_card( $key ) {
		$s = self::service_by_key( $key );
		if ( ! $s ) {
			return null;
		}
		$buttons = array();
		if ( $s['pay_url'] ) {
			$buttons[] = array( 'label' => $key === 'membership' ? 'اشترك الآن' : 'ادفع واطلب الخدمة', 'url' => $s['pay_url'], 'primary' => true );
		}
		if ( $s['url'] ) {
			$buttons[] = array( 'label' => $key === 'membership' ? 'صفحة العضوية' : 'تفاصيل الخدمة', 'url' => $s['url'], 'primary' => empty( $buttons ) );
		}
		$price = $s['price'] ? ( $s['price'] . ' ' . $s['currency'] ) : 'حسب الاحتياج';
		return array(
			'key'      => $s['skey'],
			'title'    => $s['name'],
			'price'    => $price,
			'note'     => $s['vat_note'],
			'terms'    => $s['payment_terms'],
			'discount' => $s['member_discount'],
			'bullets'  => array_slice( $s['includes_list'], 0, 8 ),
			'buttons'  => $buttons,
		);
	}

	public static function forms_all() {
		global $wpdb;
		$t    = self::t( 'forms' );
		$rows = $wpdb->get_results( "SELECT * FROM $t WHERE active=1 ORDER BY id ASC", ARRAY_A );
		$out  = array();
		foreach ( (array) $rows as $r ) {
			$map = json_decode( (string) $r['field_map'], true );
			if ( ! is_array( $map ) ) {
				$map = array();
			}
			$fields = array();
			foreach ( $map as $k => $spec ) {
				$fields[] = array(
					'key'      => (string) $k,
					'label'    => is_array( $spec ) && isset( $spec['label'] ) ? $spec['label'] : (string) $k,
					'selector' => is_array( $spec ) && isset( $spec['selector'] ) ? $spec['selector'] : ( is_string( $spec ) ? $spec : '' ),
				);
			}
			$r['fields'] = $fields;
			$out[]       = $r;
		}
		return $out;
	}

	public static function form_by_key( $key ) {
		foreach ( self::forms_all() as $f ) {
			if ( $f['fkey'] === $key ) {
				return $f;
			}
		}
		return null;
	}

	private static function n8n_payload( $event, $c, $site, $mid, $text, $page_url = '', $page_title = '', $extra = array() ) {
		$services = array();
		foreach ( self::services_all( true ) as $s ) {
			$services[] = array(
				'key'             => $s['skey'],
				'name'            => $s['name'],
				'price'           => $s['price'],
				'currency'        => $s['currency'],
				'vat_note'        => $s['vat_note'],
				'payment_terms'   => $s['payment_terms'],
				'url'             => $s['url'],
				'pay_url'         => $s['pay_url'],
				'member_discount' => $s['member_discount'],
				'includes'        => $s['includes_list'],
				'pitch'           => $s['pitch'],
			);
		}
		$forms = array();
		foreach ( self::forms_all() as $f ) {
			$forms[] = array(
				'key'    => $f['fkey'],
				'label'  => $f['label'],
				'url'    => $f['url'],
				'fields' => array_map(
					function ( $x ) {
						return array( 'key' => $x['key'], 'label' => $x['label'] );
					},
					$f['fields']
				),
				'notes'  => $f['notes'],
			);
		}
		$sites = json_decode( (string) $c->sites, true );
		return array_merge(
			array(
				'event'    => $event,
				'secret'   => (string) vai_opt( 'webhook_secret', '' ),
				'hub_host' => vai_home_host(),
				'message'  => array( 'id' => (int) $mid, 'text' => (string) $text ),
				'site'     => array( 'id' => (int) $site->id, 'host' => $site->host, 'name' => $site->name ),
				'page'     => array( 'url' => (string) $page_url, 'title' => (string) $page_title, 'content' => self::page_excerpt( $page_url ) ),
				'projects_hint' => self::projects_hint( $text ),
				'knowledge_hint' => self::knowledge_hint( $text ),
				'contact'  => array(
					'id'          => (int) $c->id,
					'name'        => (string) $c->name,
					'phone'       => (string) $c->phone,
					'email'       => (string) $c->email,
					'stage'       => (int) $c->stage,
					'is_member'   => (int) $c->is_member ? true : false,
					'first_at'    => vai_iso( $c->first_at ),
					'last_at'     => vai_iso( $c->last_at ),
					'msg_count'   => (int) $c->msg_count,
					'reply_count' => (int) $c->reply_count,
					'sites'       => is_array( $sites ) ? $sites : array(),
					'lead_type'   => (string) $c->lead_type,
					'has_account' => ! empty( $c->pass_hash ),
					'trial_left'  => self::trial_days_left( $c ),
					'trial_days'  => (int) vai_cfg( 'trial_days' ),
					'company'     => (string) $c->company,
					'member_type' => (string) $c->member_type,
					'city'        => (string) $c->city,
					'bio'         => (string) $c->bio,
					'job_title'   => (string) $c->job_title,
					'persona'     => (string) $c->persona,
					'is_admin'    => ( $c->role === 'admin' && (int) $c->admin_verified ) ? 1 : 0,
					'member_left' => self::member_days_left( $c ),
					'member_new'  => (int) $c->is_member && ! (int) $c->member_welcomed,
					'daily_left'  => (int) $c->is_member ? max( 0, (int) vai_cfg( 'member_daily' ) - self::count_replies_today( $c->id ) ) : null,
				),
				'recent_pages' => self::recent_pages( $c->id ),
				'admin_brief'  => ( $c->role === 'admin' && (int) $c->admin_verified ) ? self::admin_brief() : null,
				'memo'     => (string) $c->memo,
				'turns'    => self::turns( $c->id, 30, (int) $mid ),
				'gate'     => self::gate_info( $c ),
				'services' => $services,
				'forms'    => $forms,
				'videos'   => vai_videos(),
				'links'    => vai_links(),
				'config'   => array(
					'instructions'  => trim( self::policy_text( $c ) . "\n" . (string) vai_opt( 'extra_instructions', '' ) ),
					'first_note'    => trim( (string) vai_cfg( 'first_reply_note' ) ),
					'bot_name'      => vai_cfg( 'bot_name' ),
					'mgmt_whatsapp' => vai_cfg( 'mgmt_whatsapp' ),
					'club_whatsapp' => vai_cfg( 'club_whatsapp' ),
					'saudi_only'    => (int) vai_cfg( 'saudi_only' ) ? true : false,
					'allowed_hosts' => vai_allowed_hosts(),
				),
			),
			$extra
		);
	}

	/** Text of the page the visitor is looking at (from the synced knowledge base), so the assistant knows what's on screen. */
	private static function page_excerpt( $url ) {
		global $wpdb;
		$url = trim( (string) $url );
		if ( $url === '' ) {
			return '';
		}
		$kt   = self::t( 'knowledge' );
		$vars = array( $url, rtrim( $url, '/' ), rtrim( $url, '/' ) . '/', rawurldecode( $url ) );
		$ph   = implode( ',', array_fill( 0, count( $vars ), '%s' ) );
		$row  = $wpdb->get_row( $wpdb->prepare( "SELECT title, content FROM $kt WHERE url_hash IN ($ph) LIMIT 1", array_map( 'md5', $vars ) ) );
		if ( ! $row ) {
			$path = trim( (string) wp_parse_url( rawurldecode( $url ), PHP_URL_PATH ), '/' );
			$seg  = $path ? basename( $path ) : '';
			if ( $seg ) {
				$row = $wpdb->get_row( $wpdb->prepare( "SELECT title, content FROM $kt WHERE url LIKE %s OR url LIKE %s LIMIT 1", '%' . $wpdb->esc_like( rawurlencode( $seg ) ) . '%', '%' . $wpdb->esc_like( $seg ) . '%' ) );
			}
		}
		return $row ? vai_clip( (string) $row->content, 2500 ) : '';
	}

	/** Top matching site pages/notes for the customer's message — injected so new pages (courses, events) are known instantly. */
	private static function knowledge_hint( $text ) {
		$text = trim( (string) $text );
		if ( mb_strlen( $text, 'UTF-8' ) < 4 ) {
			return array();
		}
		$rows = self::search( $text, '', 3 );
		$out  = array();
		foreach ( (array) $rows as $r ) {
			$out[] = array( 'title' => (string) $r['title'], 'url' => (string) $r['url'], 'excerpt' => vai_clip( (string) $r['snippet'], 420 ) );
		}
		return $out;
	}

	/** Matching projects for the customer's message, pre-fetched so the model never has to guess. */
	private static function projects_hint( $text ) {
		$text = (string) $text;
		if ( $text === '' || ! preg_match( '/(مشروع|مشاريع|بنك|فرصة|فرص|شراك|مستثمر|قطاع|project)/u', $text ) ) {
			return array();
		}
		$list = self::projects( $text, 5 );
		return array_map(
			function ( $p ) {
				return array( 'number' => $p['number'], 'name' => $p['name'], 'sector' => $p['sector'], 'stage' => $p['stage'], 'summary' => vai_clip( $p['summary'], 220 ), 'url' => $p['url'], 'golden' => $p['golden'] );
			},
			$list
		);
	}

	/** Execute an admin command issued through the assistant. Returns a short Arabic result line. */
	private static function run_admin_action( $admin, $a ) {
		global $wpdb;
		switch ( $a['op'] ) {
			case 'report_today':
				$ok = self::send_digest();
				return $ok ? '✅ أرسلت تقرير اليوم إلى إيميلات الإشعار.' : '⚠️ تعذّر إرسال التقرير — راجع البريد (SMTP).';
			case 'weekly_now':
				if ( class_exists( 'VAI_Payments' ) ) {
					VAI_Payments::weekly_members();
					return '✅ دخلت الرسالة الأسبوعية طابور الإرسال لكل الأعضاء المفعّلين (رسالة كل 5 دقائق).';
				}
				return '⚠️ نظام البريد غير متاح.';
			case 'campaign':
				if ( ! class_exists( 'VAI_Payments' ) || $a['subject'] === '' || $a['body'] === '' ) {
					return '⚠️ أحتاج عنوان الرسالة ونصها قبل الإرسال.';
				}
				$aud = in_array( $a['audience'], array( 'paid', 'unpaid', 'all' ), true ) ? $a['audience'] : 'paid';
				$r   = VAI_Payments::campaign( $aud, $a['subject'], $a['body'] );
				$who = array( 'paid' => 'الأعضاء المفعّلين', 'unpaid' => 'الحسابات غير المدفوعة', 'all' => 'كل الحسابات' );
				return '✅ جدولت ' . (int) $r['count'] . ' رسالة إلى ' . $who[ $aud ] . ' — تُرسل واحدة كل 5 دقائق تلقائيًا.';
			case 'broadcast':
				if ( $a['text'] === '' ) {
					return '⚠️ اكتب نص الرسالة أولًا.';
				}
				$ct    = self::t( 'contacts' );
				$since = gmdate( 'Y-m-d H:i:s', time() - 60 * 60 );
				$rows  = (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, last_site_id FROM $ct WHERE last_at>=%s AND id<>%d AND msg_count>0", $since, (int) $admin->id ) );
				foreach ( $rows as $r ) {
					self::insert_message( $r->id, (int) $r->last_site_id, 'human', $a['text'], null, '', array( 'by' => (string) $admin->name ) );
					$wpdb->update( $ct, array( 'human_until' => gmdate( 'Y-m-d H:i:s', time() + 5 * 60 ) ), array( 'id' => $r->id ) );
				}
				return '✅ أرسلت رسالتك باسمك إلى ' . count( $rows ) . ' عميل نشط خلال آخر ساعة.';
		}
		return '';
	}

	/** Live operations snapshot for admins talking to the assistant. */
	public static function admin_brief() {
		global $wpdb;
		$d   = self::digest_data( 24 );
		$ct  = self::t( 'contacts' );
		$mt  = self::t( 'messages' );
		$out = array(
			'today_chats'    => (int) $d['chats'],
			'today_messages' => (int) $d['messages'],
			'today_sites'    => (int) $d['sites'],
			'new_accounts'   => (int) $d['registered'],
			'paid_members'   => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ct WHERE is_member=1" ),
			'accounts_total' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ct WHERE pass_hash<>''" ),
			'unread'         => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ct c WHERE c.msg_count>0 AND EXISTS (SELECT 1 FROM $mt m WHERE m.contact_id=c.id AND m.role='user' AND m.id>c.admin_seen_id)" ),
			'per_site'       => array_map( function ( $r ) { return ( $r->host ?: '?' ) . ': ' . (int) $r->n; }, $d['per_site'] ),
			'leads'          => array_map( function ( $r ) { return $r->ltype . ': ' . (int) $r->n; }, $d['leads'] ),
			'top'            => array(),
		);
		foreach ( array_slice( $d['top'], 0, 6 ) as $c ) {
			$out['top'][] = self::intent_label( $c->intent ) . ' — ' . ( $c->name ?: 'بدون اسم' ) . ' — ' . ( $c->phone_norm ? vai_phone_local( $c->phone_norm ) : '—' ) . ( $c->persona ? ' — ' . self::persona_label( $c->persona ) : '' ) . ( $c->memo ? ' — ' . vai_clip( $c->memo, 140 ) : '' );
		}
		return $out;
	}

	/** Last distinct pages the contact was on (for «take me back to …»). */
	private static function recent_pages( $contact_id, $limit = 6 ) {
		global $wpdb;
		$mt   = self::t( 'messages' );
		$rows = $wpdb->get_col( $wpdb->prepare( "SELECT page_url FROM $mt WHERE contact_id=%d AND role='user' AND page_url IS NOT NULL AND page_url<>'' ORDER BY id DESC LIMIT 40", (int) $contact_id ) );
		$out  = array();
		foreach ( (array) $rows as $u ) {
			$u = (string) $u;
			if ( $u !== '' && ! in_array( $u, $out, true ) ) {
				$out[] = $u;
			}
			if ( count( $out ) >= $limit ) {
				break;
			}
		}
		return $out;
	}

	/** Always-on sales/behaviour policy, injected as top-priority management directives. */
	private static function policy_text( $c = null ) {
		$svc  = self::service_by_key( 'membership' );
		$pay  = $svc ? ( $svc['pay_url'] ?: $svc['url'] ) : 'https://vcmem.com/payment/';
		$prc  = $svc && $svc['price'] ? $svc['price'] . ' ' . $svc['currency'] : '1,900 ريال';
		$paid = $c && (int) $c->is_member && self::member_active( $c );
		$lines = array(
			'رقم الإدارة واحد فقط: ' . vai_phone_local( vai_cfg( 'mgmt_whatsapp' ) ) . ' (واتساب) — لا تذكر أي رقم آخر للإدارة أو للنادي. واتساب استوديو البودكاست للحجز: 0538461110.',
			'اللهجة: سعودية بيضاء جميلة وسلسة يفهمها كل عربي (حياك الله، أبشر، تبغى، وش تحتاج، الحين، تمام، الله يحييك) بجمل قصيرة وكلمات بسيطة، مع إيموجي أنيق في وسط الكلام يناسب الموقف. كلامك مرتّب ومحسوب. من يكتب بلغة أخرى تجاوبه بلغته.',
			'أنت مستشار مالي وإداري خبير قبل أن تكون بائعًا: اسأل لتفهم بدقة من الذي أمامك وماذا يحتاج (سؤال واحد في الرسالة)، ثم أعطه الجواب والخطوة والرابط المناسب لما يحتاجه فعلًا.',
			'المنظومة كلها سعودية 100% ومملوكة للمهندس سالم المسرحي مؤسس نادي المستثمرين و Vibes Ventures: عندما يناسب، ذكّر العميل أن أفضل استثمار لوقته أن يختار شركة بنت له نظامًا كاملًا يخدمه على مدار الساعة، وتكلم عن المهندس سالم ورؤيته وأعماله (الفيديوهات 3 و12 و17) بثقة واعتزاز.',
			'مزايا العضوية السنوية (' . $prc . ') التي تذكرها بالأرقام حسب ما يهم العميل: خصم 50% على كل باقات استوديو بودكاست الملتقى طوال السنة بلا حدود استخدام (أي في باقة الإنتاج المتكاملة 4,000 ريال/الساعة يوفّر 2,000 ريال في الساعة الواحدة — أكثر من 1,000 ريال في الساعة في أغلب الباقات)؛ خصم 50% على اصنع ملتقاك وعلى Pitch Deck الاحترافي وعلى تصميم المواقع والتطبيقات من مومنتوم؛ خصم 50% كامل بلا حدود على مسرح النادي (حتى 80 شخصًا) وعلى غرفة الاجتماعات (8 أشخاص باشتراك Zoom)؛ مقر النادي في الرياض — العليا، شارع الأمير محمد بن عبدالعزيز — متاح له، والعضوية عالمية «من السعودية إلى العالم»: الفعاليات تُقام في المقر وتُبث أونلاين للأعضاء في كل مكان؛ رصيد التواصل مع 5 مشاريع في بنك المشاريع (بقيمة 2,500 ريال) — فبدل أن يدفع 2,500 لبنك المشاريع وحده يدفع ' . $prc . ' ويأخذ الرصيد نفسه + كل هذه المزايا؛ تقييم مشروعه خلال 10 أيام عمل وعرضه على المستثمرين بأولوية وإعادة إبرازه مرة كل شهر لكافة الأعضاء والتقديم على شركاء النجاح بأولوية؛ دخول مقر النادي بالرياض (باركود دخول بعد حجز الموعد) وأولوية الحضور في الملتقيات وملتقى 5 دقائق حضوريًا أو أونلاين؛ استشارة أونلاين مع مستشار ذكي بدون رسوم؛ ظهور في «شخصية ومسيرة»؛ كود خصم حتى 20% على منتجات «منفذ»؛ وبرومو كود «شركاؤنا» الشخصي (5 حروف وأرقام، يجده في تطبيق النادي: شاشة «شركاؤنا» وكارت العضوية) يفتح له خصومات كل شركاء النادي فورًا — وكل خصم جديد يدخل المنظومة يسري عليه تلقائيًا بدون رسوم؛ ومستشار خاص (أنا) على مدار الساعة بذاكرة كاملة. العضوية الرسمية للنادي هي المسار الوحيد للانضمام (1,900 بدل 3,900 — توفير 2,000 لفترة محدودة). الخلاصة التي تكررها بصيغ مختلفة: العضوية تعيد ثمنها أضعافًا من أول استخدام واحد.',
		);
		$lines[] = 'الصحة اللغوية شرط لا يُتنازل عنه: كل جملة عربية سليمة نحويًا وإملائيًا ومفهومة من أول قراءة، بلا كلمات مخترعة أو غير موجودة أو حروف ناقصة أو جمل مبتورة؛ راجع ردك كاملًا قبل الإرسال وأعد صياغة أي جملة غير واضحة بأبسط كلمات.';
		$lines[] = 'لا تدّعِ فعلًا لم تفعله: لا تقل «عبّيت لك النموذج» أو «فتحت لك الصفحة» أو «أرسلت لك» إلا إذا أصدرت الفعل المقابل في الرد نفسه؛ وإلا قل «اضغط الزر وسيفتح لك النموذج معبّأً ببياناتك». وقبل أن تعِد بأي شيء («أعملك كذا») تأكد أنه ضمن ما تقدر عليه فعلًا (فتح صفحة، زر، كارت، تحويل للإدارة، تعبئة نموذج معتمد) — وما عدا ذلك اشرح الطريقة الصحيحة.';
		$lines[] = 'الروابط بدقة: قبل إرسال أي رابط تأكد أن هذا بالضبط ما يريده العميل؛ إن كان الطلب محتملًا لأكثر من صفحة اسأل سؤالًا واحدًا أولًا. الروابط من مكتبة الروابط المعتمدة أو من نتيجة بحث/صفحة فعلية فقط — لا تخمّن رابطًا أبدًا. عندما تكتشف معلومة جديدة من صفحة عبر get_page أو search_site، احفظها لنفسك بأداة save_note حتى لا تبحث عنها مرة أخرى.';
		$lines[] = 'إدراج المشاريع في بنك المشاريع — المسار الرسمي الذي تشرحه بدقة: التسجيل يكون عبر بوابة شركاء النجاح، ثم يُعرض المشروع على لجنة مختصة، وفي حال الموافقة يُدرَج في بنك المشاريع؛ كل مشروع موجود في البنك مرّ على اللجنة، وقد لا يناسب المشروع توجه Vibes Ventures فلا يُقبل. جودة ملف Pitch Deck عامل حاسم في القبول والعرض على المستثمرين — لذلك ترشّح خدمة Pitch Deck الاحترافية (بخصم 50% للأعضاء).';
		$lines[] = 'المهندس سالم المسرحي: تحدث عنه بفخر واعتزاز كمؤسس نادي المستثمرين و Vibes Ventures وصاحب رؤية المنظومة السعودية الكاملة، ورشّح كتابه «مليونير تحت الإنشاء» (بدون رسوم: https://vcmem.com/book) وفيديوهاته (12، 17) عندما يناسب السياق.';
		$lines[] = 'الاستثمار الجريء: أنت على دراية كاملة بريادة الأعمال والاستثمار الجريء وقصص نجاح الشركات الناشئة (محليًا وعالميًا) — استخدمها بأريحية وبأمثلة قصيرة عندما تشعر أن العميل يحتاجها لفهم قرار أو فرصة، بلغة بسيطة وبلا توصيات مالية شخصية.';
		if ( $c && $c->role === 'admin' && (int) $c->admin_verified ) {
			$lines[] = 'أوامر الأدمن التي تنفّذها فعلًا: عندما يطلب الأدمن تنفيذ شيء، اعرض له أولًا ما ستفعله بالضبط (النص/الجمهور) واسأله «هل تؤكد الإرسال؟»، وعندما يؤكد صراحة أصدر في [[ACTIONS]] فعلًا من نوع admin مع confirm:true — الأنواع: {"type":"admin","op":"report_today","confirm":true} يرسل تقرير اليوم للإدارة الآن | {"type":"admin","op":"campaign","audience":"paid|unpaid|all","subject":"…","body":"…","confirm":true} يجدول إيميلًا للأعضاء المفعّلين أو غير المدفوعين أو الكل (يُرسل تلقائيًا رسالة كل 5 دقائق) | {"type":"admin","op":"broadcast","text":"…","confirm":true} يرسل رسالة باسمه داخل محادثات كل العملاء النشطين الآن (آخر ساعة) | {"type":"admin","op":"weekly_now","confirm":true} يدخل الرسالة الأسبوعية في الطابور. بدون confirm:true لا يُنفَّذ شيء — لذلك اطلب التأكيد دائمًا قبل الفعل، واقترح عليه صياغة جاهزة للإيميل أو الرسالة ليعتمدها أو يعدّلها.';
			$lines[] = 'في أول رد للأدمن في الجلسة رحّب به باسمه ثم اعرض عليه بوضوح ما تقدر تقدمه: (1) كم عميل تكلم معك اليوم وكم أُغلق منهم واشترك؛ (2) إرسال رسالة باسمه لكل العملاء الأونلاين الآن؛ (3) إرسال تقرير اليوم فورًا؛ (4) إيميل لكل الحسابات غير المسجّلة في العضوية؛ (5) إيميل لكل الأعضاء المفعّلين (البريميوم) — واستقبل منه أوامر كاملة ونفّذها بعد تأكيده.';
			$lines[] = 'وضع خاص: الذي يكلمك الآن هو أدمن المنظومة (' . $c->name . ') وله التحكم الكامل — عامله كمدير، نادِه باسمه، بلا أي بيع أو بوابات؛ نفّذ طلباته المعلوماتية من «ملخص العمليات» في السياق (عدد المحادثات اليوم، الحسابات الجديدة، الأعضاء، الليدز، أهم العملاء وما وصلوا إليه)، واقترح عليه ما تقدر تقدمه: إحصاءات اليوم، أهم العملاء الجادين، ملخص عميل معيّن، صياغة رد، رابط لوحة الإدارة ' . home_url( '/?vai-console=1' ) . '. ما لا تقدر عليه (تعديل إعدادات، إرسال إيميلات) اشرح مكانه في لوحة التحكم.';
		}
		if ( $paid ) {
			$lines[] = 'وضع العميل: عضو مدفوع ⭐ — أنت مستشاره الخاص: تكلم معه بحرية وبتوسّع وعمق، بلا حدود على طول الحوار، وبلا أي محاولة بيع للعضوية. عرّف نفسك عند بداية التعامل كمستشاره الشخصي: للمحايد «أنا مستشارك الخاص الموجود لك 24 ساعة في اليوم»، ولرائد الأعمال «أساعدك في تحويل شركتك ونموها خطوة بخطوة»، وللمستثمر «أساعدك تلاقي الشركة المناسبة لتوجهك ونتابع معًا حتى الشراكة». طبّق خصومات الأعضاء تلقائيًا على كل خدمة تذكرها.';
			$lines[] = 'مع المستثمر الجاد اسأل بلطف: كم نسبة الحصة التي يفضّل الدخول بها إن أعجبته شركة؟ وهل لديه القدرة المالية الجاهزة للشراكة الآن؟ — لتوجّهه للفرصة المناسبة وتمهّد للإدارة.';
			$lines[] = 'بنك المشاريع للعضو: افهم توجهه أولًا (قطاعه، قائم أم ناشئ، شريك صامت أم فاعل، مدينته) ثم رشّح له من «مشاريع مطابقة» أو find_projects بروح المستشار الحريص: «رصيدك 5 مشاريع فقط للتواصل مع مؤسسيها — خلنا نختار بتأنٍ ونفكر أحسن قبل ما نفتح أي مشروع» — واعرض المشروع الأنسب أولًا مع سبب الترشيح.';
			$lines[] = 'خدمات الأعضاء عنده جاهزة بزر «خدمات الأعضاء» في المساعد: حجز حلقة بودكاست بخصم 50% (أقرب موعد عبر واتساب الاستوديو، ويمكن لأي شخص من طرفه الاستفادة بنفس الخصم)، Pitch Deck بخصم 50% (رابط دفع الأعضاء)، اصنع ملتقاك بخصم 50% (رابط دفع الأعضاء)، بنك المشاريع، وباقي الخدمات عبر رقم الإدارة الموحد. عند طلب أي منها وجّهه للزر أو أرسل الرابط المناسب من مكتبة الروابط/الخدمات.';
			$lines[] = 'رصيده اليومي من ردودك كبير (2,500) — لا تذكره إطلاقًا إلا إذا سأل أو أخبرك السياق أنه اقترب من النهاية.';
		} else {
			$reg = $c && ! empty( $c->pass_hash ) && (int) $c->verified;
			if ( ! $reg ) {
				$lines[] = 'الزائر غير معروف الهوية: بعد ردك هذا يعرض النظام نموذج البيانات تلقائيًا — فاختم ردك بجملة لطيفة تمهّد له أنك تحتاج تتعرّف عليه أكثر لتكمل معه صح (اسمه وجواله وبريده وفئته في النادي)، خاصة لو ذكر شراكة أو استثمارًا: لا تناقش أي تفاصيل شراكة ولا تحوّله للإدارة قبل التسجيل.';
			}
			$lines[] = 'وضع العميل: ' . ( $reg ? 'مسجّل لكن عضويته غير مفعّلة (لم يدفع) — ابدأ ردك الأول له بـ «عضويتك غير مفعّلة بعد» وذكّره عند المناسبة' : 'زائر غير مشترك' ) . ' — الممنوع: الدردشة والسوالف والاستشارات والخطط والتحليلات؛ المسموح فقط: شرح مزايا العضوية بالأرقام، والإجابة المختصرة عن الخدمات (تسجيل مشروع، اصنع ملتقاك، Pitch Deck، البودكاست) بسطر أو سطرين، ثم في كل رد دعوة واضحة للاشتراك: «لازم تسجّل عضوية سنوية عشان نكمل» مع رابط الدفع المباشر ' . $pay . '. لا خصومات له ولا بنك مشاريع قبل التفعيل — قل ذلك صراحة إن سأل. ' . ( trim( (string) vai_cfg( 'first_reply_note' ) ) !== '' ? 'في أول رد له فقط أضف هذه الجملة بمعناها وبأسلوبك (مرة واحدة): «' . trim( (string) vai_cfg( 'first_reply_note' ) ) . '».' : 'لا تذكر شيئًا عن تسجيل المحادثة من عدمه.' ) . ' الترحيب الأول بلا قوائم نقطية وبلا سرد خيارات — سطران وسؤال واحد.';
			$lines[] = 'الشراكات وبنك المشاريع للمشتركين فقط: لا تفتح نقاش حصص أو تفاصيل شراكة عميقة قبل الاشتراك — وجّهه للاشتراك أولًا.';
		}
		$lines[] = 'ترشيح واحد فقط في كل رد حسب طلب العميل — لا قوائم ولا أزرار إلا لطلب محدد (خياران كحد أقصى). عند طلب رابط أرسله فورًا في أول سطر.';
		$lines[] = 'بيع الخدمات (Pitch Deck، اصنع ملتقاك، البودكاست، المواقع والتطبيقات) بذكاء وبلا إلحاح: عند اهتمام حقيقي فقط، مرة واحدة، والرفض نهائي. صاحب المشروع المستعجل: العضوية أولًا ثم اصنع ملتقاك بالنصف بفضل العضوية ثم حلقة في البودكاست تعرّف الناس بمشروعه.';
		$lines[] = 'النماذج: عند التسجيل في بوابة شركاء النجاح أو أي نموذج معتمد افتحه له معبّأً بكل ما تعرفه عنه وقل له يكمل الباقي بنفسه. الروابط دائمًا من مكتبة الروابط المعتمدة.';
		$sheet = trim( (string) vai_cfg( 'price_sheet' ) );
		if ( $sheet !== '' ) {
			$lines[] = 'قائمة الأسعار المعتمدة (استخدمها للأرقام والمقارنات ولحساب توفير خصم 50% للأعضاء): ' . $sheet;
		}
		return implode( "\n", $lines );
	}

	private static function call_n8n( $payload ) {
		$url = trim( (string) vai_opt( 'n8n_webhook', '' ) );
		if ( $url === '' ) {
			update_option( 'vai_last_n8n', array( 'at' => vai_now(), 'code' => 0, 'err' => 'رابط الويبهوك فارغ' ), false );
			return false;
		}
		$t0 = microtime( true );
		list( $code, $data, $err ) = vai_http_json( 'POST', $url, $payload, array(), 20 );
		update_option( 'vai_last_n8n', array( 'at' => vai_now(), 'code' => (int) $code, 'err' => (string) $err, 'ms' => (int) round( ( microtime( true ) - $t0 ) * 1000 ), 'event' => $payload['event'] ), false );
		return $code >= 200 && $code < 300;
	}

	private static function op_poll( $site, $d ) {
		global $wpdb;
		list( $c ) = self::resolve_contact( $site, isset( $d['uuid'] ) ? $d['uuid'] : '', false );
		if ( ! $c ) {
			return array( 'ok' => true, 'messages' => array(), 'contact' => null, 'waiting' => false );
		}
		$after = isset( $d['after'] ) ? (int) $d['after'] : 0;
		$mt    = self::t( 'messages' );
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT id, role, content, actions, meta, created_at FROM $mt WHERE contact_id=%d AND id>%d AND role IN ('assistant','human','system') ORDER BY id ASC LIMIT 20", $c->id, $after ) );
		$msgs  = array();
		foreach ( (array) $rows as $r ) {
			$a      = $r->actions ? json_decode( $r->actions, true ) : array();
			$meta   = $r->meta ? json_decode( $r->meta, true ) : array();
			$msgs[] = array(
				'id'      => (int) $r->id,
				'role'    => $r->role,
				'content' => (string) $r->content,
				'actions' => is_array( $a ) ? $a : array(),
				'by'      => is_array( $meta ) && ! empty( $meta['by'] ) ? (string) $meta['by'] : '',
				'at'      => vai_iso( $r->created_at ),
			);
		}
		$waiting = false;
		$timeout = false;
		if ( ! empty( $c->awaiting_since ) ) {
			$age = time() - strtotime( $c->awaiting_since . ' UTC' );
			if ( $age > (int) vai_cfg( 'reply_timeout' ) ) {
				$wpdb->update( self::t( 'contacts' ), array( 'awaiting_since' => null ), array( 'id' => $c->id ) );
				$timeout = empty( $msgs );
			} else {
				$waiting = true;
			}
		}
		return array(
			'ok'       => true,
			'messages' => $msgs,
			'waiting'  => $waiting,
			'timeout'  => $timeout,
			'cfg_rev'  => (int) get_option( 'vai_cfg_rev', 0 ),
			'human'    => ! empty( $c->human_until ) && strtotime( $c->human_until . ' UTC' ) > time(),
			'contact'  => self::public_contact( $c ),
		);
	}

	private static function op_history( $site, $d ) {
		global $wpdb;
		list( $c ) = self::resolve_contact( $site, isset( $d['uuid'] ) ? $d['uuid'] : '', false );
		if ( ! $c ) {
			return array( 'ok' => true, 'messages' => array(), 'contact' => null );
		}
		return array( 'ok' => true, 'messages' => self::history_rows( $c->id, 40 ), 'contact' => self::public_contact( $c ) );
	}

	private static function history_rows( $contact_id, $limit = 40 ) {
		global $wpdb;
		$mt   = self::t( 'messages' );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT id, role, content, actions, meta, created_at FROM $mt WHERE contact_id=%d AND role IN ('user','assistant','human') ORDER BY id DESC LIMIT %d", (int) $contact_id, (int) $limit ) );
		$out  = array();
		foreach ( array_reverse( (array) $rows ) as $r ) {
			$a     = $r->actions ? json_decode( $r->actions, true ) : array();
			$meta  = $r->meta ? json_decode( $r->meta, true ) : array();
			$out[] = array(
				'id'      => (int) $r->id,
				'role'    => $r->role,
				'content' => (string) $r->content,
				'actions' => is_array( $a ) ? $a : array(),
				'image'   => is_array( $meta ) && ! empty( $meta['image'] ) ? (string) $meta['image'] : '',
				'audio'   => is_array( $meta ) && ! empty( $meta['audio'] ) ? (string) $meta['audio'] : '',
				'by'      => is_array( $meta ) && ! empty( $meta['by'] ) ? (string) $meta['by'] : '',
				'at'      => vai_iso( $r->created_at ),
			);
		}
		return $out;
	}

	private static function member_lookup( $phone_norm, $email_norm ) {
		global $wpdb;
		$t     = self::t( 'members' );
		$where = array();
		$args  = array();
		if ( $phone_norm ) {
			$where[] = 'phone_norm=%s';
			$args[]  = $phone_norm;
		}
		if ( $email_norm ) {
			$where[] = 'email_norm=%s';
			$args[]  = $email_norm;
		}
		if ( ! $where ) {
			return null;
		}
		$sql = "SELECT * FROM $t WHERE (" . implode( ' OR ', $where ) . ') AND (expires_at IS NULL OR expires_at>=CURDATE()) LIMIT 1';
		return $wpdb->get_row( $wpdb->prepare( $sql, $args ) );
	}

	private static function op_identify( $site, $d ) {
		global $wpdb;
		$name  = vai_str( $d, 'name', 120 );
		$phone = vai_str( $d, 'phone', 40 );
		$email = vai_norm_email( vai_str( $d, 'email', 190 ) );
		$pn    = vai_norm_phone( $phone );
		if ( $name === '' || strlen( $pn ) < 9 || strlen( $pn ) > 15 ) {
			return vai_error( 'invalid', 'الاسم ورقم الجوال مطلوبان' );
		}
		if ( (int) vai_cfg( 'saudi_only' ) && strpos( $pn, '966' ) !== 0 ) {
			return vai_error( 'saudi', 'نخدم داخل المملكة فقط — نحتاج رقم جوال سعودي (966)' );
		}
		list( $c, $v ) = self::resolve_contact( $site, isset( $d['uuid'] ) ? $d['uuid'] : '', true, array( 'ip' => isset( $d['ip'] ) ? $d['ip'] : '' ) );
		if ( ! $c ) {
			return vai_error( 'bad_uuid', 'معرّف الزائر غير صحيح' );
		}
		$ct  = self::t( 'contacts' );
		$now = vai_now();

		$sql  = "SELECT * FROM $ct WHERE id<>%d AND stage>=1 AND (phone_norm=%s" . ( $email ? ' OR email_norm=%s' : '' ) . ') ORDER BY last_at DESC LIMIT 1';
		$args = $email ? array( $c->id, $pn, $email ) : array( $c->id, $pn );
		$ex   = $wpdb->get_row( $wpdb->prepare( $sql, $args ) );
		if ( self::needs_login( $site, $ex ) ) {
			$ex = null; // stays a lead of its own: on the app server's site an account is reached by login only
		}

		$returning = false;
		if ( $ex ) {
			self::merge_contacts( $c, $ex );
			$c         = self::contact( $ex->id );
			$returning = (int) $c->msg_count > 0;
			$upd       = array( 'last_at' => $now, 'last_site_id' => $site->id, 'sites' => self::touch_sites( $c, $site ) );
			if ( ! $c->name ) {
				$upd['name'] = $name;
			}
			if ( $email && ! $c->email ) {
				$upd['email']      = $email;
				$upd['email_norm'] = $email;
			}
			$wpdb->update( $ct, $upd, array( 'id' => $c->id ) );
		} else {
			$wpdb->update(
				$ct,
				array(
					'name'       => $name,
					'phone'      => $phone,
					'phone_norm' => $pn,
					'email'      => $email,
					'email_norm' => $email,
					'stage'      => max( 1, (int) $c->stage ),
					'last_at'    => $now,
				),
				array( 'id' => $c->id )
			);
		}
		$c = self::contact( $c->id );

		// Member auto-detection.
		$member = self::member_lookup( $c->phone_norm, $c->email_norm );
		if ( $member && ! (int) $c->is_member ) {
			$wpdb->update( $ct, array( 'is_member' => 1, 'stage' => 2 ), array( 'id' => $c->id ) );
			self::log_event( $c->id, 'activated', 0, 'list', '', 0, $site->host );
			$c = self::contact( $c->id );
		}

		self::insert_message( $c->id, $site->id, 'system', $returning ? 'عميل عائد — تعرّفنا عليه من بياناته: ' . $c->name . ' / ' . $c->phone : 'سجّل بياناته: ' . $c->name . ' / ' . $c->phone . ( $c->email ? ' / ' . $c->email : '' ), null, vai_str( $d, 'page_url', 500 ) );

		if ( $returning ) {
			$payload = self::n8n_payload( 'identified', $c, $site, 0, '', vai_str( $d, 'page_url', 500 ), vai_str( $d, 'page_title', 200 ), array( 'returning' => true ) );
			$wpdb->update( $ct, array( 'awaiting_since' => $now ), array( 'id' => $c->id ) );
			if ( ! self::call_n8n( $payload ) ) {
				$wpdb->update( $ct, array( 'awaiting_since' => null ), array( 'id' => $c->id ) );
				self::insert_message( $c->id, $site->id, 'assistant', 'أهلًا بك من جديد يا أستاذ ' . $c->name . ' 🌹 كلمتني قبل كذا وسجلك عندي — نكمل من حيث وقفنا؟' );
			}
		} else {
			self::insert_message( $c->id, $site->id, 'assistant', 'تشرفت يا أستاذ ' . $name . ' 🌹 سجّلت بياناتك، ونكمل مع بعض — وش تحتاج بالضبط؟' );
			self::add_lead( $c, $site, 'contact', 'سجّل بياناته في المحادثة', '', 'الصفحة: ' . vai_str( $d, 'page_url', 300 ) );
		}
		return array(
			'ok'        => true,
			'returning' => $returning,
			'contact'   => self::public_contact( $c ),
			'is_member' => (int) $c->is_member ? 1 : 0,
		);
	}

	private static function merge_contacts( $from, $into ) {
		global $wpdb;
		if ( (int) $from->id === (int) $into->id ) {
			return;
		}
		$ct = self::t( 'contacts' );
		$wpdb->update( self::t( 'messages' ), array( 'contact_id' => $into->id ), array( 'contact_id' => $from->id ) );
		$wpdb->update( self::t( 'visitors' ), array( 'contact_id' => $into->id ), array( 'contact_id' => $from->id ) );
		$wpdb->update( self::t( 'leads' ), array( 'contact_id' => $into->id ), array( 'contact_id' => $from->id ) );
		$wpdb->update( self::t( 'tokens' ), array( 'contact_id' => $into->id ), array( 'contact_id' => $from->id ) );
		$wpdb->update( self::t( 'events' ), array( 'contact_id' => $into->id ), array( 'contact_id' => $from->id ) );
		$sites = array_unique( array_merge( (array) json_decode( (string) $into->sites, true ), (array) json_decode( (string) $from->sites, true ) ) );
		$memo  = trim( (string) $into->memo );
		if ( trim( (string) $from->memo ) ) {
			$memo = vai_clip( $memo . ( $memo ? ' | ' : '' ) . 'من محادثة جديدة: ' . $from->memo, 900 );
		}
		$wpdb->update(
			$ct,
			array(
				'msg_count'   => (int) $into->msg_count + (int) $from->msg_count,
				'reply_count' => (int) $into->reply_count + (int) $from->reply_count,
				'sites'       => wp_json_encode( array_values( array_filter( $sites ) ) ),
				'memo'        => $memo,
				'first_at'    => ( $from->first_at && ( ! $into->first_at || $from->first_at < $into->first_at ) ) ? $from->first_at : $into->first_at,
			),
			array( 'id' => $into->id )
		);
		$wpdb->delete( $ct, array( 'id' => $from->id ) );
	}

	/* ───────────── accounts (one account for all ecosystem sites) ───────────── */

	private static function too_many_attempts( $key, $limit = 8 ) {
		$k = 'vai_att_' . md5( $key );
		$n = (int) get_transient( $k );
		if ( $n >= $limit ) {
			return true;
		}
		set_transient( $k, $n + 1, 15 * MINUTE_IN_SECONDS );
		return false;
	}

	/**
	 * On the trusted app-server site the visitor → account link is what bridge_actor() and the server's own guards rely
	 * on, so there it is made only by a password-grade proof (login, verify code, set-password link) — never by a phone
	 * number (identify) or a hand-over token (claim). Websites keep the 2.6 behaviour.
	 */
	private static function needs_login( $site, $target ) {
		if ( ! $site || empty( $site->trusted ) || ! $target ) {
			return false;
		}
		return ! empty( $target->pass_hash ) || (int) $target->verified === 1 || (int) $target->is_member === 1 || in_array( $target->role, array( 'admin', 'publisher' ), true );
	}

	private static function find_account( $login ) {
		global $wpdb;
		$ct    = self::t( 'contacts' );
		$login = trim( (string) $login );
		if ( $login === '' ) {
			return null;
		}
		$em = vai_norm_email( $login );
		if ( $em ) {
			return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $ct WHERE email_norm=%s AND pass_hash<>'' ORDER BY id ASC LIMIT 1", $em ) );
		}
		$pn = vai_norm_phone( $login );
		if ( strlen( $pn ) >= 9 ) {
			return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $ct WHERE phone_norm=%s AND pass_hash<>'' ORDER BY id ASC LIMIT 1", $pn ) );
		}
		return null;
	}

	private static function attach_visitor( $site, $uuid, $target ) {
		global $wpdb;
		$uuid = preg_replace( '/[^a-zA-Z0-9\-]/', '', (string) $uuid );
		if ( strlen( $uuid ) < 8 ) {
			return;
		}
		$vt  = self::t( 'visitors' );
		$now = vai_now();
		$v   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $vt WHERE uuid=%s AND site_id=%d", $uuid, $site->id ) );
		if ( $v ) {
			if ( (int) $v->contact_id !== (int) $target->id ) {
				$old = self::contact( $v->contact_id );
				if ( $old && (int) $old->stage < 1 && empty( $old->pass_hash ) ) {
					self::merge_contacts( $old, $target );
				}
				$wpdb->update( $vt, array( 'contact_id' => $target->id, 'last_at' => $now ), array( 'id' => $v->id ) );
			}
		} else {
			$wpdb->insert( $vt, array( 'uuid' => $uuid, 'site_id' => $site->id, 'contact_id' => $target->id, 'first_at' => $now, 'last_at' => $now ) );
		}
		$t = self::contact( $target->id );
		$wpdb->update( self::t( 'contacts' ), array( 'sites' => self::touch_sites( $t, $site ), 'last_site_id' => $site->id, 'last_login_at' => $now ), array( 'id' => $t->id ) );
	}

	private static function send_code_email( $c, $code, $link = '' ) {
		// 2.15.5 (owner): the activation mail leads with a ONE-CLICK link; the 4-digit code stays as the fallback.
		$body = $link !== ''
			? "مرحبًا " . $c->name . "،\n\nاضغط هذا الرابط وسيتفعّل حسابك فورًا — بدون إدخال أي أرقام:\n" . $link . "\n\nأو إن كنت تفضّل الرمز: أدخل هذا الرمز المكوّن من 4 أرقام في نافذة المساعد:\n\n" . $code . "\n\nالرابط والرمز صالحان 48 ساعة و30 دقيقة على الترتيب. إن لم تطلب هذا فتجاهل الرسالة.\n\nنادي المستثمرين — Vibes Ventures"
			: "مرحبًا " . $c->name . "،\n\nرمز التأكيد المكوّن من 4 أرقام:\n\n" . $code . "\n\nأدخله في الصفحة التي طلبتَه منها. الرمز صالح 30 دقيقة.\n\nإن لم تطلب هذا الرمز فتجاهل الرسالة.\n\nنادي المستثمرين — Vibes Ventures";
		return self::mail( $c->email, $link !== '' ? 'فعّل حسابك بضغطة واحدة — نادي المستثمرين' : 'رمز التأكيد — نادي المستثمرين', $body );
	}

	/** wp_mail wrapper that records the last failure for the diagnostics box. */
	public static function mail( $to, $subject, $body ) {
		$ok = wp_mail( $to, $subject, $body );
		update_option( 'vai_last_mail', array( 'at' => vai_now(), 'to' => (string) $to, 'ok' => $ok ? 1 : 0, 'subject' => (string) $subject ), false );
		return $ok;
	}

	private static function issue_verify_code( $c, $with_link = false ) {
		global $wpdb;
		$code = (string) wp_rand( 1000, 9999 ); // 2.15.5 (owner): «الأرقام اللي توصل ديما 4 فقط»
		$wpdb->update( self::t( 'contacts' ), array( 'verify_code' => vai_hash( $code ), 'verify_expires' => gmdate( 'Y-m-d H:i:s', time() + 30 * 60 ) ), array( 'id' => $c->id ) );
		$c    = self::contact( $c->id );
		$link = '';
		if ( $with_link ) {
			// 2.15.5: one-click activation — single-use token, 48 h, consumed by /?vai-activate=…
			$token = vai_key( 32 );
			set_transient( 'vai_actlink_' . vai_hash( $token ), (int) $c->id, 2 * DAY_IN_SECONDS );
			$link = home_url( '/?vai-activate=' . rawurlencode( $token ) );
		}
		return self::send_code_email( $c, $code, $link );
	}

	/** 2.15.5: the mailed one-click link — verifies the account exactly like op_verify, then shows a branded page. */
	public static function render_activate_page( $token ) {
		global $wpdb;
		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		header( 'X-Robots-Tag: noindex' );
		$logo = esc_url( vai_cfg( 'avatar_url' ) );
		$page = function ( $emoji, $title, $body ) use ( $logo ) {
			echo '<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>' . esc_html( $title ) . '</title>'
				. '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;600;700&display=swap">'
				. '<style>body{margin:0;background:#0d0d0d;font-family:"IBM Plex Sans Arabic",Tahoma,sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px 12px;box-sizing:border-box}.c{width:100%;max-width:420px;background:#fff;border-radius:26px;overflow:hidden;box-shadow:0 24px 60px rgba(0,0,0,.5);text-align:center}.h{background:#000;padding:24px;border-bottom:3px solid #B8962E}.h img{width:62px;height:62px;border-radius:50%;border:2px solid #B8962E}.b{padding:28px 24px;font-size:16px;line-height:2;color:#111}.e{font-size:44px}.a{display:inline-block;margin-top:14px;background:#B8962E;color:#fff;text-decoration:none;font-weight:700;padding:12px 26px;border-radius:999px;font-size:15px}</style></head><body><div class="c">'
				. '<div class="h"><img src="' . $logo . '" alt=""></div><div class="b"><div class="e">' . $emoji . '</div>' . $body . '</div></div></body></html>';
			exit;
		};
		$token = preg_replace( '/[^a-zA-Z0-9]/', '', (string) $token );
		$tk    = 'vai_actlink_' . vai_hash( $token );
		$cid   = $token !== '' ? (int) get_transient( $tk ) : 0;
		$c     = $cid ? self::contact( $cid ) : null;
		if ( ! $c ) {
			$page( '🙏', 'الرابط غير صالح', '<b>هذا الرابط غير صالح أو انتهت صلاحيته</b><br>اطلب رمزًا جديدًا من نافذة المساعد («لم يصلك؟ إعادة إرسال الرمز»)، أو تواصل مع الإدارة.<br><a class="a" href="' . esc_url( home_url( '/' ) ) . '">العودة للموقع</a>' );
		}
		delete_transient( $tk ); // single use
		if ( (int) $c->verified ) {
			$page( '✅', 'حسابك مفعّل بالفعل', '<b>حسابك مفعّل بالفعل يا ' . esc_html( $c->name ) . '</b><br>ادخل ببريدك وكلمة مرورك من أيقونة المساعد أسفل أي موقع من مواقع المنظومة.<br><a class="a" href="' . esc_url( home_url( '/' ) ) . '">افتح الموقع</a>' );
		}
		$now = vai_now();
		$wpdb->update( self::t( 'contacts' ), array( 'verified' => 1, 'verify_code' => '', 'verify_expires' => null, 'stage' => max( 1, (int) $c->stage ), 'trial_started_at' => $c->trial_started_at ? $c->trial_started_at : $now, 'last_at' => $now ), array( 'id' => $c->id ) );
		self::note_verified( $c->id, 'actlink', 'one-click mail link' );
		$c      = self::contact( $c->id );
		$member = self::member_lookup( $c->phone_norm, $c->email_norm );
		if ( $member && ! (int) $c->is_member ) {
			self::member_context( 'list' );
			self::set_member( $c->id, true );
			$c = self::contact( $c->id );
		}
		self::insert_message( $c->id, (int) $c->last_site_id, 'system', (int) $c->is_member ? 'فعّل حسابه برابط البريد ✅ وتم تفعيل عضويته تلقائيًا (دفع مسبق) ⭐' : 'فعّل حسابه برابط البريد (ضغطة واحدة) ✅' );
		self::send_welcome_email( $c );
		self::notify_registration( $c, self::self_site() );
		$page( '🎉', 'تم تفعيل حسابك', '<b>تم تفعيل حسابك بنجاح يا ' . esc_html( $c->name ) . '!</b><br>' . ( (int) $c->is_member ? 'وعضويتك السنوية مفعّلة ⭐' : 'ادخل الآن ببريدك وكلمة مرورك من أيقونة المساعد أسفل أي موقع من مواقع المنظومة.' ) . '<br><a class="a" href="' . esc_url( home_url( '/' ) ) . '">افتح الموقع الآن</a>' );
	}

	/* ── 2.15.2 pay-page e-mail proof (owner: «نتأكد إن هو صاحب الحساب اللي بيحجز») ──
	 * The pay page proves the typed e-mail with the SAME 4-digit code the widget uses,
	 * BEFORE any password lands and before the checkout opens. */

	/** Find-or-create the UNVERIFIED pay-page contact — no password yet; the e-mail code proves ownership first.
	 * Returns the contact, or a WP_Error when the phone already belongs to a different e-mail. */
	public static function pay_hold_contact( $name, $pn, $em ) {
		global $wpdb;
		$ct  = self::t( 'contacts' );
		$pn  = vai_norm_phone( $pn );
		$em  = vai_norm_email( $em );
		$now = vai_now();
		$c   = $em !== '' ? $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $ct WHERE email_norm=%s ORDER BY (pass_hash<>'') DESC, verified DESC, id ASC LIMIT 1", $em ) ) : null;
		if ( ! $c && $pn !== '' ) {
			$byPhone = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $ct WHERE phone_norm=%s ORDER BY (pass_hash<>'') DESC, verified DESC, id ASC LIMIT 1", $pn ) );
			if ( $byPhone && (string) $byPhone->email_norm !== '' && (string) $byPhone->email_norm !== $em ) {
				return new WP_Error( 'phone_taken', 'هذا الجوال مسجّل ببريد آخر — استخدم نفس البريد المسجّل أو تواصل مع الإدارة' );
			}
			$c = $byPhone;
		}
		if ( ! $c ) {
			$wpdb->insert( $ct, array( 'name' => (string) $name, 'phone' => vai_phone_local( $pn ), 'phone_norm' => $pn, 'email' => $em, 'email_norm' => $em, 'stage' => 0, 'verified' => 0, 'created_at' => $now, 'first_at' => $now, 'last_at' => $now, 'sites' => '[]', 'last_site_id' => (int) self::self_site()->id ) );
			return self::contact( $wpdb->insert_id );
		}
		$upd = array( 'last_at' => $now );
		if ( (string) $c->name === '' && $name !== '' ) {
			$upd['name'] = (string) $name;
		}
		if ( (string) $c->email_norm === '' && $em !== '' ) {
			$upd['email']      = $em;
			$upd['email_norm'] = $em;
		}
		if ( (string) $c->phone_norm === '' && $pn !== '' ) {
			$upd['phone']      = vai_phone_local( $pn );
			$upd['phone_norm'] = $pn;
		}
		$wpdb->update( $ct, $upd, array( 'id' => $c->id ) );
		return self::contact( $c->id );
	}

	/** Mail a fresh 4-digit code to the held contact. */
	public static function pay_issue_code( $contact_id ) {
		$c = self::contact( (int) $contact_id );
		return $c && $c->email ? self::issue_verify_code( $c ) : false;
	}

	/** Check and CONSUME the code (the caller completes the account afterwards). */
	public static function pay_check_code( $contact_id, $code ) {
		global $wpdb;
		$c    = self::contact( (int) $contact_id );
		$code = preg_replace( '/\D+/', '', (string) $code );
		if ( ! $c || strlen( $code ) < 4 || strlen( $code ) > 6 || (string) $c->verify_code === '' || ! $c->verify_expires || strtotime( $c->verify_expires . ' UTC' ) < time() || ! hash_equals( (string) $c->verify_code, vai_hash( $code ) ) ) {
			return false;
		}
		$wpdb->update( self::t( 'contacts' ), array( 'verify_code' => '', 'verify_expires' => null ), array( 'id' => $c->id ) );
		return true;
	}

	private static function op_register( $site, $d ) {
		global $wpdb;
		$name    = vai_str( $d, 'name', 120 );
		$country = strtolower( vai_str( $d, 'country', 5 ) ) ?: 'sa';
		$phone_in = vai_str( $d, 'phone', 40 );
		$email   = vai_norm_email( vai_str( $d, 'email', 190 ) );
		$job     = vai_str( $d, 'job_title', 150 );
		$pass    = isset( $d['password'] ) && is_string( $d['password'] ) ? $d['password'] : '';
		$persona = preg_replace( '/[^a-z]/', '', strtolower( vai_str( $d, 'persona', 20 ) ) );
		$bio     = vai_text_ok( $d, 'bio', 600 );
		// 2.18.0 (M69): «فرد / شركة» right under the name — a company registration carries the company name.
		$mtype   = preg_replace( '/[^a-z]/', '', strtolower( vai_str( $d, 'member_type', 20 ) ) ) ?: 'individual';
		$cname   = vai_str( $d, 'company_name', 190 );
		if ( $name === '' ) {
			return vai_error( 'invalid', 'الاسم مطلوب' );
		}
		if ( ! in_array( $mtype, array( 'individual', 'company' ), true ) ) {
			return vai_error( 'invalid', 'اختر نوع الحساب: فرد أو شركة' );
		}
		if ( 'company' === $mtype && mb_strlen( trim( $cname ), 'UTF-8' ) < 2 ) {
			return vai_error( 'company_name', 'اكتب اسم الشركة لإكمال التسجيل' );
		}
		if ( 'individual' === $mtype ) {
			$cname = '';
		}
		$pn = (int) vai_cfg( 'gcc_only' ) ? vai_phone_intl( $country, $phone_in ) : vai_norm_phone( $phone_in );
		if ( $pn === '' || strlen( $pn ) < 9 || strlen( $pn ) > 15 ) {
			$cc = vai_gcc_countries();
			$ex = isset( $cc[ $country ] ) && $cc[ $country ]['example'] !== '' ? $cc[ $country ]['example'] : '';
			return vai_error( 'phone', 'رقم الجوال غير صحيح أو ناقص — تأكد من اختيار دولتك من القائمة ثم اكتب الرقم بدون مسافات وبدون رمز الدولة' . ( $ex !== '' ? ' بهذا الشكل: ' . $ex . ( $country === 'sa' ? ' (للسعودية)' : '' ) : '' ) . '.' );
		}
		$phone = vai_phone_local( $pn );
		if ( ! in_array( $persona, array( 'neutral', 'entrepreneur', 'investor' ), true ) ) {
			return vai_error( 'invalid', 'اختر فئتك في النادي: محايد، رائد أعمال، أو مستثمر' );
		}
		if ( mb_strlen( trim( $bio ), 'UTF-8' ) < 10 ) {
			return vai_error( 'invalid', 'اكتب نبذة مختصرة عنك (سطر على الأقل) لنكمل التسجيل' );
		}
		if ( $email === '' ) {
			return vai_error( 'invalid', 'البريد الإلكتروني مطلوب — يصلك عليه رمز التفعيل' );
		}
		if ( ! is_email( $email ) || ! vai_email_allowed( $email ) ) {
			return vai_error( 'email_domain', 'البريد الإلكتروني غير صحيح — سيصلك كود التفعيل عليه، فتأكد من كتابته صحيحًا (أي بريد شخصي أو بريد شركة مقبول)' );
		}
		if ( strlen( $pass ) < 6 ) {
			return vai_error( 'invalid', 'كلمة المرور 6 أحرف على الأقل' );
		}
		if ( (int) vai_cfg( 'saudi_only' ) && strpos( $pn, '966' ) !== 0 ) {
			return vai_error( 'saudi', 'نخدم داخل المملكة فقط — نحتاج رقم جوال سعودي (966)' );
		}
		// 2.7.2 (app M32): an invite code = another member's membership number. The hub itself resolves the
		// digits and stores the inviter on the new contact — the app server passes the code through, never a verdict.
		$referral = vai_str( $d, 'referral', 40 );
		$ref_id   = 0;
		$ref_name = '';
		if ( $referral !== '' ) {
			$rid = (int) preg_replace( '/\D+/', '', $referral );
			$rc  = $rid > 0 ? self::contact( $rid ) : null;
			if ( ! $rc || empty( $rc->pass_hash ) || ! (int) $rc->verified || ! self::member_active( $rc ) ) {
				return vai_error( 'referral', 'كود الدعوة غير صحيح أو عضوية صاحبه غير سارية — راجعه مع من دعاك، أو امسحه وأكمل التسجيل' );
			}
			$ref_id   = (int) $rc->id;
			$ref_name = (string) $rc->name;
		}
		if ( self::too_many_attempts( 'reg_' . ( isset( $d['ip'] ) ? $d['ip'] : '' ), 12 ) ) {
			return vai_error( 'rate', 'محاولات كثيرة — حاول بعد قليل', 429 );
		}
		$ct = self::t( 'contacts' );
		$ex = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $ct WHERE (email_norm=%s OR phone_norm=%s) AND pass_hash<>'' ORDER BY verified DESC, id ASC LIMIT 1", $email, $pn ) );
		if ( $ex && (int) $ex->verified ) {
			return vai_error( 'exists', 'عندك حساب بهذا البريد أو الجوال — سجّل الدخول، أو استخدم «نسيت كلمة المرور»', 409 );
		}
		list( $c ) = self::resolve_contact( $site, isset( $d['uuid'] ) ? $d['uuid'] : '', true, array( 'ip' => isset( $d['ip'] ) ? $d['ip'] : '' ) );
		if ( ! $c ) {
			return vai_error( 'bad_uuid', 'معرّف الزائر غير صحيح' );
		}
		if ( $ex ) {
			// pending (unverified) account: adopt it and resend the code
			if ( (int) $ex->id !== (int) $c->id ) {
				self::merge_contacts( $c, $ex );
				$c = self::contact( $ex->id );
				self::attach_visitor( $site, isset( $d['uuid'] ) ? $d['uuid'] : '', $c );
			}
		} else {
			$ex2 = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $ct WHERE id<>%d AND stage>=1 AND pass_hash='' AND (phone_norm=%s OR email_norm=%s) ORDER BY last_at DESC LIMIT 1", $c->id, $pn, $email ) );
			if ( $ex2 ) {
				self::merge_contacts( $c, $ex2 );
				$c = self::contact( $ex2->id );
				self::attach_visitor( $site, isset( $d['uuid'] ) ? $d['uuid'] : '', $c );
			}
		}
		if ( $ref_id === (int) $c->id ) {
			$ref_id   = 0;
			$ref_name = '';
		}
		$fields = array(
			'name'       => $name,
			'phone'      => $phone,
			'phone_norm' => $pn,
			'email'      => $email,
			'email_norm' => $email,
			'job_title'   => $job,
			'persona'     => $persona,
			'bio'         => $bio,
			'member_type' => $mtype,
			'pass_hash'   => wp_hash_password( $pass ),
			'verified'    => 0,
			'last_at'     => vai_now(),
		);
		if ( $cname !== '' ) {
			$fields['company'] = $cname;
		}
		if ( $ref_id ) {
			$fields['referred_by'] = $ref_id;
		}
		$wpdb->update( $ct, $fields, array( 'id' => $c->id ) );
		$c    = self::contact( $c->id );
		$sent = self::issue_verify_code( $c, true );
		self::log_event_once( $c->id, 'registered', self::site_source( $site ), $site->host );
		self::insert_message( $c->id, $site->id, 'system', 'بدأ إنشاء حساب للاشتراك (بانتظار رمز التفعيل): ' . $c->name . ( 'company' === $mtype ? ' (شركة: ' . $cname . ')' : ' (فرد)' ) . ' / ' . $c->phone . ' / ' . $c->email . ( $job ? ' / ' . $job : '' ) . ( $ref_id ? ' — بدعوة من العضو #' . $ref_id . ' ' . $ref_name : '' ) . ( $sent ? '' : ' — فشل إرسال البريد!' ), null, vai_str( $d, 'page_url', 500 ) );
		return array( 'ok' => true, 'pending' => true, 'mail_sent' => $sent ? 1 : 0, 'contact' => self::public_contact( $c ), 'referred_by' => $ref_id, 'referred_name' => $ref_name, 'text' => $sent ? 'أرسلنا رمز التفعيل إلى ' . $email : 'تعذّر إرسال البريد الآن — اضغط «إعادة الإرسال» بعد لحظات أو تواصل مع الإدارة' );
	}

	private static function op_resend_code( $site, $d ) {
		list( $c ) = self::resolve_contact( $site, isset( $d['uuid'] ) ? $d['uuid'] : '', false );
		if ( ! $c || empty( $c->pass_hash ) || (int) $c->verified ) {
			return vai_error( 'invalid', 'لا يوجد حساب بانتظار التفعيل' );
		}
		if ( get_transient( 'vai_resend_' . $c->id ) ) {
			return vai_error( 'rate', 'انتظر دقيقة قبل إعادة الإرسال', 429 );
		}
		set_transient( 'vai_resend_' . $c->id, 1, 60 );
		$sent = self::issue_verify_code( $c, true );
		return array( 'ok' => true, 'mail_sent' => $sent ? 1 : 0, 'text' => $sent ? 'أعدنا إرسال الرمز إلى ' . $c->email : 'تعذّر إرسال البريد — تواصل مع الإدارة' );
	}

	private static function op_verify( $site, $d ) {
		global $wpdb;
		list( $c ) = self::resolve_contact( $site, isset( $d['uuid'] ) ? $d['uuid'] : '', false );
		$code = preg_replace( '/\D+/', '', vai_str( $d, 'code', 10 ) );
		if ( ! $c || empty( $c->pass_hash ) ) {
			return vai_error( 'invalid', 'لا يوجد حساب بانتظار التفعيل' );
		}
		if ( (int) $c->verified ) {
			return array( 'ok' => true, 'contact' => self::public_contact( $c ), 'already' => true );
		}
		if ( self::too_many_attempts( 'verify_' . $c->id, 8 ) ) {
			return vai_error( 'rate', 'محاولات كثيرة — أعد إرسال رمز جديد', 429 );
		}
		if ( strlen( $code ) < 4 || strlen( $code ) > 6 || $c->verify_code === '' || ! $c->verify_expires || strtotime( $c->verify_expires . ' UTC' ) < time() || ! hash_equals( $c->verify_code, vai_hash( $code ) ) ) {
			return vai_error( 'bad_code', 'الرمز غير صحيح أو انتهت صلاحيته', 400 );
		}
		$ct  = self::t( 'contacts' );
		$now = vai_now();
		$wpdb->update(
			$ct,
			array(
				'verified'         => 1,
				'verify_code'      => '',
				'verify_expires'   => null,
				'stage'            => max( 1, (int) $c->stage ),
				'trial_started_at' => $c->trial_started_at ? $c->trial_started_at : $now,
				'last_login_at'    => $now,
				'last_at'          => $now,
			),
			array( 'id' => $c->id )
		);
		self::note_verified( $c->id, self::site_source( $site ), $site->host );
		$c = self::contact( $c->id );
		$member = self::member_lookup( $c->phone_norm, $c->email_norm );
		if ( $member && ! (int) $c->is_member ) {
			self::member_context( 'list' );
			self::set_member( $c->id, true );
			$c = self::contact( $c->id );
		}
		self::insert_message( $c->id, $site->id, 'system', (int) $c->is_member ? 'فعّل حسابه بالبريد ✅ وتم تفعيل عضويته تلقائيًا (دفع مسبق) ⭐' : 'فعّل حسابه بالبريد ✅ — بانتظار دفع العضوية', null, vai_str( $d, 'page_url', 500 ) );
		$payload = self::n8n_payload( 'identified', $c, $site, 0, '', vai_str( $d, 'page_url', 500 ), vai_str( $d, 'page_title', 200 ), array( 'registered' => true, 'returning' => (int) $c->msg_count > 0 ) );
		$wpdb->update( $ct, array( 'awaiting_since' => $now ), array( 'id' => $c->id ) );
		if ( ! self::call_n8n( $payload ) ) {
			$wpdb->update( $ct, array( 'awaiting_since' => null ), array( 'id' => $c->id ) );
			$svc = self::service_by_key( 'membership' );
			self::insert_message( $c->id, $site->id, 'assistant', 'حياك الله يا أستاذ ' . $c->name . ' 🌹 حسابك مسجّل، لكن عضويتك غير مفعّلة بعد — برجاء تفعيل عضويتك السنوية من الرابط وبيفعّلها الفريق فورًا، وبعدها أكون مستشارك الخاص على مدار الساعة 🤝' . ( $svc && $svc['pay_url'] ? "\n" . $svc['pay_url'] : '' ) );
		}
		self::send_welcome_email( $c );
		self::notify_registration( $c, $site );
		self::add_lead( $c, $site, 'contact', 'أنشأ حسابًا (مفعّل بالبريد) — بانتظار دفع العضوية', $c->company, ( $c->job_title ? 'الوظيفة: ' . $c->job_title . ' — ' : '' ) . 'الصفحة: ' . vai_str( $d, 'page_url', 300 ) );
		return array( 'ok' => true, 'contact' => self::public_contact( $c ), 'messages' => self::history_rows( $c->id, 40 ) );
	}

	public static function persona_label( $p ) {
		// 2.7.1 — the owner's order and wording (the same three lines as the app): neutral, entrepreneur, investor
		$m = array( 'neutral' => 'محايد — أستكشف توجهي', 'entrepreneur' => 'رائد أعمال — لدي مشروع', 'investor' => 'مستثمر — أبحث عن فرص' );
		return isset( $m[ $p ] ) ? $m[ $p ] : ( $p ?: '—' );
	}

	/** 2.14.3 (owner): a social-born account is complete once his real phone + category + bio exist. */
	public static function profile_complete( $c ) {
		if ( ! $c ) { return false; }
		$ph = trim( (string) ( $c->phone_norm ?: $c->phone ) );
		return $ph !== '' && in_array( (string) $c->persona, array( 'neutral', 'entrepreneur', 'investor' ), true ) && mb_strlen( trim( (string) $c->bio ), 'UTF-8' ) >= 10;
	}

	/** 2.14.3: the deferred admin mail — fires ONCE, only when the held account turns complete. */
	public static function maybe_deferred_notify( $contact_id, $site = null ) {
		global $wpdb;
		$c = self::contact( (int) $contact_id );
		if ( ! $c || empty( $c->notify_pending ) || ! self::profile_complete( $c ) ) {
			return;
		}
		$wpdb->update( self::t( 'contacts' ), array( 'notify_pending' => 0 ), array( 'id' => $c->id ) );
		self::notify_registration( self::contact( $c->id ), $site );
	}

	private static function notify_registration( $c, $site ) {
		if ( ! (int) vai_cfg( 'notify_registration' ) ) {
			return;
		}
		$lines = array(
			'🆕 حساب جديد في Vibes Ventures — بانتظار دفع العضوية السنوية',
			'',
			'الاسم: ' . $c->name,
			'الجوال: ' . vai_phone_local( $c->phone_norm ?: $c->phone ),
			'البريد: ' . $c->email,
			'الوظيفة: ' . ( $c->job_title ?: '—' ),
			'الفئة: ' . self::persona_label( $c->persona ),
			'نبذة: ' . ( $c->bio ?: '—' ),
			'الموقع الذي سجّل منه: ' . ( $site ? $site->host : '' ),
			'التاريخ: ' . vai_riyadh( vai_now() ) . ' (الرياض)',
			'',
			'ملفه في لوحة المتابعة: ' . admin_url( 'admin.php?page=vibes-ai&contact=' . (int) $c->id ),
			'كل الحسابات: ' . admin_url( 'admin.php?page=vibes-ai-accounts' ),
		);
		$emails = array_filter( array_map( 'trim', explode( ',', (string) vai_opt( 'notify_email', get_option( 'admin_email' ) ) ) ) );
		foreach ( $emails as $e ) {
			if ( is_email( $e ) ) {
				self::mail( $e, '[Vibes AI] عضو جديد: ' . $c->name . ' — ' . ( $site ? $site->host : '' ), implode( "\n", $lines ) );
			}
		}
	}

	private static function op_login( $site, $d ) {
		global $wpdb;
		$login = vai_str( $d, 'login', 190 );
		$pass  = isset( $d['password'] ) && is_string( $d['password'] ) ? $d['password'] : '';
		if ( self::too_many_attempts( 'login_' . ( isset( $d['ip'] ) ? $d['ip'] : '' ) . '_' . strtolower( $login ) ) ) {
			return vai_error( 'rate', 'محاولات كثيرة — انتظر 15 دقيقة أو استخدم «نسيت كلمة المرور»', 429 );
		}
		$acc = self::find_account( $login );
		if ( ! $acc || $pass === '' || ! wp_check_password( $pass, $acc->pass_hash ) ) {
			return vai_error( 'bad_login', 'البريد/الجوال أو كلمة المرور غير صحيحة', 401 );
		}
		self::attach_visitor( $site, isset( $d['uuid'] ) ? $d['uuid'] : '', $acc );
		if ( class_exists( 'VAI_Payments' ) && (int) $acc->verified ) {
			VAI_Payments::notify_user_event( $acc, 'login', $site->host );
		}
		if ( ! (int) $acc->verified ) {
			$sent = get_transient( 'vai_resend_' . $acc->id ) ? true : self::issue_verify_code( $acc, true );
			set_transient( 'vai_resend_' . $acc->id, 1, 60 );
			return array( 'ok' => true, 'pending' => true, 'mail_sent' => $sent ? 1 : 0, 'contact' => self::public_contact( self::contact( $acc->id ) ), 'text' => 'حسابك بانتظار التفعيل — أرسلنا الرمز إلى ' . $acc->email );
		}
		$acc = self::contact( $acc->id );
		self::insert_message( $acc->id, $site->id, 'system', 'سجّل الدخول على ' . $site->host );
		// The app server signs people in for the app and for the dashboard, often several times a day: no «welcome back»
		// line is written into the conversation for it and no model call is spent on one (2.7.0).
		if ( ! empty( $site->trusted ) ) {
			return array( 'ok' => true, 'contact' => self::public_contact( $acc ), 'messages' => self::history_rows( $acc->id, 40 ) );
		}
		$payload = self::n8n_payload( 'identified', $acc, $site, 0, '', vai_str( $d, 'page_url', 500 ), vai_str( $d, 'page_title', 200 ), array( 'returning' => true, 'login' => true ) );
		$wpdb->update( self::t( 'contacts' ), array( 'awaiting_since' => vai_now() ), array( 'id' => $acc->id ) );
		if ( ! self::call_n8n( $payload ) ) {
			$wpdb->update( self::t( 'contacts' ), array( 'awaiting_since' => null ), array( 'id' => $acc->id ) );
			self::insert_message( $acc->id, $site->id, 'assistant', 'أهلًا بك من جديد يا أستاذ ' . $acc->name . ' 🌹 تعرّفت عليك — نكمل من حيث وقفنا؟' );
		}
		return array( 'ok' => true, 'contact' => self::public_contact( $acc ), 'messages' => self::history_rows( $acc->id, 40 ) );
	}

	/**
	 * 2.8.0 (M46): sign-in with Google / Apple. Trusted-only: the app server verified the provider's ID
	 * token itself (signature, audience, expiry) and vouches for this e-mail — the hub finds or creates
	 * the contact by it (rule 2: one identity source) and answers like op_login, with no code step.
	 */
	private static function op_social_login( $site, $d ) {
		$provider = strtolower( vai_str( $d, 'provider', 20 ) );
		$email    = vai_norm_email( vai_str( $d, 'email', 190 ) );
		$sub      = vai_str( $d, 'sub', 190 );
		if ( ! in_array( $provider, array( 'google', 'apple' ), true ) || $email === '' || ! is_email( $email ) || $sub === '' ) {
			return vai_error( 'invalid', 'بيانات الدخول غير مكتملة' );
		}
		if ( self::too_many_attempts( 'social_' . ( isset( $d['ip'] ) ? $d['ip'] : '' ), 20 ) ) {
			return vai_error( 'rate', 'محاولات كثيرة — حاول بعد قليل', 429 );
		}
		$res = self::social_account( $site, $d, $provider, $email, vai_str( $d, 'name', 120 ), ! empty( $d['allow_create'] ), 'التسجيل من التطبيق' );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		list( $acc, $created ) = $res;
		return array( 'ok' => true, 'contact' => self::public_contact( $acc ), 'created' => $created ? 1 : 0, 'messages' => self::history_rows( $acc->id, 40 ) );
	}

	/**
	 * 2.9.0 (M49): «المتابعة بحساب Google» from the SITE widget. A public site op — no trusted server in
	 * between — so the hub verifies the ID token ITSELF (VAI_Google: RS256 against Google's JWKS, audience
	 * = the «Google Web Client ID» setting, expiry, provider-verified e-mail), then walks the same
	 * find-or-create path as social_login. Satellites reach it through their own /client proxy once their
	 * origin is added on the same Google client. Empty setting = the button is hidden and this op refuses.
	 */
	private static function op_google( $site, $d ) {
		global $wpdb;
		$cid = trim( (string) vai_opt( 'google_client_id', '' ) );
		if ( $cid === '' ) {
			return vai_error( 'off', 'الدخول بحساب Google غير مفعّل حاليًا', 403 );
		}
		if ( self::too_many_attempts( 'social_' . ( isset( $d['ip'] ) ? $d['ip'] : '' ), 20 ) ) {
			return vai_error( 'rate', 'محاولات كثيرة — حاول بعد قليل', 429 );
		}
		$claims = VAI_Google::verify( isset( $d['credential'] ) && is_string( $d['credential'] ) ? $d['credential'] : '', $cid );
		if ( is_wp_error( $claims ) ) {
			return vai_error( 'google', 'تعذّر التحقق من حساب Google — حاول مرة ثانية أو ادخل بالبريد وكلمة المرور', 401 );
		}
		// The widget's register step is open to visitors, so creation is allowed here (same as op_register).
		$res = self::social_account( $site, $d, 'google', $claims['email'], vai_str( $claims, 'name', 120 ), true, 'التسجيل من الويدجت — Google' );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		list( $acc, $created ) = $res;
		// The adviser greets like login/verify do on a widget site (the app's trusted path never calls n8n here).
		if ( empty( $site->trusted ) ) {
			$extra   = $created ? array( 'registered' => true, 'social' => 'google', 'returning' => (int) $acc->msg_count > 0 ) : array( 'returning' => true, 'login' => true );
			$payload = self::n8n_payload( 'identified', $acc, $site, 0, '', vai_str( $d, 'page_url', 500 ), vai_str( $d, 'page_title', 200 ), $extra );
			$wpdb->update( self::t( 'contacts' ), array( 'awaiting_since' => vai_now() ), array( 'id' => $acc->id ) );
			if ( ! self::call_n8n( $payload ) ) {
				$wpdb->update( self::t( 'contacts' ), array( 'awaiting_since' => null ), array( 'id' => $acc->id ) );
				self::insert_message( $acc->id, $site->id, 'assistant', $created ? 'حياك الله يا أستاذ ' . $acc->name . ' 🌹 تم إنشاء حسابك بحساب Google وتفعيله — كيف أقدر أخدمك؟' : 'أهلًا بك من جديد يا أستاذ ' . $acc->name . ' 🌹 تعرّفت عليك — نكمل من حيث وقفنا؟' );
			}
		}
		return array( 'ok' => true, 'contact' => self::public_contact( $acc ), 'created' => $created ? 1 : 0, 'messages' => self::history_rows( $acc->id, 40 ) );
	}

	/**
	 * Find or create a VERIFIED account for a provider-proven e-mail (shared by the trusted social_login
	 * and the widget's op_google). Returns array( $acc, $created ) or WP_Error.
	 */
	private static function social_account( $site, $d, $provider, $email, $name, $allow_create, $lead_notes ) {
		global $wpdb;
		$pname = $provider === 'google' ? 'Google' : 'Apple';
		$ct    = self::t( 'contacts' );
		// Any account with this e-mail — with or without a password (a social account may never set one).
		$acc     = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $ct WHERE email_norm=%s ORDER BY (pass_hash<>'') DESC, verified DESC, id ASC LIMIT 1", $email ) );
		$created = false;
		if ( ! $acc ) {
			if ( ! $allow_create ) {
				return vai_error( 'registration_closed', 'التسجيل غير متاح حاليًا — تواصل مع الإدارة', 403 );
			}
			list( $c ) = self::resolve_contact( $site, isset( $d['uuid'] ) ? $d['uuid'] : '', true, array( 'ip' => isset( $d['ip'] ) ? $d['ip'] : '' ) );
			if ( ! $c ) {
				return vai_error( 'bad_uuid', 'معرّف الزائر غير صحيح' );
			}
			$wpdb->update(
				$ct,
				array(
					'name'       => $name !== '' ? $name : substr( $email, 0, (int) strpos( $email, '@' ) ),
					'email'      => $email,
					'email_norm' => $email,
					// A random unusable password makes it a full account everywhere (has_account, audiences,
					// find_account); the member can set his own any time via «نسيت كلمة المرور» — the e-mail is his.
					'pass_hash'  => wp_hash_password( vai_key( 32 ) ),
					'last_at'    => vai_now(),
				),
				array( 'id' => $c->id )
			);
			$acc     = self::contact( $c->id );
			$created = true;
			self::log_event_once( $acc->id, 'registered', self::site_source( $site ), $pname . ' — ' . $site->host );
		}
		if ( ! (int) $acc->verified ) {
			// The provider proved the e-mail — no code step.
			$wpdb->update( $ct, array( 'verified' => 1, 'stage' => max( 1, (int) $acc->stage ) ), array( 'id' => $acc->id ) );
			self::note_verified( $acc->id, self::site_source( $site ), $pname );
		}
		if ( empty( $acc->pass_hash ) ) {
			// A matched account Paymob once created without a password: complete it the same way.
			$wpdb->update( $ct, array( 'pass_hash' => wp_hash_password( vai_key( 32 ) ) ), array( 'id' => $acc->id ) );
		}
		if ( $name !== '' && trim( (string) $acc->name ) === '' ) {
			$wpdb->update( $ct, array( 'name' => $name ), array( 'id' => $acc->id ) );
		}
		self::attach_visitor( $site, isset( $d['uuid'] ) ? $d['uuid'] : '', $acc );
		$acc = self::contact( $acc->id );
		// A pre-paid member (paylink / campaign / manual store row) signing in socially for the first time
		// gets his membership recognized at once — the same match op_verify runs after the e-mail code (2.9.0).
		$member = self::member_lookup( $acc->phone_norm, $acc->email_norm );
		if ( $member && ! (int) $acc->is_member ) {
			self::member_context( 'list' );
			self::set_member( $acc->id, true );
			$acc = self::contact( $acc->id );
		}
		if ( $created ) {
			self::insert_message( $acc->id, $site->id, 'system', '🆕 أنشأ حسابه بالدخول عبر ' . $pname . ' ✅' . ( (int) $acc->is_member ? ' وتم تفعيل عضويته تلقائيًا (دفع مسبق) ⭐' : '' ), null, vai_str( $d, 'page_url', 500 ) );
			// 2.12.0 (owner): the new social account hears from us AT ONCE — his details + how to complete them.
			if ( is_email( $acc->email ) && class_exists( 'VAI_Payments' ) ) {
				$hello = 'مرحبًا ' . $acc->name . "،

" . 'تم إنشاء حسابك في Vibes Ventures ونادي المستثمرين بحساب ' . $pname . " ✅

" . 'بيانات حسابك:' . "
" . '• البريد: ' . $acc->email . "
" . '• الدخول: بزر «المتابعة بحساب ' . $pname . '» نفسه على أي موقع من مواقع المنظومة أو من التطبيق، أو عيّن كلمة مرور خاصة بك في أي وقت من «نسيت كلمة المرور».' . "

" . 'خطوة واحدة ناقصة لإكمال حسابك: افتح المساعد (الأيقونة أسفل الموقع) وأكمل جوالك وفئتك في النادي ونبذة عنك — دقيقة واحدة وتصلك كل خدماتنا باسمك.' . "

" . ( (int) $acc->is_member ? 'عضويتك السنوية مفعّلة ⭐ — استمتع بكل المزايا.' : 'ولتفعيل عضويتك السنوية وكل مزاياها ادفع مباشرة من هنا: {pay_url}' ) . "

" . 'نادي المستثمرين — Vibes Ventures';
				VAI_Hub::mail( $acc->email, 'حسابك في نادي المستثمرين جاهز — أكمل بياناتك في دقيقة', VAI_Payments::render( $hello, $acc ) );
			}
			if ( self::profile_complete( $acc ) ) {
				self::notify_registration( $acc, $site );
			} else {
				// 2.14.3 (owner): «تسجيلات بدون أي بيانات» — the admin mail waits for his real data; one full mail, never an empty one.
				$wpdb->update( $ct, array( 'notify_pending' => 1 ), array( 'id' => $acc->id ) );
			}
			self::add_lead( $acc, $site, 'contact', 'أنشأ حسابًا عبر ' . $pname . ( (int) $acc->is_member ? ' — عضويته مفعّلة (دفع مسبق)' : ' — بانتظار دفع العضوية' ), $acc->company, $lead_notes );
		} else {
			self::insert_message( $acc->id, $site->id, 'system', 'سجّل الدخول عبر ' . $pname . ' على ' . $site->host );
			if ( class_exists( 'VAI_Payments' ) ) {
				VAI_Payments::notify_user_event( $acc, 'login', $site->host );
			}
		}
		return array( $acc, $created );
	}

	private static function op_logout( $site, $d ) {
		global $wpdb;
		$uuid = preg_replace( '/[^a-zA-Z0-9\-]/', '', (string) ( isset( $d['uuid'] ) ? $d['uuid'] : '' ) );
		if ( strlen( $uuid ) >= 8 ) {
			$wpdb->delete( self::t( 'visitors' ), array( 'uuid' => $uuid, 'site_id' => $site->id ) );
		}
		return array( 'ok' => true );
	}

	private static function op_account( $site, $d ) {
		list( $c ) = self::resolve_contact( $site, isset( $d['uuid'] ) ? $d['uuid'] : '', false );
		return array( 'ok' => true, 'contact' => self::public_contact( $c ) );
	}

	private static function op_profile( $site, $d ) {
		global $wpdb;
		list( $c ) = self::resolve_contact( $site, isset( $d['uuid'] ) ? $d['uuid'] : '', false );
		if ( ! $c || empty( $c->pass_hash ) ) {
			return vai_error( 'no_account', 'سجّل الدخول أولًا', 401 );
		}
		$upd = array();
		if ( isset( $d['name'] ) && vai_str( $d, 'name', 120 ) !== '' ) {
			$upd['name'] = vai_str( $d, 'name', 120 );
		}
		if ( isset( $d['phone'] ) ) {
			$pn = (int) vai_cfg( 'gcc_only' ) ? vai_phone_intl( strtolower( vai_str( $d, 'country', 5 ) ) ?: 'sa', vai_str( $d, 'phone', 40 ) ) : vai_norm_phone( vai_str( $d, 'phone', 40 ) );
			if ( strlen( $pn ) < 9 ) {
				return vai_error( 'phone', 'رقم الجوال غير صحيح — اكتبه بهذا الشكل: 0512345678 أو اختر دولتك الخليجية' );
			}
			$other = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . self::t( 'contacts' ) . " WHERE phone_norm=%s AND pass_hash<>'' AND id<>%d LIMIT 1", $pn, $c->id ) );
			if ( $other ) {
				return vai_error( 'exists', 'هذا الجوال مسجّل لحساب آخر' );
			}
			$upd['phone']      = vai_phone_local( $pn );
			$upd['phone_norm'] = $pn;
		}
		if ( isset( $d['email'] ) ) {
			$em = vai_norm_email( vai_str( $d, 'email', 190 ) );
			if ( $em === '' || ! vai_email_allowed( $em ) ) {
				return vai_error( 'email_domain', vai_email_policy_text() );
			}
			$other = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . self::t( 'contacts' ) . " WHERE email_norm=%s AND pass_hash<>'' AND id<>%d LIMIT 1", $em, $c->id ) );
			if ( $other ) {
				return vai_error( 'exists', 'هذا البريد مسجّل لحساب آخر' );
			}
			$upd['email']      = $em;
			$upd['email_norm'] = $em;
		}
		foreach ( array( 'company' => 190, 'city' => 120, 'job_title' => 150, 'website' => 300 ) as $k => $max ) {
			if ( isset( $d[ $k ] ) ) {
				$upd[ $k ] = vai_str( $d, $k, $max );
			}
		}
		if ( isset( $d['persona'] ) ) {
			$pv = preg_replace( '/[^a-z]/', '', strtolower( vai_str( $d, 'persona', 20 ) ) );
			if ( ! in_array( $pv, array( 'neutral', 'entrepreneur', 'investor' ), true ) ) {
				return vai_error( 'invalid', 'اختر فئتك في النادي: محايد، رائد أعمال، أو مستثمر' );
			}
			$upd['persona'] = $pv;
		}
		if ( isset( $d['bio'] ) ) {
			$upd['bio'] = vai_text_ok( $d, 'bio', 600 );
		}
		if ( isset( $d['social'] ) ) {
			$upd['social'] = vai_text_ok( $d, 'social', 800 );
		}
		if ( ! empty( $d['avatar'] ) && is_string( $d['avatar'] ) ) {
			$url = self::store_image( $d['avatar'] );
			if ( $url ) {
				$upd['avatar_url'] = $url;
			}
		}
		if ( isset( $d['password'] ) && is_string( $d['password'] ) && $d['password'] !== '' ) {
			if ( strlen( $d['password'] ) < 6 ) {
				return vai_error( 'invalid', 'كلمة المرور 6 أحرف على الأقل' );
			}
			$upd['pass_hash'] = wp_hash_password( $d['password'] );
		}
		if ( $upd ) {
			$wpdb->update( self::t( 'contacts' ), $upd, array( 'id' => $c->id ) );
			self::insert_message( $c->id, $site->id, 'system', 'حدّث ملفه الشخصي: ' . implode( '، ', array_keys( $upd ) ) );
			if ( class_exists( 'VAI_Payments' ) ) {
				VAI_Payments::notify_user_event( self::contact( $c->id ), 'profile', $site->host );
			}
			self::maybe_deferred_notify( $c->id, $site );
		}
		return array( 'ok' => true, 'contact' => self::public_contact( self::contact( $c->id ) ) );
	}

	/** M56 (WhatsApp-style reactions): the visitor's emoji on an adviser message becomes a system note
	 * in the conversation — visible to the team, stored, and it never wakes the bot. */
	private static function op_react( $site, $d ) {
		global $wpdb;
		$allowed = array( '❤️', '👍', '😂', '😮', '🙏', '' );
		$emoji   = isset( $d['emoji'] ) && is_string( $d['emoji'] ) ? trim( $d['emoji'] ) : '';
		$mid     = isset( $d['message_id'] ) ? (int) $d['message_id'] : 0;
		if ( ! in_array( $emoji, $allowed, true ) || $mid <= 0 ) {
			return vai_error( 'invalid', 'تفاعل غير معروف' );
		}
		global $wpdb;
		$uuid = preg_replace( '/[^a-zA-Z0-9\-]/', '', isset( $d['uuid'] ) ? (string) $d['uuid'] : '' );
		$cid  = strlen( $uuid ) >= 8 ? (int) $wpdb->get_var( $wpdb->prepare( 'SELECT contact_id FROM ' . self::t( 'visitors' ) . ' WHERE uuid=%s AND contact_id>0 ORDER BY last_at DESC LIMIT 1', $uuid ) ) : 0;
		$c    = $cid ? self::contact( $cid ) : null;
		if ( ! $c ) {
			return vai_error( 'no_contact', 'ابدأ محادثة أولًا', 401 );
		}
		if ( self::too_many_attempts( 'react_' . $c->id, 40 ) ) {
			return vai_error( 'rate', 'تفاعلات كثيرة — هوّن عليك', 429 );
		}
		$own = $wpdb->get_var( $wpdb->prepare( 'SELECT contact_id FROM ' . self::t( 'messages' ) . ' WHERE id=%d', $mid ) );
		if ( (int) $own !== (int) $c->id ) {
			return vai_error( 'invalid', 'الرسالة ليست في محادثتك' );
		}
		self::insert_message( $c->id, $site->id, 'system', $emoji === '' ? '↩️ أزال تفاعله عن رسالة #' . $mid : $emoji . ' تفاعل مع رسالة المستشار #' . $mid );
		return array( 'ok' => true );
	}

	/** Magic link from the "we created your account" e-mail: check token → set password → log in. */
	private static function op_setpass_check( $site, $d ) {
		global $wpdb;
		$t = preg_replace( '/[^a-zA-Z0-9]/', '', vai_str( $d, 'token', 80 ) );
		$c = $t ? $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'contacts' ) . ' WHERE pass_token=%s AND pass_token_expires>%s', vai_hash( $t ), vai_now() ) ) : null;
		if ( ! $c ) {
			return vai_error( 'bad_token', 'الرابط غير صالح أو انتهت صلاحيته — استخدم «نسيت كلمة المرور» ببريدك', 400 );
		}
		return array( 'ok' => true, 'name' => (string) $c->name, 'email' => (string) $c->email );
	}

	private static function op_setpass( $site, $d ) {
		global $wpdb;
		$t    = preg_replace( '/[^a-zA-Z0-9]/', '', vai_str( $d, 'token', 80 ) );
		$pass = isset( $d['password'] ) && is_string( $d['password'] ) ? $d['password'] : '';
		$c    = $t ? $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'contacts' ) . ' WHERE pass_token=%s AND pass_token_expires>%s', vai_hash( $t ), vai_now() ) ) : null;
		if ( ! $c ) {
			return vai_error( 'bad_token', 'الرابط غير صالح أو انتهت صلاحيته', 400 );
		}
		if ( strlen( $pass ) < 6 ) {
			return vai_error( 'invalid', 'كلمة المرور 6 أحرف على الأقل' );
		}
		$wpdb->update( self::t( 'contacts' ), array( 'pass_hash' => wp_hash_password( $pass ), 'pass_token' => '', 'pass_token_expires' => null, 'verified' => 1, 'stage' => max( 1, (int) $c->stage ), 'last_login_at' => vai_now() ), array( 'id' => $c->id ) );
		self::attach_visitor( $site, isset( $d['uuid'] ) ? $d['uuid'] : '', self::contact( $c->id ) );
		self::note_verified( $c->id, self::site_source( $site ), $site->host );
		$c = self::contact( $c->id );
		self::insert_message( $c->id, $site->id, 'system', 'أنشأ كلمة مروره من رابط التفعيل ودخل حسابه ✅' );
		return array( 'ok' => true, 'contact' => self::public_contact( $c ), 'messages' => self::history_rows( $c->id, 40 ) );
	}

	/** Create a verified account for someone we already know (e.g. a Paymob payer) and e-mail them a set-password link.
	 * 2.8.1 (M45): `$pass_hash` = a password the payer chose on the pay page BEFORE paying — applied only on a new
	 * account or one without a password (never overwrites an existing password: payment proves the money, not the account). */
	public static function create_account_for( $name, $phone, $email, $make_member = true, $source = 'paymob', $pass_hash = '' ) {
		global $wpdb;
		$ct = self::t( 'contacts' );
		$pn = vai_norm_phone( $phone );
		$em = vai_norm_email( $email );
		if ( $em === '' && $pn === '' ) {
			self::$member_ctx = null;
			return null;
		}
		$where = array();
		$args  = array();
		if ( $pn !== '' ) {
			$where[] = 'phone_norm=%s';
			$args[]  = $pn;
		}
		if ( $em !== '' ) {
			$where[] = 'email_norm=%s';
			$args[]  = $em;
		}
		$c = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $ct WHERE (" . implode( ' OR ', $where ) . ") ORDER BY (pass_hash<>'') DESC, verified DESC, id ASC LIMIT 1", $args ) );
		$now = vai_now();
		// 2.15.2 (owner): 'paypage' = the visitor registered HIMSELF on the pay page, before any payment.
		$src = in_array( $source, array( 'paymob', 'paypage' ), true ) ? $source : 'manual';
		if ( ! $c ) {
			$wpdb->insert( $ct, array( 'name' => (string) $name, 'phone' => vai_phone_local( $pn ), 'phone_norm' => $pn, 'email' => $em, 'email_norm' => $em, 'pass_hash' => (string) $pass_hash, 'stage' => 1, 'verified' => 1, 'created_at' => $now, 'first_at' => $now, 'last_at' => $now, 'sites' => '[]', 'last_site_id' => (int) self::self_site()->id ) );
			$c = self::contact( $wpdb->insert_id );
			self::insert_message( $c->id, (int) $c->last_site_id, 'system', $source === 'paypage' ? 'سجّل حسابه بنفسه من صفحة الدفع بكلمة مرور اختارها — قبل إتمام الدفع' : 'أُنشئ الحساب تلقائيًا من دفعة (' . $source . ')' . ( $pass_hash ? ' بكلمة مرور اختارها في صفحة الدفع' : '' ) );
		} else {
			$upd = array( 'verified' => 1, 'stage' => max( 1, (int) $c->stage ), 'last_at' => $now );
			if ( $pass_hash && empty( $c->pass_hash ) ) {
				$upd['pass_hash'] = (string) $pass_hash;
			}
			if ( $c->name === '' && $name ) {
				$upd['name'] = (string) $name;
			}
			if ( $c->email === '' && $em ) {
				$upd['email']      = $em;
				$upd['email_norm'] = $em;
			}
			if ( $c->phone_norm === '' && $pn ) {
				$upd['phone']      = vai_phone_local( $pn );
				$upd['phone_norm'] = $pn;
			}
			$wpdb->update( $ct, $upd, array( 'id' => $c->id ) );
			$c = self::contact( $c->id );
		}
		self::log_event_once( $c->id, 'registered', $src, 'auto' ); // an account made for a payer (or by «تفعيل بالبيانات») is a sign-up too
		self::note_verified( $c->id, $src );
		if ( $make_member && ! (int) $c->is_member ) {
			if ( ! is_array( self::$member_ctx ) ) {
				self::member_context( $src );
			}
			self::set_member( $c->id, true );
			$c = self::contact( $c->id );
		}
		self::$member_ctx = null;
		if ( $pass_hash && $c->pass_hash === (string) $pass_hash && $c->email ) {
			if ( $source === 'paypage' && ! $make_member ) {
				// 2.15.2: registered on the pay page BEFORE paying — welcome him at once (no payment claims),
				// and hand him the membership link so he can activate from the same page any time.
				self::mail( $c->email, 'أهلًا بك في نادي المستثمرين — حسابك جاهز ✅', 'مرحبًا ' . $c->name . "،\n\nتم إنشاء حسابك بنجاح 🌹\n\nتدخل حسابك الآن مباشرة: البريد " . $c->email . ( $c->phone ? ' أو الجوال ' . vai_phone_local( $c->phone_norm ) : '' ) . " مع كلمة المرور التي اخترتها — على أي موقع من مواقع المنظومة من أيقونة المساعد أسفل الموقع.\n\nولتفعيل عضويتك السنوية (إن لم تكن أكملت الدفع بعد) ادفع في أي وقت من هذه الصفحة وتتفعّل تلقائيًا فور تأكيد الدفع:\n" . home_url( '/?vai-pay=membership' ) . "\n\nللإدارة: " . vai_phone_local( vai_cfg( 'mgmt_whatsapp' ) ) . "\nنادي المستثمرين — Vibes Ventures" );
			} else {
				// The payer chose his password on the pay page: the account is complete — no set-password link needed.
				self::mail( $c->email, $make_member ? 'تم تفعيل عضويتك وحسابك جاهز — نادي المستثمرين ⭐' : 'حسابك في نادي المستثمرين جاهز ✅', 'مرحبًا ' . $c->name . "،\n\n" . ( $make_member ? "تم تأكيد دفعتك وتفعيل عضويتك السنوية في نادي المستثمرين ✅\n\n" : "تم تأكيد دفعتك وإنشاء حسابك في Vibes Ventures ✅\n\n" ) . "تدخل حسابك الآن مباشرة: البريد " . $c->email . ( $c->phone ? ' أو الجوال ' . vai_phone_local( $c->phone_norm ) : '' ) . " مع كلمة المرور التي اخترتها في صفحة الدفع — على أي موقع من مواقع المنظومة من أيقونة المساعد.\n\nللإدارة: " . vai_phone_local( vai_cfg( 'mgmt_whatsapp' ) ) . "\nنادي المستثمرين — Vibes Ventures" );
			}
		} elseif ( empty( $c->pass_hash ) && $c->email ) {
			$token = vai_key( 40 );
			$wpdb->update( $ct, array( 'pass_token' => vai_hash( $token ), 'pass_token_expires' => gmdate( 'Y-m-d H:i:s', time() + 30 * 86400 ) ), array( 'id' => $c->id ) );
			$link = home_url( '/?vai=setpass&t=' . rawurlencode( $token ) );
			self::mail( $c->email, 'حسابك في نادي المستثمرين جاهز — أنشئ كلمة مرورك', 'مرحبًا ' . $c->name . "،\n\n" . ( $make_member ? "تم تفعيل عضويتك السنوية في نادي المستثمرين ✅ وأنشأنا لك حسابك تلقائيًا ببيانات الدفع.\n\n" : "أنشأنا لك حسابك في Vibes Ventures.\n\n" ) . "خطوة واحدة فقط: افتح الرابط التالي لتختار كلمة مرورك وتدخل مباشرة (الرابط صالح 30 يومًا):\n" . $link . "\n\nبيانات دخولك بعدها: البريد " . $c->email . ( $c->phone ? ' أو الجوال ' . vai_phone_local( $c->phone_norm ) : '' ) . " — على أي موقع من مواقع المنظومة من أيقونة المساعد.\n\nللإدارة: " . vai_phone_local( vai_cfg( 'mgmt_whatsapp' ) ) . "\nنادي المستثمرين — Vibes Ventures" );
		}
		return $c;
	}

	private static function op_reset_request( $site, $d ) {
		global $wpdb;
		$login = vai_str( $d, 'login', 190 );
		if ( self::too_many_attempts( 'reset_' . ( isset( $d['ip'] ) ? $d['ip'] : '' ), 6 ) ) {
			return vai_error( 'rate', 'محاولات كثيرة — حاول بعد قليل', 429 );
		}
		$acc = self::find_account( $login );
		if ( $acc && $acc->email ) {
			$code = (string) wp_rand( 1000, 9999 );
			$wpdb->update( self::t( 'contacts' ), array( 'reset_code' => vai_hash( $code ), 'reset_expires' => gmdate( 'Y-m-d H:i:s', time() + 20 * 60 ) ), array( 'id' => $acc->id ) );
			wp_mail( $acc->email, '[' . vai_cfg( 'bot_name' ) . '] رمز استعادة كلمة المرور', "مرحبًا " . $acc->name . "،\n\nرمز استعادة كلمة المرور: " . $code . "\nصالح لمدة 20 دقيقة. إن لم تطلبه فتجاهل هذه الرسالة.\n\nنادي المستثمرين — Vibes Ventures" );
		}
		return array( 'ok' => true, 'sent' => true );
	}

	private static function op_reset_confirm( $site, $d ) {
		global $wpdb;
		$login = vai_str( $d, 'login', 190 );
		$code  = preg_replace( '/\D+/', '', vai_str( $d, 'code', 10 ) );
		$pass  = isset( $d['password'] ) && is_string( $d['password'] ) ? $d['password'] : '';
		if ( self::too_many_attempts( 'resetc_' . ( isset( $d['ip'] ) ? $d['ip'] : '' ), 10 ) ) {
			return vai_error( 'rate', 'محاولات كثيرة — حاول بعد قليل', 429 );
		}
		$acc = self::find_account( $login );
		if ( ! $acc || $acc->reset_code === '' || ! $acc->reset_expires || strtotime( $acc->reset_expires . ' UTC' ) < time() || ! hash_equals( $acc->reset_code, vai_hash( $code ) ) ) {
			return vai_error( 'bad_code', 'الرمز غير صحيح أو انتهت صلاحيته', 400 );
		}
		if ( strlen( $pass ) < 6 ) {
			return vai_error( 'invalid', 'كلمة المرور 6 أحرف على الأقل' );
		}
		$wpdb->update( self::t( 'contacts' ), array( 'pass_hash' => wp_hash_password( $pass ), 'reset_code' => '', 'reset_expires' => null ), array( 'id' => $acc->id ) );
		if ( class_exists( 'VAI_Payments' ) ) {
			VAI_Payments::notify_user_event( $acc, 'reset', $site->host );
		}
		return array( 'ok' => true );
	}

	private static function send_welcome_email( $c ) {
		if ( ! $c->email ) {
			return;
		}
		$days = (int) vai_cfg( 'trial_days' );
		$end  = vai_riyadh( gmdate( 'Y-m-d H:i:s', strtotime( $c->trial_started_at . ' UTC' ) + $days * 86400 ), 'Y-m-d' );
		$svc  = self::service_by_key( 'membership' );
		$pay  = $svc ? ( $svc['pay_url'] ?: $svc['url'] ) : 'https://vcmem.com/payment/';
		$tpl  = (string) vai_cfg( 'welcome_email' );
		$body = str_replace(
			array( '{name}', '{days}', '{end_date}', '{email}', '{phone}', '{pay_url}', '{mgmt}' ),
			array( $c->name, $days, $end, $c->email, $c->phone, $pay, vai_cfg( 'mgmt_whatsapp' ) ),
			$tpl
		);
		wp_mail( $c->email, str_replace( '{name}', $c->name, (string) vai_cfg( 'welcome_email_subject' ) ), $body );
	}

	/** Server-to-server: membership status of a person by phone/email (for other plugins on satellite sites). */
	private static function op_member_status( $site, $d ) {
		global $wpdb;
		$pn = vai_norm_phone( vai_str( $d, 'phone', 40 ) );
		$em = vai_norm_email( vai_str( $d, 'email', 190 ) );
		if ( $pn === '' && $em === '' ) {
			return array( 'ok' => true, 'found' => false );
		}
		$ct    = self::t( 'contacts' );
		$where = array();
		$args  = array();
		if ( $pn !== '' ) {
			$where[] = 'phone_norm=%s';
			$args[]  = $pn;
		}
		if ( $em !== '' ) {
			$where[] = 'email_norm=%s';
			$args[]  = $em;
		}
		$c = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $ct WHERE (" . implode( ' OR ', $where ) . ") ORDER BY is_member DESC, verified DESC, id ASC LIMIT 1", $args ) );
		if ( ! $c ) {
			$m = self::member_lookup( $pn, $em );
			return array( 'ok' => true, 'found' => (bool) $m, 'is_member' => $m ? 1 : 0, 'source' => $m ? 'members_list' : '' );
		}
		return array( 'ok' => true, 'found' => true, 'contact' => self::public_contact( $c ) );
	}

	private static function op_member( $site, $d ) {
		global $wpdb;
		list( $c ) = self::resolve_contact( $site, isset( $d['uuid'] ) ? $d['uuid'] : '', false );
		if ( ! $c ) {
			return array( 'ok' => true, 'member' => false );
		}
		$pn = $c->phone_norm ?: vai_norm_phone( vai_str( $d, 'phone', 40 ) );
		$em = $c->email_norm ?: vai_norm_email( vai_str( $d, 'email', 190 ) );
		$m  = self::member_lookup( $pn, $em );
		if ( $m ) {
			$wpdb->update( self::t( 'contacts' ), array( 'is_member' => 1, 'stage' => 2 ), array( 'id' => $c->id ) );
			if ( ! (int) $c->is_member ) {
				self::log_event( $c->id, 'activated', 0, 'list', '', 0, $site->host );
			}
			self::insert_message( $c->id, $site->id, 'system', 'تم التحقق من العضوية ✅' );
			return array( 'ok' => true, 'member' => true, 'contact' => self::public_contact( self::contact( $c->id ) ) );
		}
		return array( 'ok' => true, 'member' => false, 'contact' => self::public_contact( $c ) );
	}

	private static function op_token( $site, $d ) {
		global $wpdb;
		list( $c ) = self::resolve_contact( $site, isset( $d['uuid'] ) ? $d['uuid'] : '', true );
		if ( ! $c ) {
			return vai_error( 'bad_uuid', 'معرّف الزائر غير صحيح' );
		}
		$url = vai_str( $d, 'url', 600 );
		if ( ! vai_url_allowed( $url ) ) {
			return vai_error( 'bad_url', 'رابط غير مسموح' );
		}
		$payload = array(
			'url'     => $url,
			'prefill' => isset( $d['prefill'] ) && is_array( $d['prefill'] ) ? $d['prefill'] : null,
			'open'    => ! empty( $d['open'] ),
			'fs'      => ! empty( $d['fs'] ),
			'from'    => $site->host,
		);
		$token   = strtolower( vai_key( 32 ) );
		$wpdb->insert(
			self::t( 'tokens' ),
			array(
				'token'      => $token,
				'contact_id' => $c->id,
				'payload'    => wp_json_encode( $payload, JSON_UNESCAPED_UNICODE ),
				'expires_at' => gmdate( 'Y-m-d H:i:s', time() + 900 ),
			)
		);
		return array( 'ok' => true, 'token' => $token );
	}

	private static function op_claim( $site, $d ) {
		global $wpdb;
		$token = preg_replace( '/[^a-z0-9]/', '', strtolower( vai_str( $d, 'token', 80 ) ) );
		$tt    = self::t( 'tokens' );
		$row   = $token ? $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $tt WHERE token=%s", $token ) ) : null;
		if ( ! $row || (int) $row->used || strtotime( $row->expires_at . ' UTC' ) < time() ) {
			return vai_error( 'bad_token', 'الرابط انتهى أو استُخدم', 410 );
		}
		$target = self::contact( $row->contact_id );
		if ( ! $target ) {
			return vai_error( 'bad_token', 'العميل غير موجود', 410 );
		}
		$uuid = preg_replace( '/[^a-zA-Z0-9\-]/', '', vai_str( $d, 'uuid', 64 ) );
		if ( strlen( $uuid ) < 8 ) {
			return vai_error( 'bad_uuid', 'معرّف الزائر غير صحيح' );
		}
		$vt  = self::t( 'visitors' );
		$now = vai_now();
		$v   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $vt WHERE uuid=%s AND site_id=%d", $uuid, $site->id ) );
		if ( ( ! $v || (int) $v->contact_id !== (int) $target->id ) && self::needs_login( $site, $target ) ) {
			return vai_error( 'login_required', 'سجّل الدخول بكلمة المرور للوصول إلى هذا الحساب', 403 );
		}
		if ( $v ) {
			if ( (int) $v->contact_id !== (int) $target->id ) {
				$old = self::contact( $v->contact_id );
				if ( $old && (int) $old->stage < 1 ) {
					self::merge_contacts( $old, $target );
				}
				$wpdb->update( $vt, array( 'contact_id' => $target->id, 'last_at' => $now ), array( 'id' => $v->id ) );
			}
		} else {
			$wpdb->insert(
				$vt,
				array(
					'uuid'       => $uuid,
					'site_id'    => $site->id,
					'contact_id' => $target->id,
					'first_at'   => $now,
					'last_at'    => $now,
				)
			);
		}
		$wpdb->update( $tt, array( 'used' => 1 ), array( 'id' => $row->id ) );
		$target = self::contact( $target->id );
		$wpdb->update( self::t( 'contacts' ), array( 'sites' => self::touch_sites( $target, $site ), 'last_site_id' => $site->id ), array( 'id' => $target->id ) );
		$payload = json_decode( (string) $row->payload, true );
		return array(
			'ok'       => true,
			'contact'  => self::public_contact( $target ),
			'payload'  => is_array( $payload ) ? $payload : array(),
			'messages' => self::history_rows( $target->id, 40 ),
		);
	}

	/* knowledge sync from satellites */

	private static function op_knowledge( $site, $d ) {
		global $wpdb;
		$pages   = isset( $d['pages'] ) && is_array( $d['pages'] ) ? $d['pages'] : array();
		$sync_id = preg_replace( '/[^a-zA-Z0-9\-]/', '', vai_str( $d, 'sync_id', 40 ) );
		$kt      = self::t( 'knowledge' );
		$n       = 0;
		$changed = 0;
		foreach ( $pages as $p ) {
			if ( ! is_array( $p ) ) {
				continue;
			}
			$url = esc_url_raw( vai_str( $p, 'url', 600 ) );
			if ( ! $url ) {
				continue;
			}
			$title   = vai_clip( isset( $p['title'] ) ? $p['title'] : '', 300 );
			$content = vai_text_ok( $p, 'content', 20000 );
			$kind    = preg_replace( '/[^a-z_]/', '', vai_str( $p, 'kind', 20 ) ) ?: 'page';
			$hash    = md5( $title . '|' . $content );
			$uh      = md5( $url );
			$row     = $wpdb->get_row( $wpdb->prepare( "SELECT id, hash FROM $kt WHERE site_id=%d AND url_hash=%s", $site->id, $uh ) );
			$data    = array(
				'site_id'    => $site->id,
				'url'        => $url,
				'url_hash'   => $uh,
				'kind'       => $kind,
				'sync_id'    => $sync_id,
				'updated_at' => vai_now(),
			);
			$fresh = ! $row || $row->hash !== $hash;
			if ( $fresh ) {
				$data['title']        = $title;
				$data['content']      = $content;
				$data['content_norm'] = vai_norm_text( $title . ' ' . $content );
				$data['hash']         = $hash;
				$changed++;
			}
			self::knowledge_put( $row, $data, $fresh );
			$n++;
		}
		if ( ! empty( $d['final'] ) && $sync_id ) {
			$changed += (int) $wpdb->query( $wpdb->prepare( "DELETE FROM $kt WHERE site_id=%d AND kind NOT IN ('note','faq','service','app_post','app_event') AND sync_id<>%s", $site->id, $sync_id ) );
		}
		$count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $kt WHERE site_id=%d", $site->id ) );
		$wpdb->update( self::t( 'sites' ), array( 'last_sync' => vai_now(), 'knowledge_count' => $count ), array( 'id' => $site->id ) );
		if ( $changed > 0 ) {
			self::knowledge_changed( $site, $changed );
		}
		return array( 'ok' => true, 'saved' => $n, 'total' => $count );
	}

	/**
	 * Save one knowledge row. A row whose text changed gets a NEW id (delete + insert): the id is the cursor of changes(),
	 * so an edited page, post or event reaches the app like a new one. An untouched row keeps its id. Returns the id, 0 on failure
	 * (a page lost here comes back with the site's next sync).
	 */
	private static function knowledge_put( $row, array $data, $fresh ) {
		global $wpdb;
		$kt = self::t( 'knowledge' );
		if ( $row && ! $fresh ) {
			$wpdb->update( $kt, $data, array( 'id' => $row->id ) );
			return (int) $row->id;
		}
		if ( $row ) {
			$wpdb->delete( $kt, array( 'id' => $row->id ) );
		}
		return $wpdb->insert( $kt, $data ) ? (int) $wpdb->insert_id : 0;
	}

	/** Tell the app server that a site's knowledge moved (knowledge.changed {site, host, count, cursor}). */
	private static function knowledge_changed( $site, $count ) {
		global $wpdb;
		$kt = self::t( 'knowledge' );
		self::webhook(
			'knowledge.changed',
			array(
				'site'   => $site ? (string) $site->name : '',
				'host'   => $site ? (string) $site->host : '',
				'count'  => (int) $count,
				'cursor' => (int) $wpdb->get_var( "SELECT MAX(id) FROM $kt" ),
			)
		);
	}

	/* ───────────────────── n8n tools + reply ───────────────────── */

	public static function tool( $op, array $d ) {
		switch ( $op ) {
			case 'reply':
				return self::tool_reply( $d );
			case 'save_note':
				return self::tool_save_note( $d );
			case 'search':
				return array( 'ok' => true, 'results' => self::search( vai_str( $d, 'q', 200 ), vai_str( $d, 'host', 100 ), 6 ) );
			case 'page':
				return self::tool_page( $d );
			case 'projects':
				return array( 'ok' => true, 'projects' => self::projects( vai_str( $d, 'q', 200 ), 6 ) );
			case 'form':
				$f = self::form_by_key( preg_replace( '/[^a-z0-9_\-]/', '', vai_str( $d, 'key', 60 ) ) );
				return $f ? array( 'ok' => true, 'form' => array( 'key' => $f['fkey'], 'label' => $f['label'], 'url' => $f['url'], 'fields' => $f['fields'], 'notes' => $f['notes'] ) ) : array( 'ok' => false, 'error' => 'form_not_found', 'forms' => array_map( function ( $x ) { return $x['fkey']; }, self::forms_all() ) );
			case 'services':
				return array( 'ok' => true, 'services' => self::services_all( true ) );
			case 'contact':
				$c = self::contact( isset( $d['id'] ) ? (int) $d['id'] : 0 );
				return $c ? array( 'ok' => true, 'contact' => self::public_contact( $c ), 'memo' => $c->memo, 'turns' => self::turns( $c->id, 30 ) ) : array( 'ok' => false );
		}
		return vai_error( 'not_found', 'أداة غير معروفة', 404 );
	}

	private static function tool_page( $d ) {
		global $wpdb;
		$url = trim( vai_str( $d, 'url', 600 ) );
		$kt  = self::t( 'knowledge' );
		$st  = self::t( 'sites' );
		$row = null;
		if ( $url !== '' ) {
			$vars = array();
			foreach ( array( $url, rtrim( $url, '/' ), rtrim( $url, '/' ) . '/' ) as $u ) {
				$vars[] = $u;
				$dec    = rawurldecode( $u );
				$vars[] = $dec;
				$parts  = wp_parse_url( $dec );
				if ( ! empty( $parts['host'] ) ) {
					$path   = isset( $parts['path'] ) ? implode( '/', array_map( 'rawurlencode', explode( '/', $parts['path'] ) ) ) : '/';
					$vars[] = ( isset( $parts['scheme'] ) ? $parts['scheme'] : 'https' ) . '://' . $parts['host'] . $path . ( isset( $parts['query'] ) ? '?' . $parts['query'] : '' );
				}
			}
			$hashes = array_values( array_unique( array_map( 'md5', $vars ) ) );
			$ph     = implode( ',', array_fill( 0, count( $hashes ), '%s' ) );
			$row    = $wpdb->get_row( $wpdb->prepare( "SELECT k.*, s.host FROM $kt k LEFT JOIN $st s ON s.id=k.site_id WHERE k.url_hash IN ($ph) LIMIT 1", $hashes ) );
			if ( ! $row ) {
				$parts = wp_parse_url( rawurldecode( $url ) );
				$seg   = isset( $parts['path'] ) ? trim( $parts['path'], '/' ) : '';
				if ( $seg !== '' ) {
					$seg  = basename( $seg );
					$like = '%' . $wpdb->esc_like( rawurlencode( $seg ) ) . '%';
					$row  = $wpdb->get_row( $wpdb->prepare( "SELECT k.*, s.host FROM $kt k LEFT JOIN $st s ON s.id=k.site_id WHERE (k.url LIKE %s OR k.url LIKE %s) LIMIT 1", $like, '%' . $wpdb->esc_like( $seg ) . '%' ) );
				}
			}
		}
		if ( ! $row ) {
			return array( 'ok' => false, 'error' => 'page_not_found', 'hint' => 'استخدم search أولًا للحصول على الرابط الصحيح' );
		}
		return array(
			'ok'      => true,
			'title'   => $row->title,
			'url'     => $row->url,
			'site'    => $row->host,
			'content' => vai_clip( $row->content, 6000 ),
		);
	}

	public static function search( $q, $host = '', $limit = 6 ) {
		global $wpdb;
		$toks = array_slice( vai_tokens( $q ), 0, 8 );
		if ( ! $toks ) {
			return array();
		}
		$kt    = self::t( 'knowledge' );
		$st    = self::t( 'sites' );
		$where = array();
		$args  = array();
		foreach ( $toks as $t ) {
			$where[] = 'k.content_norm LIKE %s';
			$args[]  = '%' . $wpdb->esc_like( $t ) . '%';
		}
		$sql  = "SELECT k.id, k.site_id, k.url, k.title, k.kind, k.content, k.content_norm, s.host FROM $kt k LEFT JOIN $st s ON s.id=k.site_id WHERE (" . implode( ' OR ', $where ) . ') LIMIT 80';
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $args ) );
		$qn   = vai_norm_text( $q );
		$host = vai_norm_host( $host );
		$out  = array();
		foreach ( (array) $rows as $r ) {
			$score = 0;
			$tn    = vai_norm_text( $r->title );
			$cn    = (string) $r->content_norm;
			foreach ( $toks as $t ) {
				if ( $tn !== '' && strpos( $tn, $t ) !== false ) {
					$score += 6;
				}
				$score += min( 5, substr_count( $cn, $t ) );
			}
			if ( $qn !== '' && strpos( $cn, $qn ) !== false ) {
				$score += 10;
			}
			if ( in_array( $r->kind, array( 'note', 'faq', 'service', 'app_post', 'app_event' ), true ) ) {
				$score += 3;
			}
			if ( $host && $r->host === $host ) {
				$score += 2;
			}
			if ( $score <= 0 ) {
				continue;
			}
			$out[] = array( 'score' => $score, 'row' => $r );
		}
		usort(
			$out,
			function ( $a, $b ) {
				return $b['score'] - $a['score'];
			}
		);
		$res = array();
		foreach ( array_slice( $out, 0, $limit ) as $x ) {
			$r       = $x['row'];
			$content = (string) $r->content;
			$snippet = '';
			$cn      = vai_norm_text( $content );
			foreach ( $toks as $t ) {
				$pos = mb_strpos( $cn, $t, 0, 'UTF-8' );
				if ( $pos !== false ) {
					$start   = max( 0, $pos - 90 );
					$snippet = mb_substr( $content, $start, 260, 'UTF-8' );
					break;
				}
			}
			if ( $snippet === '' ) {
				$snippet = mb_substr( $content, 0, 220, 'UTF-8' );
			}
			$res[] = array(
				'title'   => $r->title,
				'url'     => $r->url,
				'site'    => $r->host,
				'kind'    => $r->kind,
				'snippet' => trim( preg_replace( '/\s+/u', ' ', $snippet ) ),
			);
		}
		return $res;
	}

	/** 2.15.0 (owner): bonus Projects-Bank balance from the members screen — hub → PB bridge `grant`. */
	public static function pb_grant( $contact_id, $amount, $note, $actor ) {
		$url = trim( (string) vai_opt( 'pb_bridge_url', '' ) );
		$key = trim( (string) vai_opt( 'pb_bridge_key', '' ) );
		if ( $url === '' || $key === '' ) {
			return new WP_Error( 'off', 'ضع رابط جسر بنك المشاريع ومفتاحه في إعدادات المساعد أولًا' );
		}
		$r = wp_remote_post(
			rtrim( $url, '/' ) . '/grant',
			array(
				'timeout' => 12,
				'headers' => array( 'Content-Type' => 'application/json', 'X-PB-Bridge-Key' => $key ),
				'body'    => wp_json_encode( array( 'contact_id' => (int) $contact_id, 'amount' => (int) $amount, 'note' => (string) $note, 'actor' => (string) $actor, 'ref' => 'hubadm-' . (int) $contact_id . '-' . time() ) ),
			)
		);
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$j = json_decode( (string) wp_remote_retrieve_body( $r ), true );
		if ( 200 !== wp_remote_retrieve_response_code( $r ) || empty( $j['ok'] ) ) {
			return new WP_Error( 'pb', is_array( $j ) && isset( $j['text'] ) ? (string) $j['text'] : 'رفض بنك المشاريع العملية' );
		}
		return $j;
	}

	/* projects bank proxy (pb-agent-api) */

	public static function projects( $q, $limit = 6 ) {
		$all = self::projects_cache();
		if ( ! $all ) {
			$all = self::projects_from_knowledge();
		}
		if ( ! $all ) {
			return array();
		}
		$qn   = vai_norm_text( $q );
		$toks = vai_tokens( $q );
		$nums = array();
		if ( preg_match_all( '/\d{1,6}/u', $q, $m ) ) {
			$nums = array_map( 'intval', $m[0] );
		}
		$scored = array();
		foreach ( $all as $p ) {
			$s = 0;
			if ( $nums && in_array( (int) $p['number'], $nums, true ) ) {
				$s += 100;
			}
			$hay = vai_norm_text( $p['name'] . ' ' . $p['company'] . ' ' . $p['sector'] . ' ' . $p['stage'] . ' ' . $p['summary'] );
			$tn  = vai_norm_text( $p['name'] );
			foreach ( $toks as $t ) {
				if ( $tn !== '' && strpos( $tn, $t ) !== false ) {
					$s += 12;
				} elseif ( strpos( $hay, $t ) !== false ) {
					$s += 3;
				}
			}
			if ( $qn !== '' && strpos( $hay, $qn ) !== false ) {
				$s += 10;
			}
			if ( preg_match( '/ذهبي|golden|فايبز|ڤايبز|vibes/ui', $qn ) && $p['golden'] ) {
				$s += 8;
			}
			if ( $s > 0 ) {
				$scored[] = array( 's' => $s, 'p' => $p );
			}
		}
		if ( ! $scored && preg_match( '/مشاريع|احدث|جديد|projects|بنك/u', $qn ) ) {
			usort(
				$all,
				function ( $a, $b ) {
					return (int) $b['number'] - (int) $a['number'];
				}
			);
			return array_slice( $all, 0, $limit );
		}
		usort(
			$scored,
			function ( $a, $b ) {
				return $b['s'] - $a['s'];
			}
		);
		return array_map(
			function ( $x ) {
				return $x['p'];
			},
			array_slice( $scored, 0, $limit )
		);
	}

	/** Fallback when PB Agent API is not configured: project pages synced from vibesholding.com. */
	private static function projects_from_knowledge() {
		global $wpdb;
		$kt   = self::t( 'knowledge' );
		$rows = $wpdb->get_results( "SELECT title, url, content FROM $kt WHERE kind='project' OR url LIKE '%/project/%' ORDER BY id DESC LIMIT 600" );
		$out  = array();
		foreach ( (array) $rows as $r ) {
			$num = 0;
			if ( preg_match( '/(?:رقم|#|No\.?)\s*(\d{1,6})/u', $r->title . ' ' . mb_substr( (string) $r->content, 0, 300, 'UTF-8' ), $m ) ) {
				$num = (int) $m[1];
			}
			$out[] = array(
				'number'      => $num,
				'name'        => (string) $r->title,
				'company'     => '',
				'sector'      => '',
				'stage'       => '',
				'summary'     => vai_clip( (string) $r->content, 500 ),
				'url'         => (string) $r->url,
				'golden'      => false,
				'partner_url' => '',
			);
		}
		return $out;
	}

	public static function projects_source() {
		$api = self::projects_cache();
		if ( $api ) {
			return array( 'source' => 'api', 'count' => count( $api ) );
		}
		$kb = self::projects_from_knowledge();
		return array( 'source' => $kb ? 'knowledge' : 'none', 'count' => count( $kb ) );
	}

	private static function projects_cache() {
		$url = trim( (string) vai_opt( 'pb_api_url', '' ) );
		if ( $url === '' ) {
			return array();
		}
		$cached = get_transient( 'vai_pb_projects' );
		if ( is_array( $cached ) ) {
			return $cached;
		}
		$key = trim( (string) vai_opt( 'pb_api_key', '' ) );
		$u   = $url;
		if ( $key ) {
			$u = add_query_arg( 'key', rawurlencode( $key ), $u );
		}
		list( $code, $data ) = vai_http_json( 'GET', $u, null, array(), 40 );
		if ( $code < 200 || $code >= 300 || ! is_array( $data ) ) {
			set_transient( 'vai_pb_projects', array(), 300 );
			return array();
		}
		$items = array();
		foreach ( array( 'projects', 'items', 'data', 'results' ) as $k ) {
			if ( isset( $data[ $k ] ) && is_array( $data[ $k ] ) ) {
				$items = $data[ $k ];
				break;
			}
		}
		if ( ! $items && isset( $data[0] ) ) {
			$items = $data;
		}
		$out = array();
		foreach ( $items as $it ) {
			if ( ! is_array( $it ) ) {
				continue;
			}
			$meta  = isset( $it['meta'] ) && is_array( $it['meta'] ) ? $it['meta'] : $it;
			$pick  = function ( $keys, $src ) {
				foreach ( $keys as $k ) {
					if ( isset( $src[ $k ] ) && $src[ $k ] !== '' && $src[ $k ] !== null ) {
						$v = $src[ $k ];
						if ( is_array( $v ) ) {
							$flat = array();
							foreach ( $v as $x ) {
								if ( is_array( $x ) ) {
									$flat[] = isset( $x['name'] ) ? $x['name'] : ( isset( $x['title'] ) ? $x['title'] : '' );
								} else {
									$flat[] = (string) $x;
								}
							}
							return implode( '، ', array_filter( $flat ) );
						}
						return is_scalar( $v ) ? (string) $v : '';
					}
				}
				return '';
			};
			$title = $pick( array( 'title', 'name', 'post_title', 'project_name' ), $it );
			if ( is_array( $title ) ) {
				$title = isset( $title['rendered'] ) ? $title['rendered'] : '';
			}
			$number  = $pick( array( 'project_number', 'number' ), $meta ) ?: $pick( array( 'project_number', 'number' ), $it );
			$details = $pick( array( 'project_details', 'details', 'content', 'excerpt', 'description' ), $meta ) ?: $pick( array( 'content', 'excerpt', 'description' ), $it );
			$out[]   = array(
				'number'      => (int) preg_replace( '/\D+/', '', (string) $number ),
				'name'        => wp_strip_all_tags( (string) $title ),
				'company'     => wp_strip_all_tags( $pick( array( 'company_name' ), $meta ) ),
				'sector'      => wp_strip_all_tags( $pick( array( 'sector', 'sectors', 'sector_name' ), $it ) ?: $pick( array( 'sector' ), $meta ) ),
				'stage'       => wp_strip_all_tags( $pick( array( 'project_stage', 'stage', 'stages' ), $it ) ?: $pick( array( 'project_stage', 'stage' ), $meta ) ),
				'summary'     => vai_clip( wp_strip_all_tags( (string) $details ), 500 ),
				'url'         => $pick( array( 'url', 'link', 'permalink' ), $it ),
				'golden'      => (bool) ( $pick( array( 'is_featured', 'golden', 'featured' ), $meta ) ?: $pick( array( 'is_featured', 'golden' ), $it ) ),
				'partner_url' => $pick( array( 'golden_partner_url' ), $meta ),
			);
		}
		set_transient( 'vai_pb_projects', $out, 30 * MINUTE_IN_SECONDS );
		return $out;
	}

	/* reply from n8n */

	public static function expand_actions( $actions, $site_host ) {
		$out = array();
		if ( ! is_array( $actions ) ) {
			return $out;
		}
		$counts = array();
		foreach ( $actions as $a ) {
			if ( ! is_array( $a ) || empty( $a['type'] ) ) {
				continue;
			}
			$type = preg_replace( '/[^a-z_]/', '', (string) $a['type'] );
			$counts[ $type ] = isset( $counts[ $type ] ) ? $counts[ $type ] + 1 : 1;
			switch ( $type ) {
				case 'admin':
					$op = preg_replace( '/[^a-z_]/', '', strtolower( (string) ( $a['op'] ?? '' ) ) );
					if ( in_array( $op, array( 'report_today', 'campaign', 'broadcast', 'weekly_now' ), true ) && $counts[ $type ] <= 2 ) {
						$out[] = array(
							'type'     => 'admin',
							'op'       => $op,
							'audience' => preg_replace( '/[^a-z]/', '', strtolower( (string) ( $a['audience'] ?? 'paid' ) ) ) ?: 'paid',
							'subject'  => vai_clip( (string) ( $a['subject'] ?? '' ), 150 ),
							'body'     => vai_clip( (string) ( $a['body'] ?? '' ), 4000 ),
							'text'     => vai_clip( (string) ( $a['text'] ?? '' ), 1500 ),
							'confirm'  => ! empty( $a['confirm'] ),
						);
					}
					break;
				case 'quick_replies':
					$opts = isset( $a['options'] ) && is_array( $a['options'] ) ? $a['options'] : array();
					$opts = array_values( array_filter( array_map( function ( $o ) { return is_scalar( $o ) ? vai_clip( $o, 48 ) : ''; }, $opts ) ) );
					if ( $opts && $counts[ $type ] === 1 && empty( $GLOBALS['vai_no_quick'] ) ) {
						$out[] = array( 'type' => 'quick_replies', 'options' => array_slice( $opts, 0, 4 ) ); // 2.7.0: up to 4 (the widget and the app draw four)
					}
					break;
				case 'card':
					$card = self::service_card( preg_replace( '/[^a-z0-9_\-]/', '', (string) ( isset( $a['key'] ) ? $a['key'] : '' ) ) );
					if ( $card && $counts[ $type ] <= 2 ) {
						$out[] = array( 'type' => 'card', 'card' => $card );
					}
					break;
				case 'video':
					if ( $counts[ $type ] > 1 ) {
						break;
					}
					$id = isset( $a['id'] ) ? (int) $a['id'] : 0;
					foreach ( vai_videos() as $v ) {
						if ( $v['id'] === $id ) {
							$out[] = array( 'type' => 'video', 'title' => $v['title'], 'url' => $v['url'], 'yt' => $v['yt'] );
							break;
						}
					}
					break;
				case 'open_page':
					$url = isset( $a['url'] ) ? trim( (string) $a['url'] ) : '';
					if ( $url && vai_url_allowed( $url ) && $counts[ $type ] === 1 ) {
						$out[] = array( 'type' => 'open_page', 'url' => $url, 'carry' => vai_url_host( $url ) !== vai_norm_host( $site_host ) );
					}
					break;
				case 'prefill_form':
					$f = self::form_by_key( preg_replace( '/[^a-z0-9_\-]/', '', (string) ( isset( $a['form'] ) ? $a['form'] : '' ) ) );
					if ( $f && $counts[ $type ] === 1 ) {
						$fields = isset( $a['fields'] ) && is_array( $a['fields'] ) ? $a['fields'] : array();
						$clean  = array();
						$map    = array();
						foreach ( $f['fields'] as $ff ) {
							$map[ $ff['key'] ] = $ff['selector'];
						}
						foreach ( $fields as $k => $v ) {
							$k = preg_replace( '/[^a-z0-9_]/', '', strtolower( (string) $k ) );
							if ( $k && is_scalar( $v ) && trim( (string) $v ) !== '' ) {
								$clean[ $k ] = vai_clip( $v, 300 );
							}
						}
						$out[] = array(
							'type'   => 'prefill_form',
							'form'   => $f['fkey'],
							'label'  => $f['label'],
							'url'    => $f['url'],
							'fields' => $clean,
							'map'    => $map,
							'carry'  => vai_url_host( $f['url'] ) !== vai_norm_host( $site_host ),
						);
					}
					break;
				case 'link':
					$url = isset( $a['url'] ) ? trim( (string) $a['url'] ) : '';
					if ( $url && vai_url_allowed( $url ) && $counts[ $type ] <= 2 ) {
						$out[] = array( 'type' => 'link', 'label' => vai_clip( isset( $a['label'] ) ? $a['label'] : 'افتح الرابط', 60 ), 'url' => $url, 'carry' => vai_url_host( $url ) !== vai_norm_host( $site_host ) && vai_url_host( $url ) !== 'paymob.link' );
					}
					break;
				case 'handoff':
					if ( $counts[ $type ] === 1 ) {
						$num = preg_replace( '/\D+/', '', (string) ( ! empty( $a['club'] ) ? vai_cfg( 'club_whatsapp' ) : vai_cfg( 'mgmt_whatsapp' ) ) );
						$out[] = array( 'type' => 'handoff', 'number' => $num, 'text' => vai_clip( isset( $a['text'] ) ? $a['text'] : '', 400 ), 'label' => ! empty( $a['club'] ) ? 'راسل فريق النادي على واتساب' : 'راسل الإدارة على واتساب' );
					}
					break;
				case 'request_contact':
					if ( $counts[ $type ] === 1 ) {
						$out[] = array( 'type' => 'request_contact' );
					}
					break;
				case 'scroll_to':
					$sel = isset( $a['selector'] ) ? vai_clip( $a['selector'], 120 ) : '';
					if ( $sel && $counts[ $type ] === 1 ) {
						$out[] = array( 'type' => 'scroll_to', 'selector' => $sel );
					}
					break;
			}
			if ( count( $out ) >= 6 ) {
				break;
			}
		}
		return $out;
	}

	/** The assistant teaches itself: store a fact it learned from a site page (visible/deletable under المعرفة). */
	private static function tool_save_note( $d ) {
		global $wpdb;
		$title   = vai_str( $d, 'title', 150 );
		$content = vai_text_ok( $d, 'content', 1500 );
		$url     = esc_url_raw( vai_str( $d, 'url', 500 ) );
		if ( $title === '' || mb_strlen( $content, 'UTF-8' ) < 20 ) {
			return array( 'ok' => false, 'error' => 'العنوان والمحتوى مطلوبان (20 حرفًا على الأقل)' );
		}
		if ( $url && ! vai_url_allowed( $url ) ) {
			$url = '';
		}
		$kt   = self::t( 'knowledge' );
		$hash = md5( 'ai-note:' . vai_norm_text( $title ) );
		$site = self::self_site();
		$row  = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM $kt WHERE url_hash=%s", $hash ) );
		$data = array( 'site_id' => $site->id, 'url' => $url, 'url_hash' => $hash, 'title' => 'تعلّم ذاتي: ' . $title, 'content' => $content, 'content_norm' => vai_norm_text( $title . ' ' . $content ), 'kind' => 'note', 'hash' => md5( $content ), 'updated_at' => vai_now() );
		if ( $row ) {
			$wpdb->update( $kt, $data, array( 'id' => $row->id ) );
		} else {
			$wpdb->insert( $kt, $data );
		}
		return array( 'ok' => true, 'saved' => $title );
	}

	private static function tool_reply( $d ) {
		global $wpdb;
		if ( ! empty( $d['pong'] ) ) {
			update_option( 'vai_last_pong', array( 'id' => vai_str( $d, 'ping_id', 40 ), 'at' => vai_now() ), false );
			return array( 'ok' => true, 'pong' => true );
		}
		$cid = isset( $d['contact_id'] ) ? (int) $d['contact_id'] : 0;
		$c   = self::contact( $cid );
		if ( ! $c ) {
			return vai_error( 'no_contact', 'العميل غير موجود', 404 );
		}
		$site_id = isset( $d['site_id'] ) ? (int) $d['site_id'] : (int) $c->last_site_id;
		$site    = self::site_by_id( $site_id );
		$host    = $site ? $site->host : '';
		$reply   = vai_strip_bad_urls( vai_text_ok( $d, 'reply', 6000 ) );
		$reply   = trim( preg_replace( '/^#{1,6}\s+/mu', '', $reply ) );
		// Suggestion chips only when the customer asked for something specific — never on greetings / first contact.
		$umid = isset( $d['user_message_id'] ) ? (int) $d['user_message_id'] : 0;
		// 2.7.0: n8n retries «Post Reply» when the hub answers slowly — the same user message gets one reply only.
		if ( $umid > 0 ) {
			$dup = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . self::t( 'messages' ) . " WHERE contact_id=%d AND id>%d AND role='assistant' AND meta LIKE %s ORDER BY id ASC LIMIT 1", $c->id, $umid, '%' . $wpdb->esc_like( '"umid":' . $umid . ',' ) . '%' ) );
			if ( $dup ) {
				return array( 'ok' => true, 'message_id' => $dup, 'duplicate' => true );
			}
		}
		$utxt = $umid ? (string) $wpdb->get_var( $wpdb->prepare( 'SELECT content FROM ' . self::t( 'messages' ) . ' WHERE id=%d', $umid ) ) : '';
		$is_admin_now = ( $c->role === 'admin' && (int) $c->admin_verified );
		$GLOBALS['vai_no_quick'] = ! $is_admin_now && ( $utxt === '' || (int) $c->reply_count === 0 || preg_match( '/^\W*(?:و?عليكم\s*السلام.*|السلام\s*عليكم.*|سلام|هلا.*|اهلا.*|أهلا.*|مرحبا.*|مرحبًا|صباح.*|مساء.*|hi|hello|hey)\W*$/iu', trim( $utxt ) ) );
		$actions = self::expand_actions( isset( $d['actions'] ) ? $d['actions'] : array(), $host );
		unset( $GLOBALS['vai_no_quick'] );
		// Admin commands (only for verified admins, only when the assistant marked them confirmed)
		$kept = array();
		foreach ( $actions as $a ) {
			if ( $a['type'] === 'admin' ) {
				if ( $c->role === 'admin' && (int) $c->admin_verified && ! empty( $a['confirm'] ) ) {
					$res    = self::run_admin_action( $c, $a );
					$reply .= "\n\n" . $res;
				}
				continue;
			}
			$kept[] = $a;
		}
		$actions = $kept;
		if ( ! empty( $d['registered'] ) ) {
			foreach ( vai_welcome_links() as $wl ) {
				$actions[] = array( 'type' => 'link', 'label' => $wl['label'] . ' ↗', 'url' => $wl['url'], 'carry' => vai_url_host( $wl['url'] ) !== vai_norm_host( $host ), 'auto' => true );
			}
		} else {
			$actions = self::ensure_links( $actions, $reply, isset( $d['user_message_id'] ) ? (int) $d['user_message_id'] : 0, $host );
		}
		$actions = self::maybe_auto_open( $actions, $reply, isset( $d['user_message_id'] ) ? (int) $d['user_message_id'] : 0, $host );
		if ( (int) $c->is_member && ! (int) $c->member_welcomed ) {
			$wpdb->update( self::t( 'contacts' ), array( 'member_welcomed' => 1 ), array( 'id' => $c->id ) );
		}
		if ( $reply === '' && ! $actions ) {
			$reply = 'حياك الله 🌹 وش أقدر أخدمك فيه؟';
		}
		$mid = self::insert_message( $c->id, $site_id, 'assistant', $reply, $actions, '', array( 'umid' => $umid, 'model' => vai_str( $d, 'model', 40 ), 'route' => vai_str( $d, 'route', 60 ), 'guard' => vai_str( $d, 'guard', 200 ) ) );
		self::webhook( 'message.assistant', array( 'contact_id' => (int) $c->id, 'message_id' => (int) $mid ) );
		$lat = ! empty( $c->awaiting_since ) ? max( 0, time() - strtotime( $c->awaiting_since . ' UTC' ) ) : null;
		update_option( 'vai_last_reply', array( 'at' => vai_now(), 'contact' => (int) $c->id, 'model' => vai_str( $d, 'model', 40 ), 'route' => vai_str( $d, 'route', 60 ), 'guard' => vai_str( $d, 'guard', 200 ), 'latency' => $lat ), false );

		$upd = array(
			'reply_count'    => (int) $c->reply_count + 1,
			'awaiting_since' => null,
			'last_at'        => vai_now(),
		);
		$memo = vai_text_ok( $d, 'memo', 800 );
		if ( $memo !== '' ) {
			$upd['memo'] = vai_clip( $memo, 700 );
		}
		$lead = isset( $d['lead'] ) && is_array( $d['lead'] ) ? $d['lead'] : null;
		if ( $lead && ! empty( $lead['type'] ) ) {
			$type = preg_replace( '/[^a-z_]/', '', strtolower( (string) $lead['type'] ) );
			$upd['lead_type'] = $type;
			self::add_lead( $c, $site, $type, vai_str( $lead, 'reason', 400 ), vai_str( $lead, 'company', 190 ), vai_str( $lead, 'notes', 600 ) );
		}
		$wpdb->update( self::t( 'contacts' ), $upd, array( 'id' => $c->id ) );
		return array( 'ok' => true, 'message_id' => $mid );
	}

	/**
	 * Deterministic link buttons: whenever the customer or the assistant mentions something from the
	 * links library (by keyword) and no navigation action exists for that host, attach a link button.
	 */
	private static function ensure_links( $actions, $reply, $user_message_id, $site_host ) {
		global $wpdb;
		$links = vai_links();
		if ( ! $links ) {
			return $actions;
		}
		$have_hosts = array();
		foreach ( $actions as $a ) {
			if ( in_array( $a['type'], array( 'open_page', 'prefill_form', 'link' ), true ) && ! empty( $a['url'] ) ) {
				$have_hosts[] = vai_url_host( $a['url'] ) . wp_parse_url( $a['url'], PHP_URL_PATH );
			}
		}
		$user = '';
		if ( $user_message_id ) {
			$user = (string) $wpdb->get_var( $wpdb->prepare( 'SELECT content FROM ' . self::t( 'messages' ) . ' WHERE id=%d', $user_message_id ) );
		}
		$un = vai_norm_text( $user );
		$rn = vai_norm_text( $reply );
		$asks_link   = (bool) preg_match( '/(رابط|لينك|link|url|ابعت|ارسل|أرسل|ارسلي|أرسلي|افتح|افتحي|وديني|ودني|خذني|وريني|ورني|صفحه|صفحة|موقع)/u', $un );
		$claims_link = (bool) preg_match( '/(ارسلت لك|أرسلت لك|هذا رابط|هذا هو الرابط|اليك الرابط|إليك الرابط|فتحت لك|افتح الصفحه|اضغط الزر|اضغط الرابط|الرابط:)/u', $rn );
		$scored = array();
		foreach ( $links as $i => $l ) {
			$kws = array_merge( $l['keywords'], array( $l['label'] ) );
			$su  = 0;
			$sr  = 0;
			foreach ( $kws as $k ) {
				$kn = vai_norm_text( $k );
				if ( $kn === '' || mb_strlen( $kn, 'UTF-8' ) < 3 ) {
					continue;
				}
				$w = mb_strlen( $kn, 'UTF-8' ) >= 6 || preg_match( '/\s/', $kn ) ? 2 : 1;
				if ( $un !== '' && strpos( $un, $kn ) !== false ) {
					$su += 10 * $w;
				}
				if ( strpos( $rn, $kn ) !== false ) {
					$sr += 4 * $w;
				}
			}
			// Inject only when the CUSTOMER brought the subject up, asked for a link, or the assistant claims it sent/opened one.
			if ( $su > 0 || ( ( $asks_link || $claims_link ) && $sr > 0 ) ) {
				$scored[] = array( 's' => $su * 3 + $sr, 'i' => $i );
			}
		}
		if ( ! $scored ) {
			return $actions;
		}
		$max_add = 1; // one relevant button per reply — never a pile of links
		usort( $scored, function ( $a, $b ) { return $b['s'] - $a['s']; } );
		$added = 0;
		$skip  = array( 'paymob.link' );
		foreach ( $scored as $x ) {
			$l    = $links[ $x['i'] ];
			$host = vai_url_host( $l['url'] );
			$key  = $host . wp_parse_url( $l['url'], PHP_URL_PATH );
			if ( in_array( $key, $have_hosts, true ) ) {
				continue;
			}
			// Success-Partners form: open it prefilled with what we already know about the customer.
			$form = self::form_by_key( 'sp' );
			if ( $form && strpos( $l['url'], 'pvspaces.com/sp' ) !== false && $user_message_id ) {
				$cid = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT contact_id FROM ' . self::t( 'messages' ) . ' WHERE id=%d', $user_message_id ) );
				$cc  = $cid ? self::contact( $cid ) : null;
				if ( $cc && ( $cc->name || $cc->phone ) ) {
					$fields = array_filter( array( 'name' => (string) $cc->name, 'phone' => (string) $cc->phone, 'email' => (string) $cc->email, 'project' => (string) $cc->company ) );
					$map    = array();
					foreach ( $form['fields'] as $ff ) {
						$map[ $ff['key'] ] = $ff['selector'];
					}
					$actions[]    = array( 'type' => 'prefill_form', 'form' => 'sp', 'label' => $form['label'], 'url' => $form['url'], 'fields' => $fields, 'map' => $map, 'carry' => vai_url_host( $form['url'] ) !== vai_norm_host( $site_host ), 'auto' => true );
					$have_hosts[] = $key;
					$added++;
					if ( $added >= $max_add ) {
						break;
					}
					continue;
				}
			}
			$actions[] = array( 'type' => 'link', 'label' => 'افتح: ' . vai_clip( $l['label'], 50 ) . ' ↗', 'url' => $l['url'], 'carry' => $host !== vai_norm_host( $site_host ) && ! in_array( $host, $skip, true ), 'auto' => true );
			$have_hosts[] = $key;
			$added++;
			if ( $added >= $max_add ) {
				break;
			}
		}
		return $actions;
	}

	/** If the visitor clearly asked to open/go to a page and the reply carries one ecosystem URL, open it automatically. */
	private static function maybe_auto_open( $actions, $reply, $user_message_id, $site_host ) {
		global $wpdb;
		if ( ! (int) vai_cfg( 'auto_open' ) ) {
			return $actions;
		}
		foreach ( $actions as $a ) {
			if ( in_array( $a['type'], array( 'open_page', 'prefill_form' ), true ) ) {
				return $actions;
			}
		}
		if ( ! $user_message_id ) {
			return $actions;
		}
		$mt   = self::t( 'messages' );
		$text = (string) $wpdb->get_var( $wpdb->prepare( "SELECT content FROM $mt WHERE id=%d", $user_message_id ) );
		if ( $text === '' ) {
			return $actions;
		}
		$tn    = vai_norm_text( $text );
		$words = array_filter( array_map( 'trim', explode( ',', (string) vai_cfg( 'auto_open_words' ) ) ) );
		$hit   = false;
		foreach ( $words as $w ) {
			$w = vai_norm_text( $w );
			if ( $w !== '' && strpos( $tn, $w ) !== false ) {
				$hit = true;
				break;
			}
		}
		if ( ! $hit ) {
			return $actions;
		}
		if ( ! preg_match_all( '~https?://[^\s<>"\'«»()\]]+~u', $reply, $m ) ) {
			return $actions;
		}
		$skip = array( 'paymob.link', 'youtube.com', 'youtu.be', 'wa.me', 'maps.app.goo.gl', 'chat.whatsapp.com' );
		foreach ( $m[0] as $u ) {
			$u = rtrim( $u, '.,،;:!?؟' );
			$h = vai_url_host( $u );
			if ( $h === '' || in_array( $h, $skip, true ) || ! vai_url_allowed( $u ) ) {
				continue;
			}
			$actions[] = array( 'type' => 'open_page', 'url' => $u, 'carry' => $h !== vai_norm_host( $site_host ), 'auto' => true );
			break;
		}
		return $actions;
	}

	private static function add_lead( $c, $site, $type, $reason, $company = '', $notes = '' ) {
		global $wpdb;
		$wpdb->insert(
			self::t( 'leads' ),
			array(
				'contact_id' => $c->id,
				'site_id'    => $site ? (int) $site->id : 0,
				'ltype'      => $type,
				'reason'     => $reason,
				'company'    => $company,
				'notes'      => $notes,
				'created_at' => vai_now(),
			)
		);
		self::notify( $c, $site, $type, $reason, $company, $notes );
	}

	private static function notify( $c, $site, $type, $reason, $company, $notes ) {
		$labels = array(
			'contact'     => 'عميل جديد سجّل بياناته',
			'service'     => 'طلب خدمة مدفوعة',
			'membership'  => 'رغبة في عضوية النادي',
			'partner'     => 'رغبة في شراكة رسمية',
			'owner'       => 'متابعة صاحب مشروع',
			'management'  => 'طلب تواصل مع الإدارة',
			'cooperation' => 'تعاون تجاري بين جهات',
			'support'     => 'دعم / تصعيد',
			'payment'     => '💳 عميل دفع أو أرسل إثبات دفع — فعّل عضويته',
		);
		$head    = isset( $labels[ $type ] ) ? $labels[ $type ] : 'ليد جديد';
		$instant = array_filter( array_map( 'trim', explode( ',', strtolower( (string) vai_cfg( 'instant_lead_types' ) ) ) ) );
		if ( ! in_array( $type, $instant, true ) ) {
			return; // everything else is summarised in the periodic digest
		}
		if ( $c->name === '' || $c->phone_norm === '' ) {
			return; // no identity yet — the assistant asks them to register first; nothing to call
		}
		$lines = array(
			'🔔 ' . $head . ' — من الموقع: ' . ( $site ? $site->host : '' ),
			'',
			'الاسم: ' . ( $c->name ?: 'غير معروف' ),
			'الجوال: ' . ( $c->phone ?: '—' ),
			'الإيميل: ' . ( $c->email ?: '—' ),
			'السبب: ' . ( $reason ?: '—' ),
		);
		if ( $company ) {
			$lines[] = 'الشركة/المشروع: ' . $company;
		}
		if ( $notes ) {
			$lines[] = 'ملاحظات: ' . $notes;
		}
		if ( $c->memo ) {
			$lines[] = '';
			$lines[] = 'ملف العميل: ' . vai_clip( $c->memo, 500 );
		}
		$lines[] = '';
		$lines[] = 'الداشبورد: ' . admin_url( 'admin.php?page=vibes-ai&contact=' . (int) $c->id );
		$body    = implode( "\n", $lines );

		$emails = array_filter( array_map( 'trim', explode( ',', (string) vai_opt( 'notify_email', '' ) ) ) );
		foreach ( $emails as $e ) {
			if ( is_email( $e ) ) {
				wp_mail( $e, '[Vibes AI] ' . $head . ' — ' . ( $c->name ?: $c->phone ), $body );
			}
		}
		$hook = trim( (string) vai_opt( 'notify_webhook', '' ) );
		if ( $hook ) {
			vai_http_json(
				'POST',
				$hook,
				array(
					'type'    => $type,
					'title'   => $head,
					'text'    => $body,
					'site'    => $site ? $site->host : '',
					'contact' => array( 'id' => (int) $c->id, 'name' => $c->name, 'phone' => $c->phone, 'email' => $c->email ),
					'reason'  => $reason,
					'company' => $company,
					'notes'   => $notes,
					'memo'    => $c->memo,
				),
				array(),
				10
			);
		}
	}

	/* ───────────── staff console sessions (admins promoted from member accounts) ───────────── */

	public static function session_admin( $req_or_token ) {
		global $wpdb;
		$token = '';
		if ( is_string( $req_or_token ) ) {
			$token = $req_or_token;
		} elseif ( $req_or_token instanceof WP_REST_Request ) {
			$token = (string) $req_or_token->get_header( 'x-vai-session' );
		}
		$token = preg_replace( '/[^a-z0-9]/', '', strtolower( $token ) );
		if ( strlen( $token ) < 32 ) {
			return null;
		}
		$st  = self::t( 'sessions' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $st WHERE token=%s AND expires_at>%s", $token, vai_now() ) );
		if ( ! $row ) {
			return null;
		}
		$c = self::contact( $row->contact_id );
		if ( ! $c || $c->role !== 'admin' || ! (int) $c->admin_verified ) {
			return null;
		}
		$wpdb->update( $st, array( 'last_at' => vai_now() ), array( 'id' => $row->id ) );
		return $c;
	}

	private static function current_staff_name( $d = array() ) {
		$c = self::session_admin( isset( $d['_session'] ) ? (string) $d['_session'] : '' );
		if ( $c ) {
			return (string) $c->name;
		}
		$u = wp_get_current_user();
		return $u && $u->ID ? (string) $u->display_name : 'الفريق';
	}

	public static function console_login( $login, $pass, $ip ) {
		global $wpdb;
		if ( self::too_many_attempts( 'console_' . $ip . '_' . strtolower( $login ) ) ) {
			return vai_error( 'rate', 'محاولات كثيرة — انتظر 15 دقيقة', 429 );
		}
		$acc = self::find_account( $login );
		if ( ! $acc || $pass === '' || ! wp_check_password( $pass, $acc->pass_hash ) ) {
			return vai_error( 'bad_login', 'بيانات الدخول غير صحيحة', 401 );
		}
		if ( $acc->role !== 'admin' ) {
			return vai_error( 'not_admin', 'هذا الحساب ليس أدمن — اطلب الترقية من الإدارة', 403 );
		}
		$token = strtolower( vai_key( 48 ) );
		$wpdb->insert(
			self::t( 'sessions' ),
			array(
				'token'      => $token,
				'contact_id' => $acc->id,
				'ip_hash'    => vai_hash( $ip ),
				'created_at' => vai_now(),
				'last_at'    => vai_now(),
				'expires_at' => gmdate( 'Y-m-d H:i:s', time() + 30 * 86400 ),
			)
		);
		return array( 'ok' => true, 'token' => $token, 'name' => $acc->name, 'verified' => (int) $acc->admin_verified );
	}

	public static function console_activate( $token, $code ) {
		global $wpdb;
		$token = preg_replace( '/[^a-z0-9]/', '', strtolower( (string) $token ) );
		$st    = self::t( 'sessions' );
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $st WHERE token=%s AND expires_at>%s", $token, vai_now() ) );
		$c     = $row ? self::contact( $row->contact_id ) : null;
		if ( ! $c || $c->role !== 'admin' ) {
			return vai_error( 'bad_session', 'الجلسة غير صالحة', 401 );
		}
		$code = preg_replace( '/\D+/', '', (string) $code );
		if ( self::too_many_attempts( 'admincode_' . $c->id, 8 ) ) {
			return vai_error( 'rate', 'محاولات كثيرة', 429 );
		}
		if ( $c->admin_code === '' || strlen( $code ) < 4 || strlen( $code ) > 6 || ! hash_equals( $c->admin_code, vai_hash( $code ) ) ) {
			return vai_error( 'bad_code', 'رمز التفعيل غير صحيح', 400 );
		}
		$wpdb->update( self::t( 'contacts' ), array( 'admin_verified' => 1, 'admin_code' => '' ), array( 'id' => $c->id ) );
		return array( 'ok' => true, 'name' => $c->name );
	}

	public static function console_logout( $token ) {
		global $wpdb;
		$token = preg_replace( '/[^a-z0-9]/', '', strtolower( (string) $token ) );
		if ( $token ) {
			$wpdb->delete( self::t( 'sessions' ), array( 'token' => $token ) );
		}
	}

	/** Promote a member account to admin: role=admin, e-mail a 4-digit activation code with full instructions. */
	public static function promote_admin( $contact_id ) {
		global $wpdb;
		$c = self::contact( $contact_id );
		if ( ! $c || empty( $c->pass_hash ) || ! $c->email ) {
			return vai_error( 'invalid', 'لا يمكن ترقية هذا الحساب (يلزم حساب مفعّل ببريد)' );
		}
		$code = (string) wp_rand( 1000, 9999 );
		$wpdb->update( self::t( 'contacts' ), array( 'role' => 'admin', 'admin_verified' => 0, 'admin_code' => vai_hash( $code ) ), array( 'id' => $c->id ) );
		self::log_event( $c->id, 'role', 0, 'manual', '', 0, 'admin' );
		$console = home_url( '/?vai-console=1' );
		$body    = "مرحبًا " . $c->name . "،\n\nتمت ترقية حسابك في Vibes Ventures إلى «أدمن» بقرار من الإدارة. من الآن تستطيع متابعة كل المحادثات التي تدور مع مساعد المنظومة على كل المواقع والرد عليها باسمك.\n\nخطوات التفعيل:\n1) افتح لوحة الإدارة (على vcmem فقط — الموقع الأم): " . $console . "\n2) سجّل الدخول بنفس بريدك وكلمة مرور حسابك.\n3) أدخل رمز التفعيل: " . $code . "\n\nبعد التفعيل يتحول حسابك إلى أدمن، وأي رد تكتبه يظهر للعميل باسمك (" . $c->name . ").\n\nبياناتك: البريد " . $c->email . " — الجوال " . $c->phone . "\n\nنادي المستثمرين — Vibes Ventures";
		$sent    = self::mail( $c->email, 'تمت ترقيتك إلى أدمن في Vibes Ventures — رمز التفعيل', $body );
		if ( class_exists( 'VAI_Payments' ) ) {
			VAI_Payments::notify_user_event( $c, 'admin' );
		}
		return array( 'ok' => true, 'mail_sent' => $sent ? 1 : 0, 'code' => $code );
	}

	public static function demote_admin( $contact_id ) {
		global $wpdb;
		$wpdb->update( self::t( 'contacts' ), array( 'role' => 'member', 'admin_verified' => 0, 'admin_code' => '' ), array( 'id' => (int) $contact_id ) );
		$wpdb->delete( self::t( 'sessions' ), array( 'contact_id' => (int) $contact_id ) );
		self::log_event( (int) $contact_id, 'role', 0, 'manual', '', 0, 'member' );
	}

	/**
	 * Role «publisher» (2.7.0): may publish posts / events from the app dashboard, nothing else. Admin promotion keeps
	 * its own page and code step (promote_admin); this only moves an account between member and publisher.
	 */
	public static function set_role( $contact_id, $role, $source = 'manual', $actor_id = 0 ) {
		global $wpdb;
		$c = self::contact( $contact_id );
		if ( ! $c ) {
			return vai_error( 'no_contact', 'الحساب غير موجود', 404 );
		}
		if ( ! in_array( $role, array( 'member', 'publisher' ), true ) ) {
			return vai_error( 'invalid', 'الدور غير معروف' );
		}
		if ( $c->role === 'admin' ) {
			return vai_error( 'is_admin', 'هذا الحساب أدمن — ألغِ صلاحية الأدمن أولًا من صفحة الحسابات في الهب', 409 );
		}
		if ( $role === 'publisher' && ( (int) $c->verified !== 1 || empty( $c->pass_hash ) ) ) {
			// A password too: an account without one can still be adopted by a new sign-up with the same phone (op_register).
			return vai_error( 'invalid', 'يلزم حساب مفعّل بالبريد وله كلمة مرور قبل الترقية إلى ناشر' );
		}
		if ( $c->role !== $role ) {
			$wpdb->update( self::t( 'contacts' ), array( 'role' => $role ), array( 'id' => $c->id ) );
			self::log_event( $c->id, 'role', 0, $source, '', $actor_id, $role );
		}
		return self::contact( $c->id );
	}

	public static function paid_members() {
		global $wpdb;
		$ct = self::t( 'contacts' );
		$st = self::t( 'sites' );
		return (array) $wpdb->get_results( "SELECT c.*, s.host FROM $ct c LEFT JOIN $st s ON s.id=c.last_site_id WHERE c.is_member=1 ORDER BY c.member_started_at DESC, c.id DESC LIMIT 500" );
	}

	public static function accounts( $q = '', $limit = 300 ) {
		global $wpdb;
		$ct   = self::t( 'contacts' );
		$st   = self::t( 'sites' );
		$args = array();
		$w    = "c.pass_hash<>''";
		if ( $q !== '' ) {
			$like = '%' . $wpdb->esc_like( $q ) . '%';
			$w   .= ' AND (c.name LIKE %s OR c.email LIKE %s OR c.phone LIKE %s OR c.company LIKE %s)';
			$args = array( $like, $like, $like, $like );
		}
		$sql = "SELECT c.*, s.host FROM $ct c LEFT JOIN $st s ON s.id=c.last_site_id WHERE $w ORDER BY c.id DESC LIMIT " . (int) $limit;
		return (array) ( $args ? $wpdb->get_results( $wpdb->prepare( $sql, $args ) ) : $wpdb->get_results( $sql ) );
	}

	/* ───────────────────────── admin ops ───────────────────────── */

	public static function admin( $op, array $d ) {
		global $wpdb;
		$ct = self::t( 'contacts' );
		$mt = self::t( 'messages' );
		$st = self::t( 'sites' );
		$lt = self::t( 'leads' );

		switch ( $op ) {
			case 'me':
				return array( 'ok' => true, 'name' => self::current_staff_name( $d ) );
			case 'overview':
				$day  = vai_riyadh_day_start_utc();
				$week = gmdate( 'Y-m-d H:i:s', time() - 7 * 86400 );
				$row  = function ( $since ) use ( $wpdb, $mt, $ct, $lt ) {
					return array(
						'conversations' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT contact_id) FROM $mt WHERE role='user' AND created_at>=%s", $since ) ),
						'messages'      => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $mt WHERE role IN ('user','assistant') AND created_at>=%s", $since ) ),
						'leads'         => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $ct WHERE stage>=1 AND created_at>=%s", $since ) ),
						'hot'           => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $lt WHERE ltype<>'contact' AND created_at>=%s", $since ) ),
					);
				};
				$sites = $wpdb->get_results( "SELECT s.id, s.name, s.host, (SELECT COUNT(DISTINCT contact_id) FROM $mt m WHERE m.site_id=s.id AND m.role='user' AND m.created_at>='" . esc_sql( $week ) . "') AS week_conv, (SELECT COUNT(*) FROM $mt m WHERE m.site_id=s.id AND m.role='assistant' AND m.created_at>='" . esc_sql( $day ) . "') AS today_replies, s.knowledge_count, s.last_sync, s.last_seen FROM $st s ORDER BY week_conv DESC" );
				return array(
					'ok'      => true,
					'today'   => $row( $day ),
					'week'    => $row( $week ),
					'total'   => array(
						'contacts' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ct" ),
						'leads'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ct WHERE stage>=1" ),
						'members'  => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ct WHERE is_member=1" ),
					),
					'waiting' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ct WHERE awaiting_since IS NOT NULL" ),
					'human'   => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ct WHERE human_until IS NOT NULL AND human_until>UTC_TIMESTAMP()" ),
					'sites'   => array_map(
						function ( $s ) {
							return array(
								'id'        => (int) $s->id,
								'name'      => $s->name,
								'host'      => $s->host,
								'week_conv' => (int) $s->week_conv,
								'today'     => (int) $s->today_replies,
								'knowledge' => (int) $s->knowledge_count,
								'last_sync' => vai_riyadh( $s->last_sync ),
								'last_seen' => vai_riyadh( $s->last_seen ),
							);
						},
						(array) $sites
					),
					'now'     => vai_riyadh( vai_now(), 'Y-m-d H:i:s' ),
					'diag'    => self::diag(),
				);

			case 'threads':
				$where = array( '1=1' );
				$args  = array();
				if ( ! empty( $d['site_id'] ) ) {
					$where[] = 'c.last_site_id=%d';
					$args[]  = (int) $d['site_id'];
				}
				if ( isset( $d['stage'] ) && $d['stage'] !== '' ) {
					if ( $d['stage'] === 'member' ) {
						$where[] = 'c.is_member=1';
					} elseif ( $d['stage'] === 'lead' ) {
						$where[] = 'c.stage>=1';
					} elseif ( $d['stage'] === 'anon' ) {
						$where[] = 'c.stage=0';
					} elseif ( $d['stage'] === 'human' ) {
						$where[] = 'c.human_until IS NOT NULL AND c.human_until>UTC_TIMESTAMP()';
					}
				}
				$q = vai_str( $d, 'q', 100 );
				if ( $q !== '' ) {
					$like    = '%' . $wpdb->esc_like( $q ) . '%';
					$where[] = '(c.name LIKE %s OR c.phone LIKE %s OR c.email LIKE %s OR c.memo LIKE %s)';
					array_push( $args, $like, $like, $like, $like );
				}
				$page  = max( 1, (int) ( isset( $d['page'] ) ? $d['page'] : 1 ) );
				$per   = 30;
				$sql   = "SELECT c.*, s.host AS site_host, s.name AS site_name,
					(SELECT content FROM $mt m WHERE m.contact_id=c.id AND m.role IN ('user','assistant','human') ORDER BY m.id DESC LIMIT 1) AS last_content,
					(SELECT role FROM $mt m WHERE m.contact_id=c.id AND m.role IN ('user','assistant','human') ORDER BY m.id DESC LIMIT 1) AS last_role,
					(SELECT MAX(id) FROM $mt m WHERE m.contact_id=c.id AND m.role='user') AS last_user_id
					FROM $ct c LEFT JOIN $st s ON s.id=c.last_site_id WHERE " . implode( ' AND ', $where ) . ' ORDER BY c.last_at DESC LIMIT %d OFFSET %d';
				$args2 = array_merge( $args, array( $per, ( $page - 1 ) * $per ) );
				$rows  = $wpdb->get_results( $wpdb->prepare( $sql, $args2 ) );
				$total = (int) $wpdb->get_var( $args ? $wpdb->prepare( "SELECT COUNT(*) FROM $ct c WHERE " . implode( ' AND ', $where ), $args ) : "SELECT COUNT(*) FROM $ct c WHERE " . implode( ' AND ', $where ) );
				$out   = array();
				foreach ( (array) $rows as $r ) {
					$out[] = array(
						'id'           => (int) $r->id,
						'name'         => (string) $r->name,
						'phone'        => (string) $r->phone,
						'email'        => (string) $r->email,
						'stage'        => (int) $r->stage,
						'is_member'    => (int) $r->is_member,
						'site'         => (string) $r->site_host,
						'site_name'    => (string) $r->site_name,
						'last'         => vai_clip( (string) $r->last_content, 90 ),
						'last_role'    => (string) $r->last_role,
						'last_at'      => vai_riyadh( $r->last_at ),
						'last_at_iso'  => vai_iso( $r->last_at ),
						'msg_count'    => (int) $r->msg_count,
						'lead_type'    => (string) $r->lead_type,
						'human'        => ! empty( $r->human_until ) && strtotime( $r->human_until . ' UTC' ) > time(),
						'waiting'      => ! empty( $r->awaiting_since ),
						'unread'       => (int) $r->last_user_id > (int) $r->admin_seen_id,
						'intent'       => self::intent_score( $r ),
						'intent_label' => self::intent_label( self::intent_score( $r ) ),
					);
				}
				return array( 'ok' => true, 'threads' => $out, 'total' => $total, 'page' => $page, 'per' => $per );

			case 'thread':
				$c = self::contact( isset( $d['id'] ) ? (int) $d['id'] : 0 );
				if ( ! $c ) {
					return vai_error( 'no_contact', 'غير موجود', 404 );
				}
				$rows = $wpdb->get_results( $wpdb->prepare( "SELECT m.id, m.role, m.content, m.actions, m.page_url, m.meta, m.created_at, s.host FROM $mt m LEFT JOIN $st s ON s.id=m.site_id WHERE m.contact_id=%d ORDER BY m.id ASC LIMIT 400", $c->id ) );
				$msgs = array();
				$max  = (int) $c->admin_seen_id;
				$last_user_ts = 0;
				foreach ( (array) $rows as $r ) {
					$a    = $r->actions ? json_decode( $r->actions, true ) : array();
					$meta = $r->meta ? json_decode( $r->meta, true ) : array();
					$ts   = $r->created_at ? strtotime( $r->created_at . ' UTC' ) : 0;
					$lat  = null;
					if ( $r->role === 'user' ) {
						$last_user_ts = $ts;
					} elseif ( $r->role === 'assistant' && $last_user_ts && $ts ) {
						$lat          = max( 0, $ts - $last_user_ts );
						$last_user_ts = 0;
					}
					$msgs[] = array(
						'id'      => (int) $r->id,
						'role'    => $r->role,
						'content' => (string) $r->content,
						'actions' => is_array( $a ) ? $a : array(),
						'image'   => is_array( $meta ) && ! empty( $meta['image'] ) ? (string) $meta['image'] : '',
						'audio'   => is_array( $meta ) && ! empty( $meta['audio'] ) ? (string) $meta['audio'] : '',
						'page'    => (string) $r->page_url,
						'site'    => (string) $r->host,
						'at'      => vai_riyadh( $r->created_at, 'Y-m-d H:i:s' ),
						'by'      => is_array( $meta ) && ! empty( $meta['by'] ) ? (string) $meta['by'] : '',
						'model'   => is_array( $meta ) && ! empty( $meta['model'] ) ? (string) $meta['model'] : '',
						'route'   => is_array( $meta ) && ! empty( $meta['route'] ) ? (string) $meta['route'] : '',
						'guard'   => is_array( $meta ) && ! empty( $meta['guard'] ) ? (string) $meta['guard'] : '',
						'focus'   => is_array( $meta ) && ! empty( $meta['focus'] ) ? (string) $meta['focus'] : '',
						'latency' => $lat,
					);
					$max    = max( $max, (int) $r->id );
				}
				$wpdb->update( $ct, array( 'admin_seen_id' => $max ), array( 'id' => $c->id ) );
				$leads = $wpdb->get_results( $wpdb->prepare( "SELECT l.*, s.host FROM $lt l LEFT JOIN $st s ON s.id=l.site_id WHERE l.contact_id=%d ORDER BY l.id DESC LIMIT 20", $c->id ) );
				return array(
					'ok'       => true,
					'contact'  => array(
						'id'          => (int) $c->id,
						'name'        => (string) $c->name,
						'phone'       => vai_phone_local( $c->phone_norm ?: $c->phone ),
						'email'       => (string) $c->email,
						'stage'       => (int) $c->stage,
						'is_member'   => (int) $c->is_member,
						'memo'        => (string) $c->memo,
						'notes'       => (string) $c->notes,
						'first_at'    => vai_riyadh( $c->first_at ),
						'last_at'     => vai_riyadh( $c->last_at ),
						'msg_count'   => (int) $c->msg_count,
						'reply_count' => (int) $c->reply_count,
						'sites'       => (array) json_decode( (string) $c->sites, true ),
						'last_page'   => (string) $c->last_page,
						'human'       => ! empty( $c->human_until ) && strtotime( $c->human_until . ' UTC' ) > time(),
						'human_until' => vai_riyadh( $c->human_until, 'H:i' ),
						'waiting'     => ! empty( $c->awaiting_since ),
						'lead_type'   => (string) $c->lead_type,
						'wa'          => $c->phone_norm ? 'https://wa.me/' . $c->phone_norm : '',
						'has_account' => ! empty( $c->pass_hash ),
						'trial_left'  => self::trial_days_left( $c ),
						'member_left' => self::member_days_left( $c ),
						'persona'     => self::persona_label( $c->persona ),
						'avatar'      => (string) $c->avatar_url,
						'company'     => (string) $c->company,
						'city'        => (string) $c->city,
						'bio'         => (string) $c->bio,
					),
					'messages' => $msgs,
					'leads'    => array_map(
						function ( $l ) {
							return array(
								'type'    => $l->ltype,
								'reason'  => $l->reason,
								'company' => $l->company,
								'notes'   => $l->notes,
								'site'    => $l->host,
								'at'      => vai_riyadh( $l->created_at ),
							);
						},
						(array) $leads
					),
				);

			case 'send':
				$c    = self::contact( isset( $d['id'] ) ? (int) $d['id'] : 0 );
				$text = vai_text_ok( $d, 'text', 3000 );
				if ( ! $c || $text === '' ) {
					return vai_error( 'invalid', 'بيانات ناقصة' );
				}
				$mid = self::staff_send( $c, $text, self::current_staff_name( $d ) );
				return array( 'ok' => true, 'message_id' => $mid );

			case 'contact':
				$c = self::contact( isset( $d['id'] ) ? (int) $d['id'] : 0 );
				if ( ! $c ) {
					return vai_error( 'no_contact', 'غير موجود', 404 );
				}
				$upd = array();
				if ( isset( $d['name'] ) ) {
					$upd['name'] = vai_str( $d, 'name', 120 );
				}
				if ( isset( $d['phone'] ) ) {
					$upd['phone']      = vai_str( $d, 'phone', 40 );
					$upd['phone_norm'] = vai_norm_phone( $upd['phone'] );
				}
				if ( isset( $d['email'] ) ) {
					$upd['email']      = vai_norm_email( vai_str( $d, 'email', 190 ) );
					$upd['email_norm'] = $upd['email'];
				}
				if ( isset( $d['notes'] ) ) {
					$upd['notes'] = vai_text_ok( $d, 'notes', 2000 );
				}
				if ( isset( $d['is_member'] ) ) {
					self::set_member( $c->id, (bool) $d['is_member'] );
				}
				if ( isset( $d['bot'] ) ) {
					if ( $d['bot'] === 'pause' ) {
						$upd['human_until'] = gmdate( 'Y-m-d H:i:s', time() + 30 * 86400 );
					} elseif ( $d['bot'] === 'resume' ) {
						$upd['human_until'] = null;
					}
				}
				if ( $upd ) {
					$wpdb->update( $ct, $upd, array( 'id' => $c->id ) );
				}
				return array( 'ok' => true );

			case 'delete':
				$c = self::contact( isset( $d['id'] ) ? (int) $d['id'] : 0 );
				if ( ! $c ) {
					return vai_error( 'no_contact', 'غير موجود', 404 );
				}
				$wpdb->delete( $mt, array( 'contact_id' => $c->id ) );
				$wpdb->delete( self::t( 'visitors' ), array( 'contact_id' => $c->id ) );
				$wpdb->delete( $lt, array( 'contact_id' => $c->id ) );
				$wpdb->delete( $ct, array( 'id' => $c->id ) );
				self::log_event( $c->id, 'deleted', 0, 'manual', '', 0, 'hub admin' );
				return array( 'ok' => true );

			case 'search_test':
				return array( 'ok' => true, 'results' => self::search( vai_str( $d, 'q', 200 ), '', 6 ), 'projects' => self::projects( vai_str( $d, 'q', 200 ), 4 ) );
		}
		return vai_error( 'not_found', 'عملية غير معروفة', 404 );
	}

	public static function diag() {
		$n = get_option( 'vai_last_n8n', array() );
		$r = get_option( 'vai_last_reply', array() );
		$g = get_option( 'vai_last_pong', array() );
		$m = get_option( 'vai_last_mail', array() );
		return array(
			'mail'  => is_array( $m ) && $m ? array( 'at' => vai_riyadh( $m['at'] ?? '' ), 'ok' => (int) ( $m['ok'] ?? 0 ), 'to' => (string) ( $m['to'] ?? '' ), 'subject' => (string) ( $m['subject'] ?? '' ), 'error' => (string) get_option( 'vai_last_mail_error', '' ) ) : null,
			'pong'  => is_array( $g ) && $g ? vai_riyadh( $g['at'] ?? '', 'Y-m-d H:i:s' ) : '',
			'n8n'   => is_array( $n ) && $n ? array( 'at' => vai_riyadh( $n['at'] ?? '', 'H:i:s' ), 'code' => (int) ( $n['code'] ?? 0 ), 'err' => (string) ( $n['err'] ?? '' ), 'ms' => (int) ( $n['ms'] ?? 0 ) ) : null,
			'reply' => is_array( $r ) && $r ? array( 'at' => vai_riyadh( $r['at'] ?? '', 'H:i:s' ), 'model' => (string) ( $r['model'] ?? '' ), 'route' => (string) ( $r['route'] ?? '' ), 'guard' => (string) ( $r['guard'] ?? '' ), 'latency' => $r['latency'] ?? null ) : null,
		);
	}

	/* knowledge notes (admin) */

	public static function add_note( $title, $content ) {
		global $wpdb;
		$kt = self::t( 'knowledge' );
		$wpdb->insert(
			$kt,
			array(
				'site_id'      => 0,
				'url'          => 'note:' . time() . '-' . wp_rand( 100, 999 ),
				'url_hash'     => md5( 'note:' . time() . wp_rand() ),
				'title'        => vai_clip( $title, 200 ),
				'content'      => $content,
				'content_norm' => vai_norm_text( $title . ' ' . $content ),
				'kind'         => 'note',
				'hash'         => md5( $title . $content ),
				'updated_at'   => vai_now(),
			)
		);
		$id = (int) $wpdb->insert_id;
		self::knowledge_changed( null, 1 );
		return $id;
	}

	public static function notes_all() {
		global $wpdb;
		$kt = self::t( 'knowledge' );
		return (array) $wpdb->get_results( "SELECT id, title, content, updated_at FROM $kt WHERE kind='note' ORDER BY id DESC LIMIT 200" );
	}

	public static function delete_note( $id ) {
		global $wpdb;
		$wpdb->delete( self::t( 'knowledge' ), array( 'id' => (int) $id, 'kind' => 'note' ) );
	}

	/* ═════════════ bridge v2 (2.7.0) — ops for the trusted app server (docs/BRIDGE_V2.md) ═════════════ */

	/**
	 * The dashboard user behind an admin_* / publish op. The hub decides who is an admin (role + code step); the app
	 * server only passes that person's own visitor uuid. $roles: array( 'admin' ) or array( 'admin', 'publisher' ).
	 */
	private static function bridge_actor( $site, $d, $roles = array( 'admin' ) ) {
		list( $a ) = self::resolve_contact( $site, isset( $d['uuid'] ) ? $d['uuid'] : '', false );
		$ok        = $a && in_array( $a->role, $roles, true ) && ( $a->role !== 'admin' || (int) $a->admin_verified === 1 );
		if ( ! $ok ) {
			return vai_error( 'not_admin', 'هذا الحساب لا يملك صلاحية الإدارة', 403 );
		}
		return $a;
	}

	/** page / per_page (≤100) → array( page, per_page, offset ). */
	private static function bridge_page( $d, $default = 30 ) {
		$per  = vai_int_in( $d, 'per_page', 1, 100, $default );
		$page = vai_int_in( $d, 'page', 1, 100000, 1 );
		return array( $page, $per, ( $page - 1 ) * $per );
	}

	/** $wpdb->prepare() only when there is something to bind (it rejects a query without placeholders). */
	private static function prep( $sql, array $args ) {
		global $wpdb;
		return $args ? $wpdb->prepare( $sql, $args ) : $sql;
	}

	/** SQL: end of the paid period of contact alias c (UTC). A member without a start date never expires. */
	private static function sql_member_end() {
		return 'DATE_ADD(c.member_started_at, INTERVAL IF(c.member_days>0, c.member_days, ' . max( 1, (int) vai_cfg( 'member_days' ) ) . ') DAY)';
	}

	/** SQL condition of one account state on contact alias c (no user input in here). */
	private static function sql_state( $state ) {
		$end = self::sql_member_end();
		$map = array(
			'all'       => "(c.stage>=1 OR c.verified=1 OR c.pass_hash<>'')",
			'pending'   => "(c.pass_hash<>'' AND c.verified=0 AND c.is_member=0)",
			'unpaid'    => '(c.verified=1 AND c.is_member=0)',
			'member'    => '(c.is_member=1 AND (c.member_started_at IS NULL OR ' . $end . '>UTC_TIMESTAMP()))',
			'expired'   => '(c.is_member=1 AND c.member_started_at IS NOT NULL AND ' . $end . '<=UTC_TIMESTAMP())',
			'admin'     => "(c.role='admin')",
			'publisher' => "(c.role='publisher')",
			'lead'      => "(c.stage>=1 AND c.verified=0 AND c.pass_hash='' AND c.is_member=0)",
		);
		return isset( $map[ $state ] ) ? $map[ $state ] : $map['all'];
	}

	/** The same states in PHP, for one row. */
	private static function account_state( $c ) {
		if ( (int) $c->is_member ) {
			return self::member_active( $c ) ? 'member' : 'expired';
		}
		if ( (int) $c->verified ) {
			return 'unpaid';
		}
		return ! empty( $c->pass_hash ) ? 'pending' : 'lead';
	}

	/** Search box → array( sql, args ) on contact alias c. */
	private static function where_contact_q( $q ) {
		global $wpdb;
		if ( $q === '' ) {
			return array( '', array() );
		}
		$like = '%' . $wpdb->esc_like( $q ) . '%';
		return array( ' AND (c.name LIKE %s OR c.email LIKE %s OR c.phone LIKE %s OR c.phone_norm LIKE %s OR c.company LIKE %s)', array( $like, $like, $like, $like, $like ) );
	}

	private static function clean_ids( array $ids ) {
		return array_values( array_unique( array_filter( array_map( 'intval', $ids ) ) ) );
	}

	/** contact_id => lead types, one query for the whole page (list ops never run a query per row). */
	private static function bulk_lead_types( array $ids ) {
		global $wpdb;
		$out = array();
		$ids = self::clean_ids( $ids );
		if ( ! $ids ) {
			return $out;
		}
		$lt   = self::t( 'leads' );
		$ph   = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT contact_id, ltype FROM $lt WHERE contact_id IN ($ph)", $ids ) );
		foreach ( $rows as $r ) {
			$out[ (int) $r->contact_id ][] = (string) $r->ltype;
		}
		return $out;
	}

	/** contact_id => assistant replies since Riyadh midnight, one query for the whole page. */
	private static function bulk_replies_today( array $ids ) {
		global $wpdb;
		$out = array();
		$ids = self::clean_ids( $ids );
		if ( ! $ids ) {
			return $out;
		}
		$mt   = self::t( 'messages' );
		$ph   = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$args = array_merge( $ids, array( vai_riyadh_day_start_utc() ) );
		$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT contact_id, COUNT(*) AS n FROM $mt WHERE contact_id IN ($ph) AND role='assistant' AND created_at>=%s GROUP BY contact_id", $args ) );
		foreach ( $rows as $r ) {
			$out[ (int) $r->contact_id ] = (int) $r->n;
		}
		return $out;
	}

	/** Shape «Account» of the contract. $c may carry site_host from a JOIN. Times are UTC, member_end is a Riyadh day. */
	private static function account_row( $c, array $types, $used_today ) {
		$std   = (int) vai_cfg( 'member_days' );
		$daily = (int) vai_cfg( 'member_daily' );
		$days  = (int) $c->member_days > 0 ? (int) $c->member_days : $std;
		$score = self::intent_calc( $c, $types );
		return array(
			'id'            => (int) $c->id,
			'name'          => (string) $c->name,
			'email'         => (string) $c->email,
			'phone'         => vai_phone_local( $c->phone_norm ? $c->phone_norm : $c->phone ),
			'state'         => self::account_state( $c ),
			'role'          => (string) $c->role,
			'persona'       => (string) $c->persona,
			'job_title'     => (string) $c->job_title,
			'company'       => (string) $c->company,
			'member_type'   => (string) $c->member_type,
			'city'          => (string) $c->city,
			'created_at'    => (string) $c->created_at,
			'verified_at'   => isset( $c->verified_at ) ? (string) $c->verified_at : '',
			'last_at'       => (string) $c->last_at,
			'last_login_at' => (string) $c->last_login_at,
			'site'          => isset( $c->site_host ) ? (string) $c->site_host : '',
			'msg_count'     => (int) $c->msg_count,
			'is_member'     => self::member_active( $c ) ? 1 : 0,
			'member_left'   => self::member_days_left( $c ),
			'member_days'   => $days,
			'member_end'    => ! empty( $c->member_started_at ) ? vai_riyadh( gmdate( 'Y-m-d H:i:s', strtotime( $c->member_started_at . ' UTC' ) + $days * 86400 ), 'Y-m-d' ) : '',
			'never_expires' => ( (int) $c->is_member && empty( $c->member_started_at ) ) ? 1 : 0,
			'daily_limit'   => $daily,
			'daily_left'    => (int) $c->is_member ? max( 0, $daily - (int) $used_today ) : null,
			'intent'        => $score,
			'intent_label'  => self::intent_label( $score ),
			'has_password'  => ! empty( $c->pass_hash ) ? 1 : 0,
			'referred_by'   => isset( $c->referred_by ) ? (int) $c->referred_by : 0,
		);
	}

	/** Accounts of a list of contact rows, with intent and today's replies computed in two bulk queries. */
	private static function account_rows( array $rows ) {
		$ids = array();
		foreach ( $rows as $r ) {
			$ids[] = (int) $r->id;
		}
		$types = self::bulk_lead_types( $ids );
		$used  = self::bulk_replies_today( $ids );
		$out   = array();
		foreach ( $rows as $r ) {
			$id    = (int) $r->id;
			$out[] = self::account_row( $r, isset( $types[ $id ] ) ? $types[ $id ] : array(), isset( $used[ $id ] ) ? $used[ $id ] : 0 );
		}
		return $out;
	}

	/** Server-to-server (Investors Club app): the account holder deletes their own account. Personal data and conversations are wiped; payment records stay. */
	private static function op_delete_account( $site, $d ) {
		global $wpdb;
		list( $c ) = self::resolve_contact( $site, isset( $d['uuid'] ) ? $d['uuid'] : '', false );
		if ( ! $c || empty( $c->pass_hash ) ) {
			return vai_error( 'no_account', 'سجّل الدخول أولًا', 401 );
		}
		if ( self::too_many_attempts( 'delete_' . $c->id, 6 ) ) {
			return vai_error( 'rate', 'محاولات كثيرة — حاول بعد قليل', 429 );
		}
		$pass = isset( $d['password'] ) && is_string( $d['password'] ) ? $d['password'] : '';
		if ( $pass === '' || ! wp_check_password( $pass, $c->pass_hash ) ) {
			return vai_error( 'bad_login', 'كلمة المرور غير صحيحة', 401 );
		}
		$label = $c->name . ' / ' . vai_phone_local( $c->phone_norm ? $c->phone_norm : $c->phone ) . ' / ' . $c->email . ( (int) $c->is_member ? ' (عضو مدفوع)' : '' ) . ' — من ' . ( $site ? $site->host : '' );
		foreach ( array( 'messages', 'visitors', 'tokens', 'sessions', 'leads' ) as $t ) {
			$wpdb->delete( self::t( $t ), array( 'contact_id' => $c->id ) );
		}
		if ( class_exists( 'VAI_Payments' ) ) {
			$wpdb->delete( VAI_Payments::table(), array( 'contact_id' => $c->id ) ); // queued e-mails carry the name and address
		}
		$wpdb->update( self::t( 'contacts' ), self::wiped_contact(), array( 'id' => $c->id ) );
		self::log_event( $c->id, 'deleted', 0, self::site_source( $site ), '', 0, $site ? $site->host : '' );
		$emails = array_filter( array_map( 'trim', explode( ',', (string) vai_opt( 'notify_email', get_option( 'admin_email' ) ) ) ) );
		foreach ( $emails as $e ) {
			if ( is_email( $e ) ) {
				self::mail( $e, '[Vibes AI] حذف حساب من التطبيق: ' . $c->name, "حذف العضو حسابه بنفسه من تطبيق نادي المستثمرين.\n\n" . $label . "\nالتاريخ: " . vai_riyadh( vai_now() ) . " (الرياض)\n\nحُذفت بياناته الشخصية ومحادثاته؛ سجلات الدفع محفوظة كما هي." );
			}
		}
		return array( 'ok' => true );
	}

	/** Column values of a deleted account: every personal field emptied, the row kept so payment records still point somewhere. */
	private static function wiped_contact() {
		return array(
			'name'               => 'حساب محذوف',
			'phone'              => '',
			'phone_norm'         => '',
			'email'              => '',
			'email_norm'         => '',
			'stage'              => 0,
			'is_member'          => 0,
			'memo'               => null,
			'msg_count'          => 0,
			'reply_count'        => 0,
			'sites'              => null,
			'last_page'          => null,
			'lead_type'          => '',
			'notes'              => null,
			'ip_hash'            => '',
			'pass_hash'          => '',
			'reset_code'         => '',
			'reset_expires'      => null,
			'avatar_url'         => '',
			'company'            => '',
			'city'               => '',
			'bio'                => null,
			'job_title'          => '',
			'website'            => '',
			'social'             => null,
			'verified'           => 0,
			'verified_at'        => null,
			'verify_code'        => '',
			'verify_expires'     => null,
			'role'               => 'member',
			'admin_code'         => '',
			'admin_verified'     => 0,
			'member_started_at'  => null,
			'member_days'        => 0,
			'member_welcomed'    => 0,
			'persona'            => '',
			'pass_token'         => '',
			'pass_token_expires' => null,
		);
	}

	/** Store purchase / renewal confirmed by the app server: contact_id, days, reference, product, store → ok, contact, already. */
	private static function op_activate_member( $site, $d ) {
		$c   = self::contact( isset( $d['contact_id'] ) ? (int) $d['contact_id'] : 0 );
		$ref = self::clean_ref( vai_str( $d, 'reference', 150 ) );
		if ( ! $c ) {
			return vai_error( 'no_contact', 'الحساب غير موجود', 404 );
		}
		if ( $ref === '' ) {
			return vai_error( 'invalid', 'مرجع عملية الشراء مطلوب', 400 );
		}
		$days = vai_int_in( $d, 'days', 1, 3660, (int) vai_cfg( 'member_days' ) );
		$note = trim( preg_replace( '/[^a-z0-9._\-]/i', '', vai_str( $d, 'store', 20 ) ) . ' ' . preg_replace( '/[^a-z0-9._\-]/i', '', vai_str( $d, 'product', 80 ) ) );
		$res  = self::member_change( $c->id, 'extend', $days, 'store', $ref, 0, $note );
		if ( ! $res ) {
			return vai_error( 'no_contact', 'الحساب غير موجود', 404 );
		}
		if ( ! empty( $res['conflict'] ) ) {
			return vai_error( 'reference_used', 'مرجع عملية الشراء مسجّل لحساب آخر — لم يتغيّر شيء في هذا الحساب', 409 );
		}
		if ( empty( $res['ok'] ) ) {
			return vai_error( 'db_error', 'تعذّر حفظ العضوية الآن — أعد المحاولة', 500 );
		}
		return array( 'ok' => true, 'contact' => self::public_contact( self::contact( $c->id ) ), 'already' => ! empty( $res['already'] ) );
	}

	/** A staff (human) message: what the console's «send» does, shared with admin_reply. Returns the message id. */
	private static function staff_send( $c, $text, $by ) {
		global $wpdb;
		$mid   = self::insert_message( $c->id, (int) $c->last_site_id, 'human', $text, null, '', array( 'by' => (string) $by ) );
		$pause = (int) vai_cfg( 'human_pause_min' );
		$wpdb->update(
			self::t( 'contacts' ),
			array(
				'human_until'    => gmdate( 'Y-m-d H:i:s', time() + max( 1, $pause ) * 60 ),
				'awaiting_since' => null,
				'last_at'        => vai_now(),
			),
			array( 'id' => $c->id )
		);
		self::webhook( 'message.staff', array( 'contact_id' => (int) $c->id, 'message_id' => (int) $mid ) );
		return $mid;
	}

	/* admin_stats — contract 1.4 */

	/**
	 * 2.19.0 (app server, owner 2026-10-21): the app mails THROUGH the hub over plain HTTPS — its
	 * own SMTP path sits behind Railway's port block. Trusted app-server key only; wp_mail does the
	 * actual sending with this site's working deliverability. Capped recipients, nothing stored.
	 */
	private static function op_send_mail( $site, $d ) {
		$raw = isset( $d['to'] ) ? ( is_array( $d['to'] ) ? $d['to'] : array( $d['to'] ) ) : array();
		$to  = array();
		foreach ( $raw as $addr ) {
			$addr = sanitize_email( (string) $addr );
			if ( $addr && is_email( $addr ) ) {
				$to[] = $addr;
			}
		}
		$to      = array_slice( array_values( array_unique( $to ) ), 0, 10 );
		$subject = vai_str( $d, 'subject', 300 );
		$text    = isset( $d['text'] ) && is_string( $d['text'] ) ? $d['text'] : '';
		$html    = isset( $d['html'] ) && is_string( $d['html'] ) ? $d['html'] : '';
		if ( ! $to || $subject === '' || ( $text === '' && $html === '' ) ) {
			return vai_error( 'invalid', 'to و subject ونص الرسالة مطلوبة', 400 );
		}
		$headers = array();
		$body    = $text;
		if ( $html !== '' ) {
			$headers[] = 'Content-Type: text/html; charset=UTF-8';
			$body      = $html;
		}
		$sent = wp_mail( $to, $subject, $body, $headers );
		return array(
			'ok'   => true,
			'sent' => (bool) $sent,
			'to'   => count( $to ),
		);
	}

	private static function op_admin_stats( $site, $d ) {
		$actor = self::bridge_actor( $site, $d );
		if ( is_wp_error( $actor ) ) {
			return $actor;
		}
		$days   = vai_int_in( $d, 'days', 7, 180, 30 );
		$today  = vai_riyadh( vai_now(), 'Y-m-d' );
		$first  = gmdate( 'Y-m-d', strtotime( $today . ' 00:00:00 UTC' ) - ( $days - 1 ) * 86400 );
		$since  = vai_riyadh_day_utc( $first );
		$series = self::stats_series( $first, $days, $since );
		$last   = $series ? $series[ count( $series ) - 1 ] : array();
		unset( $last['day'] );
		return array(
			'ok'           => true,
			'generated_at' => vai_now(),
			'tz'           => 'Asia/Riyadh',
			'days'         => $days,
			'totals'       => self::stats_totals(),
			'today'        => $last,
			'expiring'     => self::stats_expiring(),
			'series'       => $series,
			'per_site'     => self::stats_per_site( $since ),
			'mail'         => class_exists( 'VAI_Payments' ) ? VAI_Payments::queue_stats() : array( 'pending' => 0, 'sent' => 0, 'failed' => 0 ),
			'ai'           => self::stats_ai(),
		);
	}

	private static function stats_totals() {
		global $wpdb;
		$ct  = self::t( 'contacts' );
		$sql = 'SELECT COUNT(*) AS contacts'
			. ', SUM(CASE WHEN ' . self::sql_state( 'lead' ) . ' THEN 1 ELSE 0 END) AS leads'
			// accounts = members_active + members_expired + unpaid, always: someone who paid before confirming his e-mail is an account too
			. ', SUM(CASE WHEN (c.verified=1 OR c.is_member=1) THEN 1 ELSE 0 END) AS accounts'
			. ', SUM(CASE WHEN ' . self::sql_state( 'pending' ) . ' THEN 1 ELSE 0 END) AS pending_email'
			. ', SUM(CASE WHEN ' . self::sql_state( 'unpaid' ) . ' THEN 1 ELSE 0 END) AS unpaid'
			. ', SUM(CASE WHEN ' . self::sql_state( 'member' ) . ' THEN 1 ELSE 0 END) AS members_active'
			. ', SUM(CASE WHEN ' . self::sql_state( 'expired' ) . ' THEN 1 ELSE 0 END) AS members_expired'
			. ', SUM(CASE WHEN c.is_member=1 AND c.member_started_at IS NULL THEN 1 ELSE 0 END) AS members_no_expiry'
			. ", SUM(CASE WHEN c.role='admin' AND c.admin_verified=1 THEN 1 ELSE 0 END) AS admins"
			. ", SUM(CASE WHEN c.role='publisher' THEN 1 ELSE 0 END) AS publishers"
			// 2.19.0 (owner): how many investors / entrepreneurs / neutrals among the accounts.
			. ", SUM(CASE WHEN (c.verified=1 OR c.is_member=1) AND c.persona='investor' THEN 1 ELSE 0 END) AS persona_investor"
			. ", SUM(CASE WHEN (c.verified=1 OR c.is_member=1) AND c.persona='entrepreneur' THEN 1 ELSE 0 END) AS persona_entrepreneur"
			. ", SUM(CASE WHEN (c.verified=1 OR c.is_member=1) AND c.persona='neutral' THEN 1 ELSE 0 END) AS persona_neutral"
			. " FROM $ct c";
		$row = (array) $wpdb->get_row( $sql, ARRAY_A );
		$out = array();
		foreach ( array( 'contacts', 'leads', 'accounts', 'pending_email', 'unpaid', 'members_active', 'members_expired', 'members_no_expiry', 'admins', 'publishers', 'persona_investor', 'persona_entrepreneur', 'persona_neutral' ) as $k ) {
			$out[ $k ] = isset( $row[ $k ] ) ? (int) $row[ $k ] : 0;
		}
		return $out;
	}

	/** One row per Riyadh day (UTC+3), zero-filled, oldest first. */
	private static function stats_series( $first, $days, $since ) {
		global $wpdb;
		$keys = array( 'signups', 'verified', 'activations', 'renewals', 'payments_count', 'payments_cents', 'conversations', 'messages', 'leads' );
		$rows = array();
		for ( $i = 0; $i < $days; $i++ ) {
			$day          = gmdate( 'Y-m-d', strtotime( $first . ' 00:00:00 UTC' ) + $i * 86400 );
			$rows[ $day ] = array_merge( array( 'day' => $day ), array_fill_keys( $keys, 0 ) );
		}
		$et  = self::t( 'events' );
		$mt  = self::t( 'messages' );
		$lt  = self::t( 'leads' );
		$pt  = $wpdb->prefix . 'vai_payments';
		$day = 'DATE(DATE_ADD(created_at, INTERVAL 3 HOUR))';
		$rows = self::stats_fill( $rows, $wpdb->prepare( "SELECT $day AS d, SUM(CASE WHEN kind='registered' THEN 1 ELSE 0 END) AS signups, SUM(CASE WHEN kind='verified' THEN 1 ELSE 0 END) AS verified, SUM(CASE WHEN kind='activated' THEN 1 ELSE 0 END) AS activations, SUM(CASE WHEN kind='renewed' THEN 1 ELSE 0 END) AS renewals FROM $et WHERE created_at>=%s GROUP BY d", $since ), array( 'signups', 'verified', 'activations', 'renewals' ) );
		$rows = self::stats_fill( $rows, $wpdb->prepare( "SELECT $day AS d, COUNT(*) AS payments_count, SUM(amount_cents) AS payments_cents FROM $pt WHERE created_at>=%s AND success=1 GROUP BY d", $since ), array( 'payments_count', 'payments_cents' ) );
		$rows = self::stats_fill( $rows, $wpdb->prepare( "SELECT $day AS d, COUNT(DISTINCT CASE WHEN role='user' THEN contact_id END) AS conversations, SUM(CASE WHEN role IN ('user','assistant') THEN 1 ELSE 0 END) AS messages FROM $mt WHERE created_at>=%s GROUP BY d", $since ), array( 'conversations', 'messages' ) );
		$rows = self::stats_fill( $rows, $wpdb->prepare( "SELECT $day AS d, COUNT(*) AS leads FROM $lt WHERE created_at>=%s GROUP BY d", $since ), array( 'leads' ) );
		return array_values( $rows );
	}

	/** Copy the columns of one «GROUP BY day» query into the zero-filled series. */
	private static function stats_fill( array $rows, $sql, array $cols ) {
		global $wpdb;
		foreach ( (array) $wpdb->get_results( $sql, ARRAY_A ) as $r ) {
			$d = isset( $r['d'] ) ? (string) $r['d'] : '';
			if ( ! isset( $rows[ $d ] ) ) {
				continue;
			}
			foreach ( $cols as $k ) {
				$rows[ $d ][ $k ] = isset( $r[ $k ] ) ? (int) $r[ $k ] : 0;
			}
		}
		return $rows;
	}

	/** Active memberships that end within 7 / 30 days, and the soonest 20 of them. */
	private static function stats_expiring() {
		global $wpdb;
		$ct    = self::t( 'contacts' );
		$end   = self::sql_member_end();
		$where = "c.is_member=1 AND c.member_started_at IS NOT NULL AND $end>UTC_TIMESTAMP() AND $end<=DATE_ADD(UTC_TIMESTAMP(), INTERVAL 30 DAY)";
		$n     = (array) $wpdb->get_row( "SELECT COUNT(*) AS d30, SUM(CASE WHEN $end<=DATE_ADD(UTC_TIMESTAMP(), INTERVAL 7 DAY) THEN 1 ELSE 0 END) AS d7 FROM $ct c WHERE $where", ARRAY_A );
		$rows  = (array) $wpdb->get_results( "SELECT c.id, c.name, c.phone, c.phone_norm, c.email, $end AS ends FROM $ct c WHERE $where ORDER BY ends ASC, c.id ASC LIMIT 20" );
		$items = array();
		foreach ( $rows as $r ) {
			$items[] = array(
				'id'         => (int) $r->id,
				'name'       => (string) $r->name,
				'phone'      => vai_phone_local( $r->phone_norm ? $r->phone_norm : $r->phone ),
				'email'      => (string) $r->email,
				'member_end' => vai_riyadh( $r->ends, 'Y-m-d' ),
				'days_left'  => (int) ceil( ( strtotime( $r->ends . ' UTC' ) - time() ) / 86400 ),
			);
		}
		return array( 'd7' => isset( $n['d7'] ) ? (int) $n['d7'] : 0, 'd30' => isset( $n['d30'] ) ? (int) $n['d30'] : 0, 'items' => $items );
	}

	private static function stats_per_site( $since ) {
		global $wpdb;
		$mt   = self::t( 'messages' );
		$st   = self::t( 'sites' );
		$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT s.host, s.name, COUNT(DISTINCT CASE WHEN m.role='user' THEN m.contact_id END) AS conversations, SUM(CASE WHEN m.role IN ('user','assistant') THEN 1 ELSE 0 END) AS messages FROM $mt m LEFT JOIN $st s ON s.id=m.site_id WHERE m.created_at>=%s GROUP BY m.site_id, s.host, s.name ORDER BY conversations DESC", $since ) );
		$out  = array();
		foreach ( $rows as $r ) {
			$out[] = array( 'host' => (string) $r->host, 'name' => (string) $r->name, 'conversations' => (int) $r->conversations, 'messages' => (int) $r->messages );
		}
		return $out;
	}

	private static function stats_ai() {
		global $wpdb;
		$mt  = self::t( 'messages' );
		$ct  = self::t( 'contacts' );
		$day = vai_riyadh_day_start_utc();
		return array(
			'replies_today' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $mt WHERE role='assistant' AND created_at>=%s", $day ) ),
			'members_today' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT m.contact_id) FROM $mt m INNER JOIN $ct c ON c.id=m.contact_id WHERE m.role='assistant' AND m.created_at>=%s AND c.is_member=1", $day ) ),
		);
	}

	/* admin lists — contract 1.3 */

	private static function op_admin_accounts( $site, $d ) {
		global $wpdb;
		$actor = self::bridge_actor( $site, $d );
		if ( is_wp_error( $actor ) ) {
			return $actor;
		}
		$ct     = self::t( 'contacts' );
		$st     = self::t( 'sites' );
		$states = array( 'all', 'pending', 'unpaid', 'member', 'expired', 'admin', 'publisher', 'lead' );
		$state  = preg_replace( '/[^a-z]/', '', strtolower( vai_str( $d, 'state', 20 ) ) );
		$state  = in_array( $state, $states, true ) ? $state : 'all';
		list( $page, $per, $off ) = self::bridge_page( $d );
		list( $qs, $qa )          = self::where_contact_q( vai_str( $d, 'q', 100 ) );
		$base = self::sql_state( 'all' ) . $qs;
		$sum  = array();
		foreach ( $states as $k ) {
			$sum[] = 'SUM(CASE WHEN ' . self::sql_state( $k ) . ' THEN 1 ELSE 0 END) AS n_' . $k;
		}
		$crow   = (array) $wpdb->get_row( self::prep( 'SELECT ' . implode( ', ', $sum ) . " FROM $ct c WHERE $base", $qa ), ARRAY_A );
		$counts = array();
		foreach ( $states as $k ) {
			$counts[ $k ] = isset( $crow[ 'n_' . $k ] ) ? (int) $crow[ 'n_' . $k ] : 0;
		}
		$sql  = "SELECT c.*, s.host AS site_host FROM $ct c LEFT JOIN $st s ON s.id=c.last_site_id WHERE " . self::sql_state( $state ) . " AND $base ORDER BY c.last_at DESC, c.id DESC LIMIT %d OFFSET %d";
		$rows = (array) $wpdb->get_results( $wpdb->prepare( $sql, array_merge( $qa, array( $per, $off ) ) ) );
		return array( 'ok' => true, 'total' => $counts[ $state ], 'page' => $page, 'per_page' => $per, 'counts' => $counts, 'items' => self::account_rows( $rows ) );
	}

	private static function op_admin_member( $site, $d ) {
		global $wpdb;
		$actor = self::bridge_actor( $site, $d );
		if ( is_wp_error( $actor ) ) {
			return $actor;
		}
		$c = self::contact_with_site( isset( $d['contact_id'] ) ? (int) $d['contact_id'] : 0 );
		if ( ! $c ) {
			return vai_error( 'no_contact', 'الحساب غير موجود', 404 );
		}
		$accounts = self::account_rows( array( $c ) );
		$sites    = json_decode( (string) $c->sites, true );
		$lt       = self::t( 'leads' );
		$st       = self::t( 'sites' );
		$leads    = (array) $wpdb->get_results( $wpdb->prepare( "SELECT l.*, s.host AS site_host FROM $lt l LEFT JOIN $st s ON s.id=l.site_id WHERE l.contact_id=%d ORDER BY l.id DESC LIMIT 50", $c->id ) );
		return array(
			'ok'       => true,
			'account'  => $accounts[0],
			'memo'     => (string) $c->memo,
			'notes'    => (string) $c->notes,
			'sites'    => is_array( $sites ) ? array_values( $sites ) : array(),
			'payments' => array_map( array( __CLASS__, 'payment_row' ), self::rows_of_person( $wpdb->prefix . 'vai_payments', $c ) ),
			'tickets'  => array_map( array( __CLASS__, 'ticket_row' ), self::rows_of_person( $wpdb->prefix . 'vai_tickets', $c ) ),
			'leads'    => self::lead_rows( $leads, array( (int) $c->id => $c ) ),
			'events'   => self::event_rows( $c->id ),
		);
	}

	/** Last 50 rows of a payments-like table (contact_id, email, phone) that belong to this person. */
	private static function rows_of_person( $table, $c ) {
		global $wpdb;
		$where = array( 'contact_id=%d' );
		$args  = array( (int) $c->id );
		if ( $c->email !== '' ) {
			$where[] = 'email=%s';
			$args[]  = (string) $c->email;
		}
		if ( $c->phone_norm !== '' ) {
			$where[] = 'phone=%s';
			$args[]  = vai_phone_local( $c->phone_norm );
		}
		return (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table WHERE (" . implode( ' OR ', $where ) . ') ORDER BY id DESC LIMIT 50', $args ) );
	}

	/** Shape «Payment». */
	public static function payment_row( $r ) {
		return array(
			'id'           => (int) $r->id,
			'txn_id'       => (string) $r->txn_id,
			'order_id'     => (string) $r->order_id,
			'amount_cents' => (int) $r->amount_cents,
			'currency'     => (string) $r->currency,
			'success'      => (int) $r->success ? 1 : 0,
			'action'       => (string) $r->action,
			'name'         => (string) $r->name,
			'phone'        => (string) $r->phone,
			'email'        => (string) $r->email,
			'contact_id'   => (int) $r->contact_id,
			'note'         => (string) $r->note,
			'created_at'   => (string) $r->created_at,
		);
	}

	/** Shape «Ticket». */
	public static function ticket_row( $r ) {
		return array(
			'id'          => (int) $r->id,
			'ref'         => (string) $r->ref,
			'contact_id'  => (int) $r->contact_id,
			'name'        => (string) $r->name,
			'phone'       => (string) $r->phone,
			'email'       => (string) $r->email,
			'event_title' => (string) $r->event_title,
			'event_date'  => (string) $r->event_date,
			'event_place' => (string) $r->event_place,
			'source'      => (string) $r->source,
			'checked_in'  => (int) $r->checked_in ? 1 : 0,
			'created_at'  => (string) $r->created_at,
		);
	}

	/** Shape «Lead» for lead rows (site_host joined); $contacts = contact_id => contact row, intent computed in bulk. */
	private static function lead_rows( array $leads, array $contacts ) {
		$types = self::bulk_lead_types( array_keys( $contacts ) );
		$out   = array();
		foreach ( $leads as $l ) {
			$cid   = (int) $l->contact_id;
			$c     = isset( $contacts[ $cid ] ) ? $contacts[ $cid ] : null;
			$score = $c ? self::intent_calc( $c, isset( $types[ $cid ] ) ? $types[ $cid ] : array() ) : 0;
			$out[] = array(
				'id'           => (int) $l->id,
				'contact_id'   => $cid,
				'name'         => $c ? (string) $c->name : '',
				'phone'        => $c ? vai_phone_local( $c->phone_norm ? $c->phone_norm : $c->phone ) : '',
				'site'         => isset( $l->site_host ) ? (string) $l->site_host : '',
				'ltype'        => (string) $l->ltype,
				'reason'       => (string) $l->reason,
				'company'      => (string) $l->company,
				'notes'        => (string) $l->notes,
				'status'       => (string) $l->status,
				'intent'       => $score,
				'intent_label' => self::intent_label( $score ),
				'created_at'   => (string) $l->created_at,
			);
		}
		return $out;
	}

	/** Shape «Event»: last 50 history rows of a contact, newest first, with the acting admin's name. */
	private static function event_rows( $contact_id ) {
		global $wpdb;
		$et   = self::t( 'events' );
		$ct   = self::t( 'contacts' );
		$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT e.*, a.name AS actor_name FROM $et e LEFT JOIN $ct a ON a.id=e.actor_id AND e.actor_id>0 WHERE e.contact_id=%d ORDER BY e.created_at DESC, e.id DESC LIMIT 50", (int) $contact_id ) );
		return array_map( array( __CLASS__, 'event_row' ), $rows );
	}

	public static function event_row( $e ) {
		return array(
			'id'         => (int) $e->id,
			'contact_id' => (int) $e->contact_id,
			'kind'       => (string) $e->kind,
			'days'       => (int) $e->days,
			'source'     => (string) $e->source,
			'ref'        => (string) $e->ref,
			'actor_id'   => (int) $e->actor_id,
			'actor_name' => isset( $e->actor_name ) ? (string) $e->actor_name : '',
			'note'       => (string) $e->note,
			'created_at' => (string) $e->created_at,
		);
	}

	private static function op_admin_payments( $site, $d ) {
		global $wpdb;
		$actor = self::bridge_actor( $site, $d );
		if ( is_wp_error( $actor ) ) {
			return $actor;
		}
		$pt    = $wpdb->prefix . 'vai_payments';
		$where = '1=1';
		$args  = array();
		$status = vai_str( $d, 'status', 10 );
		if ( $status === 'ok' || $status === 'failed' ) {
			$where .= $status === 'ok' ? ' AND success=1' : ' AND success=0';
		}
		$action = preg_replace( '/[^a-z0-9_]/', '', strtolower( vai_str( $d, 'action', 30 ) ) );
		if ( $action !== '' && $action !== 'all' ) {
			$where .= ' AND action=%s';
			$args[] = $action;
		}
		$q = vai_str( $d, 'q', 100 );
		if ( $q !== '' ) {
			$like   = '%' . $wpdb->esc_like( $q ) . '%';
			$where .= ' AND (name LIKE %s OR phone LIKE %s OR email LIKE %s OR txn_id LIKE %s OR order_id LIKE %s OR note LIKE %s)';
			array_push( $args, $like, $like, $like, $like, $like, $like );
		}
		list( $page, $per, $off ) = self::bridge_page( $d );
		$tot  = (array) $wpdb->get_row( self::prep( "SELECT COUNT(*) AS n, SUM(CASE WHEN success=1 THEN amount_cents ELSE 0 END) AS cents FROM $pt WHERE $where", $args ), ARRAY_A );
		$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $pt WHERE $where ORDER BY id DESC LIMIT %d OFFSET %d", array_merge( $args, array( $per, $off ) ) ) );
		return array( 'ok' => true, 'total' => isset( $tot['n'] ) ? (int) $tot['n'] : 0, 'sum_cents_ok' => isset( $tot['cents'] ) ? (int) $tot['cents'] : 0, 'page' => $page, 'per_page' => $per, 'items' => array_map( array( __CLASS__, 'payment_row' ), $rows ) );
	}

	private static function op_admin_tickets( $site, $d ) {
		global $wpdb;
		$actor = self::bridge_actor( $site, $d );
		if ( is_wp_error( $actor ) ) {
			return $actor;
		}
		$tt    = $wpdb->prefix . 'vai_tickets';
		$where = '1=1';
		$args  = array();
		$q     = vai_str( $d, 'q', 100 );
		if ( $q !== '' ) {
			$like   = '%' . $wpdb->esc_like( $q ) . '%';
			$where .= ' AND (ref LIKE %s OR name LIKE %s OR phone LIKE %s OR email LIKE %s OR event_title LIKE %s)';
			array_push( $args, $like, $like, $like, $like, $like );
		}
		list( $page, $per, $off ) = self::bridge_page( $d );
		$total = (int) $wpdb->get_var( self::prep( "SELECT COUNT(*) FROM $tt WHERE $where", $args ) );
		$rows  = (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $tt WHERE $where ORDER BY id DESC LIMIT %d OFFSET %d", array_merge( $args, array( $per, $off ) ) ) );
		return array( 'ok' => true, 'total' => $total, 'page' => $page, 'per_page' => $per, 'items' => array_map( array( __CLASS__, 'ticket_row' ), $rows ) );
	}

	private static function op_admin_leads( $site, $d ) {
		global $wpdb;
		$actor = self::bridge_actor( $site, $d );
		if ( is_wp_error( $actor ) ) {
			return $actor;
		}
		$lt    = self::t( 'leads' );
		$ct    = self::t( 'contacts' );
		$st    = self::t( 'sites' );
		$where = '1=1';
		$args  = array();
		$ltype = preg_replace( '/[^a-z_]/', '', strtolower( vai_str( $d, 'ltype', 40 ) ) );
		if ( $ltype !== '' && $ltype !== 'all' ) {
			$where .= ' AND l.ltype=%s';
			$args[] = $ltype;
		}
		$q = vai_str( $d, 'q', 100 );
		if ( $q !== '' ) {
			$like   = '%' . $wpdb->esc_like( $q ) . '%';
			$where .= ' AND (c.name LIKE %s OR c.phone LIKE %s OR c.email LIKE %s OR l.reason LIKE %s OR l.company LIKE %s OR l.notes LIKE %s)';
			array_push( $args, $like, $like, $like, $like, $like, $like );
		}
		list( $page, $per, $off ) = self::bridge_page( $d );
		$from  = "$lt l LEFT JOIN $ct c ON c.id=l.contact_id LEFT JOIN $st s ON s.id=l.site_id";
		$total = (int) $wpdb->get_var( self::prep( "SELECT COUNT(*) FROM $from WHERE $where", $args ) );
		$leads = (array) $wpdb->get_results( $wpdb->prepare( "SELECT l.*, s.host AS site_host FROM $from WHERE $where ORDER BY l.id DESC LIMIT %d OFFSET %d", array_merge( $args, array( $per, $off ) ) ) );
		$ids   = array();
		foreach ( $leads as $l ) {
			$ids[] = (int) $l->contact_id;
		}
		return array( 'ok' => true, 'total' => $total, 'page' => $page, 'per_page' => $per, 'items' => self::lead_rows( $leads, self::contacts_by_id( $ids ) ) );
	}

	private static function op_admin_threads( $site, $d ) {
		global $wpdb;
		$actor = self::bridge_actor( $site, $d );
		if ( is_wp_error( $actor ) ) {
			return $actor;
		}
		$ct     = self::t( 'contacts' );
		$mt     = self::t( 'messages' );
		$st     = self::t( 'sites' );
		$unread = "EXISTS (SELECT 1 FROM $mt u WHERE u.contact_id=c.id AND u.role='user' AND u.id>c.admin_seen_id)";
		$where  = 'c.msg_count>0';
		$filter = vai_str( $d, 'filter', 12 );
		if ( $filter === 'waiting' ) {
			$where .= ' AND c.awaiting_since IS NOT NULL';
		} elseif ( $filter === 'human' ) {
			$where .= ' AND c.human_until IS NOT NULL AND c.human_until>UTC_TIMESTAMP()';
		} elseif ( $filter === 'unread' ) {
			$where .= ' AND ' . $unread;
		}
		list( $qs, $qa )          = self::where_contact_q( vai_str( $d, 'q', 100 ) );
		list( $page, $per, $off ) = self::bridge_page( $d );
		$total = (int) $wpdb->get_var( self::prep( "SELECT COUNT(*) FROM $ct c WHERE $where$qs", $qa ) );
		$rows  = (array) $wpdb->get_results( $wpdb->prepare( "SELECT c.*, s.host AS site_host, ($unread) AS is_unread FROM $ct c LEFT JOIN $st s ON s.id=c.last_site_id WHERE $where$qs ORDER BY c.last_at DESC, c.id DESC LIMIT %d OFFSET %d", array_merge( $qa, array( $per, $off ) ) ) );
		$ids   = array();
		foreach ( $rows as $r ) {
			$ids[] = (int) $r->id;
		}
		$last  = self::bulk_last_messages( $ids );
		$types = self::bulk_lead_types( $ids );
		$items = array();
		foreach ( $rows as $r ) {
			$id      = (int) $r->id;
			$score   = self::intent_calc( $r, isset( $types[ $id ] ) ? $types[ $id ] : array() );
			$items[] = array(
				'contact_id'   => $id,
				'name'         => (string) $r->name,
				'phone'        => vai_phone_local( $r->phone_norm ? $r->phone_norm : $r->phone ),
				'site'         => (string) $r->site_host,
				'last_text'    => isset( $last[ $id ] ) ? vai_clip( $last[ $id ]['content'], 140 ) : '',
				'last_role'    => isset( $last[ $id ] ) ? $last[ $id ]['role'] : '',
				'last_at'      => (string) $r->last_at,
				'unread'       => (int) $r->is_unread ? 1 : 0,
				'waiting'      => ! empty( $r->awaiting_since ) ? 1 : 0,
				'human'        => ( ! empty( $r->human_until ) && strtotime( $r->human_until . ' UTC' ) > time() ) ? 1 : 0,
				'is_member'    => self::member_active( $r ) ? 1 : 0,
				'intent'       => $score,
				'intent_label' => self::intent_label( $score ),
			);
		}
		return array( 'ok' => true, 'total' => $total, 'page' => $page, 'per_page' => $per, 'items' => $items );
	}

	/** contact_id => array( role, content ) of the last visible message, one query for the whole page. */
	private static function bulk_last_messages( array $ids ) {
		global $wpdb;
		$out = array();
		$ids = self::clean_ids( $ids );
		if ( ! $ids ) {
			return $out;
		}
		$mt   = self::t( 'messages' );
		$ph   = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT m.contact_id, m.role, m.content FROM $mt m INNER JOIN (SELECT MAX(id) AS mid FROM $mt WHERE contact_id IN ($ph) AND role IN ('user','assistant','human') GROUP BY contact_id) x ON x.mid=m.id", $ids ) );
		foreach ( $rows as $r ) {
			$out[ (int) $r->contact_id ] = array( 'role' => (string) $r->role, 'content' => (string) $r->content );
		}
		return $out;
	}

	/** One conversation, 40 messages per page, oldest first; «before» = the oldest message id already shown. */
	private static function op_admin_thread( $site, $d ) {
		global $wpdb;
		$actor = self::bridge_actor( $site, $d );
		if ( is_wp_error( $actor ) ) {
			return $actor;
		}
		$c = self::contact_with_site( isset( $d['contact_id'] ) ? (int) $d['contact_id'] : 0 );
		if ( ! $c ) {
			return vai_error( 'no_contact', 'المحادثة غير موجودة', 404 );
		}
		$mt     = self::t( 'messages' );
		$before = isset( $d['before'] ) ? (int) $d['before'] : 0;
		$sql    = "SELECT id, role, content, page_url, meta, created_at FROM $mt WHERE contact_id=%d" . ( $before > 0 ? ' AND id<%d' : '' ) . ' ORDER BY id DESC LIMIT 41';
		$rows   = (array) $wpdb->get_results( $wpdb->prepare( $sql, $before > 0 ? array( $c->id, $before ) : array( $c->id ) ) );
		$more   = count( $rows ) > 40;
		$msgs   = array();
		$max    = (int) $c->admin_seen_id;
		foreach ( array_reverse( array_slice( $rows, 0, 40 ) ) as $r ) {
			$meta   = $r->meta ? json_decode( $r->meta, true ) : array();
			$msgs[] = array(
				'id'       => (int) $r->id,
				'role'     => (string) $r->role,
				'content'  => (string) $r->content,
				'by'       => is_array( $meta ) && ! empty( $meta['by'] ) ? (string) $meta['by'] : '',
				'page_url' => (string) $r->page_url,
				'at'       => (string) $r->created_at,
			);
			$max    = max( $max, (int) $r->id );
		}
		if ( $before <= 0 && $max > (int) $c->admin_seen_id ) {
			$wpdb->update( self::t( 'contacts' ), array( 'admin_seen_id' => $max ), array( 'id' => $c->id ) ); // opening the latest page marks it read, like the console
		}
		$accounts = self::account_rows( array( $c ) );
		return array( 'ok' => true, 'account' => $accounts[0], 'messages' => $msgs, 'has_more' => $more );
	}

	/** A staff reply from the app dashboard, signed with the admin's own name — the same path as the console's «send». */
	private static function op_admin_reply( $site, $d ) {
		$actor = self::bridge_actor( $site, $d );
		if ( is_wp_error( $actor ) ) {
			return $actor;
		}
		$c    = self::contact( isset( $d['contact_id'] ) ? (int) $d['contact_id'] : 0 );
		$text = vai_text_ok( $d, 'text', 3000 );
		if ( ! $c || $text === '' ) {
			return vai_error( 'invalid', 'بيانات ناقصة' );
		}
		return array( 'ok' => true, 'message_id' => self::staff_send( $c, $text, (string) $actor->name ) );
	}

	/** Mail queue: counters and the last 50 rows — never the body. */
	private static function op_admin_mail( $site, $d ) {
		global $wpdb;
		$actor = self::bridge_actor( $site, $d );
		if ( is_wp_error( $actor ) ) {
			return $actor;
		}
		if ( ! class_exists( 'VAI_Payments' ) ) {
			return array( 'ok' => true, 'stats' => array( 'pending' => 0, 'sent' => 0, 'failed' => 0 ), 'items' => array() );
		}
		$rows  = (array) $wpdb->get_results( 'SELECT id, to_email, subject, kind, status, attempts, created_at, sent_at FROM ' . VAI_Payments::table() . ' ORDER BY id DESC LIMIT 50' );
		$items = array();
		foreach ( $rows as $r ) {
			$items[] = array( 'id' => (int) $r->id, 'to_email' => (string) $r->to_email, 'subject' => (string) $r->subject, 'kind' => (string) $r->kind, 'status' => (string) $r->status, 'attempts' => (int) $r->attempts, 'created_at' => (string) $r->created_at, 'sent_at' => (string) $r->sent_at );
		}
		return array( 'ok' => true, 'stats' => VAI_Payments::queue_stats(), 'items' => $items );
	}

	/** Membership from the app dashboard: activate | extend | revoke, audited in vai_events (source admin, actor_id). */
	private static function op_admin_grant( $site, $d ) {
		global $wpdb;
		$actor = self::bridge_actor( $site, $d );
		if ( is_wp_error( $actor ) ) {
			return $actor;
		}
		$c      = self::contact( isset( $d['contact_id'] ) ? (int) $d['contact_id'] : 0 );
		$action = vai_str( $d, 'action', 10 );
		if ( ! $c || ! in_array( $action, array( 'activate', 'extend', 'revoke' ), true ) ) {
			return vai_error( 'invalid', 'بيانات ناقصة' );
		}
		$days = vai_int_in( $d, 'days', 1, 3660, (int) vai_cfg( 'member_days' ) );
		$res  = self::member_change( $c->id, $action, $days, 'admin', '', (int) $actor->id, vai_str( $d, 'note', 250 ) );
		if ( ! $res ) {
			return vai_error( 'no_contact', 'الحساب غير موجود', 404 );
		}
		if ( empty( $res['ok'] ) ) {
			return vai_error( 'db_error', 'تعذّر حفظ العضوية الآن — أعد المحاولة', 500 );
		}
		$et    = self::t( 'events' );
		$ct    = self::t( 'contacts' );
		$event = $res['event_id'] ? $wpdb->get_row( $wpdb->prepare( "SELECT e.*, a.name AS actor_name FROM $et e LEFT JOIN $ct a ON a.id=e.actor_id WHERE e.id=%d", (int) $res['event_id'] ) ) : null;
		return array( 'ok' => true, 'contact' => self::public_contact( self::contact( $c->id ) ), 'event' => $event ? self::event_row( $event ) : null );
	}

	/** member ↔ publisher from the app dashboard (admin promotion stays on the hub page, it has its own code step). */
	private static function op_admin_set_role( $site, $d ) {
		$actor = self::bridge_actor( $site, $d );
		if ( is_wp_error( $actor ) ) {
			return $actor;
		}
		$res = self::set_role( isset( $d['contact_id'] ) ? (int) $d['contact_id'] : 0, vai_str( $d, 'role', 12 ), 'admin', (int) $actor->id );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		return array( 'ok' => true, 'contact' => self::public_contact( $res ) );
	}

	/* one brain: changes / publish / feed */

	/**
	 * What is new on the websites since a knowledge id. since_id 0 = the latest 30. Team notes and AI self-notes are never
	 * returned; the catalog rows and the app's own posts only when asked for by kind.
	 */
	private static function op_changes( $site, $d ) {
		global $wpdb;
		$kt    = self::t( 'knowledge' );
		$st    = self::t( 'sites' );
		$since = isset( $d['since_id'] ) ? max( 0, (int) $d['since_id'] ) : 0;
		$limit = vai_int_in( $d, 'limit', 1, 100, 30 );
		$asked = ( isset( $d['kinds'] ) && is_array( $d['kinds'] ) ) ? $d['kinds'] : array();
		$kinds = array();
		foreach ( $asked as $k ) {
			$k = is_string( $k ) ? preg_replace( '/[^a-z_]/', '', strtolower( $k ) ) : '';
			if ( $k !== '' && $k !== 'note' ) {
				$kinds[] = $k;
			}
		}
		$kinds = array_slice( array_values( array_unique( $kinds ) ), 0, 20 );
		if ( $kinds ) {
			$where = 'k.kind IN (' . implode( ',', array_fill( 0, count( $kinds ), '%s' ) ) . ')';
			$args  = $kinds;
		} else {
			$where = "k.kind NOT IN ('note','faq','service','app_post','app_event')";
			$args  = array();
		}
		if ( $since > 0 ) {
			$sql  = "SELECT k.id, k.url, k.title, k.kind, k.content, k.updated_at, s.host, s.name FROM $kt k LEFT JOIN $st s ON s.id=k.site_id WHERE $where AND k.id>%d ORDER BY k.id ASC LIMIT %d";
			$rows = (array) $wpdb->get_results( $wpdb->prepare( $sql, array_merge( $args, array( $since, $limit ) ) ) );
		} else {
			$sql  = "SELECT k.id, k.url, k.title, k.kind, k.content, k.updated_at, s.host, s.name FROM $kt k LEFT JOIN $st s ON s.id=k.site_id WHERE $where ORDER BY k.id DESC LIMIT %d";
			$rows = array_reverse( (array) $wpdb->get_results( $wpdb->prepare( $sql, array_merge( $args, array( min( 30, $limit ) ) ) ) ) );
		}
		$cursor = $since;
		$items  = array();
		foreach ( $rows as $r ) {
			$cursor  = max( $cursor, (int) $r->id );
			$items[] = array(
				'id'         => (int) $r->id,
				'host'       => (string) $r->host,
				'site'       => (string) $r->name,
				'url'        => (string) $r->url,
				'title'      => (string) $r->title,
				'kind'       => (string) $r->kind,
				'excerpt'    => vai_clip( (string) $r->content, 300 ),
				'updated_at' => (string) $r->updated_at,
			);
		}
		return array( 'ok' => true, 'cursor' => $cursor, 'items' => $items );
	}

	/**
	 * The app publishes (or edits, or removes) a post / event: it becomes a knowledge row of the calling site at once, so
	 * the assistant knows it on every website, and a public card for feed / [vai_feed]. Admins and publishers only.
	 */
	private static function op_publish( $site, $d ) {
		global $wpdb;
		$actor = self::bridge_actor( $site, $d, array( 'admin', 'publisher' ) );
		if ( is_wp_error( $actor ) ) {
			return $actor;
		}
		$key = substr( preg_replace( '/[^A-Za-z0-9_\-]/', '', vai_str( $d, 'key', 80 ) ), 0, 64 );
		if ( $key === '' ) {
			return vai_error( 'invalid', 'معرّف المنشور مطلوب' );
		}
		$kt  = self::t( 'knowledge' );
		$ft  = self::t( 'feed' );
		$url = 'app://posts/' . $key;
		$uh  = md5( $url );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT id, hash FROM $kt WHERE site_id=%d AND url_hash=%s", $site->id, $uh ) );
		if ( ! empty( $d['remove'] ) ) {
			$wpdb->delete( $kt, array( 'site_id' => $site->id, 'url_hash' => $uh ) );
			$wpdb->delete( $ft, array( 'site_id' => $site->id, 'pkey' => $key ) );
			self::publish_done( $site );
			return array( 'ok' => true, 'id' => $row ? (int) $row->id : 0, 'removed' => true );
		}
		$card = self::publish_card( $d );
		if ( is_wp_error( $card ) ) {
			return $card;
		}
		$text = $card['content'] . self::publish_facts( $card );
		$data = array( 'site_id' => $site->id, 'url' => $url, 'url_hash' => $uh, 'title' => $card['title'], 'content' => $text, 'content_norm' => vai_norm_text( $card['title'] . ' ' . $text ), 'kind' => $card['kind'] === 'event' ? 'app_event' : 'app_post', 'hash' => md5( $card['title'] . '|' . $text ), 'sync_id' => '', 'updated_at' => vai_now() );
		$kid = self::knowledge_put( $row, $data, ! $row || $row->hash !== $data['hash'] );
		if ( ! $kid ) {
			return vai_error( 'db_error', 'تعذّر حفظ المنشور الآن — أعد المحاولة', 500 );
		}
		self::publish_feed_row( $site, $key, $card, $kid, (int) $actor->id );
		self::publish_done( $site );
		return array( 'ok' => true, 'id' => $kid );
	}

	/** Validate and clean the body of publish → array( kind, title, content, url, image, date, place, online ) or WP_Error. */
	private static function publish_card( $d ) {
		// Plain text only: the card is public (feed, [vai_feed] on every site, the app), whatever the renderer escapes.
		$title   = vai_clip( wp_strip_all_tags( vai_text_ok( $d, 'title', 600 ) ), 300 );
		$content = trim( wp_strip_all_tags( vai_text_ok( $d, 'content', 20000 ) ) );
		if ( $title === '' ) {
			return vai_error( 'invalid', 'عنوان المنشور مطلوب' );
		}
		$ev   = isset( $d['event'] ) && is_array( $d['event'] ) ? $d['event'] : array();
		$http = array( 'http', 'https' );
		return array(
			'kind'    => vai_str( $d, 'kind', 10 ) === 'event' ? 'event' : 'post',
			'title'   => $title,
			'content' => $content,
			'url'     => esc_url_raw( vai_str( $d, 'url', 600 ), $http ),
			'image'   => esc_url_raw( vai_str( $d, 'image', 600 ), $http ),
			'date'    => vai_clip( wp_strip_all_tags( vai_text_ok( $ev, 'date', 80 ) ), 40 ),
			'place'   => vai_clip( wp_strip_all_tags( vai_text_ok( $ev, 'place', 400 ) ), 190 ),
			'online'  => esc_url_raw( vai_str( $ev, 'online_url', 600 ), $http ),
		);
	}

	/** The facts the assistant needs beside the text: when, where, and the public link. */
	private static function publish_facts( $card ) {
		$lines = array();
		if ( $card['kind'] === 'event' ) {
			if ( $card['date'] !== '' ) {
				$lines[] = 'الموعد: ' . $card['date'];
			}
			if ( $card['place'] !== '' ) {
				$lines[] = 'المكان: ' . $card['place'];
			}
			if ( $card['online'] !== '' ) {
				$lines[] = 'رابط الحضور عن بُعد: ' . $card['online'];
			}
		}
		if ( $card['url'] !== '' ) {
			$lines[] = 'الرابط: ' . $card['url'];
		}
		return $lines ? "\n\n" . implode( "\n", $lines ) : '';
	}

	private static function publish_feed_row( $site, $key, $card, $knowledge_id, $author_id ) {
		global $wpdb;
		$ft   = self::t( 'feed' );
		$now  = vai_now();
		$data = array( 'kind' => $card['kind'], 'title' => $card['title'], 'excerpt' => vai_clip( $card['content'], 300 ), 'url' => $card['url'], 'image' => $card['image'], 'event_date' => $card['date'], 'event_place' => $card['place'], 'event_online' => $card['online'], 'knowledge_id' => (int) $knowledge_id, 'author_id' => (int) $author_id, 'updated_at' => $now );
		$id   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $ft WHERE site_id=%d AND pkey=%s", $site->id, $key ) );
		if ( $id ) {
			$wpdb->update( $ft, $data, array( 'id' => $id ) );
			return;
		}
		$wpdb->insert( $ft, array_merge( $data, array( 'site_id' => (int) $site->id, 'pkey' => $key, 'created_at' => $now ) ) );
	}

	/** After a publish / remove: fresh counters, fresh feed cache, and knowledge.changed for the app server. */
	private static function publish_done( $site ) {
		global $wpdb;
		$kt = self::t( 'knowledge' );
		$wpdb->update( self::t( 'sites' ), array( 'knowledge_count' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $kt WHERE site_id=%d", $site->id ) ) ), array( 'id' => $site->id ) );
		foreach ( array( 'all', 'post', 'event' ) as $k ) {
			delete_transient( 'vai_feed_' . $k );
		}
		self::knowledge_changed( $site, 1 );
	}

	/** Public, read-only, cached 60 s: the cards every site shows through [vai_feed]. kind: post | event | (empty = both). */
	private static function op_feed( $site, $d ) {
		$kind  = vai_str( $d, 'kind', 10 );
		$kind  = in_array( $kind, array( 'post', 'event' ), true ) ? $kind : 'all';
		$limit = vai_int_in( $d, 'limit', 1, 12, 6 );
		$items = get_transient( 'vai_feed_' . $kind );
		if ( ! is_array( $items ) ) {
			$items = self::feed_items( $kind );
			set_transient( 'vai_feed_' . $kind, $items, 60 );
		}
		return array( 'ok' => true, 'items' => array_slice( $items, 0, $limit ) );
	}

	/** The newest 12 cards of a kind (the cache holds 12, feed slices to its limit). */
	private static function feed_items( $kind ) {
		global $wpdb;
		$ft   = self::t( 'feed' );
		$rows = $kind === 'all'
			? (array) $wpdb->get_results( "SELECT * FROM $ft ORDER BY created_at DESC, id DESC LIMIT 12" )
			: (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $ft WHERE kind=%s ORDER BY created_at DESC, id DESC LIMIT 12", $kind ) );
		$out  = array();
		foreach ( $rows as $r ) {
			$out[] = array(
				'key'     => (string) $r->pkey,
				'kind'    => (string) $r->kind,
				'title'   => (string) $r->title,
				'excerpt' => (string) $r->excerpt,
				'url'     => (string) $r->url,
				'image'   => (string) $r->image,
				'event'   => $r->kind === 'event' ? array( 'date' => (string) $r->event_date, 'place' => (string) $r->event_place, 'online_url' => (string) $r->event_online ) : null,
				'at'      => (string) $r->created_at,
			);
		}
		return $out;
	}

	/** contact_id => contact row, one query. */
	private static function contacts_by_id( array $ids ) {
		global $wpdb;
		$out = array();
		$ids = self::clean_ids( $ids );
		if ( ! $ids ) {
			return $out;
		}
		$ct = self::t( 'contacts' );
		$ph = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $ct WHERE id IN ($ph)", $ids ) ) as $c ) {
			$out[ (int) $c->id ] = $c;
		}
		return $out;
	}

	/** One contact with its site host, as account_row() expects it. */
	private static function contact_with_site( $id ) {
		global $wpdb;
		$ct = self::t( 'contacts' );
		$st = self::t( 'sites' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT c.*, s.host AS site_host FROM $ct c LEFT JOIN $st s ON s.id=c.last_site_id WHERE c.id=%d", (int) $id ) );
	}

	/* ───────────── periodic digest e-mail ───────────── */

	/** Heuristic seriousness score 0–9 for daily sorting (who is worth a call). */
	public static function intent_score( $c ) {
		global $wpdb;
		if ( (int) $c->is_member ) {
			return 9;
		}
		$lt    = self::t( 'leads' );
		$types = (array) $wpdb->get_col( $wpdb->prepare( "SELECT ltype FROM $lt WHERE contact_id=%d", $c->id ) );
		return self::intent_calc( $c, $types );
	}

	/** The score itself, from lead types fetched by the caller (list ops fetch them for the whole page in one query). */
	private static function intent_calc( $c, array $types ) {
		$s = 0;
		if ( (int) $c->is_member ) {
			return 9;
		}
		foreach ( $types as $t ) {
			$s += array( 'payment' => 4, 'partner' => 3, 'membership' => 3, 'service' => 2, 'cooperation' => 2, 'owner' => 1, 'management' => 1 )[ $t ] ?? 0;
		}
		if ( ! empty( $c->pass_hash ) ) {
			$s += 1;
		}
		if ( (int) $c->msg_count >= 6 ) {
			$s += 1;
		}
		if ( (int) $c->msg_count >= 14 ) {
			$s += 1;
		}
		if ( $c->persona === 'investor' ) {
			$s += 1;
		}
		$memo = vai_norm_text( (string) $c->memo );
		$hits = 0;
		foreach ( array( 'اشترك', 'يدفع', 'الدفع', 'مستعد', 'جاد', 'راس مال', 'رأس مال', 'حصه', 'يبغى شراكه', 'يبي شراكه', 'مهتم بالعضويه', 'موافق' ) as $w ) {
			if ( strpos( $memo, vai_norm_text( $w ) ) !== false ) {
				$hits++;
			}
		}
		$s += min( 3, $hits );
		return min( 9, $s );
	}

	public static function intent_label( $score ) {
		if ( $score >= 6 ) {
			return '🔥 جاد جدًا';
		}
		if ( $score >= 4 ) {
			return '👍 مهتم';
		}
		if ( $score >= 2 ) {
			return '🙂 يستكشف';
		}
		return '⚪ بارد';
	}

	public static function digest_data( $hours ) {
		global $wpdb;
		$ct    = self::t( 'contacts' );
		$mt    = self::t( 'messages' );
		$st    = self::t( 'sites' );
		$lt    = self::t( 'leads' );
		$since = gmdate( 'Y-m-d H:i:s', time() - max( 1, (int) $hours ) * 3600 );
		$d     = array( 'since' => $since, 'hours' => (int) $hours );
		$adm               = "(SELECT id FROM $ct WHERE role='admin' AND admin_verified=1)";
		$d['chats']        = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT contact_id) FROM $mt WHERE role='user' AND created_at>=%s AND contact_id NOT IN $adm", $since ) );
		$d['messages']     = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $mt WHERE role='user' AND created_at>=%s AND contact_id NOT IN $adm", $since ) );
		$d['sites']        = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT site_id) FROM $mt WHERE role='user' AND created_at>=%s AND contact_id NOT IN $adm", $since ) );
		$d['new_contacts'] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $ct WHERE created_at>=%s AND msg_count>0", $since ) );
		$d['registered']   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $ct WHERE pass_hash<>'' AND trial_started_at>=%s", $since ) );
		$d['leads']        = (array) $wpdb->get_results( $wpdb->prepare( "SELECT ltype, COUNT(*) n FROM $lt WHERE created_at>=%s GROUP BY ltype", $since ) );
		$d['per_site']     = (array) $wpdb->get_results( $wpdb->prepare( "SELECT s.host, COUNT(DISTINCT m.contact_id) n FROM $mt m LEFT JOIN $st s ON s.id=m.site_id WHERE m.role='user' AND m.created_at>=%s AND m.contact_id NOT IN $adm GROUP BY s.host ORDER BY n DESC", $since ) );
		$top = (array) $wpdb->get_results( $wpdb->prepare( "SELECT c.*, s.host FROM $ct c LEFT JOIN $st s ON s.id=c.last_site_id WHERE c.last_at>=%s AND NOT (c.role='admin' AND c.admin_verified=1) AND (c.stage>=1 OR c.msg_count>=3) ORDER BY c.msg_count DESC LIMIT 60", $since ) );
		foreach ( $top as $c ) {
			$c->intent = self::intent_score( $c );
		}
		usort( $top, function ( $a, $b ) { return $b->intent - $a->intent ?: (int) $b->msg_count - (int) $a->msg_count; } );
		$d['top'] = array_slice( $top, 0, 15 );
		return $d;
	}

	public static function digest_text( $d ) {
		$lines   = array();
		$lines[] = '📊 تقرير مساعد Vibes Ventures — آخر ' . (int) $d['hours'] . ' ساعة (حتى ' . vai_riyadh( vai_now(), 'Y-m-d H:i' ) . ' بتوقيت الرياض)';
		$lines[] = '';
		$lines[] = 'محادثات بدأت: ' . (int) $d['chats'] . ' (رسائل: ' . (int) $d['messages'] . ') على ' . (int) $d['sites'] . ' موقع';
		$lines[] = 'زوار جدد تكلموا: ' . (int) $d['new_contacts'] . ' — أنشأوا حسابًا للاشتراك: ' . (int) $d['registered'] . ( $d['new_contacts'] ? ' (نسبة الإقناع ' . round( 100 * $d['registered'] / max( 1, $d['new_contacts'] ) ) . '%)' : '' );
		if ( $d['per_site'] ) {
			$lines[] = 'حسب الموقع: ' . implode( ' · ', array_map( function ( $r ) { return ( $r->host ?: '?' ) . ' ' . (int) $r->n; }, $d['per_site'] ) );
		}
		if ( $d['leads'] ) {
			$names   = array( 'contact' => 'تسجيلات', 'service' => 'طلبات خدمة', 'membership' => 'عضوية', 'partner' => 'مستثمرون/شراكة', 'owner' => 'أصحاب مشاريع', 'management' => 'طلب إدارة', 'cooperation' => 'تعاون', 'support' => 'دعم', 'payment' => 'دفع' );
			$lines[] = 'الليدز: ' . implode( ' · ', array_map( function ( $r ) use ( $names ) { return ( isset( $names[ $r->ltype ] ) ? $names[ $r->ltype ] : $r->ltype ) . ' ' . (int) $r->n; }, $d['leads'] ) );
		}
		$lines[] = '';
		$lines[] = '👥 أهم العملاء في هذه الفترة — مرتّبون بدرجة الجدية (من يستحق اتصالًا اليوم أولًا):';
		if ( ! $d['top'] ) {
			$lines[] = '— لا يوجد';
		}
		$i = 0;
		foreach ( $d['top'] as $c ) {
			$i++;
			$status  = $c->is_member ? 'عضو مدفوع' : ( $c->pass_hash ? 'حساب — بانتظار الدفع' : ( $c->stage >= 1 ? 'سجّل بياناته' : 'زائر' ) );
			$lines[] = $i . ') ' . self::intent_label( isset( $c->intent ) ? $c->intent : self::intent_score( $c ) ) . ' — ' . ( $c->name ?: 'بدون اسم' ) . ' — ' . ( $c->phone_norm ? vai_phone_local( $c->phone_norm ) : '—' ) . ( $c->email ? ' — ' . $c->email : '' ) . ' — ' . $status . ( $c->persona ? ' — ' . self::persona_label( $c->persona ) : '' ) . ' — الموقع: ' . ( $c->host ?: '?' ) . ' — ' . (int) $c->msg_count . ' رسالة' . ( $c->lead_type ? ' — ليد: ' . $c->lead_type : '' );
			if ( $c->memo ) {
				$lines[] = '   وصل معه إلى: ' . vai_clip( $c->memo, 260 );
			}
			$lines[] = '   الرابط: ' . admin_url( 'admin.php?page=vibes-ai&contact=' . (int) $c->id );
		}
		$lines[] = '';
		$lines[] = 'لوحة المتابعة: ' . admin_url( 'admin.php?page=vibes-ai' );
		return implode( "\n", $lines );
	}

	public static function send_digest() {
		if ( ! (int) vai_cfg( 'digest_enabled' ) ) {
			return false;
		}
		$emails = array_filter( array_map( 'trim', explode( ',', (string) vai_opt( 'notify_email', get_option( 'admin_email' ) ) ) ) );
		if ( ! $emails ) {
			return false;
		}
		$d    = self::digest_data( (int) vai_cfg( 'digest_hours' ) );
		$body = self::digest_text( $d );
		$ok   = false;
		foreach ( $emails as $e ) {
			if ( is_email( $e ) ) {
				$ok = wp_mail( $e, '[Vibes AI] تقرير ' . (int) $d['hours'] . ' ساعة — ' . (int) $d['chats'] . ' محادثة، ' . (int) $d['registered'] . ' تسجيل', $body ) || $ok;
			}
		}
		update_option( 'vai_last_digest', array( 'at' => vai_now(), 'ok' => $ok ? 1 : 0, 'chats' => (int) $d['chats'] ), false );
		return $ok;
	}

	public static function cleanup() {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . self::t( 'tokens' ) . ' WHERE expires_at<%s', gmdate( 'Y-m-d H:i:s', time() - 86400 ) ) );
		$wpdb->query( 'UPDATE ' . self::t( 'contacts' ) . " SET awaiting_since=NULL WHERE awaiting_since IS NOT NULL AND awaiting_since<'" . esc_sql( gmdate( 'Y-m-d H:i:s', time() - 600 ) ) . "'" );
		// Remove anonymous contacts that never sent a message (older than 2 days).
		$ct = self::t( 'contacts' );
		$wpdb->query( "DELETE FROM $ct WHERE stage=0 AND msg_count=0 AND created_at<'" . esc_sql( gmdate( 'Y-m-d H:i:s', time() - 2 * 86400 ) ) . "'" );
	}

	public static function export_csv() {
		if ( ! current_user_can( 'manage_options' ) || ! wp_verify_nonce( isset( $_GET['_wpnonce'] ) ? $_GET['_wpnonce'] : '', 'vai_export' ) ) {
			wp_die( 'غير مصرح' );
		}
		global $wpdb;
		$ct   = self::t( 'contacts' );
		$st   = self::t( 'sites' );
		$rows = $wpdb->get_results( "SELECT c.*, s.host FROM $ct c LEFT JOIN $st s ON s.id=c.last_site_id WHERE c.stage>=1 ORDER BY c.last_at DESC LIMIT 5000" );
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=vibes-ai-leads-' . gmdate( 'Y-m-d' ) . '.csv' );
		echo "\xEF\xBB\xBF";
		$out = fopen( 'php://output', 'w' );
		fputcsv( $out, array( 'الاسم', 'الجوال', 'الإيميل', 'حساب', 'درجة الجدية', 'عضو', 'الشركة', 'المدينة', 'الموقع', 'أول تواصل', 'آخر تواصل', 'عدد الرسائل', 'نوع الليد', 'ملف العميل', 'نبذة' ) );
		foreach ( (array) $rows as $r ) {
			$left = self::intent_label( self::intent_score( $r ) );
			fputcsv( $out, array( $r->name, vai_phone_local( $r->phone_norm ?: $r->phone ), $r->email, $r->pass_hash ? 'نعم' : 'لا', $left, $r->is_member ? 'نعم' : 'لا', $r->company, $r->city, $r->host, vai_riyadh( $r->first_at ), vai_riyadh( $r->last_at ), $r->msg_count, $r->lead_type, $r->memo, $r->bio ) );
		}
		fclose( $out );
		exit;
	}
}
