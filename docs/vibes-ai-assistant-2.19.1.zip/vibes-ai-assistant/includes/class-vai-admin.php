<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class VAI_Admin {

	public static function init() {
		if ( get_option( 'vai_roles_v' ) !== '1' ) {
			vai_ensure_roles();
		}
		add_action( 'admin_init', array( __CLASS__, 'agent_redirect' ) );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_vai_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_notices', array( __CLASS__, 'notices' ) );
	}

	public static function agent_redirect() {
		global $pagenow;
		if ( $pagenow === 'index.php' && ! current_user_can( 'manage_options' ) && current_user_can( 'vai_dashboard' ) && vai_is_hub() ) {
			wp_safe_redirect( admin_url( 'admin.php?page=vibes-ai' ) );
			exit;
		}
	}

	public static function menu() {
		$icon = 'dashicons-format-chat';
		if ( vai_is_hub() ) {
			add_menu_page( 'Vibes AI', 'Vibes AI', 'vai_dashboard', 'vibes-ai', array( __CLASS__, 'page_dashboard' ), $icon, 3 );
			add_submenu_page( 'vibes-ai', 'لوحة المتابعة', 'لوحة المتابعة', 'vai_dashboard', 'vibes-ai', array( __CLASS__, 'page_dashboard' ) );
			add_submenu_page( 'vibes-ai', 'الحسابات المسجّلة', 'الحسابات المسجّلة', 'manage_options', 'vibes-ai-accounts', array( __CLASS__, 'page_accounts' ) );
			add_submenu_page( 'vibes-ai', 'الرسائل البريدية والمدفوعات', 'الرسائل البريدية', 'manage_options', 'vibes-ai-mail', array( __CLASS__, 'page_mail' ) );
			add_submenu_page( 'vibes-ai', 'التوجيهات والروابط', 'التوجيهات والروابط', 'manage_options', 'vibes-ai-instructions', array( __CLASS__, 'page_instructions' ) );
			add_submenu_page( 'vibes-ai', 'المواقع', 'المواقع', 'manage_options', 'vibes-ai-sites', array( __CLASS__, 'page_sites' ) );
			add_submenu_page( 'vibes-ai', 'المعرفة', 'المعرفة', 'manage_options', 'vibes-ai-knowledge', array( __CLASS__, 'page_knowledge' ) );
			add_submenu_page( 'vibes-ai', 'الخدمات والأسعار', 'الخدمات والأسعار', 'manage_options', 'vibes-ai-services', array( __CLASS__, 'page_services' ) );
			add_submenu_page( 'vibes-ai', 'الفورمات', 'الفورمات', 'manage_options', 'vibes-ai-forms', array( __CLASS__, 'page_forms' ) );
			add_submenu_page( 'vibes-ai', 'الأعضاء والعضويات', 'الأعضاء والعضويات', 'manage_options', 'vibes-ai-members', array( __CLASS__, 'page_members' ) );
			add_submenu_page( 'vibes-ai', 'الإعدادات', 'الإعدادات', 'manage_options', 'vibes-ai-settings', array( __CLASS__, 'page_settings' ) );
		} else {
			add_menu_page( 'Vibes AI', 'Vibes AI', 'manage_options', 'vibes-ai', array( __CLASS__, 'page_site' ), $icon, 3 );
		}
	}

	public static function assets( $hook ) {
		if ( strpos( (string) $hook, 'vibes-ai' ) === false ) {
			return;
		}
		wp_enqueue_style( 'vai-font', 'https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&display=swap', array(), null );
		wp_enqueue_style( 'vai-admin', VAI_URL . 'assets/admin.css', array(), VAI_VERSION );
		wp_enqueue_script( 'vai-admin', VAI_URL . 'assets/admin.js', array(), VAI_VERSION, true );
		wp_add_inline_script(
			'vai-admin',
			'window.VAI_ADMIN=' . wp_json_encode(
				array(
					'rest'  => esc_url_raw( rest_url( 'vibes-ai/v1/hub/admin/' ) ),
					'nonce' => wp_create_nonce( 'wp_rest' ),
					'hub'   => vai_is_hub(),
					'open'  => isset( $_GET['contact'] ) ? (int) $_GET['contact'] : 0,
				),
				JSON_UNESCAPED_UNICODE
			) . ';',
			'before'
		);
	}

	public static function notices() {
		if ( ! isset( $_GET['page'] ) || strpos( (string) $_GET['page'], 'vibes-ai' ) !== 0 ) {
			return;
		}
		if ( isset( $_GET['vai_msg'] ) ) {
			$msg = sanitize_text_field( wp_unslash( $_GET['vai_msg'] ) );
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $msg ) . '</p></div>';
		}
		if ( isset( $_GET['vai_err'] ) ) {
			$msg = sanitize_text_field( wp_unslash( $_GET['vai_err'] ) );
			echo '<div class="notice notice-error is-dismissible"><p>' . esc_html( $msg ) . '</p></div>';
		}
		if ( isset( $_GET['vai_key'] ) ) {
			$key = sanitize_text_field( wp_unslash( $_GET['vai_key'] ) );
			echo '<div class="notice notice-warning"><p><strong>مفتاح الموقع الجديد (انسخه الآن — لن يظهر مرة أخرى):</strong><br><code style="font-size:15px;user-select:all">' . esc_html( $key ) . '</code></p></div>';
		}
	}

	private static function back( $page, $msg = '', $err = '', $extra = array() ) {
		$args = array( 'page' => $page );
		if ( $msg ) {
			$args['vai_msg'] = $msg;
		}
		if ( $err ) {
			$args['vai_err'] = $err;
		}
		$args = array_merge( $args, $extra );
		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		exit;
	}

	/* ─────────────── save handler ─────────────── */

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'غير مصرح' );
		}
		check_admin_referer( 'vai_save' );
		$action = isset( $_POST['vai_action'] ) ? sanitize_key( $_POST['vai_action'] ) : '';
		// The «نسخة تجريبية» button lives inside the campaign form and only adds op=campaign_test (2.7.0 fix: it used to schedule the real campaign).
		if ( $action === 'campaign' && isset( $_POST['op'] ) && sanitize_key( $_POST['op'] ) === 'campaign_test' ) {
			$action = 'campaign_test';
		}
		global $wpdb;

		switch ( $action ) {

			case 'site_settings':
				$mode = isset( $_POST['mode'] ) && $_POST['mode'] === 'hub' ? 'hub' : 'site';
				$patch = array(
					'mode'               => $mode,
					'hub_url'            => esc_url_raw( trim( (string) wp_unslash( $_POST['hub_url'] ?? '' ) ) ),
					'site_key'           => sanitize_text_field( wp_unslash( $_POST['site_key'] ?? '' ) ),
					'widget_position'    => ( $_POST['widget_position'] ?? 'right' ) === 'left' ? 'left' : 'right',
					'widget_color'       => sanitize_hex_color( wp_unslash( $_POST['widget_color'] ?? '' ) ) ?: '',
					'widget_off'         => empty( $_POST['widget_off'] ) ? 0 : 1,
					'hide_paths'         => sanitize_textarea_field( wp_unslash( $_POST['hide_paths'] ?? '' ) ),
					'sync_exclude_types' => sanitize_text_field( wp_unslash( $_POST['sync_exclude_types'] ?? '' ) ),
				);
				vai_update_settings( $patch );
				delete_transient( 'vai_widget_config_' . VAI_VERSION );
				if ( $mode === 'hub' ) {
					VAI_Hub::install();
					self::back( 'vibes-ai', 'تم الحفظ — هذا الموقع الآن هو «الهب». افتح صفحة الإعدادات لضبط رابط n8n.' );
				}
				if ( $patch['hub_url'] !== '' && vai_url_host( $patch['hub_url'] ) === vai_home_host() ) {
					update_option( 'vai_site_ping', array( 'ok' => 0, 'at' => vai_now(), 'msg' => 'رابط الهب لا يمكن أن يكون هذا الموقع نفسه — ضع رابط الموقع الذي فيه الهب (مثال: https://vcmem.com)' ), false );
					self::back( 'vibes-ai', '', 'تم الحفظ، لكن «رابط الهب» يشير إلى هذا الموقع نفسه. الهب هو الموقع المركزي (مثال https://vcmem.com) — صحّحه ثم احفظ.' );
				}
				if ( $patch['hub_url'] !== '' && $patch['site_key'] !== '' ) {
					$res = VAI_Site::client( 'ping', array(), 15 );
					if ( is_wp_error( $res ) ) {
						update_option( 'vai_site_ping', array( 'ok' => 0, 'at' => vai_now(), 'msg' => $res->get_error_message() ), false );
						self::back( 'vibes-ai', '', 'تم الحفظ، لكن الاتصال بالهب فشل: ' . $res->get_error_message() );
					}
					update_option( 'vai_site_ping', array( 'ok' => 1, 'at' => vai_now(), 'msg' => (string) ( $res['hub'] ?? '' ) ), false );
					delete_transient( 'vai_widget_config_' . VAI_VERSION );
					self::back( 'vibes-ai', 'تم الحفظ والاتصال بالهب ناجح ✅ (' . ( $res['hub'] ?? '' ) . ') — امسح كاش الموقع لو لم تظهر الأيقونة.' );
				}
				self::back( 'vibes-ai', 'تم حفظ الإعدادات.' );
				break;

			case 'test_connection':
				$res = VAI_Site::client( 'ping', array(), 15 );
				if ( is_wp_error( $res ) ) {
					update_option( 'vai_site_ping', array( 'ok' => 0, 'at' => vai_now(), 'msg' => $res->get_error_message() ), false );
					self::back( 'vibes-ai', '', 'فشل الاتصال: ' . $res->get_error_message() );
				}
				update_option( 'vai_site_ping', array( 'ok' => 1, 'at' => vai_now(), 'msg' => (string) ( $res['hub'] ?? '' ) ), false );
				delete_transient( 'vai_widget_config_' . VAI_VERSION );
				self::back( 'vibes-ai', 'الاتصال بالهب ناجح ✅ (' . ( $res['hub'] ?? '' ) . ')' );
				break;

			case 'sync_now':
				$res = VAI_Site::sync_all();
				if ( empty( $res['ok'] ) ) {
					self::back( 'vibes-ai', '', 'المزامنة انتهت بأخطاء (' . (int) ( $res['errors'] ?? 0 ) . ') — أُرسل ' . (int) ( $res['sent'] ?? 0 ) . ' من ' . (int) ( $res['total'] ?? 0 ) );
				}
				self::back( 'vibes-ai', 'تمت مزامنة ' . (int) $res['sent'] . ' صفحة/مقال مع الهب.' );
				break;

			case 'test_n8n':
				$url = trim( (string) vai_opt( 'n8n_webhook', '' ) );
				if ( $url === '' ) {
					self::back( 'vibes-ai-settings', '', 'خانة «رابط ويبهوك n8n» فارغة — الصق الرابط ثم احفظ ثم اختبر.' );
				}
				$ping_id = vai_key( 12 );
				delete_option( 'vai_last_pong' );
				$t0 = microtime( true );
				list( $code, $data, $err ) = vai_http_json( 'POST', $url, array( 'event' => 'ping', 'secret' => (string) vai_opt( 'webhook_secret', '' ), 'ping_id' => $ping_id ), array(), 20 );
				if ( $code >= 200 && $code < 300 ) {
					global $wpdb;
					for ( $i = 0; $i < 20; $i++ ) {
						sleep( 1 );
						// read straight from the DB: the option is written by n8n's request, and WordPress caches "missing option" per request
						$raw  = $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name=%s", 'vai_last_pong' ) );
						$pong = $raw ? maybe_unserialize( $raw ) : array();
						if ( is_array( $pong ) && ( $pong['id'] ?? '' ) === $ping_id ) {
							self::back( 'vibes-ai-settings', 'الاتصال الكامل ناجح ✅ n8n استلم النبضة وردّ على الهب خلال ' . round( microtime( true ) - $t0, 1 ) . ' ثانية — الرابط والسرّ ومفتاح الهب كلها صحيحة.' );
						}
					}
					self::back( 'vibes-ai-settings', '', 'n8n استلم النبضة (كود ' . $code . ') لكنه لم يردّ على الهب خلال 20 ثانية ⚠️ — الأرجح أن «سرّ الويبهوك» أو «مفتاح الهب» في عقدة Config لا يطابقان القيم هنا، أو أن الوركفلو المفعّل نسخة قديمة لا تدعم النبضة. افتح n8n → Executions لآخر تنفيذ.' );
				}
				$hint = $code === 404 ? ' (404 غالبًا = الوركفلو غير مفعّل Active، أو الرابط Test بدل Production)' : ( $code === 0 ? ' (لا يوجد اتصال بالخادم — تحقق من الرابط)' : '' );
				self::back( 'vibes-ai-settings', '', 'n8n رد بكود ' . $code . $hint . ' ' . $err );
				break;

			case 'instructions':
				vai_update_settings(
					array(
						'extra_instructions' => sanitize_textarea_field( wp_unslash( $_POST['extra_instructions'] ?? '' ) ),
						'links'              => sanitize_textarea_field( wp_unslash( $_POST['links'] ?? '' ) ),
						'auto_open'          => empty( $_POST['auto_open'] ) ? 0 : 1,
						'auto_open_words'    => sanitize_text_field( wp_unslash( $_POST['auto_open_words'] ?? '' ) ),
					)
				);
				update_option( 'vai_cfg_rev', time(), false );
				delete_transient( 'vai_widget_config_' . VAI_VERSION );
				self::back( 'vibes-ai-instructions', 'تم الحفظ — التوجيهات والروابط تصل للمساعد من الرسالة التالية.' );
				break;

			case 'test_mail':
				$to = (string) get_option( 'admin_email' );
				$ok = VAI_Hub::mail( $to, '[Vibes AI] اختبار إرسال البريد', "هذه رسالة اختبار من مساعد Vibes Ventures على " . home_url() . "\nإن وصلتك فالبريد يعمل." );
				self::back( 'vibes-ai-settings', $ok ? 'تم إرسال رسالة اختبار إلى ' . $to . ' ✅ تحقق من الإنبوكس (أو السبام).' : '', $ok ? '' : 'فشل إرسال البريد: ' . (string) get_option( 'vai_last_mail_error', 'wp_mail رجع false' ) . ' — ثبّت إضافة SMTP (مثل FluentSMTP) واضبطها.' );
				break;

			case 'account_action':
				$id  = (int) ( $_POST['id'] ?? 0 );
				$act = sanitize_key( $_POST['act'] ?? '' );
				global $wpdb;
				if ( $act === 'promote' ) {
					$r = VAI_Hub::promote_admin( $id );
					if ( is_wp_error( $r ) ) {
						self::back( 'vibes-ai-accounts', '', $r->get_error_message() );
					}
					self::back( 'vibes-ai-accounts', 'تمت الترقية إلى أدمن' . ( $r['mail_sent'] ? ' وأُرسلت رسالة التفعيل بالكود إلى بريده ✅' : ' — لكن فشل إرسال البريد؛ الكود: ' . $r['code'] . ' (أعطه له يدويًا)' ) );
				} elseif ( $act === 'demote' ) {
					VAI_Hub::demote_admin( $id );
					self::back( 'vibes-ai-accounts', 'تم إلغاء صلاحية الأدمن.' );
				} elseif ( $act === 'verify' ) {
					$wpdb->update( VAI_Hub::t( 'contacts' ), array( 'verified' => 1, 'stage' => 1, 'trial_started_at' => vai_now() ), array( 'id' => $id, 'verified' => 0 ) );
					VAI_Hub::note_verified( $id, 'manual', 'hub admin' );
					self::back( 'vibes-ai-accounts', 'تم تفعيل الحساب يدويًا — بانتظار دفع العضوية.' );
				} elseif ( $act === 'publisher' || $act === 'unpublisher' ) {
					$r = VAI_Hub::set_role( $id, $act === 'publisher' ? 'publisher' : 'member', 'manual' );
					if ( is_wp_error( $r ) ) {
						self::back( 'vibes-ai-accounts', '', $r->get_error_message() );
					}
					self::back( 'vibes-ai-accounts', $act === 'publisher' ? 'تمت الترقية إلى «ناشر» — يستطيع نشر المنشورات والفعاليات من لوحة التطبيق فقط.' : 'أُلغيت صلاحية الناشر.' );
				} elseif ( $act === 'delete' ) {
					VAI_Hub::admin( 'delete', array( 'id' => $id ) );
					self::back( 'vibes-ai-accounts', 'تم حذف الحساب وكل بياناته.' );
				} elseif ( $act === 'member' ) {
					$c = VAI_Hub::contact( $id );
					if ( $c ) {
						VAI_Hub::set_member( $id, ! (int) $c->is_member );
					}
					self::back( sanitize_key( $_POST['back'] ?? 'vibes-ai-accounts' ), (int) $c->is_member ? 'أُلغيت العضوية المدفوعة.' : 'تم التحويل إلى عضوية مدفوعة ⭐ وبدأ عدّاد ' . (int) vai_cfg( 'member_days' ) . ' يومًا.' );
				} elseif ( $act === 'renew' ) {
					VAI_Hub::set_member( $id, true );
					self::back( sanitize_key( $_POST['back'] ?? 'vibes-ai-members' ), 'تم تجديد العضوية — عدّاد جديد من اليوم.' );
				}
				self::back( sanitize_key( $_POST['back'] ?? 'vibes-ai-accounts' ) );
				break;

			case 'test_voice':
				$r = VAI_Hub::voice_test();
				self::back( 'vibes-ai-settings', $r['ok'] ? $r['msg'] : '', $r['ok'] ? '' : $r['msg'] );
				break;

			case 'test_pb':
				delete_transient( 'vai_pb_projects' );
				$src = VAI_Hub::projects_source();
				if ( $src['source'] === 'api' ) {
					self::back( 'vibes-ai-settings', 'بنك المشاريع متصل عبر PB Agent API ✅ — ' . (int) $src['count'] . ' مشروع.' );
				} elseif ( $src['source'] === 'knowledge' ) {
					self::back( 'vibes-ai-settings', '', 'PB Agent API غير متصل (المفتاح أو الرابط غير صحيح) — المساعد يستخدم صفحات المشاريع المُزامَنة من فايبز (' . (int) $src['count'] . ' صفحة) كبديل. ضع المفتاح الصحيح ليحصل على الرقم والقطاع والمرحلة.' );
				}
				self::back( 'vibes-ai-settings', '', 'لا يوجد أي مصدر للمشاريع: PB Agent API غير متصل ولم تُزامَن صفحات المشاريع من vibesholding.com — شغّل «مزامنة محتوى الموقع الآن» على فايبز أو ضع مفتاح PB Agent API.' );
				break;

			case 'campaign':
				$aud = sanitize_key( $_POST['audience'] ?? 'paid' );
				$per = sanitize_key( $_POST['persona'] ?? '' );
				$sub = sanitize_text_field( wp_unslash( $_POST['subject'] ?? '' ) );
				$bod = sanitize_textarea_field( wp_unslash( $_POST['body'] ?? '' ) );
				if ( $sub === '' || $bod === '' ) {
					self::back( 'vibes-ai-mail', '', 'العنوان والنص مطلوبان.' );
				}
				$r = VAI_Payments::campaign( $aud, $sub, $bod, $per );
				self::back( 'vibes-ai-mail', (int) $r['count'] > 0 ? 'تمت جدولة ' . (int) $r['count'] . ' رسالة — تُرسل واحدة كل 5 دقائق.' : '', (int) $r['count'] > 0 ? '' : 'لا يوجد مستلمون بهذا الاختيار (الجمهور أو الفئة).' );
				break;

			case 'campaign_test':
				$sub = sanitize_text_field( wp_unslash( $_POST['subject'] ?? '' ) );
				$bod = sanitize_textarea_field( wp_unslash( $_POST['body'] ?? '' ) );
				$me  = wp_get_current_user();
				$ok  = VAI_Hub::mail( $me->user_email, VAI_Payments::render( $sub ?: 'اختبار', null ), VAI_Payments::render( $bod, null ) );
				self::back( 'vibes-ai-mail', $ok ? 'أُرسلت نسخة تجريبية إلى ' . $me->user_email : '', $ok ? '' : 'فشل الإرسال — راجع SMTP.' );
				break;

			case 'rematch_payments':
				$n = VAI_Payments::rematch_payments();
				self::back( 'vibes-ai-mail', 'تمت مطابقة ' . (int) $n . ' دفعة عضوية: أُنشئت/فُعّلت حساباتهم وأُرسلت روابط كلمة المرور.' );
				break;

			case 'activate_by_data':
				$name  = sanitize_text_field( wp_unslash( $_POST['a_name'] ?? '' ) );
				$phone = sanitize_text_field( wp_unslash( $_POST['a_phone'] ?? '' ) );
				$email = sanitize_email( wp_unslash( $_POST['a_email'] ?? '' ) );
				if ( $email === '' && $phone === '' ) {
					self::back( 'vibes-ai-mail', '', 'أدخل البريد أو الجوال على الأقل.' );
				}
				$c = VAI_Hub::create_account_for( $name, $phone, $email, true, 'manual' );
				self::back( 'vibes-ai-mail', $c ? '⭐ تم تفعيل عضوية ' . ( $c->name ?: $c->email ) . ( empty( $c->pass_hash ) ? ' وأُرسل له رابط اختيار كلمة المرور على بريده' : ' (حسابه موجود مسبقًا)' ) : '', $c ? '' : 'تعذّر التفعيل.' );
				break;

			case 'queue_clear':
				$n = VAI_Payments::clear_pending();
				self::back( 'vibes-ai-mail', 'أُلغيت ' . (int) $n . ' رسالة من طابور الإرسال.' );
				break;

			case 'weekly_now':
				VAI_Payments::weekly_members();
				self::back( 'vibes-ai-mail', 'دخلت الرسالة الأسبوعية طابور الإرسال لكل الأعضاء المفعّلين.' );
				break;

			case 'broadcast_now':
				$r = VAI_Payments::broadcast_run( true );
				self::back( 'vibes-ai-mail', ! empty( $r['ok'] ) ? '📮 دخلت دفعة «كل يومين» الطابور الآن: أعضاء ' . (int) $r['members'] . ' · غير مشتركين ' . (int) $r['nonmembers'] . '.' : '', ! empty( $r['ok'] ) ? '' : 'لم تنطلق الدفعة (' . esc_html( (string) $r['reason'] ) . ').' );
				break;

			case 'pb_grant':
				$cid  = (int) ( $_POST['cid'] ?? 0 );
				$amt  = (int) ( $_POST['amount'] ?? 0 );
				$note = sanitize_text_field( wp_unslash( $_POST['note'] ?? '' ) );
				if ( $cid <= 0 || $amt < 1 || $amt > 1000 ) {
					self::back( 'vibes-ai-members', '', 'أدخل مبلغًا من 1 إلى 1000 ريال.' );
				}
				$u = wp_get_current_user();
				$r = VAI_Hub::pb_grant( $cid, $amt, $note !== '' ? $note : 'رصيد إضافي من الإدارة', 'hub-admin:' . ( $u ? $u->user_login : '' ) );
				self::back( 'vibes-ai-members', is_wp_error( $r ) ? '' : '🏦 أُضيف رصيد ' . (int) $amt . ' لحساب #' . $cid . ( isset( $r['left'] ) ? ' — رصيده الآن: ' . (int) $r['left'] : '' ), is_wp_error( $r ) ? $r->get_error_message() : '' );
				break;

			case 'issue_ticket':
				$name  = sanitize_text_field( wp_unslash( $_POST['t_name'] ?? '' ) );
				$phone = sanitize_text_field( wp_unslash( $_POST['t_phone'] ?? '' ) );
				$email = sanitize_email( wp_unslash( $_POST['t_email'] ?? '' ) );
				if ( $name === '' || ! is_email( $email ) ) {
					self::back( 'vibes-ai-mail', '', 'الاسم والبريد مطلوبان لإصدار التذكرة.' );
				}
				$t = VAI_Payments::issue_ticket( $name, $phone, $email, 0, 'manual' );
				self::back( 'vibes-ai-mail', '🎟️ أُصدرت التذكرة ' . $t['ref'] . ' وأُرسلت إلى ' . $email . ' — الرابط: ' . VAI_Payments::ticket_url( $t['ref'] ) );
				break;

			case 'send_digest':
				$ok = VAI_Hub::send_digest();
				self::back( 'vibes-ai-settings', $ok ? 'تم إرسال التقرير إلى إيميلات الإشعار ✅' : '', $ok ? '' : 'لم يُرسل التقرير — تأكد من تفعيله ومن إيميلات الإشعار وأن الموقع يستطيع إرسال بريد (SMTP).' );
				break;

			case 'hub_settings':
				$keys  = array( 'n8n_webhook', 'openai_key', 'voice_enabled', 'gcc_only', 'event_title', 'event_date', 'event_place', 'event_amount', 'event_note', 'notify_user_events', 'wa_members_only', 'paymob_hmac', 'paymob_secret', 'paymob_public', 'paymob_methods', 'paymob_direct', 'paymob_amounts', 'google_client_id', 'member_services', 'member_email_subject', 'member_email', 'weekly_enabled', 'weekly_subject', 'weekly_email', 'launcher_style', 'nav_mode', 'account_pill', 'account_bar2', 'mobile_mode', 'pill_position', 'welcome_links', 'notify_registration', 'member_days', 'member_expired_text', 'allowed_email_domains', 'instant_lead_types', 'digest_enabled', 'digest_hours', 'trial_days', 'nudge_every', 'account_gate_text', 'trial_expired_text', 'unsaved_note', 'unpaid_note', 'first_reply_note', 'price_sheet', 'welcome_email_subject', 'welcome_email', 'bot_name', 'bot_subtitle', 'avatar_url', 'primary_color', 'welcome', 'menu', 'gate_free', 'gate_identified', 'member_daily', 'rate_per_hour', 'site_daily_cap', 'human_pause_min', 'reply_timeout', 'mgmt_whatsapp', 'club_whatsapp', 'saudi_only', 'contact_gate_text', 'member_gate_text', 'allowed_hosts', 'videos', 'notify_email', 'notify_webhook', 'pb_api_url', 'pb_api_key', 'gpt_api_key', 'member_check_origins', 'broadcast_enabled', 'broadcast_member_texts', 'broadcast_nonmember_texts', 'pb_bridge_url', 'pb_bridge_key' );
				$patch = array();
				foreach ( $keys as $k ) {
					$v = wp_unslash( $_POST[ $k ] ?? '' );
					if ( in_array( $k, array( 'welcome', 'menu', 'contact_gate_text', 'member_gate_text', 'allowed_hosts', 'videos', 'account_gate_text', 'trial_expired_text', 'welcome_email', 'member_expired_text', 'welcome_links', 'unsaved_note', 'unpaid_note', 'first_reply_note', 'price_sheet', 'paymob_amounts', 'paymob_direct', 'member_services', 'member_email', 'weekly_email', 'broadcast_member_texts', 'broadcast_nonmember_texts' ), true ) ) {
						$patch[ $k ] = sanitize_textarea_field( $v );
					} elseif ( in_array( $k, array( 'gate_free', 'gate_identified', 'member_daily', 'rate_per_hour', 'site_daily_cap', 'human_pause_min', 'reply_timeout', 'saudi_only', 'trial_days', 'nudge_every', 'digest_enabled', 'digest_hours', 'notify_registration', 'member_days', 'account_pill', 'account_bar2' ), true ) ) {
						$patch[ $k ] = (int) $v;
					} elseif ( in_array( $k, array( 'n8n_webhook', 'avatar_url', 'notify_webhook', 'pb_api_url' ), true ) ) {
						$patch[ $k ] = esc_url_raw( trim( (string) $v ) );
					} else {
						$patch[ $k ] = sanitize_text_field( $v );
					}
				}
				if ( ! empty( $_POST['regen_hub_key'] ) ) {
					$patch['hub_key'] = vai_key( 40 );
				}
				if ( ! empty( $_POST['regen_secret'] ) ) {
					$patch['webhook_secret'] = vai_key( 32 );
				}
				// 2.7.0: instant sync with the app server. The signing secret is generated here and shown once (never printed again).
				$patch['app_webhook_url'] = esc_url_raw( trim( (string) wp_unslash( $_POST['app_webhook_url'] ?? '' ) ), array( 'https', 'http' ) );
				if ( ! empty( $_POST['regen_app_secret'] ) || ( $patch['app_webhook_url'] !== '' && trim( (string) vai_opt( 'app_webhook_secret', '' ) ) === '' ) ) {
					$patch['app_webhook_secret'] = vai_key( 48 );
					set_transient( 'vai_app_secret_once_' . get_current_user_id(), $patch['app_webhook_secret'], 10 * MINUTE_IN_SECONDS );
				}
				vai_update_settings( $patch );
				delete_transient( 'vai_webhook_down' ); // a new address or secret is tried at once (see VAI_Hub::webhook_flush())
				update_option( 'vai_cfg_rev', time(), false );
				delete_transient( 'vai_widget_config_' . VAI_VERSION );
				delete_transient( 'vai_pb_projects' );
				self::back( 'vibes-ai-settings', 'تم حفظ الإعدادات.' );
				break;

			case 'add_site':
				$key = VAI_Hub::create_site( sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) ), sanitize_text_field( wp_unslash( $_POST['host'] ?? '' ) ), sanitize_hex_color( wp_unslash( $_POST['color'] ?? '' ) ) ?: '' );
				if ( is_wp_error( $key ) ) {
					self::back( 'vibes-ai-sites', '', $key->get_error_message() );
				}
				self::back( 'vibes-ai-sites', 'تمت إضافة الموقع. الصق المفتاح في إعدادات البلجن على ذلك الموقع.', '', array( 'vai_key' => $key ) );
				break;

			case 'delete_site':
				$wpdb->update( VAI_Hub::t( 'sites' ), array( 'status' => 'disabled', 'key_hash' => '', 'trusted' => 0 ), array( 'id' => (int) $_POST['id'], 'is_self' => 0 ) );
				self::back( 'vibes-ai-sites', 'تم تعطيل الموقع.' );
				break;

			case 'site_trusted':
				// 2.7.0: only the app server's row gets the privileged ops (activate_member, changes, publish, admin_*). Never the hub's own row.
				$on = empty( $_POST['trusted'] ) ? 0 : 1;
				$wpdb->update( VAI_Hub::t( 'sites' ), array( 'trusted' => $on ), array( 'id' => (int) ( $_POST['id'] ?? 0 ), 'is_self' => 0 ) );
				self::back( 'vibes-ai-sites', $on ? 'صار هذا الموقع «خادم التطبيق» بصلاحيات إدارية — فعّلها لصف خادم التطبيق وحده.' : 'أُلغيت الصلاحيات الإدارية عن هذا الموقع.' );
				break;

			case 'add_note':
				$title   = sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) );
				$content = sanitize_textarea_field( wp_unslash( $_POST['content'] ?? '' ) );
				if ( trim( $content ) === '' ) {
					self::back( 'vibes-ai-knowledge', '', 'المحتوى فارغ.' );
				}
				VAI_Hub::add_note( $title ?: vai_clip( $content, 60 ), $content );
				self::back( 'vibes-ai-knowledge', 'تمت الإضافة — صارت ضمن معرفة المساعد فورًا.' );
				break;

			case 'delete_note':
				VAI_Hub::delete_note( (int) $_POST['id'] );
				self::back( 'vibes-ai-knowledge', 'تم الحذف.' );
				break;

			case 'save_service':
				$t   = VAI_Hub::t( 'services' );
				$row = array(
					'skey'            => preg_replace( '/[^a-z0-9_\-]/', '', strtolower( sanitize_text_field( wp_unslash( $_POST['skey'] ?? '' ) ) ) ),
					'name'            => sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) ),
					'price'           => sanitize_text_field( wp_unslash( $_POST['price'] ?? '' ) ),
					'currency'        => sanitize_text_field( wp_unslash( $_POST['currency'] ?? 'ريال' ) ) ?: 'ريال',
					'vat_note'        => sanitize_text_field( wp_unslash( $_POST['vat_note'] ?? '' ) ),
					'payment_terms'   => sanitize_text_field( wp_unslash( $_POST['payment_terms'] ?? '' ) ),
					'url'             => esc_url_raw( trim( (string) wp_unslash( $_POST['url'] ?? '' ) ) ),
					'pay_url'         => esc_url_raw( trim( (string) wp_unslash( $_POST['pay_url'] ?? '' ) ) ),
					'member_discount' => sanitize_text_field( wp_unslash( $_POST['member_discount'] ?? '' ) ),
					'includes'        => sanitize_textarea_field( wp_unslash( $_POST['includes'] ?? '' ) ),
					'pitch'           => sanitize_textarea_field( wp_unslash( $_POST['pitch'] ?? '' ) ),
					'active'          => empty( $_POST['active'] ) ? 0 : 1,
					'sort'            => (int) ( $_POST['sort'] ?? 0 ),
				);
				if ( $row['skey'] === '' || $row['name'] === '' ) {
					self::back( 'vibes-ai-services', '', 'المفتاح والاسم مطلوبان.' );
				}
				$id = (int) ( $_POST['id'] ?? 0 );
				if ( $id ) {
					$wpdb->update( $t, $row, array( 'id' => $id ) );
				} else {
					$wpdb->insert( $t, $row );
				}
				delete_transient( 'vai_widget_config_' . VAI_VERSION );
				self::back( 'vibes-ai-services', 'تم حفظ الخدمة.' );
				break;

			case 'delete_service':
				$wpdb->delete( VAI_Hub::t( 'services' ), array( 'id' => (int) $_POST['id'] ) );
				self::back( 'vibes-ai-services', 'تم الحذف.' );
				break;

			case 'save_form':
				$t   = VAI_Hub::t( 'forms' );
				$map = json_decode( (string) wp_unslash( $_POST['field_map'] ?? '' ), true );
				if ( ! is_array( $map ) ) {
					self::back( 'vibes-ai-forms', '', 'خريطة الحقول ليست JSON صحيحًا.' );
				}
				$row = array(
					'fkey'      => preg_replace( '/[^a-z0-9_\-]/', '', strtolower( sanitize_text_field( wp_unslash( $_POST['fkey'] ?? '' ) ) ) ),
					'label'     => sanitize_text_field( wp_unslash( $_POST['label'] ?? '' ) ),
					'url'       => esc_url_raw( trim( (string) wp_unslash( $_POST['url'] ?? '' ) ) ),
					'host'      => vai_url_host( wp_unslash( $_POST['url'] ?? '' ) ),
					'field_map' => wp_json_encode( $map, JSON_UNESCAPED_UNICODE ),
					'notes'     => sanitize_textarea_field( wp_unslash( $_POST['notes'] ?? '' ) ),
					'active'    => empty( $_POST['active'] ) ? 0 : 1,
				);
				if ( $row['fkey'] === '' || $row['url'] === '' ) {
					self::back( 'vibes-ai-forms', '', 'المفتاح والرابط مطلوبان.' );
				}
				$id = (int) ( $_POST['id'] ?? 0 );
				if ( $id ) {
					$wpdb->update( $t, $row, array( 'id' => $id ) );
				} else {
					$wpdb->insert( $t, $row );
				}
				self::back( 'vibes-ai-forms', 'تم حفظ الفورم.' );
				break;

			case 'delete_form':
				$wpdb->delete( VAI_Hub::t( 'forms' ), array( 'id' => (int) $_POST['id'] ) );
				self::back( 'vibes-ai-forms', 'تم الحذف.' );
				break;

			case 'import_members':
				$t     = VAI_Hub::t( 'members' );
				$lines = preg_split( '/\r\n|\r|\n/', (string) wp_unslash( $_POST['members'] ?? '' ) );
				$n     = 0;
				foreach ( $lines as $l ) {
					$l = trim( $l );
					if ( $l === '' ) {
						continue;
					}
					$parts = array_map( 'trim', preg_split( '/[,\t|]/', $l ) );
					$name  = '';
					$pn    = '';
					$em    = '';
					foreach ( $parts as $p ) {
						if ( is_email( $p ) ) {
							$em = strtolower( $p );
						} elseif ( preg_match( '/^\+?[\d\s\-]{8,}$/', $p ) ) {
							$pn = vai_norm_phone( $p );
						} elseif ( $p !== '' ) {
							$name = sanitize_text_field( $p );
						}
					}
					if ( $pn === '' && $em === '' ) {
						continue;
					}
					$exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $t WHERE (phone_norm<>'' AND phone_norm=%s) OR (email_norm<>'' AND email_norm=%s) LIMIT 1", $pn, $em ) );
					if ( $exists ) {
						continue;
					}
					$wpdb->insert(
						$t,
						array(
							'name'       => $name,
							'phone_norm' => $pn,
							'email_norm' => $em,
							'source'     => 'import',
							'created_at' => vai_now(),
						)
					);
					$n++;
				}
				self::back( 'vibes-ai-members', 'تمت إضافة ' . $n . ' عضو.' );
				break;

			case 'delete_member':
				$wpdb->delete( VAI_Hub::t( 'members' ), array( 'id' => (int) $_POST['id'] ) );
				self::back( 'vibes-ai-members', 'تم الحذف.' );
				break;
		}
		self::back( 'vibes-ai' );
	}

	/* ─────────────── helpers ─────────────── */

	private static function form_open( $action ) {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'vai_save' );
		echo '<input type="hidden" name="action" value="vai_save"><input type="hidden" name="vai_action" value="' . esc_attr( $action ) . '">';
	}

	private static function field( $label, $name, $value, $type = 'text', $help = '', $attrs = '' ) {
		echo '<div class="vai-field"><label for="vai_' . esc_attr( $name ) . '">' . esc_html( $label ) . '</label>';
		if ( $type === 'textarea' ) {
			echo '<textarea id="vai_' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '" rows="4" ' . $attrs . '>' . esc_textarea( (string) $value ) . '</textarea>';
		} elseif ( $type === 'checkbox' ) {
			echo '<label class="vai-check"><input type="checkbox" id="vai_' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '" value="1" ' . checked( (int) $value, 1, false ) . '> ' . esc_html( $help ) . '</label>';
			$help = '';
		} else {
			echo '<input type="' . esc_attr( $type ) . '" id="vai_' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) $value ) . '" ' . $attrs . '>';
		}
		if ( $help ) {
			echo '<p class="vai-help">' . wp_kses_post( $help ) . '</p>';
		}
		echo '</div>';
	}

	private static function wrap_open( $title, $sub = '' ) {
		echo '<div class="wrap vai-wrap" dir="rtl"><div class="vai-head"><h1>' . esc_html( $title ) . '</h1>';
		if ( $sub ) {
			echo '<p class="vai-sub">' . wp_kses_post( $sub ) . '</p>';
		}
		echo '</div>';
	}

	/* ─────────────── site-mode page ─────────────── */

	public static function page_site() {
		$last = get_option( 'vai_last_sync', array() );
		self::wrap_open( 'Vibes AI Assistant — إعدادات هذا الموقع', 'الويدجت يظهر تلقائيًا على كل صفحات الموقع بمجرد ربطه بالهب. الردود، الليدز، والداشبورد كلها في الهب.' );
		echo '<div class="vai-grid2"><div class="vai-card">';
		self::form_open( 'site_settings' );
		echo '<h2>وضع التشغيل</h2>';
		echo '<div class="vai-field"><label>هذا الموقع هو:</label><label class="vai-radio"><input type="radio" name="mode" value="site" ' . checked( vai_mode(), 'site', false ) . '> موقع تابع (يعرض الويدجت ويرسل المحادثات للهب)</label><label class="vai-radio"><input type="radio" name="mode" value="hub" ' . checked( vai_mode(), 'hub', false ) . '> الهب المركزي (قاعدة البيانات + الداشبورد) — موقع واحد فقط في المنظومة</label></div>';
		self::field( 'رابط الهب', 'hub_url', vai_opt( 'hub_url', '' ), 'url', 'مثال: https://vcmem.com', 'placeholder="https://vcmem.com" dir="ltr"' );
		self::field( 'مفتاح الموقع', 'site_key', vai_opt( 'site_key', '' ), 'text', 'تولّده من صفحة «المواقع» في الهب — كل موقع له مفتاح خاص.', 'dir="ltr" autocomplete="off"' );
		echo '<h2>الويدجت</h2>';
		echo '<div class="vai-field"><label>موضع الأيقونة</label><select name="widget_position"><option value="right" ' . selected( vai_opt( 'widget_position', 'right' ), 'right', false ) . '>يمين الشاشة</option><option value="left" ' . selected( vai_opt( 'widget_position', 'right' ), 'left', false ) . '>يسار الشاشة</option></select></div>';
		self::field( 'لون هذا الموقع (اختياري)', 'widget_color', vai_opt( 'widget_color', '' ), 'text', 'اتركه فارغًا ليأخذ لون الهب. مثال: #B8962E', 'dir="ltr" placeholder="#B8962E"' );
		self::field( 'إخفاء الويدجت في مسارات تحتوي على (سطر لكل مسار)', 'hide_paths', vai_opt( 'hide_paths', '' ), 'textarea', 'مثال: /checkout أو /wp-login', 'dir="ltr"' );
		self::field( 'إيقاف الويدجت مؤقتًا', 'widget_off', vai_opt( 'widget_off', 0 ), 'checkbox', 'لا تعرض الويدجت على هذا الموقع' );
		self::field( 'أنواع محتوى تُستثنى من المزامنة (مفصولة بفاصلة)', 'sync_exclude_types', vai_opt( 'sync_exclude_types', '' ), 'text', 'مثال: product, testimonial', 'dir="ltr"' );
		echo '<p><button class="button button-primary button-large">حفظ الإعدادات</button></p></form></div>';

		echo '<div class="vai-card"><h2>الحالة</h2>';
		$ping = get_option( 'vai_site_ping', array() );
		if ( ! VAI_Site::connected() ) {
			echo '<p>🔴 غير مرتبط — الصق رابط الهب ومفتاح الموقع ثم احفظ</p>';
		} elseif ( is_array( $ping ) && isset( $ping['ok'] ) ) {
			echo '<p>' . ( $ping['ok'] ? '🟢 متصل بالهب (' . esc_html( $ping['msg'] ) . ') — آخر فحص ' . esc_html( vai_riyadh( $ping['at'], 'H:i' ) ) : '🔴 الإعدادات محفوظة لكن الهب غير قابل للوصول: ' . esc_html( $ping['msg'] ) ) . '</p>';
		} else {
			echo '<p>🟡 الإعدادات محفوظة — اضغط «اختبار الاتصال بالهب» للتأكد</p>';
		}
		if ( VAI_Site::connected() && ! VAI_Site::config() ) {
			echo '<p>⚠️ الويدجت لن يظهر لأن الموقع لم يستطع جلب إعدادات الويدجت من الهب — راجع رابط الهب والمفتاح.</p>';
		}
		if ( $last ) {
			echo '<p>آخر مزامنة معرفة: ' . esc_html( vai_riyadh( $last['at'] ?? '' ) ) . ' — أُرسل ' . (int) ( $last['sent'] ?? 0 ) . ' من ' . (int) ( $last['total'] ?? 0 ) . ( ! empty( $last['errors'] ) ? ' (أخطاء: ' . (int) $last['errors'] . ')' : '' ) . '</p>';
		} else {
			echo '<p>لم تتم أي مزامنة بعد — المزامنة تلقائية يوميًا وعند نشر أي صفحة، وتقدر تشغّلها الآن.</p>';
		}
		self::form_open( 'test_connection' );
		echo '<button class="button">اختبار الاتصال بالهب</button></form> ';
		self::form_open( 'sync_now' );
		echo '<button class="button">مزامنة محتوى الموقع الآن</button></form>';
		echo '<h2 style="margin-top:22px">كيف يعمل</h2><ol class="vai-ol"><li>الزائر يكتب في الويدجت → الرسالة تمر من هذا الموقع إلى الهب → الهب يرسلها لعقل n8n → الرد يظهر في الويدجت خلال ثوانٍ.</li><li>كل صفحة منشورة هنا تصل لمعرفة المساعد تلقائيًا (يوميًا + فور النشر).</li><li>المتابعة والرد اليدوي والليدز من داشبورد الهب.</li></ol></div></div></div>';
	}

	/* ─────────────── hub pages ─────────────── */

	public static function page_dashboard() {
		if ( empty( vai_opt( 'n8n_webhook', '' ) ) ) {
			echo '<div class="notice notice-warning"><p>لم يُضبط رابط ويبهوك n8n بعد — <a href="' . esc_url( admin_url( 'admin.php?page=vibes-ai-settings' ) ) . '">افتح الإعدادات</a>.</p></div>';
		}
		self::wrap_open( 'لوحة المتابعة', 'كل من يكلّم المساعد على أي موقع في المنظومة — مباشر. اضغط على أي محادثة لعرضها، والرد اليدوي يوقف البوت لهذا العميل ' . (int) vai_cfg( 'human_pause_min' ) . ' دقيقة.' );
		$export = wp_nonce_url( admin_url( 'admin-post.php?action=vai_export' ), 'vai_export' );
		echo '<div id="vai-app" data-export="' . esc_url( $export ) . '"><div class="vai-loading">جارٍ التحميل…</div></div></div>';
	}

	public static function page_accounts() {
		$q    = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : '';
		$rows = VAI_Hub::accounts( $q );
		self::wrap_open( 'الحسابات المسجّلة', 'كل من أنشأ حسابًا من المساعد على أي موقع — بيانات منفصلة في جداول البلجن على هذا الموقع (كلمات المرور مشفّرة). من هنا تفعّل، وترقّي أدمن أو ناشرًا، وتعلّم عضوًا مدفوعًا.' );
		// 2.19.0 (owner, 2026-10-21): how many of each فئة among the accounts — always on top of the list.
		global $wpdb;
		$ct = VAI_Hub::t( 'contacts' );
		$pc = $wpdb->get_row( "SELECT SUM(CASE WHEN persona='neutral' THEN 1 ELSE 0 END) AS n, SUM(CASE WHEN persona='entrepreneur' THEN 1 ELSE 0 END) AS e, SUM(CASE WHEN persona='investor' THEN 1 ELSE 0 END) AS i FROM $ct WHERE (verified=1 OR is_member=1)", ARRAY_A );
		$pill = function ( $label, $value ) {
			return '<span style="background:#EDE4CF;border-radius:999px;padding:6px 14px;font-weight:600;display:inline-block">' . esc_html( $label ) . ': <span dir="ltr">' . (int) $value . '</span></span>';
		};
		echo '<div class="vai-card" style="margin-bottom:12px;display:flex;gap:10px;flex-wrap:wrap;align-items:center"><strong>فئات الأعضاء:</strong> '
			. $pill( 'المحايد', isset( $pc['n'] ) ? $pc['n'] : 0 ) . ' '
			. $pill( 'رائد الأعمال', isset( $pc['e'] ) ? $pc['e'] : 0 ) . ' '
			. $pill( 'المستثمر', isset( $pc['i'] ) ? $pc['i'] : 0 ) . '</div>';
		echo '<div class="vai-card"><form method="get" class="vai-inline" style="margin-bottom:12px"><input type="hidden" name="page" value="vibes-ai-accounts"><input type="search" name="q" value="' . esc_attr( $q ) . '" placeholder="بحث بالاسم / البريد / الجوال / الشركة" style="max-width:360px;padding:7px 10px;border:1px solid #d5d2cb;border-radius:8px"> <button class="button">بحث</button> <span class="vai-help" style="display:inline">(' . count( $rows ) . ')</span> <a class="button" style="margin-right:auto" target="_blank" rel="noopener" href="' . esc_url( home_url( '/?vai-console=1' ) ) . '">لوحة الإدارة للأدمنز ↗</a></form>';
		echo '<table class="vai-table"><thead><tr><th></th><th>الاسم</th><th>البريد / الجوال</th><th>الوظيفة / الشركة</th><th>الحالة</th><th>الدور</th><th>آخر دخول</th><th>الموقع</th><th></th></tr></thead><tbody>';
		if ( ! $rows ) {
			echo '<tr><td colspan="9" class="vai-empty">لا توجد حسابات بعد.</td></tr>';
		}
		foreach ( $rows as $c ) {
			$left   = VAI_Hub::trial_days_left( $c );
			$status = $c->is_member ? ( VAI_Hub::member_active( $c ) ? '⭐ عضو مفعّل' : '⌛ عضوية منتهية' ) : ( ! (int) $c->verified ? '✉️ بانتظار تفعيل البريد' : '⚠️ عضو غير مفعّل — لم يدفع' );
			$role   = $c->role === 'admin' ? ( (int) $c->admin_verified ? '🛡️ أدمن' : '🛡️ أدمن (لم يفعّل الكود)' ) : ( $c->role === 'publisher' ? '✍️ ناشر' : 'عضو' );
			echo '<tr><td>' . ( $c->avatar_url ? '<img src="' . esc_url( $c->avatar_url ) . '" alt="" style="width:34px;height:34px;border-radius:50%;object-fit:cover">' : '' ) . '</td><td><a href="' . esc_url( admin_url( 'admin.php?page=vibes-ai&contact=' . (int) $c->id ) ) . '"><strong>' . esc_html( $c->name ) . '</strong></a>' . ( $c->city ? '<br><small>' . esc_html( $c->city ) . '</small>' : '' ) . '</td><td dir="ltr">' . esc_html( $c->email ) . '<br>' . esc_html( vai_phone_local( $c->phone_norm ?: $c->phone ) ) . '</td><td>' . ( 'company' === $c->member_type ? '<span style="background:#EDE4CF;border-radius:6px;padding:1px 6px;font-size:11px">🏢 شركة</span> ' : '' ) . esc_html( trim( $c->job_title . ( $c->company ? ' — ' . $c->company : '' ), ' —' ) ) . ( $c->persona ? '<br><small>' . esc_html( VAI_Hub::persona_label( $c->persona ) ) . '</small>' : '' ) . ( $c->website ? '<br><a dir="ltr" href="' . esc_url( $c->website ) . '" target="_blank" rel="noopener">' . esc_html( vai_clip( $c->website, 34 ) ) . '</a>' : '' ) . '</td><td>' . $status . '</td><td>' . $role . '</td><td>' . esc_html( vai_riyadh( $c->last_login_at ) ) . '</td><td dir="ltr">' . esc_html( $c->host ) . '</td><td style="white-space:nowrap">';
			$btn = function ( $act, $label, $confirm = '' ) use ( $c ) {
				self::form_open( 'account_action' );
				echo '<input type="hidden" name="id" value="' . (int) $c->id . '"><input type="hidden" name="act" value="' . esc_attr( $act ) . '"><button class="button button-small"' . ( $confirm ? ' onclick="return confirm(\'' . esc_js( $confirm ) . '\')"' : '' ) . '>' . esc_html( $label ) . '</button></form> ';
			};
			if ( ! (int) $c->verified ) {
				$btn( 'verify', 'تفعيل يدوي' );
			}
			if ( $c->role === 'admin' ) {
				$btn( 'demote', 'إلغاء الأدمن', 'إلغاء صلاحية الأدمن؟' );
			} else {
				$btn( 'promote', 'ترقية إلى أدمن', 'ترقية ' . $c->name . ' إلى أدمن؟ سيصله بريد فيه كود التفعيل وتعليمات الدخول من vcmem.' );
				if ( $c->role === 'publisher' ) {
					$btn( 'unpublisher', 'إلغاء الناشر', 'إلغاء صلاحية النشر عن ' . $c->name . '؟' );
				} elseif ( (int) $c->verified ) {
					$btn( 'publisher', 'ترقية إلى ناشر', 'ترقية ' . $c->name . ' إلى ناشر؟ يستطيع نشر المنشورات والفعاليات من لوحة التطبيق فقط، بلا أي صلاحية إدارية أخرى.' );
				}
			}
			$btn( 'member', $c->is_member ? 'إلغاء العضوية' : 'تعليم كعضو مدفوع' );
			$btn( 'delete', 'حذف', 'حذف الحساب وكل محادثاته نهائيًا؟' );
			echo '</td></tr>';
		}
		echo '</tbody></table></div></div>';
	}

	public static function page_mail() {
		global $wpdb;
		$st  = VAI_Payments::queue_stats();
		$aud = array( 'paid' => count( VAI_Payments::audience( 'paid' ) ), 'unpaid' => count( VAI_Payments::audience( 'unpaid' ) ), 'all' => count( VAI_Payments::audience( 'all' ) ) );
		$pt  = $wpdb->prefix . 'vai_payments';
		$pay = (array) $wpdb->get_results( "SELECT * FROM $pt ORDER BY id DESC LIMIT 100" );
		$q   = (array) $wpdb->get_results( 'SELECT * FROM ' . VAI_Payments::table() . ' ORDER BY id DESC LIMIT 60' );
		self::wrap_open( 'الرسائل البريدية والمدفوعات', 'أرسل رسائل للأعضاء المفعّلين متى شئت — تُجدول وتُرسل تلقائيًا واحدة كل 5 دقائق (12 في الساعة) لتفادي حظر البريد. الرسالة الأسبوعية للأعضاء والدفع التلقائي عبر Paymob هنا أيضًا.' );
		echo '<div class="vai-grid2"><div class="vai-card"><h2>رسالة جديدة للأعضاء</h2>';
		self::form_open( 'campaign' );
		echo '<div class="vai-field"><label>إلى</label><select name="audience"><option value="paid">الأعضاء المفعّلون (' . (int) $aud['paid'] . ')</option><option value="unpaid">حسابات لم تدفع بعد (' . (int) $aud['unpaid'] . ')</option><option value="all">كل الحسابات المفعّلة بالبريد (' . (int) $aud['all'] . ')</option></select></div>';
		echo '<div class="vai-field"><label>الفئة</label><select name="persona"><option value="">كل الفئات</option><option value="entrepreneur">رواد الأعمال فقط</option><option value="investor">المستثمرون فقط</option><option value="neutral">المحايدون فقط</option></select></div>';
		echo '<div class="vai-field"><label>العنوان</label><input type="text" name="subject" placeholder="مثال: يا {name}، ملتقى النادي القادم"></div>';
		echo '<div class="vai-field"><label>النص</label><textarea name="body" rows="10" placeholder="المتغيرات: {name} {phone} {email} {end_date} {pb_left} {pb_url} {podcast_wa} {pitchdeck_url} {urmeet_url} {mgmt} {pay_url}"></textarea></div>';
		echo '<p><button class="button button-primary button-large">جدولة الإرسال الآن</button> <button class="button" name="op" value="campaign_test" formaction="' . esc_url( admin_url( 'admin-post.php' ) ) . '">أرسل نسخة تجريبية لي</button></p></form>';
		echo '</div><div class="vai-card"><h2>طابور الإرسال</h2><p>قيد الانتظار: <b>' . (int) $st['pending'] . '</b> · أُرسلت: <b>' . (int) $st['sent'] . '</b> · فشلت: <b>' . (int) $st['failed'] . '</b></p>';
		self::form_open( 'queue_clear' );
		echo '<p><button class="button" onclick="return confirm(\'إلغاء كل الرسائل المنتظرة؟\')">إلغاء ما لم يُرسل</button></p></form>';
		self::form_open( 'weekly_now' );
		echo '<p><button class="button">أدخل الرسالة الأسبوعية في الطابور الآن</button> <span class="vai-help" style="display:inline">(يدوي فقط — البث التلقائي أصبح «كل يومين» أدناه.)</span></p></form>';
		self::form_open( 'broadcast_now' );
		echo '<p><button class="button" onclick="return confirm(\'إرسال دفعة التذكير لكل الجمهورين الآن؟\')">أرسل دفعة التذكير المتناوبة الآن (يدوي)</button> <span class="vai-help" style="display:inline">🔕 لا يُرسل أي شيء تلقائيًا — كل الإرسال بزر منك (قرار 2.15.1 بعد شكاوى كثرة الرسائل). آخر دفعة: <b>' . esc_html( (string) get_option( 'vai_broadcast_last', '—' ) ) . '</b></p></form>';
		echo '<table class="vai-table"><thead><tr><th>إلى</th><th>العنوان</th><th>النوع</th><th>الحالة</th><th>وقت الإرسال</th></tr></thead><tbody>';
		if ( ! $q ) {
			echo '<tr><td colspan="5" class="vai-empty">لا رسائل بعد.</td></tr>';
		}
		foreach ( $q as $r ) {
			echo '<tr><td dir="ltr">' . esc_html( $r->to_email ) . '</td><td>' . esc_html( $r->subject ) . '</td><td>' . esc_html( $r->kind ) . '</td><td>' . ( $r->status === 'sent' ? '✅' : ( $r->status === 'failed' ? '❌' : '⏳' ) ) . '</td><td>' . esc_html( $r->sent_at ? vai_riyadh( $r->sent_at ) : '' ) . '</td></tr>';
		}
		echo '</tbody></table></div></div>';
		$tk = (array) $wpdb->get_results( 'SELECT * FROM ' . VAI_Payments::tickets_table() . ' ORDER BY id DESC LIMIT 100' );
		echo '<div class="vai-grid2" style="margin-top:16px"><div class="vai-card"><h2>🎟️ إصدار تذكرة يدويًا</h2>';
		self::form_open( 'issue_ticket' );
		echo '<div class="vai-field"><label>الاسم</label><input type="text" name="t_name"></div><div class="vai-field"><label>الجوال</label><input type="text" name="t_phone" dir="ltr" placeholder="0512345678"></div><div class="vai-field"><label>البريد</label><input type="email" name="t_email" dir="ltr"></div><p><button class="button button-primary">إصدار وإرسال التذكرة</button></p></form><p class="vai-help">للفعالية الحالية: ' . esc_html( vai_cfg( 'event_title' ) ) . ' — ' . esc_html( vai_cfg( 'event_date' ) ) . '</p></div>';
		echo '<div class="vai-card"><h2>التذاكر الصادرة (' . count( $tk ) . ')</h2><table class="vai-table"><thead><tr><th>المرجع</th><th>الاسم</th><th>الجوال</th><th>البريد</th><th>المصدر</th><th>التاريخ</th></tr></thead><tbody>';
		if ( ! $tk ) {
			echo '<tr><td colspan="6" class="vai-empty">لا تذاكر بعد.</td></tr>';
		}
		foreach ( $tk as $r ) {
			echo '<tr><td><a href="' . esc_url( VAI_Payments::ticket_url( $r->ref ) ) . '" target="_blank" rel="noopener"><b>' . esc_html( $r->ref ) . '</b></a></td><td>' . esc_html( $r->name ) . '</td><td dir="ltr">' . esc_html( $r->phone ) . '</td><td dir="ltr">' . esc_html( $r->email ) . '</td><td>' . esc_html( $r->source ) . '</td><td>' . esc_html( vai_riyadh( $r->created_at ) ) . '</td></tr>';
		}
		echo '</tbody></table></div></div>';
		echo '<div class="vai-grid2" style="margin-top:16px"><div class="vai-card"><h2>⭐ تفعيل عضوية لشخص دفع من قبل (بدون حساب)</h2>';
		self::form_open( 'activate_by_data' );
		echo '<div class="vai-field"><label>الاسم</label><input type="text" name="a_name"></div><div class="vai-field"><label>الجوال</label><input type="text" name="a_phone" dir="ltr" placeholder="0512345678"></div><div class="vai-field"><label>البريد</label><input type="email" name="a_email" dir="ltr"></div><p><button class="button button-primary">إنشاء الحساب وتفعيل العضوية وإرسال رابط كلمة المرور</button></p></form><p class="vai-help">للناس اللي دفعوا قبل ربط Paymob أو بتحويل بنكي: يُنشأ لهم حساب مفعّل فورًا ويصلهم إيميل برابط لاختيار كلمة المرور والدخول مباشرة.</p></div>';
		echo '<div class="vai-card"><h2>🔁 مطابقة المدفوعات غير المرتبطة</h2><p class="vai-help">أي دفعة عضوية ناجحة بلا حساب مطابق: يُنشأ الحساب تلقائيًا وتُفعَّل العضوية ويُرسل رابط كلمة المرور. يعمل تلقائيًا كل ساعة، أو الآن:</p>';
		self::form_open( 'rematch_payments' );
		echo '<p><button class="button">طابق الآن</button></p></form></div></div>';
		echo '<div class="vai-card" style="margin-top:16px"><h2>💳 المدفوعات الواردة من Paymob</h2><table class="vai-table"><thead><tr><th>التاريخ</th><th>الاسم</th><th>الجوال</th><th>البريد</th><th>المبلغ/الخدمة</th><th>النتيجة</th></tr></thead><tbody>';
		if ( ! $pay ) {
			echo '<tr><td colspan="6" class="vai-empty">لا مدفوعات بعد — بعد ضبط رابط الإشعار في Paymob تظهر هنا كل دفعة.</td></tr>';
		}
		foreach ( $pay as $r ) {
			echo '<tr><td>' . esc_html( vai_riyadh( $r->created_at ) ) . '</td><td>' . esc_html( $r->name ) . '</td><td dir="ltr">' . esc_html( $r->phone ) . '</td><td dir="ltr">' . esc_html( $r->email ) . '</td><td>' . esc_html( $r->note ) . '</td><td>' . ( $r->success ? ( $r->action === 'membership' ? ( $r->contact_id ? '⭐ عضوية مفعّلة' : '⏳ بانتظار إنشاء الحساب' ) : '💳 ' . esc_html( $r->action ?: 'مبلغ غير معروف' ) ) : '❌ غير ناجحة' ) . '</td></tr>';
		}
		echo '</tbody></table></div></div>';
	}

	public static function page_instructions() {
		self::wrap_open( 'التوجيهات والروابط', 'هنا تقود المساعد بلغتك: على ماذا يركّز، بماذا يتكلم، وأي روابط يفتحها للعميل — كل شيء يصل له من الرسالة التالية بلا n8n.' );
		self::form_open( 'instructions' );
		echo '<div class="vai-grid2"><div class="vai-card"><h2>توجيهات الإدارة</h2>';
		self::field( 'اكتبها كما تكلّم موظفًا — سطر لكل توجيه (لها الأولوية على كل شيء)', 'extra_instructions', vai_opt( 'extra_instructions', '' ), 'textarea', 'أمثلة: «ركّز هذا الشهر على عضوية النادي» — «أي مستثمر: خذ اسمه وجواله وأعطه زر الإدارة فورًا» — «لا تذكر أسعار الخدمات قبل ما يسأل» — «لما يسأل عن الملتقيات قل إن المواعيد عند فريق النادي» — «نبرة أهدأ وأقصر».', 'rows="14"' );
		echo '<h2>الفتح التلقائي للصفحات</h2>';
		self::field( 'الفتح التلقائي', 'auto_open', vai_cfg( 'auto_open' ), 'checkbox', 'إذا طلب العميل فتح صفحة (بكلمة من القائمة أدناه) وذكر المساعد رابطًا من المنظومة في رده، يُفتح الرابط تلقائيًا حتى لو لم يصدر المساعد أمر الفتح بنفسه' );
		self::field( 'كلمات طلب الفتح (مفصولة بفاصلة)', 'auto_open_words', vai_cfg( 'auto_open_words' ), 'textarea', '', 'rows="3"' );
		echo '<p><button class="button button-primary button-large">حفظ</button></p></div>';
		echo '<div class="vai-card"><h2>مكتبة الروابط المعتمدة</h2>';
		self::field( 'سطر لكل رابط بالشكل: العنوان | الرابط | متى يستخدمه', 'links', vai_cfg( 'links' ), 'textarea', 'المساعد يفتح هذه الصفحات للعميل مباشرة (على أي موقع في المنظومة) أو يرسلها كزر. أضف أي صفحة جديدة هنا وسيعرفها فورًا. الدومينات في هذه القائمة تُسمح روابطها تلقائيًا.', 'rows="26" dir="ltr" style="font-family:monospace;font-size:12.5px"' );
		echo '<p><button class="button button-primary button-large">حفظ</button></p></div></div></form>';
		echo '<div class="vai-card" style="margin-top:16px"><h2>حساب للمدير أو للفريق (يرى المحادثات ويرد)</h2><ol class="vai-ol"><li>الأعضاء → أضف جديد → اختر الدور «مشرف Vibes AI» → أرسل له اسم المستخدم وكلمة المرور.</li><li>رابط لوحة المتابعة الذي ترسله له: <code class="vai-code">' . esc_html( admin_url( 'admin.php?page=vibes-ai' ) ) . '</code></li><li>هذا الدور يرى لوحة المتابعة فقط (كل المحادثات من كل المواقع، الرد اليدوي، تعليم الأعضاء، التصدير) ولا يرى الإعدادات ولا باقي الموقع.</li></ol></div></div>';
	}

	public static function page_sites() {
		self::wrap_open( 'المواقع المرتبطة', 'أضف كل موقع في المنظومة هنا، ثم الصق مفتاحه في إعدادات البلجن على ذلك الموقع (وضع «موقع تابع»).' );
		echo '<div class="vai-grid2"><div class="vai-card">';
		self::form_open( 'add_site' );
		echo '<h2>إضافة موقع</h2>';
		self::field( 'اسم الموقع', 'name', '', 'text', '', 'placeholder="وديني"' );
		self::field( 'الدومين', 'host', '', 'text', 'بدون https وبدون www', 'placeholder="wdeny.com" dir="ltr"' );
		self::field( 'لون الويدجت لهذا الموقع (اختياري)', 'color', '', 'text', '', 'placeholder="#B8962E" dir="ltr"' );
		echo '<p><button class="button button-primary">إضافة وتوليد مفتاح</button></p></form></div>';
		echo '<div class="vai-card"><h2>المواقع</h2><table class="vai-table"><thead><tr><th>الموقع</th><th>الدومين</th><th>الحالة</th><th>صفحات المعرفة</th><th>آخر مزامنة</th><th>آخر ظهور</th><th>الصلاحيات</th><th></th></tr></thead><tbody>';
		foreach ( VAI_Hub::sites_all() as $s ) {
			$trusted = ! empty( $s->trusted );
			echo '<tr><td>' . esc_html( $s->name ) . ( $s->is_self ? ' <span class="vai-badge">الهب</span>' : '' ) . ( $trusted ? ' <span class="vai-badge vai-badge-dark">خادم التطبيق</span>' : '' ) . '</td><td dir="ltr">' . esc_html( $s->host ) . '</td><td>' . ( $s->status === 'active' ? '🟢 نشط' : '⚪ معطل' ) . '</td><td>' . (int) $s->knowledge_count . '</td><td>' . esc_html( vai_riyadh( $s->last_sync ) ) . '</td><td>' . esc_html( vai_riyadh( $s->last_seen ) ) . '</td><td>';
			if ( ! $s->is_self ) {
				self::form_open( 'site_trusted' );
				echo '<input type="hidden" name="id" value="' . (int) $s->id . '"><label class="vai-trust"><input type="checkbox" name="trusted" value="1" ' . checked( $trusted, true, false ) . '> خادم التطبيق (صلاحيات إدارية)</label> <button class="button button-small" onclick="return confirm(\'تغيير الصلاحيات الإدارية لهذا الموقع؟ فعّلها لخادم التطبيق وحده.\')">حفظ</button></form>';
			}
			echo '</td><td>';
			if ( ! $s->is_self ) {
				self::form_open( 'add_site' );
				echo '<input type="hidden" name="name" value="' . esc_attr( $s->name ) . '"><input type="hidden" name="host" value="' . esc_attr( $s->host ) . '"><button class="button button-small" onclick="return confirm(\'توليد مفتاح جديد يلغي القديم — متأكد؟\')">مفتاح جديد</button></form> ';
				self::form_open( 'delete_site' );
				echo '<input type="hidden" name="id" value="' . (int) $s->id . '"><button class="button button-small" onclick="return confirm(\'تعطيل الموقع؟\')">تعطيل</button></form>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table><p class="vai-help">«خادم التطبيق (صلاحيات إدارية)»: علّمها لصف خادم تطبيق نادي المستثمرين وحده — تسمح لمفتاحه بتفعيل العضويات من المتجر وقراءة لوحة الإدارة والنشر. أي موقع آخر يبقى بدونها.</p></div></div></div>';
	}

	public static function page_knowledge() {
		global $wpdb;
		self::wrap_open( 'معرفة المساعد', 'المصدر الأول: صفحات المواقع (تُزامَن تلقائيًا). المصدر الثاني: ملاحظات تكتبها هنا وتدخل معرفة المساعد فورًا — أسعار، سياسات، ردود على أسئلة متكررة، أي جديد.' );
		echo '<div class="vai-grid2"><div class="vai-card">';
		self::form_open( 'add_note' );
		echo '<h2>علّم المساعد شيئًا جديدًا</h2>';
		self::field( 'العنوان', 'title', '', 'text', '', 'placeholder="مثال: مواعيد ملتقى 5 دقائق لهذا الشهر"' );
		self::field( 'المحتوى', 'content', '', 'textarea', 'اكتبه كما تحب أن يقوله المساعد للعميل. الروابط مسموحة إن كانت داخل دومينات المنظومة.', 'rows="7"' );
		echo '<p><button class="button button-primary">إضافة للمعرفة</button></p></form>';
		echo '<h2 style="margin-top:20px">اختبار البحث</h2><p class="vai-help">اكتب سؤالًا كما يكتبه العميل لترى ما سيجده المساعد.</p><div class="vai-inline"><input type="text" id="vai-search-q" placeholder="مثال: كم سعر اصنع ملتقاك؟"> <button class="button" id="vai-search-btn">ابحث</button></div><div id="vai-search-out"></div></div>';
		echo '<div class="vai-card"><h2>الملاحظات</h2><table class="vai-table"><thead><tr><th>العنوان</th><th>المحتوى</th><th>التاريخ</th><th></th></tr></thead><tbody>';
		$notes = VAI_Hub::notes_all();
		if ( ! $notes ) {
			echo '<tr><td colspan="4" class="vai-empty">لا توجد ملاحظات بعد — أضف أول معلومة من النموذج المجاور.</td></tr>';
		}
		foreach ( $notes as $n ) {
			echo '<tr><td>' . esc_html( $n->title ) . '</td><td>' . esc_html( vai_clip( $n->content, 160 ) ) . '</td><td>' . esc_html( vai_riyadh( $n->updated_at ) ) . '</td><td>';
			self::form_open( 'delete_note' );
			echo '<input type="hidden" name="id" value="' . (int) $n->id . '"><button class="button button-small" onclick="return confirm(\'حذف؟\')">حذف</button></form></td></tr>';
		}
		echo '</tbody></table>';
		$kt   = VAI_Hub::t( 'knowledge' );
		$st   = VAI_Hub::t( 'sites' );
		$rows = $wpdb->get_results( "SELECT k.title, k.url, k.kind, k.updated_at, s.host FROM $kt k LEFT JOIN $st s ON s.id=k.site_id WHERE k.kind IN ('page','post') ORDER BY k.updated_at DESC LIMIT 40" );
		echo '<h2 style="margin-top:20px">آخر الصفحات المُزامَنة</h2><table class="vai-table"><thead><tr><th>الصفحة</th><th>الموقع</th><th>آخر تحديث</th></tr></thead><tbody>';
		if ( ! $rows ) {
			echo '<tr><td colspan="3" class="vai-empty">لم تصل أي صفحات بعد — شغّل «مزامنة محتوى الموقع الآن» من إعدادات كل موقع.</td></tr>';
		}
		foreach ( (array) $rows as $r ) {
			echo '<tr><td><a href="' . esc_url( $r->url ) . '" target="_blank" rel="noopener">' . esc_html( vai_clip( $r->title, 70 ) ) . '</a></td><td dir="ltr">' . esc_html( $r->host ) . '</td><td>' . esc_html( vai_riyadh( $r->updated_at ) ) . '</td></tr>';
		}
		echo '</tbody></table></div></div></div>';
	}

	public static function page_services() {
		$edit = isset( $_GET['edit'] ) ? (int) $_GET['edit'] : 0;
		$all  = VAI_Hub::services_all( false );
		$cur  = null;
		foreach ( $all as $s ) {
			if ( (int) $s['id'] === $edit ) {
				$cur = $s;
			}
		}
		self::wrap_open( 'الخدمات والأسعار', 'هذا الكتالوج هو مرجع المساعد للأسعار والروابط ونقاط الإقناع — أي تعديل هنا يصل للمساعد في الرسالة التالية مباشرة. المفتاح «membership» مخصص لكارت العضوية وبوابة الاشتراك.' );
		echo '<div class="vai-grid2"><div class="vai-card">';
		self::form_open( 'save_service' );
		echo '<h2>' . ( $cur ? 'تعديل خدمة' : 'إضافة خدمة' ) . '</h2>';
		echo '<input type="hidden" name="id" value="' . ( $cur ? (int) $cur['id'] : 0 ) . '">';
		self::field( 'المفتاح (إنجليزي بدون مسافات)', 'skey', $cur ? $cur['skey'] : '', 'text', 'مثال: urmeet — يستخدمه المساعد لعرض الكارت', 'dir="ltr" ' . ( $cur ? 'readonly' : '' ) );
		self::field( 'اسم الخدمة', 'name', $cur ? $cur['name'] : '' );
		echo '<div class="vai-inline">';
		self::field( 'السعر', 'price', $cur ? $cur['price'] : '', 'text', 'اتركه فارغًا إذا كان حسب الاحتياج', 'dir="ltr" placeholder="30,000"' );
		self::field( 'العملة', 'currency', $cur ? $cur['currency'] : 'ريال' );
		echo '</div>';
		self::field( 'ملاحظة السعر / الضريبة', 'vat_note', $cur ? $cur['vat_note'] : '', 'text', 'مثال: غير شاملة الضريبة' );
		self::field( 'شروط الدفع', 'payment_terms', $cur ? $cur['payment_terms'] : '' );
		self::field( 'صفحة الخدمة', 'url', $cur ? $cur['url'] : '', 'url', '', 'dir="ltr"' );
		self::field( 'رابط الدفع (Paymob…)', 'pay_url', $cur ? $cur['pay_url'] : '', 'url', '', 'dir="ltr"' );
		self::field( 'خصم الأعضاء', 'member_discount', $cur ? $cur['member_discount'] : '', 'text', 'مثال: خصم 50% لأعضاء النادي' );
		self::field( 'ماذا تشمل (سطر لكل بند — تظهر في الكارت)', 'includes', $cur ? $cur['includes'] : '', 'textarea' );
		self::field( 'نقاط الإقناع وتعليمات للمساعد', 'pitch', $cur ? $cur['pitch'] : '', 'textarea', 'لا تُعرض للعميل حرفيًا — يستخدمها المساعد بأسلوبه.' );
		echo '<div class="vai-inline">';
		self::field( 'الترتيب', 'sort', $cur ? $cur['sort'] : 10, 'number' );
		self::field( 'مفعّلة', 'active', $cur ? $cur['active'] : 1, 'checkbox', 'المساعد يعرف هذه الخدمة' );
		echo '</div>';
		echo '<p><button class="button button-primary">حفظ</button> ' . ( $cur ? '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=vibes-ai-services' ) ) . '">إلغاء</a>' : '' ) . '</p></form></div>';
		echo '<div class="vai-card"><h2>الكتالوج</h2><table class="vai-table"><thead><tr><th>الخدمة</th><th>السعر</th><th>خصم الأعضاء</th><th>الحالة</th><th></th></tr></thead><tbody>';
		foreach ( $all as $s ) {
			echo '<tr><td><strong>' . esc_html( $s['name'] ) . '</strong><br><code>' . esc_html( $s['skey'] ) . '</code></td><td>' . esc_html( $s['price'] ? $s['price'] . ' ' . $s['currency'] : 'حسب الاحتياج' ) . '</td><td>' . esc_html( $s['member_discount'] ) . '</td><td>' . ( $s['active'] ? '🟢' : '⚪' ) . '</td><td><a class="button button-small" href="' . esc_url( admin_url( 'admin.php?page=vibes-ai-services&edit=' . (int) $s['id'] ) ) . '">تعديل</a> ';
			self::form_open( 'delete_service' );
			echo '<input type="hidden" name="id" value="' . (int) $s['id'] . '"><button class="button button-small" onclick="return confirm(\'حذف الخدمة؟\')">حذف</button></form></td></tr>';
		}
		echo '</tbody></table></div></div></div>';
	}

	public static function page_forms() {
		global $wpdb;
		$edit = isset( $_GET['edit'] ) ? (int) $_GET['edit'] : 0;
		$rows = $wpdb->get_results( 'SELECT * FROM ' . VAI_Hub::t( 'forms' ) . ' ORDER BY id ASC', ARRAY_A );
		$cur  = null;
		foreach ( (array) $rows as $r ) {
			if ( (int) $r['id'] === $edit ) {
				$cur = $r;
			}
		}
		self::wrap_open( 'الفورمات التي يعبّيها المساعد', 'المساعد يجمع البيانات من العميل في المحادثة، ثم يفتح صفحة الفورم ويعبّي الحقول ويعمل سكرول لها. المرفقات وخانة الموافقة وزر الإرسال يعملها العميل بنفسه.' );
		echo '<div class="vai-grid2"><div class="vai-card">';
		self::form_open( 'save_form' );
		echo '<h2>' . ( $cur ? 'تعديل فورم' : 'إضافة فورم' ) . '</h2><input type="hidden" name="id" value="' . ( $cur ? (int) $cur['id'] : 0 ) . '">';
		self::field( 'المفتاح', 'fkey', $cur ? $cur['fkey'] : '', 'text', 'مثال: sp', 'dir="ltr" ' . ( $cur ? 'readonly' : '' ) );
		self::field( 'الاسم', 'label', $cur ? $cur['label'] : '' );
		self::field( 'رابط صفحة الفورم', 'url', $cur ? $cur['url'] : '', 'url', 'يمكن إضافة #القسم ليتم السكرول إليه', 'dir="ltr"' );
		$map_default = "{\n  \"name\": {\"label\": \"الاسم الكامل\", \"selector\": \"\"},\n  \"phone\": {\"label\": \"رقم الجوال\", \"selector\": \"\"},\n  \"email\": {\"label\": \"البريد الإلكتروني\", \"selector\": \"\"}\n}";
		self::field( 'خريطة الحقول (JSON)', 'field_map', $cur ? wp_json_encode( json_decode( $cur['field_map'], true ), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ) : $map_default, 'textarea', 'المفتاح = اسم منطقي يفهمه المساعد (name, phone, email, nationality, id_number, project, company, city, notes). «selector» اختياري: CSS selector للحقل داخل الصفحة (مثال: input[name=\'names[first_name]\']). لو تركته فارغًا يبحث الويدجت عن الحقل تلقائيًا بالاسم واللابل.', 'rows="10" dir="ltr" style="font-family:monospace"' );
		self::field( 'ملاحظات للمساعد', 'notes', $cur ? $cur['notes'] : '', 'textarea' );
		self::field( 'مفعّل', 'active', $cur ? $cur['active'] : 1, 'checkbox', 'المساعد يستطيع استخدام هذا الفورم' );
		echo '<p><button class="button button-primary">حفظ</button> ' . ( $cur ? '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=vibes-ai-forms' ) ) . '">إلغاء</a>' : '' ) . '</p></form></div>';
		echo '<div class="vai-card"><h2>الفورمات</h2><table class="vai-table"><thead><tr><th>الفورم</th><th>الرابط</th><th>الحقول</th><th></th></tr></thead><tbody>';
		foreach ( (array) $rows as $r ) {
			$map = json_decode( (string) $r['field_map'], true );
			echo '<tr><td><strong>' . esc_html( $r['label'] ) . '</strong><br><code>' . esc_html( $r['fkey'] ) . '</code></td><td dir="ltr">' . esc_html( vai_clip( $r['url'], 50 ) ) . '</td><td>' . esc_html( is_array( $map ) ? implode( '، ', array_keys( $map ) ) : '' ) . '</td><td><a class="button button-small" href="' . esc_url( admin_url( 'admin.php?page=vibes-ai-forms&edit=' . (int) $r['id'] ) ) . '">تعديل</a> ';
			self::form_open( 'delete_form' );
			echo '<input type="hidden" name="id" value="' . (int) $r['id'] . '"><button class="button button-small" onclick="return confirm(\'حذف؟\')">حذف</button></form></td></tr>';
		}
		echo '</tbody></table></div></div></div>';
	}

	public static function page_members() {
		global $wpdb;
		$paid  = VAI_Hub::paid_members();
		$accts = array_values( array_filter( VAI_Hub::accounts( '', 400 ), function ( $c ) { return ! (int) $c->is_member; } ) );
		$t     = VAI_Hub::t( 'members' );
		$imp   = $wpdb->get_results( "SELECT * FROM $t ORDER BY id DESC LIMIT 300" );
		$days  = (int) vai_cfg( 'member_days' );
		self::wrap_open( 'الأعضاء', 'كل من سجّل حسابًا يظهر هنا. اضغط «تحويل إلى عضوية مدفوعة» فيبدأ عدّاد ' . $days . ' يومًا تلقائيًا ويتحول تعامل المساعد معه إلى تعامل الأعضاء (بلا بوابات، برصيد يومي ' . (int) vai_cfg( 'member_daily' ) . ' رد يتجدد كل يوم).' );
		$btn = function ( $id, $act, $label, $back, $confirm = '' ) {
			self::form_open( 'account_action' );
			echo '<input type="hidden" name="id" value="' . (int) $id . '"><input type="hidden" name="act" value="' . esc_attr( $act ) . '"><input type="hidden" name="back" value="' . esc_attr( $back ) . '"><button class="button button-small"' . ( $confirm ? ' onclick="return confirm(\'' . esc_js( $confirm ) . '\')"' : '' ) . '>' . esc_html( $label ) . '</button></form> ';
		};
		echo '<div class="vai-card" style="margin-bottom:16px;border-color:#B8962E"><h2>⭐ الأعضاء المدفوعون (' . count( $paid ) . ')</h2><table class="vai-table"><thead><tr><th>الاسم</th><th>البريد / الجوال</th><th>بداية العضوية</th><th>باقي</th><th>رصيد اليوم</th><th>الموقع</th><th></th></tr></thead><tbody>';
		if ( ! $paid ) {
			echo '<tr><td colspan="7" class="vai-empty">لا يوجد أعضاء مدفوعون بعد — حوّل أي حساب من الجدول التالي.</td></tr>';
		}
		foreach ( $paid as $c ) {
			$left  = VAI_Hub::member_days_left( $c );
			$used  = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . VAI_Hub::t( 'messages' ) . " WHERE contact_id=%d AND role='assistant' AND created_at>=%s", $c->id, vai_riyadh_day_start_utc() ) );
			echo '<tr><td><a href="' . esc_url( admin_url( 'admin.php?page=vibes-ai&contact=' . (int) $c->id ) ) . '"><strong>' . esc_html( $c->name ?: 'بدون اسم' ) . '</strong></a>' . ( $c->company ? '<br><small>' . esc_html( $c->company ) . '</small>' : '' ) . '</td><td dir="ltr">' . esc_html( $c->email ) . '<br>' . esc_html( vai_phone_local( $c->phone_norm ?: $c->phone ) ) . '</td><td>' . esc_html( vai_riyadh( $c->member_started_at, 'Y-m-d' ) ) . '</td><td>' . ( $left === null ? 'بلا مدة' : ( $left > 0 ? '<strong>' . (int) $left . '</strong> يوم من ' . (int) ( $c->member_days ?: $days ) : '<span style="color:#A32A22">منتهية</span>' ) ) . '</td><td>' . max( 0, (int) vai_cfg( 'member_daily' ) - $used ) . ' / ' . (int) vai_cfg( 'member_daily' ) . '</td><td dir="ltr">' . esc_html( $c->host ) . '</td><td style="white-space:nowrap">';
			$btn( $c->id, 'renew', 'تجديد ' . $days . ' يوم', 'vibes-ai-members', 'تجديد العضوية من اليوم؟' );
			$btn( $c->id, 'member', 'إلغاء العضوية', 'vibes-ai-members', 'إلغاء العضوية المدفوعة؟' );
			self::form_open( 'pb_grant' );
			echo '<input type="hidden" name="cid" value="' . (int) $c->id . '"><input type="number" name="amount" min="1" max="1000" placeholder="ريال" style="width:64px"> <input type="text" name="note" placeholder="السبب (اختياري)" style="width:110px"> <button class="button" onclick="return confirm(\'إضافة هذا الرصيد في بنك المشاريع؟\')">+ رصيد البنك</button></form>';
			echo '</td></tr>';
		}
		echo '</tbody></table></div>';
		echo '<div class="vai-card" style="margin-bottom:16px"><h2>الحسابات المسجّلة — غير مدفوعة (' . count( $accts ) . ')</h2><table class="vai-table"><thead><tr><th>الاسم</th><th>البريد / الجوال</th><th>الحالة</th><th>الوظيفة / الشركة</th><th>الموقع</th><th></th></tr></thead><tbody>';
		if ( ! $accts ) {
			echo '<tr><td colspan="6" class="vai-empty">لا توجد حسابات مسجّلة بعد.</td></tr>';
		}
		foreach ( $accts as $c ) {
			$left   = VAI_Hub::trial_days_left( $c );
			$status = ! (int) $c->verified ? '✉️ بانتظار تفعيل البريد' : '⚠️ عضو غير مفعّل — لم يدفع';
			echo '<tr><td><a href="' . esc_url( admin_url( 'admin.php?page=vibes-ai&contact=' . (int) $c->id ) ) . '"><strong>' . esc_html( $c->name ) . '</strong></a></td><td dir="ltr">' . esc_html( $c->email ) . '<br>' . esc_html( vai_phone_local( $c->phone_norm ?: $c->phone ) ) . '</td><td>' . $status . '</td><td>' . esc_html( trim( $c->job_title . ( $c->company ? ' — ' . $c->company : '' ), ' —' ) ) . '</td><td dir="ltr">' . esc_html( $c->host ) . '</td><td style="white-space:nowrap">';
			$btn( $c->id, 'member', '⭐ تحويل إلى عضوية مدفوعة', 'vibes-ai-members', 'تحويل ' . $c->name . ' إلى عضو مدفوع لمدة ' . $days . ' يومًا من اليوم؟' );
			echo '</td></tr>';
		}
		echo '</tbody></table></div>';
		echo '<div class="vai-grid2"><div class="vai-card">';
		self::form_open( 'import_members' );
		echo '<h2>أعضاء مدفوعون خارج النظام (قائمة بالجوال/البريد)</h2>';
		self::field( 'الأعضاء', 'members', '', 'textarea', "سطر لكل عضو: الاسم، الجوال، الإيميل بأي ترتيب — من يسجّل حسابًا بنفس الجوال أو البريد يتحول إلى عضو مدفوع تلقائيًا.", 'rows="8" dir="ltr"' );
		echo '<p><button class="button button-primary">إضافة</button></p></form></div>';
		echo '<div class="vai-card"><h2>القائمة الخارجية (' . count( (array) $imp ) . ')</h2><table class="vai-table"><thead><tr><th>الاسم</th><th>الجوال</th><th>الإيميل</th><th></th></tr></thead><tbody>';
		if ( ! $imp ) {
			echo '<tr><td colspan="4" class="vai-empty">لا يوجد.</td></tr>';
		}
		foreach ( (array) $imp as $m ) {
			echo '<tr><td>' . esc_html( $m->name ) . '</td><td dir="ltr">' . esc_html( $m->phone_norm ) . '</td><td dir="ltr">' . esc_html( $m->email_norm ) . '</td><td>';
			self::form_open( 'delete_member' );
			echo '<input type="hidden" name="id" value="' . (int) $m->id . '"><button class="button button-small">حذف</button></form></td></tr>';
		}
		echo '</tbody></table></div></div></div>';
	}

	public static function page_settings() {
		self::wrap_open( 'إعدادات الهب', 'كل ما يخص عقل n8n، البوابات، شكل الويدجت، والإشعارات — في مكان واحد.' );
		$dg = VAI_Hub::diag();
		echo '<div class="vai-card" style="margin-bottom:14px"><h2>التشخيص</h2>';
		if ( $dg['n8n'] ) {
			$ok = $dg['n8n']['code'] >= 200 && $dg['n8n']['code'] < 300;
			echo '<p>' . ( $ok ? '🟢' : '🔴' ) . ' آخر إرسال للعقل (n8n): الساعة ' . esc_html( $dg['n8n']['at'] ) . ' — كود ' . (int) $dg['n8n']['code'] . ( $dg['n8n']['ms'] ? ' خلال ' . (int) $dg['n8n']['ms'] . ' ملّي ثانية' : '' ) . ( $dg['n8n']['err'] ? ' — ' . esc_html( $dg['n8n']['err'] ) : '' ) . '</p>';
		} else {
			echo '<p>⚪ لم تُرسل أي رسالة للعقل بعد.</p>';
		}
		if ( $dg['reply'] ) {
			echo '<p>🟢 آخر رد وصل من العقل: الساعة ' . esc_html( $dg['reply']['at'] ) . ( $dg['reply']['latency'] !== null ? ' — استغرق ' . (int) $dg['reply']['latency'] . ' ثانية' : '' ) . ( $dg['reply']['model'] ? ' — ' . esc_html( $dg['reply']['model'] . ' / ' . $dg['reply']['route'] ) : '' ) . ( $dg['reply']['guard'] ? ' — ' . esc_html( $dg['reply']['guard'] ) : '' ) . '</p>';
		} else {
			echo '<p>🔴 لم يصل أي رد من العقل بعد — لو كان الإرسال أخضر أعلاه، فالمشكلة داخل n8n (افتح Executions) أو في عقدة Post Reply (مفتاح الهب أو Cloudflare).</p>';
		}
		if ( ! empty( $dg['pong'] ) ) {
			echo '<p>🟢 آخر اختبار اتصال كامل ناجح: ' . esc_html( $dg['pong'] ) . '</p>';
		}
		if ( ! empty( $dg['mail'] ) ) {
			echo '<p>' . ( $dg['mail']['ok'] ? '🟢' : '🔴' ) . ' آخر بريد: ' . esc_html( $dg['mail']['subject'] ) . ' → ' . esc_html( $dg['mail']['to'] ) . ' (' . esc_html( $dg['mail']['at'] ) . ')' . ( ! $dg['mail']['ok'] && $dg['mail']['error'] ? ' — ' . esc_html( $dg['mail']['error'] ) : '' ) . '</p>';
		} else {
			echo '<p>⚪ لم يُرسل أي بريد بعد — اضغط «اختبار إرسال البريد» أدناه. رموز التفعيل والإشعارات كلها تعتمد على البريد.</p>';
		}
		echo '<p class="vai-help">مهلة انتظار الرد الحالية: ' . (int) vai_cfg( 'reply_timeout' ) . ' ثانية (الحد الأدنى 60).</p></div>';
		self::form_open( 'test_n8n' );
		echo '<p style="margin:0 0 12px"><button class="button button-primary">اختبار الاتصال الكامل مع n8n</button> <span class="vai-help" style="display:inline">يرسل نبضة للويبهوك وينتظر رد n8n على الهب (حتى 14 ثانية) — يتحقق من الرابط والسرّ ومفتاح الهب دفعة واحدة.</span></p></form>';
		self::form_open( 'test_mail' );
		echo '<p style="margin:0 0 12px"><button class="button">اختبار إرسال البريد</button> <span class="vai-help" style="display:inline">يرسل رسالة إلى بريد مدير الموقع — لو فشل ثبّت FluentSMTP.</span></p></form>';
		$lv = get_option( 'vai_last_voice', array() );
		if ( is_array( $lv ) && ! empty( $lv['at'] ) ) {
			echo '<p>' . ( ! empty( $lv['ok'] ) ? '🟢' : '🔴' ) . ' آخر رسالة صوتية (' . esc_html( vai_riyadh( $lv['at'], 'H:i' ) ) . '): ' . esc_html( $lv['msg'] ) . '</p>';
		}
		self::form_open( 'test_voice' );
		echo '<p style="margin:0 0 12px"><button class="button">اختبار الرسائل الصوتية</button> <span class="vai-help" style="display:inline">يتحقق من مفتاح OpenAI ومن تفعيل الزر — ' . ( ( (int) vai_cfg( 'voice_enabled' ) && trim( (string) vai_opt( 'openai_key', '' ) ) !== '' ) ? '🟢 الصوت مفعّل حاليًا' : '🔴 الصوت غير مفعّل حاليًا (المفتاح فارغ أو الخيار مطفأ)' ) . '</span></p></form>';
		self::form_open( 'test_pb' );
		echo '<p style="margin:0 0 12px"><button class="button">اختبار بنك المشاريع</button> <span class="vai-help" style="display:inline">يتحقق من مفتاح PB Agent API وعدد المشاريع التي يراها المساعد.</span></p></form>';
		self::form_open( 'send_digest' );
		echo '<p style="margin:0 0 12px"><button class="button">أرسل التقرير الدوري الآن</button> <span class="vai-help" style="display:inline">للتجربة — يرسل تقرير الفترة الأخيرة إلى إيميلات الإشعار.</span></p></form>';
		self::form_open( 'hub_settings' );
		echo '<div class="vai-grid2"><div class="vai-card"><h2>الربط مع n8n</h2>';
		self::field( 'رابط ويبهوك n8n (Production URL)', 'n8n_webhook', vai_opt( 'n8n_webhook', '' ), 'url', 'من عقدة Webhook في Vibes Web Agent — الرابط الذي يبدأ بـ /webhook/ لا /webhook-test/', 'dir="ltr"' );
		echo '<div class="vai-field"><label>مفتاح الهب (يوضع في عقدة Config في n8n → hub_key)</label><code class="vai-code">' . esc_html( vai_opt( 'hub_key', '' ) ) . '</code><label class="vai-check"><input type="checkbox" name="regen_hub_key" value="1"> توليد مفتاح جديد عند الحفظ (لا تنسَ تحديثه في n8n)</label></div>';
		echo '<div class="vai-field"><label>سرّ الويبهوك (يوضع في عقدة Config في n8n → webhook_secret)</label><code class="vai-code">' . esc_html( vai_opt( 'webhook_secret', '' ) ) . '</code><label class="vai-check"><input type="checkbox" name="regen_secret" value="1"> توليد سرّ جديد عند الحفظ</label></div>';
		echo '<div class="vai-field"><label>رابط الهب للأدوات (يوضع في Config → hub_url)</label><code class="vai-code">' . esc_html( home_url() ) . '</code></div>';
		echo '<h2>المزامنة الفورية مع خادم التطبيق</h2>';
		self::field( 'رابط ويبهوك خادم التطبيق', 'app_webhook_url', vai_opt( 'app_webhook_url', '' ), 'url', 'مثال: https://[دومين خادم التطبيق]/api/webhooks/hub — يصله إشعار موقّع فور أي جديد (معرفة، عضوية، رد، دفعة، إعدادات) بلا أي بيانات شخصية. اتركه فارغًا لإيقاف الإشعارات.', 'dir="ltr"' );
		$once = get_transient( 'vai_app_secret_once_' . get_current_user_id() );
		if ( is_string( $once ) && $once !== '' ) {
			delete_transient( 'vai_app_secret_once_' . get_current_user_id() );
			echo '<div class="vai-field"><label>سرّ التوقيع الجديد (انسخه الآن إلى متغير HUB_WEBHOOK_SECRET في خادم التطبيق — لن يظهر مرة أخرى)</label><code class="vai-code">' . esc_html( $once ) . '</code></div>';
		}
		echo '<div class="vai-field"><label>سرّ توقيع الويبهوك</label><p class="vai-help">' . ( trim( (string) vai_opt( 'app_webhook_secret', '' ) ) !== '' ? '🟢 محفوظ (لا يُعرض). ' : '⚪ لم يُولَّد بعد — يُولَّد تلقائيًا عند حفظ الرابط أول مرة. ' ) . '</p><label class="vai-check"><input type="checkbox" name="regen_app_secret" value="1"> توليد سرّ جديد عند الحفظ (يظهر مرة واحدة — حدّثه في خادم التطبيق)</label></div>';
		echo '<h2>الدفع التلقائي (Paymob)</h2>';
		$lp = get_option( 'vai_last_paymob', array() );
		echo '<p class="vai-help">رابط الإشعار الذي تضعه في Paymob → Developers → Payment Integrations → التكامل الخاص بروابطك → <b>Transaction processed callback</b>: <code class="vai-code" style="display:inline;user-select:all">' . esc_html( rest_url( 'vibes-ai/v1/paymob/callback' ) ) . '</code> — و<b>Transaction response callback</b>: <code class="vai-code" style="display:inline;user-select:all">' . esc_html( home_url( '/?vai=paid' ) ) . '</code></p>';
		self::field( 'مفتاح HMAC من Paymob (Account Info)', 'paymob_hmac', vai_opt( 'paymob_hmac', '' ), 'password', 'يُستخدم فقط للتحقق أن الإشعار قادم من Paymob فعلًا', 'dir="ltr" autocomplete="off"' );
		self::field( 'جدول المبالغ (بالهللات | المفتاح | الاسم)', 'paymob_amounts', vai_cfg( 'paymob_amounts' ), 'textarea', 'المبلغ المدفوع يحدد الإجراء: membership = تفعيل العضوية تلقائيًا؛ غيره = تسجيل شراء خدمة وإشعارك. 1,900 ريال = 190000 هللة.', 'rows="4" dir="ltr"' );
		echo '<h2>💳 صفحة الدفع من الموقع (2.8.0)</h2>';
		echo '<p class="vai-help">صفحة دفع جاهزة يبدأ منها الزائر الدفع باسمه وجواله وبريده، فتصل كل دفعة معروفًا صاحبها ويُفعَّل تلقائيًا. رابط الصفحة: <code class="vai-code" style="display:inline;user-select:all">' . esc_html( home_url( '/?vai-pay' ) ) . '</code> — ولخدمة محددة أضف مفتاحها، مثال: <code class="vai-code" style="display:inline;user-select:all">' . esc_html( home_url( '/?vai-pay=membership' ) ) . '</code>. استبدل روابط Paymob الثابتة في الموقع بهذا الرابط، ولا تغيّر إعدادات الروابط القديمة في Paymob إطلاقًا. وعلى صفحات هذا الموقع نفسه يفتح الرابط نافذة دفع داخل الصفحة تلقائيًا (بدون مغادرة الموقع).</p>';
		self::field( 'Paymob Secret Key (اللايف)', 'paymob_secret', vai_opt( 'paymob_secret', '' ), 'password', 'من Paymob → Account Info. تُترك فارغة = صفحة الدفع مقفلة ولا شيء يتغير في الموقع.', 'dir="ltr" autocomplete="off"' );
		self::field( 'Paymob Public Key (اللايف)', 'paymob_public', vai_opt( 'paymob_public', '' ), 'text', 'من Paymob → Account Info (يبدأ بـ sau_pk_live_).', 'dir="ltr" autocomplete="off"' );
		self::field( 'أرقام الدمج (Integration IDs)', 'paymob_methods', vai_opt( 'paymob_methods', '' ), 'text', 'رقم دمج البطاقات في حسابك، وأكثر من رقم بفاصلة (مثال: 28390). من Paymob → Developers → Payment Integrations.', 'dir="ltr"' );
		self::field( 'روابط الدفع المباشرة (مؤقت — 2.10.2+)', 'paymob_direct', vai_opt( 'paymob_direct', '' ), 'textarea', 'مؤقت لحين تفعيل Paymob لخدمة الـ Intention. سطر لكل خدمة بالشكل: <code>membership | https://…</code> (المفاتيح من جدول المبالغ: membership، workshop، pitchdeck، urmeet — روابط لوحة Paymob التي تطلب الاسم والجوال والبريد). وسطر فيه رابط فقط = رابط افتراضي لما لم يُذكر. ما دام هنا أي سطر: زر الصفحة ينقل الزائر مباشرة لرابط خدمته، والخدمة التي بلا رابط تختفي من الصفحة (حتى لا يصل أحد لرابط بمبلغ خدمة أخرى)، وتبقى بيانات الزائر التي كتبها محفوظة 48 ساعة فيُفعَّل تلقائيًا فور وصول إشعار الدفع بنفس جواله وبريده. امسح كل الأسطر بعد إصلاح Paymob لتعود الصفحة للدفع الآلي.', 'rows="4" dir="ltr"' );
		$lps = get_option( 'vai_last_paystart', array() );
		if ( is_array( $lps ) && ! empty( $lps['at'] ) ) {
			// 2.8.2: why the last pay-page attempt succeeded or failed (network vs HTTP refusal) — for debugging live.
			echo '<p>' . ( ! empty( $lps['ok'] ) ? '🟢' : '🔴' ) . ' آخر محاولة دفع من صفحة الموقع (' . esc_html( vai_riyadh( $lps['at'] ) ) . '): ' . esc_html( $lps['msg'] ) . '</p>';
		} else {
			echo '<p>⚪ لم تبدأ أي محاولة دفع من صفحة الموقع بعد.</p>';
		}
		if ( is_array( $lp ) && ! empty( $lp['at'] ) ) {
			echo '<p>' . ( ! empty( $lp['ok'] ) ? '🟢' : '🔴' ) . ' آخر إشعار Paymob (' . esc_html( vai_riyadh( $lp['at'] ) ) . '): ' . esc_html( $lp['msg'] ) . '</p>';
		} else {
			echo '<p>⚪ لم يصل أي إشعار من Paymob بعد.</p>';
		}
		echo '<h2>🔐 الدخول بحساب Google في الويدجت (2.9.0)</h2>';
		echo '<p class="vai-help">زر «المتابعة بحساب Google» في نافذتي «حساب جديد» و«تسجيل الدخول» داخل الويدجت. الهب نفسه يتحقق من هوية Google ثم ينشئ الحساب مفعّلًا فورًا أو يدخل للحساب الموجود — بلا رمز بريد. يلزم إضافة أصل كل موقع (مثل https://vcmem.com) في Google Cloud → Credentials → نفس معرّف العميل → Authorized JavaScript origins.</p>';
		self::field( 'Google Web Client ID', 'google_client_id', vai_opt( 'google_client_id', '' ), 'text', 'معرّف عميل الويب من Google Cloud (ينتهي بـ .apps.googleusercontent.com — قيمة علنية). يُترك فارغًا = الزر مخفي ولا شيء يتغير.', 'dir="ltr" autocomplete="off"' );
		echo '<h2>🤖 مساعد المدير على ChatGPT</h2>';
		echo '<p class="vai-help">واجهة مؤمّنة تربط Custom GPT في حساب المدير بالهب: نظرة عامة وتقارير وقوائم (البريد والجوال يظهران مقنّعين للخصوصية)، وإرسال حملات بريدية لفئة محددة — كل إرسال يحتاج معاينة ثم تأكيدًا صريحًا، ويصلك أنت إيميل بكل حملة. الخدمة مقفولة تمامًا ما دام المفتاح فارغًا. لإلغاء وصول ChatGPT في أي لحظة: امسح المفتاح واحفظ.</p>';
		self::field( 'مفتاح ChatGPT API', 'gpt_api_key', vai_opt( 'gpt_api_key', '' ), 'password', 'ولّد مفتاحًا بالزر، احفظ الإعدادات، ثم ضعه في خانة API Key داخل إعدادات الـ GPT (ملف الإعداد المرفق مع التسليم يشرح الخطوات).', 'dir="ltr" autocomplete="new-password"' );
		echo '<p><button type="button" class="button" onclick="var a=new Uint8Array(24);crypto.getRandomValues(a);var k=\'vai_gpt_\';for(var i=0;i<a.length;i++){k+=(\'0\'+a[i].toString(16)).slice(-2);}var f=document.getElementById(\'vai_gpt_api_key\');f.value=k;f.type=\'text\';">🎲 توليد مفتاح جديد</button></p>';
		$gk = trim( (string) vai_opt( 'gpt_api_key', '' ) );
		if ( $gk !== '' ) {
			// 2.15.4: ChatGPT's new UI links through «Add custom MCP server» — one URL carries the key.
			echo '<p class="vai-help">🔗 رابط MCP لإضافته في ChatGPT (من زر Add ← Add custom MCP server) — اضغط عليه مرة لتحديده وانسخه كاملًا:<br><input type="text" readonly value="' . esc_attr( rest_url( 'vibes-ai/v1/mcp/' . $gk ) ) . '" style="width:100%;direction:ltr" onclick="this.select()"></p>';
		}
		$gl = get_option( 'vai_gpt_log', array() );
		if ( is_array( $gl ) && $gl ) {
			echo '<p class="vai-help">آخر استخدامات ChatGPT:<br>' . implode( '<br>', array_map( 'esc_html', array_slice( $gl, 0, 8 ) ) ) . '</p>';
		}
		echo '<h2>🎙️ تحقق العضوية لبطاقة أسعار البودكاست</h2>';
		echo '<p class="vai-help">بطاقة الأسعار التفاعلية على موقع بودكاست الملتقى بتتحقق من عضوية العميل ببريده + رمز يوصله على بريده (مفيش أي بيانات بتظهر قبل إثبات الرمز). هنا المواقع المسموح لها تستدعي التحقق فقط.</p>';
		self::field( 'المواقع المسموح لها (مفصولة بفاصلة)', 'member_check_origins', vai_opt( 'member_check_origins', 'https://almoltaqapodcast.com,https://www.almoltaqapodcast.com' ), 'text', 'عناوين كاملة بالبروتوكول. فضّيها = التحقق يشتغل من نفس الموقع فقط.', 'dir="ltr"' );
		echo '<h2>🎟️ الورشة / الفعالية الحالية (التذاكر)</h2>';
		self::field( 'اسم الفعالية', 'event_title', vai_cfg( 'event_title' ) );
		echo '<div class="vai-inline">';
		self::field( 'موعد الحضور (كما يظهر في التذكرة)', 'event_date', vai_cfg( 'event_date' ) );
		self::field( 'المكان', 'event_place', vai_cfg( 'event_place' ) );
		self::field( 'مبلغ التسجيل بالهللات (Paymob)', 'event_amount', vai_cfg( 'event_amount' ), 'number', '290 ريال = 29000 — لازم يطابق سطر workshop في جدول المبالغ' );
		echo '</div>';
		self::field( 'ملاحظة التذكرة', 'event_note', vai_cfg( 'event_note' ), 'textarea', '', 'rows="2"' );
		echo '<p class="vai-help">كل من يدفع مبلغ الورشة عبر Paymob يصله فورًا إيميل أنيق فيه رقم مرجعي وموعد الحضور ورمز QR ورابط تذكرته لحفظها كصورة JPEG. إصدار تذكرة يدوي (تحويل بنكي مثلًا) من صفحة «الرسائل البريدية».</p>';
		echo '<h2>الإشعارات للعميل</h2>';
		self::field( 'إيميل للعميل عند أي نشاط على حسابه', 'notify_user_events', vai_cfg( 'notify_user_events' ), 'checkbox', 'تسجيل دخول جديد، تغيير كلمة المرور، تحديث البيانات، تفعيل العضوية، الترقية' );
		self::field( 'زر واتساب الإدارة للأعضاء المفعّلين فقط', 'wa_members_only', vai_cfg( 'wa_members_only' ), 'checkbox', 'الزر الأخضر المتوهج في رأس المساعد يظهر للأعضاء المفعّلين فقط' );
		echo '<h2>الرسائل الصوتية</h2>';
		self::field( 'مفتاح OpenAI API (لتفريغ الصوت)', 'openai_key', vai_opt( 'openai_key', '' ), 'password', 'نفس مفتاح OpenAI المستخدم في n8n — يُستخدم هنا فقط لتحويل الرسائل الصوتية إلى نص (whisper-1). الرسائل الصوتية بالعربية فقط؛ غيرها يُرد عليه بأنها لم تُفهم.', 'dir="ltr" autocomplete="off"' );
		self::field( 'تفعيل زر التسجيل الصوتي في الويدجت', 'voice_enabled', vai_cfg( 'voice_enabled' ), 'checkbox', 'يظهر زر الميكروفون بجانب مربع الكتابة' );
		echo '<h2>بنك المشاريع</h2>';
		self::field( 'رابط PB Agent API', 'pb_api_url', vai_opt( 'pb_api_url', 'https://vibesholding.com/wp-json/pb-agent/v1/projects' ), 'url', '', 'dir="ltr"' );
		self::field( 'مفتاح PB Agent API', 'pb_api_key', vai_opt( 'pb_api_key', '' ), 'text', '', 'dir="ltr" autocomplete="off"' );
		echo '<h2>الحساب والعضوية</h2><div class="vai-inline">';
		self::field( 'مدة العضوية المدفوعة (أيام)', 'member_days', vai_cfg( 'member_days' ), 'number', 'العدّاد يبدأ يوم التحويل إلى عضو مدفوع' );
		self::field( 'رصيد العضو اليومي (ردود من المساعد)', 'member_daily', vai_cfg( 'member_daily' ), 'number', 'يتجدد كل يوم' );
		echo '</div>';
		self::field( 'نص انتهاء العضوية المدفوعة', 'member_expired_text', vai_cfg( 'member_expired_text' ), 'textarea', '', 'rows="3"' );
		self::field( 'تذكير بالاشتراك كل كم رد (لغير المشتركين)', 'nudge_every', vai_cfg( 'nudge_every' ), 'number', 'سطر لطيف من المساعد يربط حاجة العميل بميزة من العضوية' );
		self::field( 'السطر الرمادي أعلى المحادثة لغير المشتركين', 'unsaved_note', vai_cfg( 'unsaved_note' ), 'textarea', 'اتركه فارغًا لإخفائه', 'rows="2"' );
		self::field( 'جملة يقولها المساعد في أول رد لغير المشترك', 'first_reply_note', vai_cfg( 'first_reply_note' ), 'textarea', 'يقولها بمعناها وبأسلوبه مرة واحدة — اتركها فارغة إن لم ترد أن يذكر شيئًا عن تسجيل المحادثة', 'rows="2"' );
		self::field( 'نص إنشاء الحساب (خطوة الاشتراك)', 'account_gate_text', vai_cfg( 'account_gate_text' ), 'textarea', '', 'rows="2"' );
		self::field( 'تنبيه «عضويتك غير مفعّلة» (لصاحب الحساب الذي لم يدفع)', 'unpaid_note', vai_cfg( 'unpaid_note' ), 'textarea', '', 'rows="2"' );
		self::field( 'خدمات الأعضاء (زر «خدمات الأعضاء» في المساعد) — العنوان | الوصف | الرابط أو wa:رقم | نص الزر', 'member_services', vai_cfg( 'member_services' ), 'textarea', 'wa:966538461110 يفتح واتساب برسالة جاهزة فيها بيانات العضو وطلب أقرب موعد', 'rows="6"' );
		self::field( 'عنوان إيميل تفعيل العضوية', 'member_email_subject', vai_cfg( 'member_email_subject' ) );
		self::field( 'إيميل تفعيل العضوية (المزايا والخدمات)', 'member_email', vai_cfg( 'member_email' ), 'textarea', 'المتغيرات: {name} {phone} {email} {end_date} {pb_url} {podcast_wa} {pitchdeck_url} {urmeet_url} {mgmt}', 'rows="10"' );
		self::field( 'الإيميل الأسبوعي للأعضاء مفعّل', 'weekly_enabled', vai_cfg( 'weekly_enabled' ), 'checkbox', 'كل أحد صباحًا — يدخل طابور الإرسال (إيميل كل 5 دقائق)' );
		self::field( 'عنوان الإيميل الأسبوعي', 'weekly_subject', vai_cfg( 'weekly_subject' ) );
		self::field( 'نص الإيميل الأسبوعي', 'weekly_email', vai_cfg( 'weekly_email' ), 'textarea', 'المتغيرات نفسها + {pb_left}', 'rows="8"' );
		self::field( 'دفعة التذكير اليدوية — نصوص الأعضاء (موضوع متناوب)', 'broadcast_member_texts', vai_cfg( 'broadcast_member_texts' ), 'textarea', 'أول سطر في كل مقطع هو عنوان الإيميل والباقي نصه، وافصل بين المواضيع بسطر فيه --- فقط. نفس المتغيرات: {name} {end_date} {pb_left} {pb_url} {podcast_wa} {pitchdeck_url} {urmeet_url} {mgmt} {pay_url}', 'rows="14"' );
		self::field( 'دفعة التذكير اليدوية — نصوص غير المشتركين', 'broadcast_nonmember_texts', vai_cfg( 'broadcast_nonmember_texts' ), 'textarea', 'نفس الفكرة: عنوان ثم نص، وافصل بـ --- . استخدم {pay_url} لرابط الدفع الموحد.', 'rows="12"' );
		self::field( 'رابط جسر بنك المشاريع', 'pb_bridge_url', vai_opt( 'pb_bridge_url', vai_cfg( 'pb_bridge_url' ) ), 'text', 'لإضافة رصيد إضافي للأعضاء من شاشة «الأعضاء والعضويات».', 'dir="ltr"' );
		self::field( 'مفتاح جسر بنك المشاريع', 'pb_bridge_key', vai_opt( 'pb_bridge_key', '' ), 'password', 'نفس المفتاح المستخدم في سيرفر التطبيق (BRIDGE KEY).', 'dir="ltr" autocomplete="new-password"' );
		self::field( 'قائمة الأسعار المعتمدة (يقرأها المساعد مع كل رسالة ويحسب منها توفير الأعضاء)', 'price_sheet', vai_cfg( 'price_sheet' ), 'textarea', 'عدّل أي سعر هنا ويتغير عند المساعد فورًا.', 'rows="10"' );
		self::field( 'روابط الترحيب بعد تفعيل الحساب (العنوان | الرابط — سطر لكل رابط)', 'welcome_links', vai_cfg( 'welcome_links' ), 'textarea', 'تظهر كأزرار مع رسالة الترحيب، ويقول المساعد إن حسابه يعمل عليها فقط + «وخدمات أخرى كثيرة مع العضوية السنوية»', 'rows="7" dir="ltr"' );
		self::field( 'عنوان إيميل الترحيب', 'welcome_email_subject', vai_cfg( 'welcome_email_subject' ) );
		self::field( 'نص إيميل الترحيب', 'welcome_email', vai_cfg( 'welcome_email' ), 'textarea', 'المتغيرات: {name} {days} {end_date} {email} {phone} {pay_url} {mgmt}', 'rows="9"' );
		echo '<h2>البوابات والحدود</h2><div class="vai-inline">';
		self::field( 'ردود بدون رسوم قبل طلب إنشاء الحساب', 'gate_free', vai_cfg( 'gate_free' ), 'number' );
		self::field( 'ردود بعد إنشاء الحساب وقبل بوابة الاشتراك', 'gate_identified', vai_cfg( 'gate_identified' ), 'number' );
		echo '</div><div class="vai-inline">';
		self::field( 'حد العضو اليومي (ردود)', 'member_daily', vai_cfg( 'member_daily' ), 'number' );
		self::field( 'رسائل الزائر في الساعة', 'rate_per_hour', vai_cfg( 'rate_per_hour' ), 'number' );
		echo '</div><div class="vai-inline">';
		self::field( 'حد الردود اليومي لكل موقع', 'site_daily_cap', vai_cfg( 'site_daily_cap' ), 'number' );
		self::field( 'إيقاف البوت بعد ردك اليدوي (دقائق)', 'human_pause_min', vai_cfg( 'human_pause_min' ), 'number' );
		echo '</div>';
		self::field( 'مهلة انتظار رد المساعد (ثوانٍ)', 'reply_timeout', vai_cfg( 'reply_timeout' ), 'number' );
		self::field( 'الجوال السعودي فقط في التسجيل', 'saudi_only', vai_cfg( 'saudi_only' ), 'checkbox', 'رفض أي جوال لا يبدأ بـ 966 عند تسجيل البيانات (قاعدة «داخل المملكة» تبقى في الحوار على أي حال)' );
		echo '<h2>الإشعارات والتقارير</h2>';
		self::field( 'إيميلات الإشعار (مفصولة بفاصلة)', 'notify_email', vai_opt( 'notify_email', get_option( 'admin_email' ) ), 'text', 'تصلها الإشعارات الفورية والتقرير الدوري', 'dir="ltr"' );
		self::field( 'إيميل فوري عند كل تسجيل حساب جديد', 'notify_registration', vai_cfg( 'notify_registration' ), 'checkbox', 'يصلك «عضو جديد سجّل في Vibes Ventures» ببياناته فور تفعيله' );
		self::field( 'إشعار فوري لهذه الأنواع فقط', 'instant_lead_types', vai_cfg( 'instant_lead_types' ), 'text', 'partner = مستثمر يريد الدخول شريكًا · payment = دفع/إثبات دفع · cooperation = تعاون بين جهات · management · service · membership · owner · contact — الباقي يظهر في التقرير الدوري فقط', 'dir="ltr"' );
		echo '<div class="vai-inline">';
		self::field( 'التقرير الدوري مفعّل', 'digest_enabled', vai_cfg( 'digest_enabled' ), 'checkbox', 'إرسال تقرير بأهم العملاء وما وصلوا إليه' );
		self::field( 'كل كم ساعة', 'digest_hours', vai_cfg( 'digest_hours' ), 'number' );
		echo '</div>';
		$ld = get_option( 'vai_last_digest', array() );
		if ( is_array( $ld ) && ! empty( $ld['at'] ) ) {
			echo '<p class="vai-help">آخر تقرير: ' . esc_html( vai_riyadh( $ld['at'] ) ) . ( empty( $ld['ok'] ) ? ' (فشل الإرسال)' : ' ✅' ) . '</p>';
		}
		self::field( 'أرقام الجوال: تحقق حسب الدولة المختارة (كل دول العالم في القائمة)', 'gcc_only', vai_cfg( 'gcc_only' ), 'checkbox', 'قائمة كل دول العالم في نموذج التسجيل والسعودية افتراضيًا — دول الخليج بتحقق دقيق لصيغة الرقم، وباقي الدول بتحقق عام لطول الرقم' );
		self::field( 'دومينات البريد المقبولة في التسجيل', 'allowed_email_domains', vai_cfg( 'allowed_email_domains' ), 'text', '* = أي بريد صحيح (شخصي أو شركة) — التفعيل برمز البريد يضمن صحته. أو اكتب دومينات محددة مفصولة بفاصلة.', 'dir="ltr"' );
		self::field( 'ويبهوك الإشعار (اختياري)', 'notify_webhook', vai_opt( 'notify_webhook', '' ), 'url', 'مثال: ويبهوك «Lead Alert» في n8n لإرسال تنبيه واتساب لرقم الإدارة', 'dir="ltr"' );
		echo '</div><div class="vai-card"><h2>هوية المساعد والويدجت</h2>';
		self::field( 'اسم المساعد', 'bot_name', vai_cfg( 'bot_name' ) );
		self::field( 'السطر التعريفي', 'bot_subtitle', vai_cfg( 'bot_subtitle' ) );
		self::field( 'صورة المساعد (رابط)', 'avatar_url', vai_cfg( 'avatar_url' ), 'url', '', 'dir="ltr"' );
		self::field( 'اللون الأساسي', 'primary_color', vai_cfg( 'primary_color' ), 'text', 'يمكن لكل موقع تجاوزه من إعداداته', 'dir="ltr"' );
		echo '<div class="vai-field"><label>فتح الصفحات</label><select name="nav_mode"><option value="button" ' . selected( vai_cfg( 'nav_mode' ), 'button', false ) . '>زر «افتح الصفحة وأكمل معك هناك» (موثوق — العميل يضغط)</option><option value="auto" ' . selected( vai_cfg( 'nav_mode' ), 'auto', false ) . '>فتح تلقائي فوري (بعض المتصفحات تمنعه)</option></select></div>';
		self::field( 'شريط الحساب الثابت أعلى كل صفحة (اختياري — مطفّأ)', 'account_bar2', vai_cfg( 'account_bar2' ), 'checkbox', 'شريط أسود بحد ذهبي في أعلى كل صفحة على كل المواقع: للزائر «اشترك في العضوية السنوية · دخول»، وللعضو صورته واسمه والأيام الباقية — يفتح لوحة الحساب بكل بياناته' );
		self::field( 'زر الحساب العائم أسفل الصفحة (المعتمد)', 'account_pill', vai_cfg( 'account_pill' ), 'checkbox', 'صورة العميل أو أيقونة الحساب بحدّ ذهبي متوهج في الجهة المقابلة لأيقونة المساعد — يفتح لوحة الحساب' );
		echo '<div class="vai-field"><label>المساعد على الجوال والتابلت</label><select name="mobile_mode"><option value="compact" ' . selected( vai_cfg( 'mobile_mode' ), 'compact', false ) . '>نافذة صغيرة فوق الصفحة (يتصفح الموقع أثناء المحادثة — وزر ملء الشاشة متاح)</option><option value="full" ' . selected( vai_cfg( 'mobile_mode' ), 'full', false ) . '>ملء الشاشة دائمًا</option></select></div>';
		echo '<div class="vai-field"><label>موضع زر «حسابي»</label><select name="pill_position"><option value="opposite" ' . selected( vai_cfg( 'pill_position' ), 'opposite', false ) . '>أسفل الصفحة في الجهة المقابلة لأيقونة المساعد (واتساب يمين — الحساب يسار)</option><option value="bottom" ' . selected( vai_cfg( 'pill_position' ), 'bottom', false ) . '>أسفل الصفحة فوق أيقونة المساعد</option><option value="top-left" ' . selected( vai_cfg( 'pill_position' ), 'top-left', false ) . '>أعلى يسار الصفحة</option><option value="top-right" ' . selected( vai_cfg( 'pill_position' ), 'top-right', false ) . '>أعلى يمين الصفحة</option></select></div>';
		echo '<p class="vai-help">روابط جاهزة تعمل على أي موقع فيه البلجن (استبدل الدومين): صفحة الحساب الثابتة <code class="vai-code" style="display:inline;user-select:all">https://[الدومين]/?vai-account=1</code> · يفتح المساعد مباشرة <code class="vai-code" style="display:inline;user-select:all">https://[الدومين]/?vai=open</code> · يفتح المساعد على نموذج التسجيل <code class="vai-code" style="display:inline;user-select:all">https://[الدومين]/?vai=register</code> · على نموذج الدخول <code class="vai-code" style="display:inline;user-select:all">https://[الدومين]/?vai=login</code></p>';
		echo '<div class="vai-field"><label>شكل أيقونة الفتح</label><select name="launcher_style"><option value="whatsapp" ' . selected( vai_cfg( 'launcher_style' ), 'whatsapp', false ) . '>علامة واتساب خضراء مضيئة ومتحركة</option><option value="logo" ' . selected( vai_cfg( 'launcher_style' ), 'logo', false ) . '>لوجو المساعد على خلفية سوداء</option></select><p class="vai-help">موضع الأيقونة (يمين/يسار) يُضبط من إعدادات كل موقع.</p></div>';
		self::field( 'رسالة الترحيب', 'welcome', vai_cfg( 'welcome' ), 'textarea' );
		self::field( 'أزرار البداية (سطر لكل زر — حتى 8)', 'menu', vai_cfg( 'menu' ), 'textarea', '', 'rows="8"' );
		self::field( 'واتساب الإدارة', 'mgmt_whatsapp', vai_cfg( 'mgmt_whatsapp' ), 'text', '', 'dir="ltr"' );
		self::field( 'واتساب النادي الرسمي', 'club_whatsapp', vai_cfg( 'club_whatsapp' ), 'text', '', 'dir="ltr"' );
		self::field( 'نص بوابة تسجيل البيانات', 'contact_gate_text', vai_cfg( 'contact_gate_text' ), 'textarea', '', 'rows="3"' );
		self::field( 'نص بوابة العضوية', 'member_gate_text', vai_cfg( 'member_gate_text' ), 'textarea', 'يظهر معه كارت العضوية من الكتالوج (المفتاح membership) وزر «عندي عضوية»', 'rows="4"' );
		self::field( 'الدومينات المسموح بروابطها (سطر لكل دومين)', 'allowed_hosts', vai_cfg( 'allowed_hosts' ), 'textarea', 'أي رابط خارجها يُحذف من ردود المساعد تلقائيًا', 'rows="6" dir="ltr"' );
		self::field( 'مكتبة الفيديو (رقم|العنوان|الرابط|سطر التشويق)', 'videos', vai_cfg( 'videos' ), 'textarea', '', 'rows="8" dir="ltr"' );
		echo '<p><button class="button button-primary button-large">حفظ الإعدادات</button></p></div></div></form></div>';
	}
}
