<?php
/**
 * 2.9.0 (M49): verifies a Google ID token ON the hub itself, for the widget's «المتابعة بحساب Google».
 * The app keeps its own path (the app server verifies and calls the trusted op social_login); this class
 * serves the public widget path, where no trusted server stands between the browser and the hub.
 * No SDK: Google's public JWKS (cached), RS256 through OpenSSL, then the claim checks.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class VAI_Google {

	const JWKS_URL = 'https://www.googleapis.com/oauth2/v3/certs';

	/**
	 * Verifies an ID token against $client_id. Returns the claims we use
	 * array( 'email', 'sub', 'name' ) or WP_Error (its code never reaches the visitor verbatim).
	 */
	public static function verify( $jwt, $client_id ) {
		$client_id = trim( (string) $client_id );
		$jwt       = (string) $jwt;
		if ( $client_id === '' || $jwt === '' || substr_count( $jwt, '.' ) !== 2 || strlen( $jwt ) > 4000 ) {
			return new WP_Error( 'jwt', 'malformed token' );
		}
		list( $h64, $p64, $s64 ) = explode( '.', $jwt );
		$header  = json_decode( self::b64u( $h64 ), true );
		$claims  = json_decode( self::b64u( $p64 ), true );
		$sig     = self::b64u( $s64 );
		if ( ! is_array( $header ) || ! is_array( $claims ) || $sig === '' ) {
			return new WP_Error( 'jwt', 'undecodable token' );
		}
		if ( ! isset( $header['alg'] ) || $header['alg'] !== 'RS256' || empty( $header['kid'] ) ) {
			return new WP_Error( 'alg', 'unexpected algorithm' );
		}
		$pem = self::key_pem( (string) $header['kid'] );
		if ( is_wp_error( $pem ) ) {
			return $pem;
		}
		if ( ! function_exists( 'openssl_verify' ) || openssl_verify( $h64 . '.' . $p64, $sig, $pem, OPENSSL_ALGO_SHA256 ) !== 1 ) {
			return new WP_Error( 'sig', 'bad signature' );
		}
		$iss = isset( $claims['iss'] ) ? (string) $claims['iss'] : '';
		if ( ! in_array( $iss, array( 'https://accounts.google.com', 'accounts.google.com' ), true ) ) {
			return new WP_Error( 'iss', 'wrong issuer' );
		}
		$aud = isset( $claims['aud'] ) ? $claims['aud'] : '';
		if ( ! is_string( $aud ) || ! hash_equals( $client_id, $aud ) ) {
			return new WP_Error( 'aud', 'wrong audience' );
		}
		if ( empty( $claims['exp'] ) || (int) $claims['exp'] < time() - 60 ) {
			return new WP_Error( 'exp', 'expired token' );
		}
		$email = isset( $claims['email'] ) ? vai_norm_email( (string) $claims['email'] ) : '';
		$evok  = isset( $claims['email_verified'] ) && ( $claims['email_verified'] === true || $claims['email_verified'] === 'true' );
		if ( $email === '' || ! is_email( $email ) || ! $evok || empty( $claims['sub'] ) ) {
			return new WP_Error( 'email', 'no verified e-mail in the token' );
		}
		return array(
			'email' => $email,
			'sub'   => (string) $claims['sub'],
			'name'  => isset( $claims['name'] ) ? (string) $claims['name'] : '',
		);
	}

	/** The PEM public key for a kid, from Google's JWKS (cached 6 h; a miss refreshes once — key rotation). */
	private static function key_pem( $kid ) {
		foreach ( array( true, false ) as $cached ) {
			$jwks = self::jwks( $cached );
			if ( is_array( $jwks ) ) {
				foreach ( $jwks as $k ) {
					if ( is_array( $k ) && isset( $k['kid'], $k['kty'], $k['n'], $k['e'] ) && $k['kid'] === $kid && $k['kty'] === 'RSA' ) {
						$pem = self::rsa_pem( self::b64u( (string) $k['n'] ), self::b64u( (string) $k['e'] ) );
						if ( $pem !== '' ) {
							return $pem;
						}
					}
				}
			}
			if ( $cached ) {
				delete_transient( 'vai_google_jwks' );
			}
		}
		return new WP_Error( 'kid', 'signing key not found' );
	}

	private static function jwks( $allow_cache ) {
		// The local test rig blocks outbound HTTP and injects its own keys through this filter.
		$injected = apply_filters( 'vai_google_jwks', null );
		if ( null !== $injected ) {
			return is_array( $injected ) && isset( $injected['keys'] ) ? $injected['keys'] : $injected;
		}
		if ( $allow_cache ) {
			$hit = get_transient( 'vai_google_jwks' );
			if ( is_array( $hit ) ) {
				return $hit;
			}
		}
		$res = wp_remote_get( self::JWKS_URL, array( 'timeout' => 10 ) );
		if ( is_wp_error( $res ) || (int) wp_remote_retrieve_response_code( $res ) !== 200 ) {
			return null;
		}
		$body = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		if ( ! is_array( $body ) || empty( $body['keys'] ) || ! is_array( $body['keys'] ) ) {
			return null;
		}
		set_transient( 'vai_google_jwks', $body['keys'], 6 * HOUR_IN_SECONDS );
		return $body['keys'];
	}

	/** SubjectPublicKeyInfo PEM from the JWK's modulus and exponent (DER built by hand — no extensions needed). */
	private static function rsa_pem( $n, $e ) {
		if ( $n === '' || $e === '' ) {
			return '';
		}
		$seq  = self::der_int( $n ) . self::der_int( $e );
		$rsa  = "\x30" . self::der_len( strlen( $seq ) ) . $seq;
		$bits = "\x03" . self::der_len( strlen( $rsa ) + 1 ) . "\x00" . $rsa;
		$alg  = "\x30\x0d\x06\x09\x2a\x86\x48\x86\xf7\x0d\x01\x01\x01\x05\x00"; // rsaEncryption + NULL
		$spki = "\x30" . self::der_len( strlen( $alg . $bits ) ) . $alg . $bits;
		return "-----BEGIN PUBLIC KEY-----\n" . chunk_split( base64_encode( $spki ), 64, "\n" ) . "-----END PUBLIC KEY-----\n";
	}

	private static function der_len( $len ) {
		if ( $len < 128 ) {
			return chr( $len );
		}
		$out = '';
		while ( $len > 0 ) {
			$out = chr( $len & 0xFF ) . $out;
			$len >>= 8;
		}
		return chr( 0x80 | strlen( $out ) ) . $out;
	}

	private static function der_int( $bytes ) {
		if ( $bytes === '' ) {
			$bytes = "\x00";
		}
		if ( ord( $bytes[0] ) > 0x7F ) {
			$bytes = "\x00" . $bytes;
		}
		return "\x02" . self::der_len( strlen( $bytes ) ) . $bytes;
	}

	private static function b64u( $s ) {
		$d = base64_decode( strtr( (string) $s, '-_', '+/' ), true );
		return $d === false ? '' : $d;
	}
}
