/* Vibes AI Assistant — admin dashboard */
(function () {
	'use strict';
	var A = window.VAI_ADMIN;
	if (!A) { return; }

	function api(op, data, method) {
		method = method || 'POST';
		var url = A.rest + op;
		var headers = { 'Content-Type': 'application/json' };
		if (A.nonce) { headers['X-WP-Nonce'] = A.nonce; }
		if (A.session) { headers['X-VAI-Session'] = A.session; }
		var opts = { method: method, headers: headers, credentials: 'same-origin' };
		if (method === 'GET') { url += (url.indexOf('?') === -1 ? '?' : '&') + new URLSearchParams(data || {}).toString() + '&_=' + Date.now(); } else { opts.body = JSON.stringify(data || {}); }
		return fetch(url, opts).then(function (r) { if (A.console && (r.status === 401 || r.status === 403)) { try { localStorage.removeItem('vai_console_session'); } catch (e) {} location.reload(); } return r.json(); });
	}
	function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
	function nl(s) { return esc(s).replace(/\n/g, '<br>'); }

	/* ─── knowledge search test (knowledge page) ─── */
	var sq = document.getElementById('vai-search-q');
	if (sq) {
		var run = function () {
			var out = document.getElementById('vai-search-out');
			out.innerHTML = '<p class="vai-help">جارٍ البحث…</p>';
			api('search_test', { q: sq.value }, 'GET').then(function (r) {
				var h = '';
				if (r.results && r.results.length) {
					h += '<h3>نتائج المعرفة</h3>' + r.results.map(function (x) { return '<div class="vai-result"><b>' + esc(x.title) + '</b> <small dir="ltr">' + esc(x.site || '') + ' · ' + esc(x.kind) + '</small><div>' + esc(x.snippet) + '</div><a href="' + esc(x.url) + '" target="_blank" rel="noopener" dir="ltr">' + esc(x.url) + '</a></div>'; }).join('');
				} else { h += '<p class="vai-help">لا نتائج في المعرفة — تأكد من مزامنة المواقع أو أضف ملاحظة.</p>'; }
				if (r.projects && r.projects.length) {
					h += '<h3>بنك المشاريع</h3>' + r.projects.map(function (p) { return '<div class="vai-result"><b>#' + esc(p.number) + ' — ' + esc(p.name) + '</b> <small>' + esc(p.sector || '') + ' ' + esc(p.stage || '') + (p.golden ? ' · ذهبي' : '') + '</small><div>' + esc((p.summary || '').slice(0, 160)) + '</div></div>'; }).join('');
				}
				out.innerHTML = h;
			});
		};
		document.getElementById('vai-search-btn').addEventListener('click', run);
		sq.addEventListener('keydown', function (e) { if (e.key === 'Enter') { run(); } });
	}

	/* ─── dashboard app ─── */
	var app = document.getElementById('vai-app');
	if (!app) { return; }
	var st = { filter: { site_id: '', stage: '', q: '', page: 1 }, current: A.open || 0, threads: [], sites: [], listTimer: null, threadTimer: null, lastThreadMax: 0 };

	app.innerHTML =
		'<div class="vai-stats" id="vai-stats"></div>' +
		'<div class="vai-split">' +
		'<div class="vai-list-col"><div class="vai-filters">' +
		'<input type="search" id="vai-q" placeholder="بحث بالاسم / الجوال / الإيميل…">' +
		'<select id="vai-site"><option value="">كل المواقع</option></select>' +
		'<select id="vai-stage"><option value="">الكل</option><option value="lead">سجّلوا بياناتهم</option><option value="member">الأعضاء</option><option value="anon">زوار بلا بيانات</option><option value="human">يتابعها الفريق</option></select>' +
		(app.getAttribute('data-export') ? '<a class="button" id="vai-export" href="' + esc(app.getAttribute('data-export')) + '">تصدير CSV</a>' : '') +
		'</div><div class="vai-list" id="vai-list"><div class="vai-loading">جارٍ التحميل…</div></div><div class="vai-pager" id="vai-pager"></div></div>' +
		'<div class="vai-thread-col" id="vai-thread"><div class="vai-empty-thread">اختر محادثة من القائمة</div></div>' +
		'</div>';

	var qEl = document.getElementById('vai-q'), siteEl = document.getElementById('vai-site'), stageEl = document.getElementById('vai-stage');
	var qT = null;
	qEl.addEventListener('input', function () { clearTimeout(qT); qT = setTimeout(function () { st.filter.q = qEl.value.trim(); st.filter.page = 1; loadList(); }, 350); });
	siteEl.addEventListener('change', function () { st.filter.site_id = siteEl.value; st.filter.page = 1; loadList(); });
	stageEl.addEventListener('change', function () { st.filter.stage = stageEl.value; st.filter.page = 1; loadList(); });

	function loadOverview() {
		api('overview', {}, 'GET').then(function (r) {
			if (!r || !r.ok) { return; }
			var s = document.getElementById('vai-stats');
			var card = function (label, v, sub) { return '<div class="vai-stat"><div class="vai-stat-v">' + v + '</div><div class="vai-stat-l">' + label + '</div>' + (sub ? '<div class="vai-stat-s">' + sub + '</div>' : '') + '</div>'; };
			var d = r.diag || {}, dn = d.n8n, dr = d.reply;
			var diagTxt = (dn ? (dn.code >= 200 && dn.code < 300 ? '🟢' : '🔴') + ' n8n ' + dn.code + ' @' + esc(dn.at) : '⚪ لا إرسال بعد') + '<br>' + (dr ? '🟢 آخر رد @' + esc(dr.at) + (dr.latency != null ? ' (' + dr.latency + ' ث)' : '') : '🔴 لا رد بعد');
			s.innerHTML = card('محادثات اليوم', r.today.conversations, 'آخر 7 أيام: ' + r.week.conversations) + card('رسائل اليوم', r.today.messages, 'آخر 7 أيام: ' + r.week.messages) + card('ليدز اليوم', r.today.leads, 'الإجمالي: ' + r.total.leads) + card('طلبات ساخنة اليوم', r.today.hot, 'خدمات / عضوية / شراكة') + card('أعضاء', r.total.members, 'إجمالي العملاء: ' + r.total.contacts) + card('ينتظرون ردًا', r.waiting + (r.human ? ' <small>+' + r.human + ' مع الفريق</small>' : ''), 'الآن ' + esc(r.now)) + '<div class="vai-stat"><div class="vai-stat-l" style="font-size:12px;line-height:1.7">' + diagTxt + '</div></div>';
			if (siteEl.options.length <= 1 && r.sites) {
				r.sites.forEach(function (x) { var o = document.createElement('option'); o.value = x.id; o.textContent = (x.name || x.host) + ' (' + x.week_conv + ')'; siteEl.appendChild(o); });
			}
			st.sites = r.sites || [];
		}).catch(function () {});
	}

	function badgeFor(t) {
		var b = [];
		if (t.is_member) { b.push('<span class="vai-tag vai-tag-gold">عضو</span>'); } else if (t.stage >= 1) { b.push('<span class="vai-tag' + (t.has_account ? ' vai-tag-red' : '') + '">' + (t.has_account ? 'عضو غير مفعّل' : 'ليد') + '</span>'); } else { b.push('<span class="vai-tag vai-tag-grey">زائر</span>'); }
		if (t.intent_label) { b.push('<span class="vai-tag vai-tag-blue">' + esc(t.intent_label) + '</span>'); }
		if (t.human) { b.push('<span class="vai-tag vai-tag-green">الفريق</span>'); }
		if (t.waiting) { b.push('<span class="vai-tag vai-tag-blue">ينتظر</span>'); }
		if (t.lead_type && t.lead_type !== 'contact') { b.push('<span class="vai-tag vai-tag-red">' + esc(t.lead_type) + '</span>'); }
		return b.join(' ');
	}

	function loadList() {
		api('threads', st.filter, 'GET').then(function (r) {
			if (!r || !r.ok) { return; }
			st.threads = r.threads;
			var list = document.getElementById('vai-list');
			if (!r.threads.length) { list.innerHTML = '<div class="vai-empty-thread">لا توجد محادثات مطابقة بعد — أول عميل يكتب في أي موقع سيظهر هنا فورًا.</div>'; }
			else {
				list.innerHTML = r.threads.map(function (t) {
					return '<div class="vai-item' + (t.id === st.current ? ' vai-active' : '') + (t.unread ? ' vai-unread' : '') + '" data-id="' + t.id + '">' +
						'<div class="vai-item-top"><b>' + esc(t.name || t.phone || 'زائر #' + t.id) + '</b><span class="vai-item-time">' + esc(t.last_at) + '</span></div>' +
						'<div class="vai-item-mid"><span dir="ltr" class="vai-host">' + esc(t.site || '') + '</span> ' + badgeFor(t) + '</div>' +
						'<div class="vai-item-last">' + (t.last_role === 'user' ? '👤 ' : (t.last_role === 'human' ? '🧑‍💼 ' : '🤖 ')) + esc(t.last) + '</div></div>';
				}).join('');
				list.querySelectorAll('.vai-item').forEach(function (it) { it.addEventListener('click', function () { openThread(parseInt(it.getAttribute('data-id'), 10)); }); });
			}
			var pages = Math.max(1, Math.ceil(r.total / r.per));
			var pg = document.getElementById('vai-pager');
			pg.innerHTML = pages > 1 ? '<button class="button" ' + (st.filter.page <= 1 ? 'disabled' : '') + ' data-d="-1">السابق</button> <span>' + st.filter.page + ' / ' + pages + '</span> <button class="button" ' + (st.filter.page >= pages ? 'disabled' : '') + ' data-d="1">التالي</button>' : '';
			pg.querySelectorAll('button').forEach(function (b) { b.addEventListener('click', function () { st.filter.page += parseInt(b.getAttribute('data-d'), 10); loadList(); }); });
		}).catch(function () {});
	}

	function openThread(id) {
		st.current = id;
		document.querySelectorAll('.vai-item').forEach(function (it) { it.classList.toggle('vai-active', parseInt(it.getAttribute('data-id'), 10) === id); });
		renderThread(true);
	}

	function renderThread(scroll) {
		if (!st.current) { return; }
		api('thread', { id: st.current }, 'GET').then(function (r) {
			if (!r || !r.ok) { return; }
			var c = r.contact, box = document.getElementById('vai-thread');
			var maxId = 0; r.messages.forEach(function (m) { if (m.id > maxId) { maxId = m.id; } });
			var same = box.getAttribute('data-id') === String(c.id);
			if (same && maxId === st.lastThreadMax && !scroll) { return; }
			st.lastThreadMax = maxId;
			var h = '<div class="vai-thread-head"><div>' + (c.avatar ? '<img src="' + esc(c.avatar) + '" alt="" style="width:40px;height:40px;border-radius:50%;object-fit:cover;vertical-align:middle;margin-left:8px">' : '') + '<b>' + esc(c.name || 'زائر #' + c.id) + '</b> ' + badgeFor(c) + (c.persona || c.company || c.city ? '<div class="vai-meta">' + esc([c.persona, c.company, c.city].filter(Boolean).join(' · ')) + '</div>' : '') + (c.bio ? '<div class="vai-meta">' + esc(c.bio) + '</div>' : '') +
				'<div class="vai-meta">' + (c.phone ? '<span dir="ltr">' + esc(c.phone) + '</span>' : '') + (c.email ? ' · <span dir="ltr">' + esc(c.email) + '</span>' : '') + '</div>' +
				'<div class="vai-meta">المواقع: <span dir="ltr">' + esc((c.sites || []).join(', ')) + '</span> · أول تواصل ' + esc(c.first_at) + ' · ' + c.msg_count + ' رسالة</div>' +
				(c.last_page ? '<div class="vai-meta">آخر صفحة: <a dir="ltr" target="_blank" rel="noopener" href="' + esc(c.last_page) + '">' + esc(c.last_page.replace(/^https?:\/\//, '').slice(0, 60)) + '</a></div>' : '') +
				'</div><div class="vai-thread-actions">' +
				(c.wa ? '<a class="button" target="_blank" rel="noopener" href="' + esc(c.wa) + '">واتساب</a> ' : '') +
				'<button class="button" id="vai-bot-toggle">' + (c.human ? 'أعد تشغيل البوت' : 'أوقف البوت لهذا العميل') + '</button> ' +
				'<button class="button" id="vai-member-toggle">' + (c.is_member ? 'إلغاء العضوية' : 'تعليم كعضو') + '</button> ' +
				'<button class="button" id="vai-edit">تعديل البيانات</button> ' +
				'<button class="button vai-danger" id="vai-delete">حذف</button>' +
				'</div></div>';
			if (c.memo) { h += '<div class="vai-memo"><b>ملف العميل (يكتبه المساعد):</b> ' + esc(c.memo) + '</div>'; }
			if (c.notes) { h += '<div class="vai-memo vai-notes"><b>ملاحظاتك:</b> ' + nl(c.notes) + '</div>'; }
			if (r.leads && r.leads.length) { h += '<div class="vai-leads">' + r.leads.map(function (l) { return '<div class="vai-lead"><b>' + esc(l.type) + '</b> · ' + esc(l.at) + ' · <span dir="ltr">' + esc(l.site || '') + '</span><br>' + esc(l.reason || '') + (l.company ? ' — ' + esc(l.company) : '') + (l.notes ? '<br><small>' + esc(l.notes) + '</small>' : '') + '</div>'; }).join('') + '</div>'; }
			h += '<div class="vai-msgs" id="vai-msgs">' + r.messages.map(function (m) {
				if (m.role === 'system') { return '<div class="vai-m-sys">' + esc(m.content) + ' <small>' + esc(m.at) + '</small></div>'; }
				var acts = (m.actions || []).map(function (a) { if (a.type === 'open_page' || a.type === 'prefill_form') { return '🔗 ' + esc(a.type === 'prefill_form' ? 'تعبئة ' + a.label : 'فتح') + ' <span dir="ltr">' + esc(a.url) + '</span>'; } if (a.type === 'card') { return '🧾 كارت: ' + esc(a.card && a.card.title); } if (a.type === 'video') { return '▶ فيديو: ' + esc(a.title); } if (a.type === 'handoff') { return '📞 تحويل للإدارة'; } if (a.type === 'quick_replies') { return '🔘 ' + esc((a.options || []).join(' | ')); } return ''; }).filter(Boolean);
				return '<div class="vai-m vai-m-' + m.role + '"><div class="vai-m-b">' + (m.image ? '<a href="' + esc(m.image) + '" target="_blank" rel="noopener"><img src="' + esc(m.image) + '" alt="" style="max-width:260px;max-height:220px;border-radius:8px;display:block;margin-bottom:6px"></a>' : '') + (m.audio ? '<audio controls preload="none" src="' + esc(m.audio) + '" style="display:block;max-width:260px;margin-bottom:6px"></audio>' : '') + nl(m.content) + (acts.length ? '<div class="vai-m-acts">' + acts.join('<br>') + '</div>' : '') + '</div><div class="vai-m-t">' + (m.role === 'user' ? 'العميل' : (m.role === 'human' ? (m.by ? 'الفريق — ' + esc(m.by) : 'الفريق') : 'المساعد')) + ' · ' + esc(m.at) + (m.latency != null ? ' · ⏱ ' + m.latency + ' ث' : '') + (m.model ? ' · ' + esc(m.model + (m.route ? '/' + m.route : '')) : '') + (m.guard ? ' · ' + esc(m.guard) : '') + (m.site ? ' · <span dir="ltr">' + esc(m.site) + '</span>' : '') + (m.page && m.role === 'user' ? ' · <a dir="ltr" target="_blank" rel="noopener" href="' + esc(m.page) + '">الصفحة</a>' : '') + (m.focus && m.role === 'user' ? ' · يسأل عن: ' + esc(m.focus) : '') + '</div></div>';
			}).join('') + '</div>';
			h += '<div class="vai-reply"><textarea id="vai-reply-text" rows="2" placeholder="اكتب ردك للعميل — يظهر له في الويدجت فورًا ويوقف البوت له مؤقتًا"></textarea><button class="button button-primary" id="vai-reply-send">إرسال</button></div>';
			box.innerHTML = h;
			box.setAttribute('data-id', String(c.id));
			var msgs = document.getElementById('vai-msgs');
			msgs.scrollTop = msgs.scrollHeight;
			document.getElementById('vai-reply-send').addEventListener('click', function () {
				var t = document.getElementById('vai-reply-text').value.trim();
				if (!t) { return; }
				api('send', { id: c.id, text: t }).then(function () { renderThread(true); loadList(); });
			});
			document.getElementById('vai-reply-text').addEventListener('keydown', function (e) { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { document.getElementById('vai-reply-send').click(); } });
			document.getElementById('vai-bot-toggle').addEventListener('click', function () { api('contact', { id: c.id, bot: c.human ? 'resume' : 'pause' }).then(function () { renderThread(true); loadList(); }); });
			document.getElementById('vai-member-toggle').addEventListener('click', function () { api('contact', { id: c.id, is_member: c.is_member ? 0 : 1 }).then(function () { renderThread(true); loadList(); }); });
			document.getElementById('vai-edit').addEventListener('click', function () {
				var name = prompt('الاسم', c.name || ''); if (name === null) { return; }
				var phone = prompt('الجوال', c.phone || ''); if (phone === null) { return; }
				var email = prompt('الإيميل', c.email || ''); if (email === null) { return; }
				var notes = prompt('ملاحظاتك عن العميل', c.notes || ''); if (notes === null) { return; }
				api('contact', { id: c.id, name: name, phone: phone, email: email, notes: notes }).then(function () { renderThread(true); loadList(); });
			});
			document.getElementById('vai-delete').addEventListener('click', function () { if (confirm('حذف العميل وكل محادثاته نهائيًا؟')) { api('delete', { id: c.id }).then(function () { st.current = 0; box.innerHTML = '<div class="vai-empty-thread">تم الحذف.</div>'; loadList(); }); } });
		}).catch(function () {});
	}

	loadOverview(); loadList();
	if (st.current) { renderThread(true); }
	st.listTimer = setInterval(function () { if (!document.hidden) { loadList(); loadOverview(); } }, 10000);
	st.threadTimer = setInterval(function () { if (!document.hidden && st.current) { renderThread(false); } }, 5000);
})();
